"""Non-invasive discovery of a game's executable, static assets and possible control hints.

This module only reads files beside the configured executable. It never reads a game's
process memory, save files, network traffic or modifies installed game files. Binary string
scanning is heuristic metadata discovery, not a full parser for the game's engine format.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import time
from pathlib import Path
from typing import Any

PROFILE_SCHEMA = 1
DEFAULT_CONTROLS = {
    "left": "left", "right": "right", "up": "up", "down": "down",
    "interact": "z", "confirm": "enter", "cancel": "x", "menu": "c",
    "jump": "space", "attack": "z", "inventory": "i", "use_item": "i",
}
SUPPORTED_KEYS = {
    "left", "right", "up", "down", "z", "x", "c", "shift", "enter", "escape", "ctrl",
    "f7", "f8", "w", "a", "s", "d", "q", "e", "r", "f", "i", "j", "k", "l",
    "space", "tab", "backspace", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0",
}
_HINT_RE = re.compile(
    r"\b(press|hold|move|movement|control|controls|keyboard|arrow|space|enter|confirm|cancel|interact|attack|inventory|items?|save|load|menu|health|game over|continue|start|walk|jump|dodge|pause)\b",
    re.IGNORECASE,
)
_PRINTABLE_ASCII_RE = re.compile(rb"[\x20-\x7e]{4,240}")
_UTF16LE_PRINTABLE_RE = re.compile(rb"(?:[\x20-\x7e]\x00){4,240}")


def _safe_slug(value: str, fallback: str = "game") -> str:
    value = re.sub(r"[^a-zA-Z0-9_-]+", "_", value.strip().lower()).strip("_-")
    return (value or fallback)[:48]


def load_game_profile() -> dict[str, Any]:
    """Load a user-owned JSON profile, then overlay simple environment overrides."""
    configured = os.environ.get("GTC_GAME_PROFILE", "").strip()
    profile: dict[str, Any] = {
        "schema_version": PROFILE_SCHEMA,
        "game_id": "undertale",
        "display_name": "Undertale",
        "window_title_contains": "Undertale",
        "executable_path": "",
        "battle_detection": True,
        "controls": dict(DEFAULT_CONTROLS),
        "primary_goal": "Продвигаться по игре, исследовать доступные области и избегать повторных ошибок",
        "state_feed_json": "",
        "notes": "Built-in default profile. Change controls for a different game.",
    }
    source: str | None = None
    configured_controls: set[str] = set()
    if configured:
        path = Path(configured).expanduser()
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(value, dict):
                profile.update({k: v for k, v in value.items() if k in {
                    "schema_version", "game_id", "display_name", "window_title_contains",
                    "executable_path", "battle_detection", "controls", "primary_goal", "state_feed_json", "notes"
                }})
                if isinstance(value.get("controls"), dict):
                    configured_controls = {str(key).strip().lower() for key in value["controls"]
                                           if str(key).strip().lower() in DEFAULT_CONTROLS}
                source = str(path.resolve())
        except (OSError, json.JSONDecodeError, UnicodeError):
            profile["profile_warning"] = f"Could not load GTC_GAME_PROFILE: {path}"
    env_id = os.environ.get("GTC_GAME_ID", "").strip()
    env_title = os.environ.get("GTC_GAME_WINDOW_TITLE", "").strip()
    env_exe = os.environ.get("GTC_GAME_EXE", "").strip()
    generic = os.environ.get("GTC_GENERIC_GAME", "").strip().lower() in {"1", "true", "yes"}
    # When the launcher explicitly chooses a JSON profile, preserve its identity/title;
    # only use environment overrides for these fields when no valid profile was loaded.
    use_profile_identity = source is not None and os.environ.get("GTC_USE_PROFILE_IDENTITY", "").strip().lower() in {"1", "true", "yes"}
    if env_id and not use_profile_identity:
        profile["game_id"] = _safe_slug(env_id)
        if source is None:
            profile["display_name"] = env_id
            if not env_title:
                profile["window_title_contains"] = env_id
    if env_title and not use_profile_identity:
        profile["window_title_contains"] = env_title
    if env_exe:
        profile["executable_path"] = env_exe
    if generic or str(profile.get("game_id", "undertale")).lower() != "undertale":
        profile["battle_detection"] = bool(profile.get("battle_detection", False)) if source else False
    controls = profile.get("controls")
    normalized = dict(DEFAULT_CONTROLS)
    if isinstance(controls, dict):
        for action in DEFAULT_CONTROLS:
            key = str(controls.get(action, normalized[action])).strip().lower()
            if key in SUPPORTED_KEYS:
                normalized[action] = key
    profile["controls"] = normalized
    if os.environ.get("GTC_GAME_STATE_JSON", "").strip():
        profile["state_feed_json"] = os.environ["GTC_GAME_STATE_JSON"].strip()
    profile["game_id"] = _safe_slug(str(profile.get("game_id", "undertale")), "undertale")
    profile["display_name"] = str(profile.get("display_name") or profile["game_id"])[:100]
    profile["window_title_contains"] = str(profile.get("window_title_contains") or profile["display_name"])[:200]
    profile["source_profile"] = source
    profile["configured_controls"] = sorted(configured_controls)
    profile["auto_detected_controls"] = []
    profile["generic_mode"] = profile["game_id"] != "undertale" or generic
    profile["battle_detection"] = bool(profile.get("battle_detection", False)) and profile["game_id"] == "undertale"
    return profile


def _strings_from_bytes(data: bytes) -> list[str]:
    raw_strings = [m.group().decode("ascii", errors="ignore").strip() for m in _PRINTABLE_ASCII_RE.finditer(data)]
    raw_strings.extend(
        m.group().decode("utf-16le", errors="ignore").strip() for m in _UTF16LE_PRINTABLE_RE.finditer(data)
    )
    return raw_strings


def _relevant_strings(data: bytes, *, limit: int = 18) -> tuple[int, list[str]]:
    found: list[str] = []
    all_strings = _strings_from_bytes(data)
    for value in all_strings:
        value = " ".join(value.split())
        if len(value) >= 4 and _HINT_RE.search(value) and value not in found:
            found.append(value[:180])
            if len(found) >= limit:
                break
    return len(all_strings), found


def _sampled_hash(path: Path) -> str:
    """Fingerprint only file edges and size to avoid a costly full hash for large assets."""
    hasher = hashlib.sha256()
    size = path.stat().st_size
    with path.open("rb") as stream:
        first = stream.read(65536)
        hasher.update(first)
        if size > 65536:
            stream.seek(max(0, size - 65536))
            hasher.update(stream.read(65536))
    hasher.update(str(size).encode("ascii"))
    return hasher.hexdigest()


def _infer_candidate_controls(hints: list[str]) -> list[dict[str, str]]:
    """Extract low-confidence key hints from installed text without changing the profile."""
    result: list[dict[str, str]] = []
    patterns = (
        (re.compile(r"\b(?:press|hold|use)\s+(spacebar|space|enter|escape|esc|ctrl|shift|tab|[a-z0-9])\s+(?:to|for)\s+(jump|interact|attack|confirm|cancel|menu|inventory|dash|dodge)\b", re.I), "key_action"),
        (re.compile(r"\b(wasd|arrow keys|arrow-key controls)\b.{0,40}\b(move|movement|walk|navigate)\b", re.I), "movement_scheme"),
        (re.compile(r"\b(move|movement|walk|navigate)\b.{0,40}\b(wasd|arrow keys|arrow-key controls)\b", re.I), "movement_scheme"),
    )
    seen: set[tuple[str, str]] = set()
    for text in hints:
        for pattern, kind in patterns:
            for match in pattern.finditer(text):
                key, action = ((match.group(1).lower(), match.group(2).lower())
                               if kind == "key_action" else (match.group(1).lower(), "movement"))
                key = {"spacebar": "space", "esc": "escape"}.get(key, key)
                identity = (key, action)
                if identity in seen:
                    continue
                seen.add(identity)
                result.append({"kind": kind, "key_or_scheme": key, "action": action,
                               "source_hint": text[:160], "confidence": "low"})
                if len(result) >= 24:
                    return result
    return result


def inspect_game_install(executable: str | Path, *, max_scan_bytes: int = 128 * 1024 * 1024) -> dict[str, Any]:
    """Collect lightweight file metadata and bounded, likely gameplay/control text hints."""
    exe = Path(executable).expanduser().resolve()
    if not exe.is_file():
        raise FileNotFoundError(f"Game executable not found: {exe}")
    base: dict[str, Any] = {
        "schema_version": PROFILE_SCHEMA,
        "status": "complete",
        "scanned_at_unix": time.time(),
        "executable": {"name": exe.name, "path": str(exe), "size_bytes": exe.stat().st_size,
                       "modified_unix": exe.stat().st_mtime, "sampled_sha256": _sampled_hash(exe)},
        "static_assets": [],
        "control_and_gameplay_hints": [],
        "analysis_method": "file metadata and printable-string heuristics; not a full engine parser",
        "runtime_internals_accessed": False,
        "saves_or_process_memory_read": False,
    }
    # Inspect only known game-resource file types in the executable directory, never save/profile directories.
    interesting_exts = {
        ".win", ".pak", ".dat", ".yy", ".gml", ".json", ".xml", ".cfg", ".txt",
        ".ini", ".yaml", ".yml", ".toml", ".csv", ".lua", ".gd", ".tscn", ".tres",
        ".assets", ".resource", ".resources", ".bundle", ".bytes", ".strings", ".po", ".dll",
    }
    # Include common installed-game resource subfolders while pruning likely user data,
    # saves, logs, caches and profiles. Never follow symbolic links/reparse points.
    excluded_dir_tokens = ("save", "profile", "userdata", "user_data", "progress", "cache",
                           "logs", "crash", "temp", "temporary", "screenshots", "config")
    files: list[Path] = []
    try:
        root = exe.parent.resolve()
        for current, dirnames, filenames in os.walk(root, topdown=True, followlinks=False):
            current_path = Path(current)
            depth = len(current_path.relative_to(root).parts)
            if depth >= 3:
                dirnames[:] = []
            else:
                dirnames[:] = [name for name in dirnames
                               if not any(token in name.lower() for token in excluded_dir_tokens)
                               and not (current_path / name).is_symlink()]
            for filename in filenames:
                child = current_path / filename
                if child.resolve() == exe or child.suffix.lower() not in interesting_exts:
                    continue
                relative_parts = child.relative_to(root).parts
                if any(any(token in part.lower() for token in excluded_dir_tokens) for part in relative_parts):
                    continue
                files.append(child)
                if len(files) >= 96:
                    break
            if len(files) >= 96:
                break
    except OSError as exc:
        base["scan_warning"] = f"Could not enumerate game directory: {type(exc).__name__}"
    files.sort(key=lambda item: (
        0 if item.name.lower() in {"data.win", "game.win"} else
        1 if item.suffix.lower() in {".json", ".cfg", ".ini", ".txt", ".gml", ".gd", ".yy"} else 2,
        len(item.relative_to(exe.parent).parts), str(item.relative_to(exe.parent)).lower()))
    hints: list[str] = []
    scanned_total = 0
    # Sample the executable's beginning and end, never load a huge executable wholesale.
    try:
        exe_size = exe.stat().st_size
        edge_cap = min(8 * 1024 * 1024, max(0, max_scan_bytes // 2))
        with exe.open("rb") as stream:
            head = stream.read(edge_cap)
            tail = b""
            if exe_size > edge_cap and edge_cap:
                stream.seek(max(edge_cap, exe_size - edge_cap))
                tail = stream.read(edge_cap)
        exe_probe = head + tail
        scanned_total += len(exe_probe)
        count, relevant = _relevant_strings(exe_probe, limit=18)
        base["executable"]["strings_scanned"] = bool(exe_probe)
        base["executable"]["candidate_string_count"] = count
        base["executable"]["control_and_gameplay_hints"] = relevant
        hints.extend(relevant)
    except OSError as exc:
        base["executable"]["strings_scan_error"] = type(exc).__name__
    for path in files[:96]:
        try:
            stat = path.stat()
            item: dict[str, Any] = {"name": path.name,
                                    "relative_path": path.relative_to(exe.parent).as_posix(),
                                    "extension": path.suffix.lower(),
                                    "size_bytes": stat.st_size, "modified_unix": stat.st_mtime,
                                    "sampled_sha256": _sampled_hash(path), "strings_scanned": False}
            if stat.st_size <= max_scan_bytes and scanned_total < max_scan_bytes:
                read_cap = min(stat.st_size, max_scan_bytes - scanned_total)
                with path.open("rb") as stream:
                    data = stream.read(read_cap)
                scanned_total += len(data)
                candidate_count, relevant = _relevant_strings(data, limit=18)
                item["strings_scanned"] = True
                item["candidate_string_count"] = candidate_count
                item["relevant_string_count"] = len(relevant)
                item["control_and_gameplay_hints"] = relevant
                for value in relevant:
                    if value not in hints:
                        hints.append(value)
            else:
                item["scan_skip_reason"] = "resource exceeds bounded scan size"
            base["static_assets"].append(item)
        except OSError as exc:
            base["static_assets"].append({"name": path.name, "error": type(exc).__name__})
    base["control_and_gameplay_hints"] = hints[:50]
    base["candidate_controls"] = _infer_candidate_controls(hints)
    base["static_asset_files_found"] = len(files)
    base["static_bytes_scanned"] = scanned_total
    base["static_scan_limits"] = {"max_files": 96, "max_depth": 3, "max_total_bytes": max_scan_bytes}
    base["hint_confidence"] = "low; strings may be unused, localized, or unrelated to active controls"
    base["runtime_note"] = (
        "Live HP, inventory, room IDs, quest flags and internal engine state require a game-specific "
        "official API, mod/plugin, or adapter. This scan does not infer them from process memory."
    )
    return base


def write_profile_report(path: str | Path, report: dict[str, Any]) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    temp = output.with_suffix(output.suffix + ".tmp")
    temp.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(output)


def read_runtime_state_feed(profile: dict[str, Any]) -> dict[str, Any] | None:
    """Read an explicitly configured JSON snapshot written by a game's own adapter/mod.

    The adapter must write current runtime state to a local JSON file. Stale or malformed
    feeds are ignored. This is the supported route for reliable HP/scene/inventory data;
    this module does not inspect another process's memory.
    """
    configured = str(profile.get("state_feed_json") or os.environ.get("GTC_GAME_STATE_JSON", "")).strip()
    if not configured:
        return None
    path = Path(configured).expanduser()
    try:
        stat = path.stat()
        if not path.is_file() or stat.st_size > 1_000_000:
            return {"available": False, "reason": "missing_or_too_large"}
        age_s = max(0.0, time.time() - stat.st_mtime)
        if age_s > 10.0:
            return {"available": False, "reason": "stale", "age_seconds": round(age_s, 2), "path": str(path)}
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return {"available": False, "reason": "invalid_shape", "path": str(path)}
        allowed = {"game_id", "world_id", "scene_id", "mode", "player_position", "health",
                   "max_health", "inventory", "objective", "allowed_actions", "status",
                   "nearby_objects", "interactables", "danger", "progress", "timestamp",
                   "game_over", "victory", "defeated", "objective_completed", "verified"}
        result = {key: data[key] for key in allowed if key in data}
        # Guard against oversized lists/strings before the snapshot is persisted to experience memory.
        for key, value in list(result.items()):
            if isinstance(value, str):
                result[key] = value[:500]
            elif isinstance(value, list):
                result[key] = value[:100]
            elif isinstance(value, dict):
                result[key] = {str(k)[:100]: v for k, v in list(value.items())[:100]}
        result.update({"available": True, "age_seconds": round(age_s, 2), "path": str(path)})
        return result
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        return {"available": False, "reason": type(exc).__name__, "path": str(path)}
