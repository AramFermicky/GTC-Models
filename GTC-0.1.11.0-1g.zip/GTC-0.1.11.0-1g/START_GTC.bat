@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not defined GTC_MODEL_ROOT set "GTC_MODEL_ROOT=%~dp0"
:menu
cls
echo ========================================================
echo GenTC AI 0.1.11.0-1g - Universal Launcher
echo ========================================================
echo 1. Start GTC Core bridge (Winter Shelter / GTC core)
echo 2. Start Undertale agent (whole game)
echo 3. Connect a different game (screen and keyboard)
echo 4. Tools, permanent analysis and learning report
echo 5. Run Python tests
echo 6. Exit
echo.
choice /c 123456 /n /m "Select 1-6: "
if errorlevel 6 exit /b 0
if errorlevel 5 goto run_tests
if errorlevel 4 goto tools
if errorlevel 3 goto generic_game
if errorlevel 2 goto undertale
goto core_bridge
:generic_game
cls
echo Connect a compatible game using its visible window and keyboard.
echo GTC will inspect static files and learn from visual changes.
echo For reliable HP, inventory and scene labels, the game needs its own JSON adapter.
echo.
set "GTC_GAME_ID="
set "GTC_GAME_WINDOW_TITLE="
set "GTC_GAME_PROFILE="
set "GTC_GAME_EXE="
set "GTC_USE_PROFILE_IDENTITY="
set "GTC_GENERIC_GAME=1"
set /p "GTC_GAME_EXE=Full path to game .exe (no surrounding quotes): "
if not defined GTC_GAME_EXE (
  echo No executable entered.
  pause
  set "GTC_GENERIC_GAME="
  goto menu
)
if not exist "%GTC_GAME_EXE%" (
  echo The selected executable does not exist.
  pause
  set "GTC_GENERIC_GAME="
  set "GTC_GAME_EXE="
  goto menu
)
for %%I in ("%GTC_GAME_EXE%") do set "GTC_GAME_ID=%%~nI"
set /p "GTC_GAME_PROFILE=Optional JSON game profile path [blank for basic defaults]: "
if defined GTC_GAME_PROFILE goto generic_profile_selected
set /p "GTC_GAME_ID=Short game id [default %GTC_GAME_ID%]: "
if not defined GTC_GAME_ID for %%I in ("%GTC_GAME_EXE%") do set "GTC_GAME_ID=%%~nI"
set /p "GTC_GAME_WINDOW_TITLE=Text contained in the game window title [default %GTC_GAME_ID%]: "
if not defined GTC_GAME_WINDOW_TITLE set "GTC_GAME_WINDOW_TITLE=%GTC_GAME_ID%"
goto generic_launch
:generic_profile_selected
set "GTC_USE_PROFILE_IDENTITY=1"
:generic_launch
call "%~dp0PLAY_UNDERTALE_GTC.bat"
set "GTC_GENERIC_GAME="
set "GTC_GAME_EXE="
set "GTC_GAME_ID="
set "GTC_GAME_WINDOW_TITLE="
set "GTC_GAME_PROFILE="
set "GTC_USE_PROFILE_IDENTITY="
goto menu
:run_tests
call "%~dp0GTC_TOOLS.bat" --tests
goto menu
:tools
call "%~dp0GTC_TOOLS.bat"
goto menu
:undertale
set "GTC_GENERIC_GAME="
set "GTC_GAME_EXE="
set "GTC_GAME_ID=undertale"
set "GTC_GAME_WINDOW_TITLE=Undertale"
call "%~dp0PLAY_UNDERTALE_GTC.bat"
goto menu
:core_bridge
start "GTC Core Bridge" /D "%~dp0" "%~dp0GTC_CORE_BRIDGE.bat"
echo Core bridge started in a separate window.
timeout /t 2 >nul
goto menu
