@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not defined GTC_MODEL_ROOT set "GTC_MODEL_ROOT=%~dp0"
if /i "%~1"=="--tests" goto tests_only
:menu
cls
echo ========================================================
echo GenTC AI 0.1.11.0-1g - Tools and Learning
echo ========================================================
echo 1. Show bridge and game status
echo 2. Analyze current game screen
echo 3. Show persistent learning report
echo 4. Enable autonomous GTC control (same as F8)
echo 5. Pause agent / learn from manual play (same as F7)
echo 6. Add explicit reward or penalty label
echo 7. Compile modules and run unit tests
echo 8. Show selected Python runtime
echo 9. Return
echo 0. Show static game analysis and control hints
echo.
choice /c 1234567890 /n /m "Select 1-9, 0 for game analysis: "
if errorlevel 10 goto introspection
if errorlevel 9 exit /b 0
if errorlevel 8 goto python_info
if errorlevel 7 goto run_tests
if errorlevel 6 goto feedback_menu
if errorlevel 5 goto pause_agent
if errorlevel 4 goto arm_agent
if errorlevel 3 goto learning_report
if errorlevel 2 goto observe
if errorlevel 1 goto status

:introspection
call :find_python || goto no_python
"%PY_EXE%" -u -m gentc_ai.integration.undertale_client --introspection
pause
goto menu
:status
call :find_python || goto no_python
"%PY_EXE%" -u -m gentc_ai.integration.undertale_client --status
pause
goto menu
:observe
call :find_python || goto no_python
"%PY_EXE%" -u -m gentc_ai.integration.undertale_client --diagnose
pause
goto menu
:learning_report
call :find_python || goto no_python
"%PY_EXE%" -u -m gentc_ai.integration.undertale_client --learning-report
pause
goto menu
:arm_agent
call :find_python || goto no_python
"%PY_EXE%" -u -m gentc_ai.integration.undertale_client --arm-agent
pause
goto menu
:pause_agent
call :find_python || goto no_python
"%PY_EXE%" -u -m gentc_ai.integration.undertale_client --pause-agent
pause
goto menu
:feedback_menu
cls
echo Record feedback only when you know the outcome actually happened.
echo This attaches a strong training label to the last known action.
echo 1. Damage received
echo 2. Death / defeat
echo 3. Missed attack
echo 4. Misused item
echo 5. Repeatedly walked into a wall
echo 6. Successful dodge
echo 7. Game progress / new path
echo 8. Goal completed
echo 9. Return
echo.
choice /c 123456789 /n /m "Select outcome: "
if errorlevel 9 goto menu
if errorlevel 8 (set "FEEDBACK=goal_completed" & goto send_feedback)
if errorlevel 7 (set "FEEDBACK=progress" & goto send_feedback)
if errorlevel 6 (set "FEEDBACK=dodge" & goto send_feedback)
if errorlevel 5 (set "FEEDBACK=blocked" & goto send_feedback)
if errorlevel 4 (set "FEEDBACK=item_misuse" & goto send_feedback)
if errorlevel 3 (set "FEEDBACK=missed_attack" & goto send_feedback)
if errorlevel 2 (set "FEEDBACK=death" & goto send_feedback)
if errorlevel 1 (set "FEEDBACK=damage" & goto send_feedback)
:send_feedback
call :find_python || goto no_python
"%PY_EXE%" -u -m gentc_ai.integration.undertale_client --feedback "%FEEDBACK%"
pause
goto menu
:python_info
call :find_python || goto no_python
"%PY_EXE%" -c "import sys; print(sys.executable); print(sys.version)"
pause
goto menu
:run_tests
call :run_test_suite
pause
goto menu
:tests_only
call :run_test_suite
exit /b %errorlevel%
:run_test_suite
call :find_python
if errorlevel 1 exit /b 2
echo [GTC] Python: %PY_EXE%
"%PY_EXE%" -m compileall -q gentc_ai tests
if errorlevel 1 exit /b 3
"%PY_EXE%" -m unittest discover -s tests -v
exit /b %errorlevel%
:no_python
echo [GTC] Python 3.11 or newer was not found.
pause
goto menu

:find_python
set "PY_EXE="
if defined GTC_PYTHON_EXE if exist "%GTC_PYTHON_EXE%" set "PY_EXE=%GTC_PYTHON_EXE%"
if not defined PY_EXE if exist "%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe" set "PY_EXE=%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe"
if not defined PY_EXE if exist "%LOCALAPPDATA%\Python\bin\python.exe" set "PY_EXE=%LOCALAPPDATA%\Python\bin\python.exe"
if not defined PY_EXE for /f "delims=" %%P in ('py -V:3.14 -c "import sys;print(sys.executable)" 2^>nul') do if not defined PY_EXE set "PY_EXE=%%P"
if not defined PY_EXE for /f "delims=" %%P in ('py -3.14 -c "import sys;print(sys.executable)" 2^>nul') do if not defined PY_EXE set "PY_EXE=%%P"
if not defined PY_EXE for /f "delims=" %%P in ('py -3 -c "import sys;print(sys.executable)" 2^>nul') do if not defined PY_EXE set "PY_EXE=%%P"
if not defined PY_EXE for /f "delims=" %%P in ('where python 2^>nul') do if not defined PY_EXE set "PY_EXE=%%P"
if not defined PY_EXE exit /b 1
"%PY_EXE%" -c "import sys;raise SystemExit(0 if sys.version_info >= (3,11) else 1)" >nul 2>&1
if errorlevel 1 (
  set "PY_EXE="
  exit /b 1
)
exit /b 0
