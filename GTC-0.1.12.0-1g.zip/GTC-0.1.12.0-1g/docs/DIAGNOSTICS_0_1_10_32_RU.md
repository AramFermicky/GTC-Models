# Историческая диагностика взаимодействия с игрой — GTC 0.1.10.32-5r

## Какие границы измеряются

`F8 -> hotkey message -> command queue -> armed=true -> find_game_window -> check_foreground_window -> capture_frame -> analyze_frame -> choose_overworld_action/choose_battle_action -> send_overworld_direction/send_battle_input -> SendInput -> реакция игры`.

В `%LOCALAPPDATA%\GenTC AI\worlds\undertale\runtime_diagnostics.jsonl` записываются старт агента, принятые горячие клавиши, применённые команды режима и traceback циклических ошибок. В JSON-статусе доступны `agent_diagnostics.stage`, `loop_iterations`, `autonomous_decisions`, `loop_errors`, `consecutive_loop_errors`, `last_error_stage`, `last_exception_type`, `last_exception_traceback`, `last_successful_frame_unix`, `last_successful_action_unix`, а также `input_diagnostics`.

Помимо статуса, `bridge_build_comparison.json` показывает, совпадает ли отвечающий сервер с ожидаемой версией этой папки. `windows_desktop_windows.json` фиксирует видимые окна, заголовки, размеры клиентских областей, PID и текущее foreground-окно — без сохранения пикселей. На Windows в `system_commands.json` также собираются пути исполняемых файлов и командные строки процессов Python/Undertale с редактированием стандартных пользовательских путей.

## Как читать отчёт

- `agent_running=false`: контроллер не работает или аварийно завершился. Смотри `last_error`, `agent_fatal_startup_exception` и `hotkey_thread_alive`.
- `hotkey_events_received=0`, `last_hotkey=null`: нажатие F8 не пришло в контроллер. Проверь `hotkey_error`; временно можно включить управление через `GTC_TOOLS.bat` → пункт 4, чтобы обойти горячую клавишу.
- `game_window_found=false`: строка заголовка не совпала, окно скрыто/слишком мало либо игра не запущена.
- `foreground_pause_count` растёт: игра не в фокусе. Агент намеренно не управляет фоновым приложением.
- `stage` застрял на `capture_frame` / `analyze_frame`, а `loop_errors` растёт: ошибка получения или обработки кадра. Используй traceback и `runtime_diagnostics.jsonl`.
- `frames_seen` растёт, но `autonomous_decisions=0`: агент пока не дошёл до выбора действия или постоянно выбрасывает исключения раньше.
- `autonomous_decisions` растёт, а `input_diagnostics.attempted_events=0`: действие не дошло до вызова Win32 ввода; смотри текущую фазу и выбранные действия в SQLite summary.
- `attempted_events` растёт, `sendinput_successes=0`, а `keybd_event_fallbacks` растёт: основной API ввода не принял события; смотри `last_error_code`.
- `sendinput_successes` растёт, но персонаж не двигается: Win32 принял событие, но это не доказывает обработку игрой. Проверь активное окно, уровни прав, раскладку и реальное назначение клавиш. Изолированный тест может отправить короткую LEFT.

## Приватность отчёта

Архив содержит статусы локального моста, короткие хвосты диагностических логов, отобранные поля событий SQLite без копирования базы, сведения о процессах/окнах и вывод unit-тестов. Он не включает изображения экрана, полную базу опыта или сохранения Undertale. Из отчёта исключаются стандартные пользовательские пути без учёта регистра, насколько они доступны через переменные среды; перед отправкой всё равно проверь файлы отчёта.

## Ограничение

Все этапы до отправки ввода могут быть подтверждены программными счётчиками. Только тест на живой Windows может подтвердить, что игра принимает клавишу. Даже `SendInput` с результатом 1 не подтверждает поведение игры.
