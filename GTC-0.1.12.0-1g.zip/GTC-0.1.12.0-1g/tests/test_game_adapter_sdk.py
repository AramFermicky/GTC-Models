from __future__ import annotations
import unittest
from gentc_ai.integration.game_adapter_sdk import (
    build_observation, build_execution_feedback, package_screen_frame, validate_action_manifest,
)


class TestGameAdapterSDK(unittest.TestCase):
    def test_observation_validates_and_keeps_allowlist(self):
        item = build_observation(game_id="demo", world_id="world", frame_id="1", state={"health": 10},
                                 available_actions=[{"id": "move_left", "semantic_action": "navigation"}])
        self.assertEqual(item["available_actions"][0]["id"], "move_left")
        self.assertEqual(item["source"], "explicit_game_adapter")

    def test_duplicate_action_ids_rejected(self):
        with self.assertRaises(ValueError):
            validate_action_manifest([{"id": "x", "semantic_action": "a"}, {"id": "x", "semantic_action": "b"}])

    def test_screen_frame_has_hash_and_base64(self):
        frame = package_screen_frame(b"fake-image", width=10, height=10, image_format="png", frame_id="f1")
        self.assertEqual(len(frame["sha256"]), 64)
        self.assertTrue(frame["data_base64"])

    def test_oversized_frame_rejected(self):
        with self.assertRaises(ValueError):
            package_screen_frame(b"x" * (8 * 1024 * 1024 + 1), width=1, height=1, image_format="png", frame_id="x")

    def test_unconfirmed_execution_not_verified(self):
        result = build_execution_feedback(decision_id="d", command_id="c", status="timed_out",
                                          before_state={}, after_state={}, goal_achieved=None,
                                          constraints_respected=True)
        self.assertFalse(result["verified"])


if __name__ == "__main__":
    unittest.main()
