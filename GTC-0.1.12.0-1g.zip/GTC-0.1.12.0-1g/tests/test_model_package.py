from __future__ import annotations
import json
import tempfile
import unittest
from pathlib import Path
from gentc_ai.model_package import load_model_manifest, resolve_model_weight, ModelPackageError


class TestModelPackage(unittest.TestCase):
    def test_manifest_and_weight_resolve(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "weights").mkdir()
            (root / "weights" / "value.json").write_text("{}", encoding="utf-8")
            (root / "model.json").write_text(json.dumps({
                "schema_version": 1, "id": "test", "name": "Test", "version": "1.0",
                "weight_files": {"character_value_mlp_v1": "weights/value.json"}
            }), encoding="utf-8")
            manifest = load_model_manifest(root)
            self.assertEqual(manifest["id"], "test")
            self.assertEqual(resolve_model_weight(root, manifest, "character_value_mlp_v1"), root / "weights" / "value.json")

    def test_missing_manifest_uses_empty_optional_weight_set(self):
        with tempfile.TemporaryDirectory() as tmp:
            manifest = load_model_manifest(tmp)
            self.assertFalse(manifest["manifest_found"])
            self.assertIsNone(resolve_model_weight(tmp, manifest, "character_value_mlp_v1"))

    def test_path_traversal_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            manifest = {"weight_files": {"character_value_mlp_v1": "../outside.json"}}
            with self.assertRaises(ModelPackageError):
                resolve_model_weight(tmp, manifest, "character_value_mlp_v1")


if __name__ == "__main__":
    unittest.main()
