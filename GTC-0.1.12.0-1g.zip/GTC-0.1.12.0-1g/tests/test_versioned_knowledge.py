from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from gentc_ai.continuity.versioned_knowledge import VersionedKnowledgeStore


class TestVersionedKnowledge(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = VersionedKnowledgeStore(Path(self.temp.name) / "knowledge.sqlite3", current_version="0.1.11.0-1g")

    def tearDown(self):
        self.temp.cleanup()

    def test_unverified_knowledge_is_rejected(self):
        result = self.store.add(identity_id="anna", game_id="game_a", semantic_key="movement",
                                statement="A guess", verified=False, confidence=0.99)
        self.assertFalse(result["stored"])
        self.assertEqual(self.store.report()["records"], 0)

    def test_newer_build_has_priority_but_old_record_is_preserved(self):
        self.store.add(identity_id="anna", game_id="game_a", semantic_key="movement",
                       statement="Old verified knowledge", verified=True, confidence=0.95,
                       source_version="0.1.10.34-3t", record_id="old")
        self.store.add(identity_id="anna", game_id="game_a", semantic_key="movement",
                       statement="New verified knowledge", verified=True, confidence=0.70,
                       source_version="0.1.11.0-1g", record_id="new")
        results = self.store.recall(identity_id="anna", semantic_key="movement", game_id="game_a")
        self.assertEqual(results[0]["record_id"], "new")
        all_records = self.store.recall(identity_id="anna", semantic_key="movement", include_superseded=True)
        self.assertEqual(len(all_records), 2)

    def test_explicit_supersession_is_auditable(self):
        self.store.add(identity_id="anna", game_id="game_a", semantic_key="jump",
                       statement="Old jump rule", verified=True, confidence=0.8,
                       source_version="0.1.10.34", record_id="old")
        self.store.add(identity_id="anna", game_id="game_a", semantic_key="jump",
                       statement="Corrected jump rule", verified=True, confidence=0.9,
                       source_version="0.1.11.0", record_id="new", supersedes_id="old")
        active = self.store.recall(identity_id="anna", semantic_key="jump")
        history = self.store.recall(identity_id="anna", semantic_key="jump", include_superseded=True)
        self.assertEqual([r["record_id"] for r in active], ["new"])
        self.assertEqual(len(history), 2)
        self.assertFalse(next(r for r in history if r["record_id"] == "old")["active"])

    def test_older_build_cannot_supersede_newer_knowledge(self):
        self.store.add(identity_id="anna", game_id="game_a", semantic_key="jump",
                       statement="New jump rule", verified=True, confidence=0.9,
                       source_version="0.1.11.0", record_id="new")
        with self.assertRaises(ValueError):
            self.store.add(identity_id="anna", game_id="game_a", semantic_key="jump",
                           statement="Old jump rule", verified=True, confidence=0.9,
                           source_version="0.1.10.34", record_id="old", supersedes_id="new")

    def test_duplicate_ids_are_idempotent(self):
        args = dict(identity_id="anna", game_id="game_a", semantic_key="rest", statement="Rest restores stamina",
                    verified=True, confidence=0.8, record_id="same")
        self.assertTrue(self.store.add(**args)["stored"])
        self.assertTrue(self.store.add(**args)["duplicate"])
        self.assertEqual(self.store.report()["records"], 1)


if __name__ == "__main__":
    unittest.main()
