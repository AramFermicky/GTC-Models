from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from gentc_ai.learning.neural_value import NeuralValueModel


ACTIONS = ("observe", "bless", "teleport", "plague", "smite", "calm", "rain")


def synthetic_examples(count: int = 30) -> list[dict]:
    examples = []
    for idx in range(count):
        action = ACTIONS[idx % 4]
        candidate = {"action": action, "risk": 0.1, "cost": 0.1,
                     "stakeholder_impact": [{"harm": 0.0, "benefit": 0.4}]}
        world = {"unrest": (idx % 10) / 10, "characters": [
            {"id": "player", "is_player": True, "alive": True, "health": 100, "mood": 0.6, "aggression": 0.1}
        ], "player": {"health": 100}}
        x = NeuralValueModel.features({"world": world, "agent_state": {"personality": {"benevolence": 0.7}}}, candidate)
        examples.append({"features": x, "reward": 0.7 if action == "bless" else -0.2,
                         "action_name": action})
    return examples


class TestNeuralValueModel(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / "model.json"

    def tearDown(self) -> None:
        self.temp.cleanup()

    def test_feature_vector_has_fixed_finite_shape(self) -> None:
        vector = NeuralValueModel.features({"world": {"unrest": float("nan"), "characters": []}},
                                           {"action": "bless"})
        self.assertEqual(len(vector), 22)
        self.assertTrue(all(-1.0 <= value <= 1.0 for value in vector))

    def test_model_waits_until_verified_coverage_is_sufficient(self) -> None:
        model = NeuralValueModel(self.path)
        self.assertEqual(model.hidden_size, 60)
        self.assertFalse(model.is_active)
        self.assertEqual(model.minimum_samples, 120)
        self.assertEqual(model.minimum_actions, 4)
        result = model.fit(synthetic_examples(9), epochs=2)
        self.assertTrue(result["trained"])
        self.assertFalse(model.is_active)
        self.assertEqual(model.training_samples, 9)

    def test_training_activation_and_persistence(self) -> None:
        model = NeuralValueModel(self.path)
        self.assertEqual(model.hidden_size, 60)
        result = model.fit(synthetic_examples(150), epochs=4)
        self.assertTrue(result["trained"])
        self.assertTrue(model.is_active)
        context = {"world": {"unrest": 0.3, "characters": []}}
        pred = model.predict(context, {"action": "bless"})
        self.assertTrue(pred["active"])
        self.assertTrue(-1.0 <= pred["value"] <= 1.0)
        reloaded = NeuralValueModel(self.path)
        self.assertTrue(reloaded.is_active)
        self.assertEqual(reloaded.training_samples, 150)
        self.assertEqual(reloaded.trained_action_names, ["bless", "observe", "plague", "teleport"])

    def test_bad_model_file_falls_back_without_crashing(self) -> None:
        self.path.write_text("{broken", encoding="utf-8")
        model = NeuralValueModel(self.path)
        self.assertFalse(model.is_active)
        self.assertIn("unreadable", model.load_warning or "")


if __name__ == "__main__":
    unittest.main()
