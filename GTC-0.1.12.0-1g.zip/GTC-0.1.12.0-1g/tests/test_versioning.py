from __future__ import annotations

import json
import unittest
from pathlib import Path

from gentc_ai import __version__
from gentc_ai.version import VERSION, BASE_VERSION, CHANGESET_NUMBER, CHANGESET_KIND, BUILD_ID
from gentc_ai.integration.http_server import GTCRequestHandler
from gentc_ai.integration.undertale_agent import ADAPTER_VERSION
from gentc_ai.integration.girl_server import Handler as GirlBridgeHandler, RUNTIME_VERSION
from tools.build_release import should_include

PROJECT_ROOT = Path(__file__).resolve().parents[1]


class ReleaseVersioningTests(unittest.TestCase):
    def test_package_version_and_release_manifest_match(self):
        release = json.loads((PROJECT_ROOT / "GTC_RELEASE.json").read_text(encoding="utf-8"))
        self.assertEqual(__version__, VERSION)
        self.assertEqual(release["version"], VERSION)
        self.assertEqual(release["build_id"], BUILD_ID)
        self.assertEqual(release["base_version"], BASE_VERSION)
        self.assertEqual(release["change_count"], CHANGESET_NUMBER)
        self.assertEqual(release["change_kind"], CHANGESET_KIND)

    def test_all_bridges_share_the_canonical_build_id(self):
        self.assertEqual(GTCRequestHandler.server_version, f"GenTC-AI-Multi-Bridge/{BUILD_ID}")
        self.assertEqual(GirlBridgeHandler.server_version, f"GenTC-Girl-Bridge/{BUILD_ID}")
        self.assertEqual(ADAPTER_VERSION, f"{BUILD_ID}-permanent-game-analysis")
        self.assertEqual(RUNTIME_VERSION, f"GTC-{BUILD_ID}")

    def test_change_suffix_is_valid_and_counts_change_groups(self):
        self.assertGreaterEqual(CHANGESET_NUMBER, 1)
        self.assertIn(CHANGESET_KIND, {"a", "b", "g", "r", "t"})
        self.assertEqual(BUILD_ID, f"{VERSION}-{CHANGESET_NUMBER}{CHANGESET_KIND}")

    def test_release_builder_excludes_engine_demos_and_runtime_output(self):
        self.assertFalse(should_include(PROJECT_ROOT / "godot_playground" / "project.godot"))
        self.assertFalse(should_include(PROJECT_ROOT / "god_sandbox" / "project.godot"))
        self.assertFalse(should_include(PROJECT_ROOT / "data" / "logs" / "events.jsonl"))
        self.assertTrue(should_include(PROJECT_ROOT / "protocol" / "GTC_GAME_ADAPTER_CONTRACT_V0_1.json"))
        self.assertTrue(should_include(PROJECT_ROOT / "data" / "logs" / "README_RU.txt"))
        self.assertFalse(should_include(PROJECT_ROOT / "GTC_DIAGNOSTICS_OUTPUT" / "session" / "status.json"))
        self.assertFalse(should_include(PROJECT_ROOT / "ERRORS_LOG_TESTING_REPORT_20300101_000000.zip"))


if __name__ == "__main__":
    unittest.main()
