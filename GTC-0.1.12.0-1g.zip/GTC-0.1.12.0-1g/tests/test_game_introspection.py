from __future__ import annotations

import json
import os
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

from gentc_ai.integration.game_introspection import (
    inspect_game_install, load_game_profile, read_runtime_state_feed,
)
from gentc_ai.integration.undertale_agent import (
    Frame, Observation, UndertalePilot, UndertaleRuntime, _external_outcome,
    analyze_profiled_frame,
)
from gentc_ai.integration.undertale_learning import UndertaleLearningMemory


def solid_frame(color=(20, 30, 40), width=160, height=120):
    r, g, b = color
    pixel = bytes((b, g, r, 255))
    return Frame(width, height, pixel * width * height, width, height)


class GameIntrospectionTests(unittest.TestCase):
    def test_static_scan_extracts_control_hints_without_reading_save_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            exe = root / "UNDERTALE.exe"
            exe.write_bytes(b"mock executable")
            (root / "data.win").write_bytes(
                b"noise\x00Press Z to interact\x00Arrow keys move the human\x00"
            )
            (root / "save.txt").write_text("Press Z to delete everything", encoding="utf-8")
            report = inspect_game_install(exe)
            self.assertEqual(report["executable"]["name"], "UNDERTALE.exe")
            self.assertEqual(report["static_asset_files_found"], 1)
            self.assertTrue(any("Press Z" in hint for hint in report["control_and_gameplay_hints"]))
            self.assertFalse(report["saves_or_process_memory_read"])
            self.assertNotIn("save.txt", [item["name"] for item in report["static_assets"]])

    def test_static_scan_checks_bounded_install_subfolders_but_skips_user_data(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            exe = root / "Platformer.exe"
            exe.write_bytes(b"mock executable")
            assets = root / "Platformer_Data" / "StreamingAssets"
            assets.mkdir(parents=True)
            (assets / "controls.txt").write_text("Press E to interact. Press Space to jump.", encoding="utf-8")
            save_dir = root / "Saves"
            save_dir.mkdir()
            (save_dir / "save.json").write_text("Press Q to erase progress", encoding="utf-8")
            report = inspect_game_install(exe)
            self.assertTrue(any("StreamingAssets/controls.txt" in item.get("relative_path", "")
                                for item in report["static_assets"]))
            self.assertFalse(any("Saves" in item.get("relative_path", "")
                                 for item in report["static_assets"]))
            candidates = report.get("candidate_controls", [])
            self.assertTrue(any(item.get("key_or_scheme") == "e" and item.get("action") == "interact"
                                for item in candidates))
            self.assertTrue(any(item.get("key_or_scheme") == "space" and item.get("action") == "jump"
                                for item in candidates))

    def test_static_scan_extracts_source_symbols_and_gameplay_api_references(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            exe = root / "SampleGame.exe"
            exe.write_bytes(b"mock executable")
            (root / "PlayerController.gd").write_text(
                "class_name PlayerController\nfunc move_player(delta):\n    Input.is_action_pressed('move_right')\n    health -= damage\n    get_tree().change_scene_to_file('res://level.tscn')\n",
                encoding="utf-8")
            report = inspect_game_install(exe)
            self.assertEqual(report["source_code_summary"]["files_read"], 1)
            self.assertIn("PlayerController", report["source_code_summary"]["classes"])
            self.assertIn("move_player", report["source_code_summary"]["functions"])
            self.assertGreater(report["source_code_summary"]["input_api_references"], 0)
            self.assertGreater(report["source_code_summary"]["scene_transition_references"], 0)
            self.assertFalse(report["source_code_executed"])

    def test_game_profile_loads_generic_title_and_custom_controls(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "profile.json"
            path.write_text(json.dumps({
                "game_id": "platformer", "display_name": "Platformer",
                "window_title_contains": "Platformer Window", "battle_detection": False,
                "controls": {"left": "a", "right": "d", "up": "w", "down": "s",
                             "interact": "e", "confirm": "enter", "cancel": "escape", "menu": "tab"},
            }), encoding="utf-8")
            with patch.dict(os.environ, {"GTC_GAME_PROFILE": str(path), "GTC_GAME_ID": "launcher_default",
                                         "GTC_GAME_WINDOW_TITLE": "Launcher Window", "GTC_USE_PROFILE_IDENTITY": "1"}, clear=True):
                profile = load_game_profile()
            self.assertEqual(profile["game_id"], "platformer")
            self.assertEqual(profile["window_title_contains"], "Platformer Window")
            self.assertFalse(profile["battle_detection"])
            self.assertEqual(profile["controls"]["left"], "a")
            self.assertTrue(profile["generic_mode"])

    def test_generic_env_identity_sets_default_window_title(self):
        with patch.dict(os.environ, {"GTC_GENERIC_GAME": "1", "GTC_GAME_ID": "platformer", "GTC_GAME_EXE": "C:/Games/Platformer.exe"}, clear=True):
            profile = load_game_profile()
        self.assertEqual(profile["game_id"], "platformer")
        self.assertEqual(profile["display_name"], "platformer")
        self.assertEqual(profile["window_title_contains"], "platformer")
        self.assertTrue(profile["generic_mode"])

    def test_static_control_hints_are_applied_and_persisted_for_generic_games(self):
        with tempfile.TemporaryDirectory() as tmp, patch(
            "gentc_ai.integration.undertale_agent._local_data_dir", return_value=Path(tmp)
        ):
            runtime = UndertaleRuntime()
            runtime.game_profile.update({"game_id": "platformer", "display_name": "Platformer",
                                         "generic_mode": True, "source_profile": None,
                                         "profile_warning": None, "configured_controls": [],
                                         "auto_detected_controls": [], "controls": {
                                             "left": "left", "right": "right", "up": "up", "down": "down",
                                             "interact": "z", "confirm": "enter", "cancel": "x", "menu": "c",
                                             "jump": "space", "attack": "z", "inventory": "i", "use_item": "i"}})
            report = {"executable": {"sampled_sha256": "test-hash"}, "candidate_controls": [
                {"kind": "movement_scheme", "key_or_scheme": "wasd", "action": "movement", "source_hint": "WASD to move", "confidence": "low"},
                {"kind": "key_action", "key_or_scheme": "e", "action": "interact", "source_hint": "Press E to interact", "confidence": "low"},
                {"kind": "key_action", "key_or_scheme": "space", "action": "jump", "source_hint": "Press Space to jump", "confidence": "low"}]}
            runtime._apply_static_control_hints(report)
            self.assertEqual(runtime.game_profile["controls"]["left"], "a")
            self.assertEqual(runtime.game_profile["controls"]["interact"], "e")
            self.assertEqual(runtime.game_profile["controls"]["jump"], "space")
            saved = json.loads((Path(tmp) / "game_controls_learned.json").read_text(encoding="utf-8"))
            self.assertEqual(saved["controls"]["right"], "d")
            self.assertEqual(report["control_hint_application"], "applied_low_confidence_hints_and_saved_for_future_sessions")
            runtime.agent = None

    def test_state_feed_rejects_stale_or_invalid_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "state.json"
            path.write_text(json.dumps({"verified": True, "health": 7, "status": "playing"}), encoding="utf-8")
            result = read_runtime_state_feed({"state_feed_json": str(path)})
            self.assertTrue(result["available"])
            self.assertEqual(result["health"], 7)
            os.utime(path, (time.time() - 30, time.time() - 30))
            stale = read_runtime_state_feed({"state_feed_json": str(path)})
            self.assertFalse(stale["available"])
            self.assertEqual(stale["reason"], "stale")

    def test_external_outcome_requires_verified_state_feed(self):
        before = {"available": True, "verified": False, "health": 10, "status": "playing"}
        after = {"available": True, "verified": True, "health": 2, "status": "playing"}
        self.assertIsNone(_external_outcome(before, after))
        before["verified"] = True
        self.assertEqual(_external_outcome(before, after), "damage")
        after["status"] = "game_over"
        self.assertEqual(_external_outcome(before, after), "death")

    def test_profiled_generic_frame_disables_undertale_battle_heuristics(self):
        from gentc_ai.integration import undertale_agent
        frame = solid_frame()
        prior = undertale_agent.GAME_PROFILE
        try:
            undertale_agent.GAME_PROFILE = {"battle_detection": False}
            obs = analyze_profiled_frame(frame)
            self.assertFalse(obs.battle_visible)
            self.assertIsNone(obs.soul)
        finally:
            undertale_agent.GAME_PROFILE = prior

    def test_permanent_observer_persists_compact_observations_while_paused(self):
        with tempfile.TemporaryDirectory() as tmp, patch(
            "gentc_ai.integration.undertale_agent._local_data_dir", return_value=Path(tmp)
        ):
            pilot = UndertalePilot(UndertaleRuntime())
            try:
                frame = solid_frame()
                obs = Observation(frame.width, frame.height, False, None, None, 0, 0.0,
                                  "2026-10-22T00:00:00+00:00")
                pilot._permanent_observe(frame, obs, time.monotonic(), source="manual_passive_observation")
                self.assertEqual(pilot.passive_frames_seen, 1)
                stats = pilot.memory.stats()
                self.assertGreaterEqual(stats["visual_observation_records"], 1)
                self.assertEqual(stats["latest_visual_observation"]["source"], "manual_passive_observation")
                # An unchanged frame is still analyzed but is not written as an identical event every tick.
                pilot._permanent_observe(frame, obs, time.monotonic() + 0.1, source="manual_passive_observation")
                self.assertEqual(pilot.memory.stats()["visual_observation_records"], 1)
            finally:
                pilot.memory.close()

    def test_control_map_accepts_profile_direction_keys(self):
        with tempfile.TemporaryDirectory() as tmp, patch(
            "gentc_ai.integration.undertale_agent._local_data_dir", return_value=Path(tmp)
        ):
            runtime = UndertaleRuntime()
            runtime.game_profile = {**runtime.game_profile, "controls": {
                "left": "a", "right": "d", "up": "w", "down": "s",
                "interact": "e", "confirm": "enter", "cancel": "escape", "menu": "tab"}}
            pilot = UndertalePilot(runtime)
            try:
                self.assertEqual(pilot._action_keys("left", "overworld"), {"a"})
                self.assertEqual(pilot._action_keys("interact", "overworld"), {"e"})
                runtime.game_profile["generic_mode"] = True
                runtime.game_profile["configured_controls"] = ["jump"]
                self.assertEqual(pilot._action_keys("jump", "overworld"), {"space"})
                self.assertIn("jump", pilot._available_overworld_actions())
                self.assertIn("confirm", pilot._available_overworld_actions())
                self.assertEqual(pilot._human_action_names({"a"}, "overworld", "red"), ["left"])
            finally:
                pilot.memory.close()


if __name__ == "__main__":
    unittest.main()
