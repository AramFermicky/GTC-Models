import os
import unittest
from unittest.mock import patch

from scripts.gtc_diagnostics import redact_text, scrub


class DiagnosticPrivacyTests(unittest.TestCase):
    def test_redacts_user_profile_from_longer_appdata_path(self):
        with patch.dict(os.environ, {"USERPROFILE": r"C:\Users\Tester",
                                     "LOCALAPPDATA": r"C:\Users\Tester\AppData\Local"}, clear=False):
            result = redact_text(r"C:\Users\Tester\AppData\Local\GenTC AI\worlds\undertale")
        self.assertNotIn("Tester", result)
        self.assertIn("%LOCALAPPDATA%", result)

    def test_redaction_is_case_insensitive_for_windows_paths(self):
        with patch.dict(os.environ, {"USERPROFILE": r"C:\Users\Tester",
                                     "LOCALAPPDATA": r"C:\Users\Tester\AppData\Local"}, clear=False):
            result = redact_text(r"c:\users\TESTER\appdata\local\GenTC AI\worlds\undertale")
        self.assertNotIn("Tester", result)
        self.assertIn("%LOCALAPPDATA%", result)

    def test_scrub_walks_nested_json_values(self):
        result = scrub({"nested": [{"path": str(os.environ.get("USERPROFILE", "") or "REDACT")}]})
        self.assertIsInstance(result["nested"], list)
        self.assertIsInstance(result["nested"][0]["path"], str)


if __name__ == "__main__":
    unittest.main()
