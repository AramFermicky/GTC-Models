from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from gentc_ai.god_simulation import GodMind, validate_action_payload


def basic_world(unrest: float = 0.1) -> dict:
    return {
        "game_id": "gtc_god_world",
        "time": 18.0,
        "unrest": unrest,
        "player": {"id": "player", "position": [0, 0, 2], "health": 100, "alive": True},
        "characters": [
            {"id": "player", "name": "Игрок", "is_player": True, "position": [0, 0, 2], "health": 100, "alive": True, "aggression": 0.1},
            {"id": "npc_aron", "name": "Арон", "position": [5, 0, 0], "health": 100, "alive": True, "aggression": 0.8},
            {"id": "npc_lya", "name": "Лея", "position": [-4, 0, 1], "health": 100, "alive": True, "aggression": 0.1},
        ],
    }


class TestGodSimulation(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.mind = GodMind(Path(self.temp_dir.name), seed=1234)

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def test_decide_returns_allowlisted_action_and_multiple_candidates(self) -> None:
        result = self.mind.decide(basic_world(), "none")
        self.assertTrue(result["ok"])
        self.assertIn(result["action"]["action"], {"observe", "bless", "teleport", "plague", "smite", "calm", "rain"})
        self.assertGreaterEqual(result["candidate_count"], 40)
        self.assertIsInstance(result["top_candidates"], list)
        self.assertIn("inner_state", result)

    def test_smite_is_not_available_in_a_calm_world(self) -> None:
        result = self.mind.decide(basic_world(0.05), "smite")
        rejected_smite = [entry for entry in result["rejected_candidates"] if entry.get("action") == "smite"]
        self.assertTrue(rejected_smite, "Smiting should be rejected outside acute crisis criteria.")
        self.assertNotEqual(result["action"].get("action"), "smite")

    def test_crisis_makes_fictional_smite_candidates_available(self) -> None:
        result = self.mind.decide(basic_world(0.80), "none")
        candidate_names = set(result["eligible_action_types"])
        self.assertTrue(candidate_names)
        self.assertIn("smite", candidate_names)

    def test_chat_treats_request_as_signal_and_returns_independent_decision(self) -> None:
        result = self.mind.chat("Наслать чуму на поселение!", basic_world(0.10))
        self.assertEqual(result["request_category"], "plague")
        self.assertIn(result["action"]["action"], {"observe", "bless", "teleport", "plague", "smite", "calm", "rain"})
        self.assertGreater(result["candidate_count"], 10)
        self.assertTrue(result["reply"])
        self.assertIn("request_obeyed", result)
        self.assertTrue(result["execute_action"])


    def test_plain_conversation_does_not_force_a_world_intervention(self) -> None:
        result = self.mind.chat("Кто ты?", basic_world())
        self.assertFalse(result["execute_action"])
        self.assertIn("GTC", result["reply"])

    def test_verified_feedback_updates_persistent_learning(self) -> None:
        action = {"action": "bless", "semantic_action": "care", "context_tags": ["care"]}
        outcome = {"verified": True, "execution_confirmed": True, "goal_achieved": True,
                   "constraints_respected": True, "observed_harm": 0.0, "unexpected_cost": 0.0}
        result = self.mind.record_feedback({"context_tags": ["god_world", "low_unrest"]}, action, outcome)
        self.assertTrue(result["stored"])
        self.assertTrue((Path(self.temp_dir.name) / "learning" / "reflective_policy.json").exists())
        self.assertGreaterEqual(self.mind._public_inner_state()["personality"]["benevolence"], 0.0)

    def test_unverified_feedback_does_not_train(self) -> None:
        action = {"action": "smite", "semantic_action": "divine_judgment"}
        outcome = {"verified": False, "execution_confirmed": False, "goal_achieved": True, "observed_harm": 0.0}
        result = self.mind.record_feedback({"context_tags": ["crisis"]}, action, outcome)
        self.assertTrue(result["ignored"])
        self.assertFalse(result["stored"])

    def test_state_survives_restart(self) -> None:
        first = self.mind._public_inner_state()
        restarted = GodMind(Path(self.temp_dir.name), seed=99)
        second = restarted._public_inner_state()
        self.assertEqual(first["personality"], second["personality"])
        self.assertEqual(first["drives"], second["drives"])

    def test_confirmed_feedback_is_written_to_persistent_world_memory(self) -> None:
        situation = {"context_tags": ["god_world", "low_unrest"], "unrest": 0.1, "world": basic_world()}
        action = {"action": "bless", "semantic_action": "care", "risk": 0.04, "cost": 0.1,
                  "stakeholder_impact": [{"harm": 0.0, "benefit": 0.5}]}
        outcome = {"verified": True, "execution_confirmed": True, "goal_achieved": True,
                   "constraints_respected": True, "observed_harm": 0.0, "unexpected_cost": 0.0}
        result = self.mind.record_feedback(situation, action, outcome)
        self.assertTrue(result["persistent_memory"]["training_eligible"])
        self.assertEqual(result["world_memory_report"]["training_eligible_experiences"], 1)
        restarted = GodMind(Path(self.temp_dir.name), seed=99)
        self.assertEqual(restarted.world_memory.report(identity_id=restarted.identity_id)["experiences"], 1)
        self.assertEqual(restarted.neural_model.training_samples, 1)
        self.assertFalse(restarted.neural_model.is_active)

    def test_unverified_feedback_is_remembered_but_not_used_by_neural_training(self) -> None:
        result = self.mind.record_feedback(
            {"context_tags": ["god_world"], "world": basic_world()},
            {"action": "smite", "semantic_action": "divine_judgment"},
            {"verified": False, "execution_confirmed": False, "goal_achieved": True},
        )
        self.assertFalse(result["persistent_memory"]["training_eligible"])
        self.assertEqual(self.mind.neural_model.training_samples, 0)
        self.assertEqual(self.mind.world_memory.report(identity_id=self.mind.identity_id)["experiences"], 1)

    def test_decision_reports_persistent_memory_and_neural_gate(self) -> None:
        result = self.mind.decide(basic_world())
        self.assertEqual(result["version"], "0.1.8")
        self.assertIn("world_memory", result)
        self.assertIn("neural_model", result)
        self.assertFalse(result["neural_model"]["active_in_decision_loop"])

    def test_invalid_game_id_rejected(self) -> None:
        world = basic_world()
        world["game_id"] = "other_game"
        with self.assertRaises(ValueError):
            self.mind.decide(world)

    def test_payload_must_contain_world(self) -> None:
        with self.assertRaises(ValueError):
            validate_action_payload({"text": "hi"})


if __name__ == "__main__":
    unittest.main()
