from __future__ import annotations
import unittest
from gentc_ai.integration import girl_server as gs
from gentc_ai.experience.decision_tracker import DecisionTracker


def sample_world():
    return {
        "schema_version": 1,
        "game_id": "winter_shelter",
        "world_id": "winter_forest_girl_lab",
        "position": {"x": 0.5, "y": 0.0, "z": -2.0},
        "player_distance": 3.0,
        "coldness": 0.3,
        "needs": {"food": 0.45, "rest": 0.2, "social": 0.65, "safety": 0.1, "curiosity": 0.7},
        "goal_priorities": {"stay_safe": 0.5, "learn_world": 0.7, "maintain_relationships": 0.6, "preserve_resources": 0.4},
        "wander_target_id": "path_a",
        "objects": [
            {"id": "player", "type": "player", "x": -2.0, "z": 2.0, "available": True},
            {"id": "shelter", "type": "shelter", "x": 5.2, "z": 1.8, "available": True},
            {"id": "berry_patch", "type": "food", "x": -4.7, "z": -1.8, "available": True},
            {"id": "path_a", "type": "waypoint", "x": -5.0, "z": -5.8, "available": True},
            {"id": "tree_a", "type": "tree", "x": -7.0, "z": -7.0, "available": True},
        ],
    }


class GirlServerTests(unittest.TestCase):
    def setUp(self):
        gs.DECISION_TRACKER = DecisionTracker(timeout_seconds=15.0)

    def test_versioned_knowledge_prior_is_bounded_and_uses_verified_outcomes(self):
        class FakeKnowledge:
            def recall(self, **_kwargs):
                return [
                    {"payload": {"outcome": {"goal_achieved": True}}, "confidence": 0.9,
                     "source_version": gs.RUNTIME_VERSION},
                    {"payload": {"outcome": {"goal_achieved": False}}, "confidence": 0.4,
                     "source_version": "0.1.10.34-3t"},
                ]
        original = gs.KNOWLEDGE
        try:
            gs.KNOWLEDGE = FakeKnowledge()
            value = gs._versioned_knowledge_adjustment("exploration")
            self.assertGreater(value, 0.0)
            self.assertLessEqual(abs(value), 0.05)
        finally:
            gs.KNOWLEDGE = original

    def test_think_returns_allowlisted_action(self):
        result = gs.process_request("/girl/think", {"world": sample_world()})
        self.assertTrue(result["ok"])
        self.assertIn(result["action"]["action"], gs.ALLOWED_ACTIONS)
        self.assertTrue(result["must_confirm_execution_with_godot"])
        self.assertTrue(result["decision_id"])
        self.assertEqual(result["action"]["command_id"], result["decision_id"])
        self.assertTrue(result["should_execute"])
        self.assertEqual(result["decision_status"], "proposed")

    def test_repeated_think_poll_reuses_decision_without_reissuing_command(self):
        world = sample_world()
        first = gs.process_request("/girl/think", {"world": world})
        second = gs.process_request("/girl/think", {"world": world})
        self.assertEqual(first["decision_id"], second["decision_id"])
        self.assertEqual(first["action"]["action"], second["action"]["action"])
        self.assertFalse(second["should_execute"])
        self.assertTrue(second["duplicate_proposal"])
        self.assertEqual(second["decision_status"], "awaiting_feedback")

    def test_chat_does_not_turn_request_into_unrestricted_command(self):
        result = gs.process_request("/girl/chat", {"world": sample_world(), "text": "Подойди ко мне, пожалуйста."})
        self.assertTrue(result["ok"])
        self.assertIn(result["action"]["action"], gs.ALLOWED_ACTIONS)
        self.assertIsInstance(result["reply"], str)
        self.assertTrue(result["reply"])

    def test_snapshot_world_id_is_preserved_for_world_specific_memory(self):
        world = sample_world()
        world["world_id"] = "winter_forest_main"
        world["world_name"] = "Winter Shelter main world"
        result = gs.process_request("/girl/think", {"world": world})
        self.assertEqual(result["world_id"], "winter_forest_main")
        self.assertEqual(gs._resolved_world_id({"world_id": "main world / 01"}), "main_world_01")

    def test_wrong_game_is_rejected(self):
        world = sample_world()
        world["game_id"] = "unknown_game"
        with self.assertRaises(ValueError):
            gs.process_request("/girl/think", {"world": world})

    def test_unknown_endpoint_is_rejected(self):
        with self.assertRaises(ValueError):
            gs.process_request("/anything", {"world": sample_world()})

    def test_unverified_feedback_does_not_enter_learning(self):
        result = gs.process_request("/girl/think", {"world": sample_world()})
        action = result["action"]
        before = int(gs.STATE.get("confirmed_actions", 0))
        response = gs.process_request("/girl/feedback", {
            "world": sample_world(), "world_before": sample_world(), "agent_state": result["inner_state"],
            "situation": {"context_tags": ["test"], "world": sample_world()}, "action": action,
            "outcome": {"verified": False, "execution_confirmed": False, "constraints_respected": True,
                        "goal_achieved": False, "failure_reason": "not_verified"},
        })
        self.assertFalse(response["learning"].get("stored", False))
        self.assertEqual(int(gs.STATE.get("confirmed_actions", 0)), before)
        self.assertEqual(gs.DECISION_TRACKER.snapshot()["pending"], 0)

    def test_unmatched_feedback_cannot_train_or_clear_pending_decision(self):
        world = sample_world()
        result = gs.process_request("/girl/think", {"world": world})
        before_actions = int(gs.STATE.get("confirmed_actions", 0))
        before_examples = gs.MEMORY.count_training_examples(identity_id=gs.IDENTITY_ID, game_id=gs.GAME_ID)
        response = gs.process_request("/girl/feedback", {
            "world": world, "world_before": world, "agent_state": result["inner_state"],
            "decision_id": "not-the-proposed-command", "experience_id": "forged-feedback-id",
            "situation": {"context_tags": ["test"], "world": world}, "action": result["action"],
            "outcome": {"verified": True, "execution_confirmed": True, "constraints_respected": True,
                        "goal_achieved": True, "observed_harm": 0.0, "unexpected_cost": 0.0},
        })
        self.assertFalse(response["learning"].get("stored", False))
        self.assertEqual(response["memory"].get("training_eligible"), False)
        self.assertEqual(int(gs.STATE.get("confirmed_actions", 0)), before_actions)
        self.assertEqual(gs.MEMORY.count_training_examples(identity_id=gs.IDENTITY_ID, game_id=gs.GAME_ID), before_examples)
        self.assertEqual(gs.DECISION_TRACKER.snapshot()["pending"], 1)

    def test_duplicate_decision_feedback_cannot_double_train(self):
        world = sample_world()
        result = gs.process_request("/girl/think", {"world": world})
        payload = {
            "world": world, "world_before": world, "agent_state": result["inner_state"],
            "decision_id": result["decision_id"], "experience_id": "first-client-experience-id",
            "situation": {"context_tags": ["test"], "world": world}, "action": result["action"],
            "outcome": {"verified": True, "execution_confirmed": True, "constraints_respected": True,
                        "goal_achieved": True, "observed_harm": 0.0, "unexpected_cost": 0.0},
        }
        first = gs.process_request("/girl/feedback", payload)
        after_first = int(gs.STATE.get("confirmed_actions", 0))
        examples_after_first = gs.MEMORY.count_training_examples(identity_id=gs.IDENTITY_ID, game_id=gs.GAME_ID)
        payload["experience_id"] = "different-client-retry-id"
        second = gs.process_request("/girl/feedback", payload)
        self.assertTrue(first["learning"].get("stored", False))
        self.assertTrue(second.get("duplicate", False))
        self.assertEqual(int(gs.STATE.get("confirmed_actions", 0)), after_first)
        self.assertEqual(gs.MEMORY.count_training_examples(identity_id=gs.IDENTITY_ID, game_id=gs.GAME_ID), examples_after_first)

    def test_nan_input_is_safely_clamped(self):
        world = sample_world()
        world["player_distance"] = float("nan")
        result = gs.process_request("/girl/think", {"world": world})
        self.assertTrue(result["ok"])
        self.assertIn(result["action"]["action"], gs.ALLOWED_ACTIONS)

    def test_character_network_is_expanded_and_waits_for_sufficient_data(self):
        self.assertEqual(gs.NETWORK.hidden_size, 96)
        self.assertEqual(gs.NETWORK.minimum_samples, 240)
        self.assertEqual(gs.NETWORK.minimum_actions, 5)
        self.assertEqual(gs.NETWORK.input_size * gs.NETWORK.hidden_size + 2 * gs.NETWORK.hidden_size + 1, 2305)
        self.assertEqual(gs.NETWORK.input_size, 13 + len(gs.ALLOWED_ACTIONS))


    def test_60_neuron_model_migrates_without_discarding_learned_weights(self):
        import json
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "legacy_model.json"
            legacy = {
                "schema_version": 2, "input_size": gs.NETWORK.input_size, "hidden_size": 60,
                "w1": [[0.125 for _ in range(gs.NETWORK.input_size)] for _ in range(60)],
                "b1": [0.05 for _ in range(60)], "w2": [0.02 for _ in range(60)],
                "b2": 0.03, "samples": 137, "covered_actions": sorted(list(gs.ALLOWED_ACTIONS))[:5], "updates": 7,
            }
            path.write_text(json.dumps(legacy), encoding="utf-8")
            migrated = gs.CharacterValueNetwork(path)
            self.assertEqual(migrated.hidden_size, 96)
            self.assertEqual(migrated.w1[0][0], 0.125)
            self.assertEqual(migrated.b1[0], 0.05)
            self.assertEqual(migrated.w2[59], 0.02)
            self.assertEqual(migrated.w2[60:], [0.0] * 36)
            self.assertEqual(migrated.samples, 137)
            saved = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(saved["schema_version"], 3)
            self.assertEqual(saved["hidden_size"], 96)

    def test_self_model_exposes_limits_and_identity(self):
        result = gs.process_request("/girl/think", {"world": sample_world()})
        self.assertEqual(result["inner_state"]["self_model"]["identity_id"], "anna.canon")
        self.assertTrue(result["inner_state"]["self_model"]["not_a_consciousness_claim"])
        self.assertTrue(result["inner_state"]["self_model"]["known_limits"])

    def test_shaped_reward_prefers_verified_progress_and_penalizes_blocked_repeats(self):
        before = sample_world()
        after = sample_world()
        after["needs"] = dict(before["needs"])
        after["needs"]["food"] = 0.1
        success, parts = gs._learning_reward(before, after, {"action": "forage"}, {
            "goal_achieved": True, "constraints_respected": True, "observed_harm": 0.0,
            "unexpected_cost": 0.0, "novelty_verified": False,
        })
        failure, fail_parts = gs._learning_reward(before, before, {"action": "inspect"}, {
            "goal_achieved": False, "constraints_respected": True, "observed_harm": 0.0,
            "unexpected_cost": 0.1, "failure_reason": "movement_stuck_collision",
        })
        self.assertGreater(success, failure)
        self.assertGreater(parts.get("need_progress_food", 0), 0)
        self.assertLess(fail_parts.get("movement_failure", 0), 0)

    def test_nearest_target_skips_cooldown_and_unavailable_objects(self):
        world = sample_world()
        world["target_cooldowns"] = {"berry_patch": 99.0}
        self.assertIsNone(gs._nearest(world, "food"))



if __name__ == "__main__":
    unittest.main()
