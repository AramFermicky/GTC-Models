from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from gentc_ai.integration.undertale_agent import Frame
from gentc_ai.integration.undertale_policy import INPUT_SIZE
from gentc_ai.integration.undertale_learning import (
    UndertaleLearningMemory, extract_features, feature_similarity, frame_change, visual_change,
)


def solid_frame(color: tuple[int, int, int], width: int = 160, height: int = 120) -> Frame:
    r, g, b = color
    pixel = bytes((b, g, r, 255))
    return Frame(width, height, pixel * (width * height), width, height)


def split_frame(left: tuple[int, int, int], right: tuple[int, int, int], width: int = 160, height: int = 120) -> Frame:
    buf = bytearray(width * height * 4)
    for y in range(height):
        for x in range(width):
            r, g, b = left if x < width // 2 else right
            i = (y * width + x) * 4
            buf[i:i+4] = bytes((b, g, r, 255))
    return Frame(width, height, bytes(buf), width, height)


class UndertaleLearningTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db_path = Path(self.tmp.name) / "undertale.sqlite3"
        self.memory = UndertaleLearningMemory(self.db_path)

    def tearDown(self):
        self.memory.close()
        self.tmp.cleanup()

    def test_identical_frames_reuse_scene(self):
        frame = solid_frame((15, 25, 35))
        one = self.memory.identify(frame)
        two = self.memory.identify(frame)
        self.assertTrue(one.is_new)
        self.assertEqual(one.state_id, two.state_id)
        self.assertGreaterEqual(two.similarity, 0.88)

    def test_large_scene_change_gets_new_state(self):
        one = self.memory.identify(solid_frame((0, 0, 0)))
        two = self.memory.identify(solid_frame((255, 255, 255)))
        self.assertNotEqual(one.state_id, two.state_id)
        self.assertTrue(two.is_new)

    def test_action_feedback_persists_across_reopen(self):
        state = self.memory.identify(solid_frame((10, 10, 10))).state_id
        self.memory.record("overworld", state, "right", state, 0.8, 0.2, {"test": True})
        visits, value = self.memory.value_for(state, "overworld", "right")
        self.assertEqual(visits, 1)
        self.assertAlmostEqual(value, 0.8)
        self.memory.close()
        self.memory = UndertaleLearningMemory(self.db_path)
        visits2, value2 = self.memory.value_for(state, "overworld", "right")
        self.assertEqual(visits2, 1)
        self.assertAlmostEqual(value2, 0.8)
        self.assertEqual(self.memory.stats()["experience_records"], 1)

    def test_policy_tries_unseen_actions_before_repeating(self):
        state = self.memory.identify(solid_frame((30, 40, 50))).state_id
        actions = ["left", "right", "up"]
        first = self.memory.choose_action(state, "overworld", actions)
        self.memory.record("overworld", state, first, state, -0.4, 0.0)
        second = self.memory.choose_action(state, "overworld", actions)
        self.assertNotEqual(first, second)

    def test_frontier_planner_returns_first_action_toward_unknown_scene(self):
        a = self.memory.identify(solid_frame((5, 5, 5))).state_id
        b = self.memory.identify(solid_frame((245, 245, 245))).state_id
        self.memory.record("overworld", a, "right", b, 0.5, 0.3)
        result = self.memory.planned_frontier_action(a, ["left", "right", "up"])
        self.assertEqual(result, "right")

    def test_human_demonstrations_are_separate_from_reward_labels(self):
        before = self.memory.identify(solid_frame((12, 18, 24))).state_id
        after = self.memory.identify(solid_frame((220, 210, 200))).state_id
        self.memory.record_demonstration("overworld", before, "right", after, 0.14, 0.24,
                                         {"source": "manual-test"})
        visits, value = self.memory.value_for(before, "overworld", "right")
        self.assertEqual(visits, 0, "Human demonstrations must not fabricate autonomous reward data")
        self.assertEqual(self.memory.demonstration_counts(before, "overworld", ["left", "right"])["right"], 1)
        self.assertEqual(self.memory.choose_action(before, "overworld", ["left", "right", "up"]), "right")
        stats = self.memory.stats()
        self.assertEqual(stats["human_demonstrations"], 1)
        self.assertEqual(stats["human_action_norm"][0]["action"], "right")
        edge = self.memory.db.execute(
            "SELECT count FROM transitions WHERE from_state=? AND action=? AND to_state=?",
            (before, "right", after)).fetchone()
        self.assertIsNotNone(edge, "Human movement should contribute route edges for BFS")

    def test_legacy_jsonl_is_imported_to_database_before_duplicate_is_removed(self):
        legacy = self.db_path.parent / "pilot_observations.jsonl"
        legacy.write_text(
            '{"timestamp":"2026-10-21T12:00:00+00:00","event":"old_event","action":"left","observation":{"visible":true}}\n',
            encoding="utf-8",
        )
        self.memory.close()
        self.memory = UndertaleLearningMemory(self.db_path)
        row = self.memory.db.execute("SELECT event,action,observation_json FROM runtime_logs ORDER BY id DESC LIMIT 1").fetchone()
        self.assertEqual(row["event"], "old_event")
        self.assertEqual(row["action"], "left")
        self.assertIn('"visible": true', row["observation_json"])
        self.assertFalse(legacy.exists(), "Duplicate source log is removed only after successful import")

    def test_td_q_learning_bootstraps_from_a_rewarded_next_state(self):
        state_a = self.memory.identify(solid_frame((101, 111, 121))).state_id
        state_b = self.memory.identify(solid_frame((201, 211, 221))).state_id
        self.memory.record("overworld", state_b, "right", state_b, 0.8, 0.1)
        next_visits, next_q = self.memory.q_value_for(state_b, "overworld", "right")
        self.assertEqual(next_visits, 1)
        self.assertGreater(next_q, 0.0)
        self.memory.record("overworld", state_a, "left", state_b, 0.2, 0.1,
                           policy_features=[0.0] * INPUT_SIZE)
        visits, q_value = self.memory.q_value_for(state_a, "overworld", "left")
        self.assertEqual(visits, 1)
        self.assertGreater(q_value, 0.2 * 0.45, "next-state value should improve the first-step Q estimate")
        row = self.memory.db.execute(
            "SELECT details_json FROM events WHERE from_state=? AND action='left' ORDER BY id DESC LIMIT 1",
            (state_a,)).fetchone()
        details = __import__("json").loads(row["details_json"])
        self.assertGreater(details["td_target"], 0.2)
        self.assertEqual(self.memory.stats()["q_value_entries"], 2)

    def test_explicit_same_state_failure_is_not_diluted_by_old_q_value(self):
        state = self.memory.identify(solid_frame((141, 151, 161))).state_id
        for _ in range(4):
            self.memory.record("overworld", state, "right", state, 0.9, 0.1)
        self.memory.record("overworld", state, "right", state, -1.0, 0.0,
                           {"feedback_source": "explicit_user_label", "outcome": "damage"})
        row = self.memory.db.execute(
            "SELECT details_json FROM events WHERE from_state=? AND action='right' ORDER BY id DESC LIMIT 1",
            (state,)).fetchone()
        details = json.loads(row["details_json"])
        self.assertEqual(details["next_state_q"], 0.0)
        self.assertEqual(details["td_target"], -1.0)

    def test_neutral_attempt_does_not_update_tabular_q(self):
        state = self.memory.identify(solid_frame((131, 141, 151))).state_id
        self.memory.record("overworld", state, "left", state, 0.0, 0.0, learn=False)
        self.assertEqual(self.memory.q_value_for(state, "overworld", "left"), (0, 0.0))

    def test_prioritized_replay_keeps_older_severe_failure(self):
        import json, time
        features = [0.0] * INPUT_SIZE
        severe_ts = time.time() - 30 * 86400
        cursor = self.memory.db.execute(
            "INSERT INTO policy_examples(ts,mode,action,features_json,target,source,sample_weight) VALUES(?,?,?,?,?,?,?)",
            (severe_ts, "overworld", "left", json.dumps(features), -1.0, "autonomous_reward", 1.0))
        severe_id = cursor.lastrowid
        for i in range(90):
            self.memory.db.execute(
                "INSERT INTO policy_examples(ts,mode,action,features_json,target,source,sample_weight) VALUES(?,?,?,?,?,?,?)",
                (time.time() + i * 0.001, "overworld", "right", json.dumps(features), 0.0,
                 "autonomous_reward", 1.0))
        self.memory.db.commit()
        batch = self.memory.policy_training_examples(limit=16)
        self.assertLessEqual(len(batch), 16)
        self.assertIn(severe_id, {item["id"] for item in batch},
                      "Prioritized replay should sample a serious old failure even after many neutral frames")
        severe = next(item for item in batch if item["id"] == severe_id)
        self.assertEqual(severe["target"], -1.0)

    def test_runtime_logs_are_stored_inside_learning_database(self):
        self.memory.log_runtime("overworld", "left", "test_event", {"visible": True}, {"test": True})
        row = self.memory.db.execute("SELECT mode,action,event FROM runtime_logs ORDER BY id DESC LIMIT 1").fetchone()
        self.assertEqual(tuple(row), ("overworld", "left", "test_event"))
        self.assertEqual(self.memory.stats()["runtime_log_records"], 1)

    def test_frame_change_notices_local_sprite_movement(self):
        base = bytearray(solid_frame((0, 0, 0)).bgra)
        moved = bytearray(base)
        for y in range(40, 56):
            for x in range(40, 56):
                i = (y * 160 + x) * 4
                base[i:i+4] = bytes((0, 0, 255, 255))
        for y in range(40, 56):
            for x in range(52, 68):
                i = (y * 160 + x) * 4
                moved[i:i+4] = bytes((0, 0, 255, 255))
        before = Frame(160, 120, bytes(base), 160, 120)
        after = Frame(160, 120, bytes(moved), 160, 120)
        self.assertGreater(frame_change(before, after), 0.003)
        self.assertEqual(frame_change(before, before), 0.0)

    def test_neutral_action_is_tracked_without_receiving_reward(self):
        state = self.memory.identify(solid_frame((60, 70, 80))).state_id
        self.memory.record("overworld", state, "interact", state, 0.0, 0.0,
                           {"reason": "no visible response"}, learn=False)
        visits, value = self.memory.value_for(state, "overworld", "interact")
        self.assertEqual(visits, 0, "Neutral observations must not create reward-labelled values")
        self.assertEqual(value, 0.0)
        attempts = self.memory.action_attempt_stats(state, "overworld", ["interact"])
        self.assertEqual(attempts["interact"]["attempts"], 1)
        self.assertEqual(attempts["interact"]["consecutive_no_progress"], 1)
        self.assertEqual(self.memory.stats()["experience_records"], 1)

    def test_neutral_attempt_stops_counting_as_untried_action(self):
        state = self.memory.identify(solid_frame((77, 88, 99))).state_id
        actions = ["left", "right", "interact"]
        self.memory.record("overworld", state, "interact", state, 0.0, 0.0,
                           {"reason": "neutral attempt"}, learn=False)
        # The two untouched directions should be explored instead of immediately
        # repeating the neutral interaction merely because it has no reward row.
        self.assertNotEqual(self.memory.choose_action(state, "overworld", actions), "interact")

    def test_repeated_blocked_hint_is_severe_but_can_expire(self):
        state = self.memory.identify(solid_frame((90, 100, 110))).state_id
        self.assertEqual(self.memory.record_blocked_attempt(state, "overworld", "left"), 1)
        self.assertEqual(self.memory.record_blocked_attempt(state, "overworld", "left"), 2)
        self.assertEqual(self.memory.blocked_count(state, "overworld", "left"), 2)
        self.memory.resolve_blocked_attempt(state, "overworld", "left")
        self.assertEqual(self.memory.blocked_count(state, "overworld", "left"), 0)
        # Expiring the current avoidance hint must not delete the historical record.
        row = self.memory.db.execute("SELECT count FROM blocked_actions WHERE state_id=? AND mode=? AND action=?",
                                     (state, "overworld", "left")).fetchone()
        self.assertEqual(row["count"], 2)

    def test_feature_metrics_are_bounded(self):
        a = extract_features(solid_frame((0, 0, 0)))
        b = extract_features(split_frame((0, 0, 0), (255, 255, 255)))
        self.assertEqual(len(a), len(b))
        self.assertTrue(0 <= feature_similarity(a, b) <= 1)
        self.assertTrue(0 <= visual_change(a, b) <= 1)


if __name__ == "__main__":
    unittest.main()
