from __future__ import annotations
import unittest

from gentc_ai.experience.decision_tracker import DecisionTracker, state_fingerprint


class FakeClock:
    def __init__(self) -> None:
        self.value = 100.0
    def __call__(self) -> float:
        return self.value
    def advance(self, seconds: float) -> None:
        self.value += seconds


class DecisionTrackerTests(unittest.TestCase):
    def test_same_pending_decision_is_reused_until_feedback(self):
        clock = FakeClock()
        tracker = DecisionTracker(timeout_seconds=15, clock=clock)
        first = tracker.create("winter_shelter:main", "state-a", {"action": "move_to", "target_id": "tree_1"})
        second = tracker.get_pending("winter_shelter:main")
        self.assertIsNotNone(second)
        self.assertEqual(first["decision_id"], second["decision_id"])
        self.assertEqual(second["action"]["command_id"], first["decision_id"])
        self.assertTrue(second["reused"])
        self.assertEqual(tracker.snapshot()["created"], 1)
        self.assertEqual(tracker.snapshot()["reused"], 1)

    def test_feedback_acknowledges_and_clears_pending_decision(self):
        tracker = DecisionTracker(clock=FakeClock())
        first = tracker.create("game:world", "state", {"action": "inspect"})
        result = tracker.acknowledge(first["decision_id"], "inspect")
        self.assertTrue(result["accepted"])
        self.assertIsNone(tracker.get_pending("game:world"))
        duplicate = tracker.acknowledge(first["decision_id"], "inspect")
        self.assertTrue(duplicate["duplicate"])

    def test_action_mismatch_does_not_clear_pending(self):
        tracker = DecisionTracker(clock=FakeClock())
        first = tracker.create("game:world", "state", {"action": "inspect"})
        result = tracker.acknowledge(first["decision_id"], "wander")
        self.assertFalse(result["accepted"])
        self.assertEqual(result["reason"], "action_name_mismatch")
        self.assertIsNotNone(tracker.get_pending("game:world"))

    def test_timeout_is_cautioned_but_not_recorded_as_negative_feedback(self):
        clock = FakeClock()
        tracker = DecisionTracker(timeout_seconds=5, clock=clock)
        tracker.create("game:world", "state-a", {"action": "inspect", "target_id": "tree_1"})
        clock.advance(5.1)
        self.assertIsNone(tracker.get_pending("game:world"))
        self.assertEqual(tracker.cautioned_actions("game:world", "state-a"), {("inspect", "tree_1")})
        stats = tracker.snapshot()
        self.assertEqual(stats["timed_out"], 1)
        self.assertEqual(stats["confirmed"], 0)

    def test_late_feedback_releases_timed_out_caution(self):
        clock = FakeClock()
        tracker = DecisionTracker(timeout_seconds=2, clock=clock)
        first = tracker.create("game:world", "state-a", {"action": "wander", "target_id": "path_a"})
        clock.advance(2.1)
        tracker.get_pending("game:world")
        self.assertIn(("wander", "path_a"), tracker.cautioned_actions("game:world", "state-a"))
        result = tracker.acknowledge(first["decision_id"], "wander")
        self.assertTrue(result["accepted"])
        self.assertTrue(result["late"])
        self.assertEqual(tracker.cautioned_actions("game:world", "state-a"), set())

    def test_state_fingerprint_ignores_frame_timestamps_and_tiny_noise(self):
        a = {"player": {"x": 1.1111}, "timestamp_ms": 100}
        b = {"timestamp_ms": 200, "player": {"x": 1.1122}}
        self.assertEqual(state_fingerprint(a), state_fingerprint(b))
        c = {"player": {"x": 1.5}}
        self.assertNotEqual(state_fingerprint(a), state_fingerprint(c))


if __name__ == "__main__":
    unittest.main()
