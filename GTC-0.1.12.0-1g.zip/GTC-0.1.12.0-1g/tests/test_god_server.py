from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from gentc_ai.god_simulation import GodMind
from gentc_ai.integration import god_server


def world() -> dict:
    return {
        "game_id": "gtc_god_world",
        "unrest": 0.12,
        "player": {"id": "player", "position": [0, 0, 2], "health": 100, "alive": True},
        "characters": [
            {"id": "player", "name": "Игрок", "is_player": True, "position": [0, 0, 2], "health": 100, "alive": True},
            {"id": "npc_lya", "name": "Лея", "position": [-3, 0, 0], "health": 100, "alive": True, "aggression": 0.1},
        ],
    }


class GodServerRouteTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.mind = GodMind(Path(self.temp_dir.name), seed=54321)
        self.patch = patch.object(god_server, "MIND", self.mind)
        self.patch.start()

    def tearDown(self) -> None:
        self.patch.stop()
        self.temp_dir.cleanup()

    def test_think_route_returns_an_action(self) -> None:
        result = god_server.process_request("/god/think", {"world": world()})
        self.assertTrue(result["ok"])
        self.assertIn("action", result)
        self.assertIn("candidate_count", result)

    def test_chat_route_returns_grounded_reply(self) -> None:
        result = god_server.process_request("/god/chat", {"world": world(), "text": "Кто ты?"})
        self.assertTrue(result["reply"])
        self.assertFalse(result["execute_action"])

    def test_feedback_route_records_confirmed_outcome(self) -> None:
        result = god_server.process_request("/god/feedback", {
            "world": world(),
            "situation": {"context_tags": ["test", "calm"]},
            "action": {"action": "bless", "semantic_action": "care", "context_tags": ["test"]},
            "outcome": {"verified": True, "execution_confirmed": True, "goal_achieved": True,
                        "constraints_respected": True, "observed_harm": 0.0, "unexpected_cost": 0.0},
        })
        self.assertTrue(result["ok"])
        self.assertTrue(result["learning"]["stored"])


if __name__ == "__main__":
    unittest.main()
