from __future__ import annotations
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from gentc_ai.continuity.paths import get_model_root, get_model_learning_dir, bootstrap_legacy_learning


class TestModelStoragePaths(unittest.TestCase):
    def test_model_root_uses_launcher_selected_model(self):
        with tempfile.TemporaryDirectory() as tmp, patch.dict(os.environ, {"GTC_MODEL_ROOT": tmp}, clear=False):
            self.assertEqual(get_model_root(), Path(tmp).resolve())
            self.assertEqual(get_model_learning_dir("worlds", "game"), Path(tmp) / "GTC_learning" / "worlds" / "game")

    def test_path_traversal_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp, patch.dict(os.environ, {"GTC_MODEL_ROOT": tmp}, clear=False):
            with self.assertRaises(ValueError):
                get_model_learning_dir("..", "outside")

    def test_legacy_package_learning_is_copied_under_selected_model_root(self):
        with tempfile.TemporaryDirectory() as tmp, patch.dict(os.environ, {"GTC_MODEL_ROOT": tmp}, clear=False):
            inherited = bootstrap_legacy_learning()
            self.assertTrue(inherited.is_relative_to(Path(tmp) / "GTC_learning"))
            self.assertTrue((inherited / "data" / "learning").is_dir())
            self.assertTrue((Path(tmp) / "GTC_learning" / ".legacy_import_0_1_10_34_3t.done").is_file())

    def test_legacy_alias_also_points_inside_model_learning(self):
        from gentc_ai.continuity.paths import get_shared_data_dir
        with tempfile.TemporaryDirectory() as tmp, patch.dict(os.environ, {"GTC_MODEL_ROOT": tmp}, clear=False):
            self.assertEqual(get_shared_data_dir(), Path(tmp) / "GTC_learning")


if __name__ == "__main__":
    unittest.main()
