from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from gentc_ai.learning.persistent_q_learning import PersistentQPolicy


class PersistentQPolicyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / "q_policy.json"
        self.policy = PersistentQPolicy(self.path)
        self.world = {"game_id": "winter_shelter", "world_id": "forest", "needs": {"food": 0.8, "rest": 0.2, "social": 0.3, "safety": 0.1, "curiosity": 0.7}, "coldness": 0.4, "player_distance": 5.0}

    def tearDown(self):
        self.temp.cleanup()

    def test_state_key_discretizes_world_and_scopes_exact_q_by_game(self):
        key1 = self.policy.state_key(self.world)
        key2 = self.policy.state_key({**self.world, "game_id": "other_game"})
        self.assertNotEqual(key1, key2)
        self.assertIn("food2", key1)

    def test_verified_negative_outcome_changes_action_value(self):
        key = self.policy.state_key(self.world)
        before = self.policy.adjustment(self.world, "inspect", "exploration")
        result = self.policy.update(state_key=key, action="inspect", semantic_action="exploration",
                                    reward=-0.8, next_state_key=key, next_actions=["rest", "observe"],
                                    game_id="winter_shelter", success=False, target_id="tree_x")
        after = self.policy.adjustment(self.world, "inspect", "exploration")
        self.assertTrue(result["updated"])
        self.assertEqual(result["transitions"], 1)
        self.assertNotEqual(before, after)
        self.assertLess(result["q_value"], 0.0)

    def test_repeat_failures_get_additional_penalty_and_success_resets_streak(self):
        key = self.policy.state_key(self.world)
        args = dict(state_key=key, action="inspect", semantic_action="exploration", reward=-0.5,
                    next_state_key=key, next_actions=["rest"], game_id="winter_shelter", success=False)
        first = self.policy.update(**args)
        second = self.policy.update(**args)
        self.assertEqual(first["repeat_failure_penalty"], 0.0)
        self.assertLess(second["repeat_failure_penalty"], 0.0)
        success = self.policy.update(**{**args, "reward": 0.5, "success": True})
        self.assertEqual(success["failure_streak"], 0)

    def test_semantic_experience_transfers_weakly_across_games(self):
        key = self.policy.state_key(self.world)
        self.policy.update(state_key=key, action="inspect", semantic_action="exploration", reward=0.9,
                           next_state_key=key, next_actions=["rest"], game_id="game_a", success=True)
        other = {**self.world, "game_id": "game_b", "world_id": "other_world"}
        adjustment = self.policy.adjustment(other, "wander", "exploration")
        self.assertGreater(adjustment, 0.0)
        self.assertLessEqual(adjustment, 0.13)

    def test_q_policy_survives_reload(self):
        key = self.policy.state_key(self.world)
        self.policy.update(state_key=key, action="rest", semantic_action="rest", reward=0.75,
                           next_state_key=key, next_actions=["rest"], game_id="winter_shelter", success=True)
        reopened = PersistentQPolicy(self.path)
        self.assertEqual(reopened.transitions, 1)
        self.assertGreater(reopened.agent.q_table[key]["rest"], 0.0)
        self.assertTrue(self.path.exists())


    def test_untried_action_gets_bounded_exploration_bonus(self):
        from gentc_ai.learning.persistent_q_learning import PersistentQPolicy
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as tmp:
            policy = PersistentQPolicy(Path(tmp) / "q.json")
            world = {"game_id": "game_a", "world_id": "map", "needs": {}}
            first = policy.adjustment(world, "wander", "exploration")
            self.assertGreater(first, 0.0)
            state = policy.state_key(world)
            policy.update(state_key=state, action="wander", semantic_action="exploration", reward=-0.4,
                          next_state_key=state, next_actions=["rest", "inspect"], game_id="game_a", success=False)
            tried = policy.adjustment(world, "wander", "exploration")
            untried = policy.adjustment(world, "rest", "rest")
            self.assertGreater(untried, tried)



if __name__ == "__main__":
    unittest.main()
