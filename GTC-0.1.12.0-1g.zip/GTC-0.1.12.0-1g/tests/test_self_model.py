from __future__ import annotations
import tempfile
import unittest
from pathlib import Path
from gentc_ai.continuity.self_model import SelfModelStore

class SelfModelTests(unittest.TestCase):
    def test_persists_identity_and_reflections_across_reload(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "self_model.json"
            a = SelfModelStore(path, identity_id="anna.canon", profile={"values": {"empathy": 0.8}})
            a.record_decision(action="forage", reason="food_need", context_tags=["hunger_high"])
            accepted = a.record_outcome(action="forage", outcome={"verified": True, "execution_confirmed": True,
                "constraints_respected": True, "goal_achieved": True, "observed_harm": 0, "outcome_summary": "food obtained"}, reward=0.7)
            self.assertTrue(accepted)
            b = SelfModelStore(path, identity_id="anna.canon")
            state = b.snapshot()
            self.assertEqual(state["decision_count"], 1)
            self.assertEqual(state["confirmed_outcomes"], 1)
            self.assertEqual(state["action_statistics"]["forage"]["successes"], 1)
            self.assertTrue(state["recent_reflections"])
            self.assertTrue(state["not_a_consciousness_claim"])


    def test_available_capabilities_are_recorded_per_game_and_world(self):
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as tmp:
            store = SelfModelStore(Path(tmp) / "self.json", identity_id="anna.canon")
            store.record_available_capabilities(game_id="winter_shelter", world_id="forest", actions=["wander", "rest"],
                                                object_types=["tree", "food"], runtime_version="GTC-test")
            data = store.snapshot()
            record = data["game_capabilities"]["winter_shelter"]["worlds"]["forest"]
            self.assertIn("wander", record["actions"])
            self.assertIn("food", record["object_types"])
            self.assertEqual(record["observations"], 1)

    def test_unverified_outcome_is_not_reflected_as_training_evidence(self):
        with tempfile.TemporaryDirectory() as folder:
            model = SelfModelStore(Path(folder) / "self_model.json", identity_id="test")
            accepted = model.record_outcome(action="teleport", outcome={"verified": False, "execution_confirmed": False}, reward=-1)
            self.assertFalse(accepted)
            self.assertEqual(model.snapshot()["confirmed_outcomes"], 0)

    def test_corrupt_model_is_backed_up_before_recovery(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "self_model.json"
            path.write_text("{invalid", encoding="utf-8")
            model = SelfModelStore(path, identity_id="anna.canon")
            self.assertIn("unreadable", model.load_warning or "")
            self.assertEqual(path.read_text(encoding="utf-8"), "{invalid")
            self.assertTrue(list(Path(folder).glob("self_model.corrupt-*.json")))

if __name__ == "__main__":
    unittest.main()
