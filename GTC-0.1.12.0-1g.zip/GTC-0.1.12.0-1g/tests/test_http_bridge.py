from __future__ import annotations

import contextlib
import io
import json
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from unittest.mock import patch

from gentc_ai.integration.http_server import GTCRequestHandler, process_decision


def make_world(inventory=None):
    trees = [
        {"id": "tree_01", "type": "tree", "available": True},
        {"id": "tree_02", "type": "tree", "available": True},
        {"id": "tree_03", "type": "tree", "available": True},
    ]
    return {
        "game_id": "gtc_playground",
        "player": {"id": "player", "position": [0.0, 0.0, 0.0]},
        "npcs": [{"id": "anna", "position": [1.0, 0.0, 0.0], "state": "idle"}],
        "objects": [dict(obj) for obj in trees],
        "nearby_objects": [dict(obj) for obj in trees],
        "inventory": inventory or [],
        "npc_busy": False,
        "mode": "godot_playground",
    }


class HttpBridgeTests(unittest.TestCase):
    def test_missing_axe_blocks_tree_plan(self):
        response = process_decision({
            "game_id": "gtc_playground",
            "text": "Поруби пару деревьев пожалуйста",
            "world": make_world(),
        })
        self.assertTrue(response["ok"])
        self.assertEqual(response["intent"]["intent"], "chop_trees")
        self.assertEqual(response["decision"]["decision"], "request_tool")
        self.assertEqual(response["decision"]["status"], "blocked_missing_tool")

    def test_axe_allows_plan_but_does_not_claim_engine_ran_it(self):
        response = process_decision({
            "game_id": "gtc_playground",
            "text": "Поруби пару деревьев пожалуйста",
            "world": make_world(["axe"]),
        })
        self.assertTrue(response["ok"])
        self.assertEqual(response["decision"]["decision"], "accept")
        self.assertEqual(response["decision"]["status"], "plan_ready_not_executed")
        self.assertEqual(len(response["decision"]["plan"]), 4)
        self.assertIn("ещё не выполнен", response["execution_note"])
        self.assertFalse(response["llm_connected"])

    def test_reject_wrong_game_id(self):
        with self.assertRaises(ValueError):
            process_decision({"game_id": "other_game", "text": "Привет", "world": make_world()})

    def test_bad_snapshot_returns_structured_failure(self):
        response = process_decision({
            "game_id": "gtc_playground", "text": "Привет", "world": {"player": "wrong"}
        })
        self.assertFalse(response["ok"])
        self.assertEqual(response["error"], "invalid_world_snapshot")

    def test_http_internal_error_does_not_leak_exception_details(self):
        server = ThreadingHTTPServer(("127.0.0.1", 0), GTCRequestHandler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        payload = json.dumps({"text": "hello", "world": {"player": {}}}).encode("utf-8")
        request = urllib.request.Request(
            f"http://127.0.0.1:{server.server_port}/decide", data=payload,
            headers={"Content-Type": "application/json"}, method="POST",
        )
        captured_stderr = io.StringIO()
        thread.start()
        try:
            with patch("gentc_ai.integration.http_server.process_decision",
                       side_effect=RuntimeError("SECRET_INTERNAL_DETAIL /private/path")):
                with contextlib.redirect_stderr(captured_stderr):
                    with self.assertRaises(urllib.error.HTTPError) as raised:
                        urllib.request.urlopen(request, timeout=3)
                    body = raised.exception.read().decode("utf-8")
            self.assertEqual(raised.exception.code, 500)
            self.assertIn("internal_error", body)
            self.assertNotIn("SECRET_INTERNAL_DETAIL", body)
            self.assertNotIn("/private/path", body)
            self.assertIn("SECRET_INTERNAL_DETAIL", captured_stderr.getvalue())
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=3)


if __name__ == "__main__":
    unittest.main()
