from __future__ import annotations
import ast
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from gentc_ai.runtime.contracts import ModuleManifest, ModuleStatus
from gentc_ai.runtime.registry import ModuleRegistry
from gentc_ai.runtime.event_bus import EventBus
from gentc_ai.runtime.health import HealthMonitor
from gentc_ai.runtime.metrics import Metrics
from gentc_ai.runtime.retry import RetryPolicy, CircuitBreaker
from gentc_ai.runtime.scheduler import DueTaskScheduler
from gentc_ai.runtime.supervisor import ModuleSupervisor
from gentc_ai.runtime.catalog import module_catalog
from gentc_ai.perception.contracts import Evidence
from gentc_ai.perception.frame_signature import frame_signature
from gentc_ai.perception.change_detector import VisualChangeDetector
from gentc_ai.perception.confidence import combine_confidence
from gentc_ai.perception.fusion import fuse_state_sources
from gentc_ai.actions.contracts import ActionRequest
from gentc_ai.actions.safety_gate import SafetyGate
from gentc_ai.actions.dispatcher import ActionDispatcher
from gentc_ai.goals.contracts import Goal, GoalStatus
from gentc_ai.goals.manager import GoalManager
from gentc_ai.goals.planner import PlanCandidate, rank_candidates
from gentc_ai.experience.contracts import Experience, Outcome
from gentc_ai.experience.feedback import assess_outcome
from gentc_ai.experience.replay_sampler import PrioritizedReplaySampler
from gentc_ai.experience.validation import validate_experience
from gentc_ai.creative.sandbox import ArtifactSandbox
from gentc_ai.creative.experiment import ExperimentSpec, run_experiment_trials
from gentc_ai.creative.evaluation import compare_experiment
from gentc_ai.gls.contracts import LanguageExample, GenerationRequest, GenerationResult
from gentc_ai.gls.dataset import JsonlDataset
from gentc_ai.gls.checkpoint import CheckpointManager
from gentc_ai.gls.inference import GLSRuntime
from gentc_ai.gls.training import split_dataset, evaluate_candidate
from gentc_ai.collective.messages import CollectiveExperience
from gentc_ai.collective.validator import validate_collective_example
from gentc_ai.collective.store import LocalKnowledgeOutbox


class RuntimeFoundationTests(unittest.TestCase):
    def test_registry_orders_dependencies_and_detects_cycles(self):
        registry = ModuleRegistry()
        registry.register(ModuleManifest("b", requires=("a",)))
        registry.register(ModuleManifest("a"))
        self.assertEqual(registry.startup_order(), ["a", "b"])
        registry.set_status("a", ModuleStatus.RUNNING)
        self.assertEqual(registry.snapshot()[0]["status"], "running")
        cyclic = ModuleRegistry()
        cyclic.register(ModuleManifest("a", requires=("b",)))
        cyclic.register(ModuleManifest("b", requires=("a",)))
        with self.assertRaisesRegex(ValueError, "cycle"):
            cyclic.startup_order()

    def test_event_bus_bounds_history_and_isolates_bad_subscriber(self):
        bus = EventBus(history_limit=2)
        seen = []
        bus.subscribe("tick", lambda event: seen.append(event.payload["n"]))
        bus.subscribe("tick", lambda event: (_ for _ in ()).throw(RuntimeError("isolated")))
        bus.publish("tick", {"n": 1}); bus.publish("tick", {"n": 2}); bus.publish("tick", {"n": 3})
        self.assertEqual(seen, [1, 2, 3])
        self.assertEqual([e.payload["n"] for e in bus.history()], [2, 3])
        self.assertEqual(bus.status()["subscriber_errors"], 3)

    def test_health_metrics_retry_and_circuit_breaker(self):
        health = HealthMonitor(); health.heartbeat("agent", now=2.0, detail={"fps": 12})
        self.assertTrue(health.inspect("agent", stale_after=1, now=2.5)["alive"])
        self.assertFalse(health.inspect("agent", stale_after=1, now=4)["alive"])
        metrics = Metrics(sample_limit=2); metrics.increment("frames"); metrics.observe("latency", 2); metrics.observe("latency", 4); metrics.observe("latency", 6)
        self.assertEqual(metrics.snapshot()["counters"]["frames"], 1)
        self.assertEqual(metrics.snapshot()["samples"]["latency"]["mean"], 5)
        self.assertEqual(RetryPolicy(attempts=3, base_delay=0.1).delay_after(3), 0.4)
        breaker = CircuitBreaker(threshold=2, cooldown=5); breaker.record_failure(now=1); breaker.record_failure(now=2)
        self.assertFalse(breaker.allow(now=4)); self.assertTrue(breaker.allow(now=7))
        with self.assertRaises(ValueError): RetryPolicy(base_delay=float("nan"))
        with self.assertRaises(ValueError): DueTaskScheduler().add("bad", float("inf"), lambda: None)
        with self.assertRaises(ValueError): CircuitBreaker(cooldown=float("nan"))

    def test_scheduler_and_supervisor_isolate_task_failures(self):
        scheduler = DueTaskScheduler(); calls = []
        scheduler.add("ok", 2, lambda: calls.append("ok") or 4)
        scheduler.add("bad", 2, lambda: (_ for _ in ()).throw(ValueError("bad")))
        results = scheduler.run_due(1)
        self.assertEqual(len(results), 2); self.assertEqual(calls, ["ok"])
        self.assertFalse(next(r for r in results if r["task_id"] == "bad")["ok"])
        supervisor = ModuleSupervisor()
        supervisor.register(ModuleManifest("a"), start=lambda: "started")
        supervisor.register(ModuleManifest("b", requires=("a",)), start=lambda: (_ for _ in ()).throw(RuntimeError("boom")))
        states = supervisor.start_all()
        self.assertTrue(states[0]["ok"]); self.assertFalse(states[1]["ok"])
        snap = {m["module_id"]: m["status"] for m in supervisor.registry.snapshot()}
        self.assertEqual(snap["a"], "running"); self.assertEqual(snap["b"], "failed")

    def test_supervisor_does_not_start_dependants_of_failed_modules(self):
        supervisor = ModuleSupervisor(); called = []
        supervisor.register(ModuleManifest("root"), start=lambda: (_ for _ in ()).throw(RuntimeError("offline")))
        supervisor.register(ModuleManifest("child", requires=("root",)), start=lambda: called.append("child"))
        supervisor.register(ModuleManifest("independent"), start=lambda: called.append("independent"))
        result = {item["module_id"]: item for item in supervisor.start_all()}
        self.assertFalse(result["root"]["ok"])
        self.assertFalse(result["child"]["ok"])
        self.assertIn("dependency_not_running", result["child"]["error"])
        self.assertTrue(result["independent"]["ok"])
        self.assertEqual(called, ["independent"])


class PerceptionFoundationTests(unittest.TestCase):
    def test_frame_signatures_and_change_detector(self):
        buf = bytes([1, 2, 3, 4] * 64)
        self.assertEqual(frame_signature(buf, 8, 8), frame_signature(buf, 8, 8))
        with self.assertRaises(ValueError): frame_signature(b"bad", 8, 8)
        detector = VisualChangeDetector(minimum_interval=0.1)
        first = detector.observe("a", 0)
        same = detector.observe("a", 0.01)
        same2 = detector.observe("a", 0.2)
        changed = detector.observe("b", 0.3)
        self.assertTrue(first.first_seen); self.assertFalse(same.changed)
        self.assertEqual(same.consecutive_unchanged, 0)
        self.assertEqual(same2.consecutive_unchanged, 1); self.assertTrue(changed.changed)

    def test_confidence_and_external_state_fusion(self):
        weak = Evidence("pixels", 0.7, "green", False)
        strong = Evidence("state_feed", 1.0, "alive", True)
        self.assertLess(combine_confidence([weak]), combine_confidence([strong]))
        state = fuse_state_sources("demo", {"scene_id": "visual", "confidence": 0.4, "health": 3},
                                   {"available": True, "verified": True, "scene_id": "internal", "health": 7})
        self.assertTrue(state.verified); self.assertEqual(state.scene_id, "internal"); self.assertEqual(state.values["health"], 7)


class ActionAndGoalFoundationTests(unittest.TestCase):
    def test_safety_gate_dispatch_and_idempotency(self):
        gate = SafetyGate({"left", "right"}, max_hold_seconds=0.2, minimum_confidence=0.3)
        dispatcher = ActionDispatcher(gate)
        request = ActionRequest("left", confidence=0.9, hold_seconds=0.1, game_id="undertale", request_id="same")
        calls = []
        result = dispatcher.dispatch(request, lambda a, h: calls.append((a, h)) or "ok", foreground=True, game_id="undertale", now=1)
        again = dispatcher.dispatch(request, lambda a, h: calls.append((a, h)), foreground=True, game_id="undertale", now=2)
        self.assertTrue(result.executed); self.assertEqual(result, again); self.assertEqual(len(calls), 1)
        blocked = dispatcher.dispatch(ActionRequest("left", hold_seconds=0.3), lambda *_: self.fail("must not execute"), foreground=True, now=3)
        self.assertEqual(blocked.reason, "hold_duration_exceeds_limit")
        unfocused = gate.evaluate(request, foreground=False, game_id="undertale")
        self.assertFalse(unfocused.allowed)

    def test_goal_manager_and_risk_aware_planner(self):
        manager = GoalManager(); manager.add(Goal("survive", "Avoid damage", priority=0.9)); manager.add(Goal("explore", "Find a route", priority=0.5))
        self.assertEqual(manager.current().goal_id, "survive")
        manager.update_progress("survive", 1)
        self.assertEqual(manager.current().goal_id, "explore")
        self.assertEqual(manager.snapshot()[0]["status"], GoalStatus.COMPLETED.value)
        ranked = rank_candidates([PlanCandidate("risky", goal_progress=1, risk=0.9), PlanCandidate("safe", goal_progress=0.7, risk=0.1)])
        self.assertEqual(ranked[0][0].action, "safe")


class ExperienceCreativeGLSCollectiveTests(unittest.TestCase):
    def test_reward_is_neutral_when_unknown_and_validates_verified_outcome(self):
        self.assertFalse(assess_outcome(Outcome.DEATH, verified=False).learn)
        neutral = assess_outcome(Outcome.NEUTRAL, verified=True)
        self.assertEqual(neutral.reward, 0); self.assertFalse(neutral.learn)
        item = Experience("undertale", "room1", "left", "room1", Outcome.DEATH, -1, 1, True)
        self.assertEqual(validate_experience(item), (True, "valid"))
        invalid = Experience("undertale", "room1", "left", "room1", Outcome.DEATH, -1, 1, False)
        self.assertEqual(validate_experience(invalid), (False, "unverified_nonzero_reward"))
        sample = PrioritizedReplaySampler(seed=2, max_sample=2).sample([1, 2, 3], priority=lambda x: x, count=2)
        self.assertEqual(len(sample), 2); self.assertEqual(len(set(sample)), 2)

    def test_creative_sandbox_is_data_only_and_evaluation_requires_repeated_gain(self):
        with tempfile.TemporaryDirectory() as tmp:
            sandbox = ArtifactSandbox(tmp, max_bytes=500)
            path = sandbox.write_json("ideas/candidate.json", {"strategy": "explore"})
            self.assertTrue(path.exists()); self.assertEqual(len(sandbox.list_artifacts()), 1)
            with self.assertRaises(ValueError): sandbox.write_text("../outside.py", "run this")
        spec = ExperimentSpec("test", "rank_routes", {"risk_weight": 1.2})
        outcome = run_experiment_trials(spec, lambda _spec, i: {"score": 0.6 + i * 0.01, "risk": 0.1}, trials=3)
        baseline = {"trials": 3, "means": {"score": 0.5, "risk": 0.1}}
        self.assertTrue(compare_experiment(outcome, baseline).accepted)
        self.assertFalse(compare_experiment({"trials": 1, "means": outcome["means"]}, baseline).accepted)

    def test_gls_dataset_checkpoint_and_training_gate(self):
        with tempfile.TemporaryDirectory() as tmp:
            dataset = JsonlDataset(Path(tmp) / "samples.jsonl")
            example = LanguageExample("Hello", "Hi", quality=0.9)
            self.assertTrue(dataset.append(example)); self.assertFalse(dataset.append(example))
            second_writer = JsonlDataset(Path(tmp) / "samples.jsonl")
            self.assertFalse(second_writer.append(example))
            examples = [LanguageExample(f"question {i}", f"answer {i}") for i in range(30)]
            plan = split_dataset(examples, seed=3)
            self.assertEqual(plan.status, "ready"); self.assertTrue(plan.validation); self.assertTrue(plan.holdout)
            self.assertTrue(evaluate_candidate({"quality": 0.9, "safety": 0.99}, {"quality": 0.8, "safety": 0.99})["accepted"])
            model = Path(tmp) / "model.bin"; model.write_bytes(b"weights")
            manager = CheckpointManager(Path(tmp) / "checkpoints")
            meta = manager.register(model, model_id="gls-small", version="0.1", metrics={"quality": 0.8})
            self.assertTrue(manager.verify(meta)["ok"])
            model.write_bytes(b"changed")
            self.assertFalse(manager.verify(meta)["ok"])
        with self.assertRaises(RuntimeError): GLSRuntime().generate(GenerationRequest("hello"))
        self.assertEqual(GenerationResult("hi", "mock", 0.01).text, "hi")

    def test_collective_queue_requires_consent_and_excludes_raw_media(self):
        item = CollectiveExperience("platformer", "sig123", "jump", "progress", 0.3, 0.9)
        self.assertEqual(validate_collective_example(item), (True, "valid"))
        with tempfile.TemporaryDirectory() as tmp:
            disabled = LocalKnowledgeOutbox(Path(tmp) / "off.db")
            with self.assertRaises(PermissionError): disabled.enqueue(item)
            disabled.close()
            enabled = LocalKnowledgeOutbox(Path(tmp) / "on.db", consent=True)
            self.assertTrue(enabled.enqueue(item)); self.assertFalse(enabled.enqueue(item))
            self.assertEqual(len(enabled.pending()), 1); enabled.close()
        bad = CollectiveExperience("platformer", "sig123", "idle", "neutral", -0.2, 0.9)
        self.assertFalse(validate_collective_example(bad)[0])

    def test_catalog_has_eight_optional_subsystem_families(self):
        catalog = module_catalog()
        self.assertEqual(catalog["family_count"], 8)
        self.assertGreaterEqual(catalog["component_count"], 30)
        self.assertTrue(all(not family["auto_started"] for family in catalog["families"]))


class RegressionGuardTests(unittest.TestCase):
    def test_win32_input_union_has_the_native_abi_size(self):
        from gentc_ai.integration.undertale_agent import WindowsScreen
        from gentc_ai.integration.win32_input import INPUT, MOUSEINPUT, KEYBDINPUT, HARDWAREINPUT, INPUT_UNION, abi_report, keyboard_event
        import ctypes
        report = abi_report()
        self.assertTrue(report["valid"], report)
        self.assertEqual(ctypes.sizeof(INPUT), 40 if ctypes.sizeof(ctypes.c_void_p) == 8 else 28)
        self.assertEqual(ctypes.sizeof(INPUT_UNION), max(ctypes.sizeof(MOUSEINPUT), ctypes.sizeof(KEYBDINPUT), ctypes.sizeof(HARDWAREINPUT)))
        self.assertEqual(keyboard_event(0x25, down=True).ki.dwFlags, 0)
        self.assertEqual(keyboard_event(0x25, down=False).ki.dwFlags, 2)
        self.assertTrue(hasattr(WindowsScreen, "input_diagnostics"))
        source = __import__("inspect").getsource(WindowsScreen.key)
        self.assertIn("abi_report()", source)
        self.assertIn("input_diagnostics", __import__("inspect").getsource(WindowsScreen.input_diagnostics))

    def test_getdibits_declares_pointer_sized_arguments_and_fixed_bitmap_layout(self):
        from gentc_ai.integration.undertale_agent import WindowsScreen
        from gentc_ai.integration.win32_gdi import BITMAPINFO, BITMAPINFOHEADER
        import ctypes, inspect
        self.assertEqual(ctypes.sizeof(BITMAPINFOHEADER), 40)
        self.assertEqual(ctypes.sizeof(BITMAPINFO), 44)
        source = inspect.getsource(WindowsScreen.__init__)
        self.assertIn("GetDIBits.argtypes", source)
        self.assertIn("ctypes.POINTER(BITMAPINFO)", source)
        capture_source = inspect.getsource(WindowsScreen.capture)
        self.assertIn("ctypes.cast(pixels, ctypes.c_void_p)", capture_source)

    def test_overworld_loop_does_not_release_key_every_frame(self):
        from gentc_ai.integration.undertale_agent import UndertalePilot
        import inspect, textwrap
        tree = ast.parse(textwrap.dedent(inspect.getsource(UndertalePilot._run)))
        target = None
        for node in ast.walk(tree):
            if isinstance(node, ast.If) and isinstance(node.test, ast.UnaryOp) and isinstance(node.test.op, ast.Not):
                if isinstance(node.test.operand, ast.Name) and node.test.operand.id == "battle_active":
                    target = node; break
        self.assertIsNotNone(target, "autonomous loop must have an explicit overworld branch")
        calls = [node for statement in target.body for node in ast.walk(statement) if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "_release_all"]
        self.assertEqual(calls, [], "key release inside the overworld branch cancels the timed movement pulse")
        status_source = __import__("inspect").getsource(__import__("gentc_ai.integration.undertale_agent", fromlist=["UndertaleRuntime"]).UndertaleRuntime.status)
        self.assertIn('"input_diagnostics"', status_source); self.assertIn('"agent_diagnostics"', status_source)


if __name__ == "__main__": unittest.main()
