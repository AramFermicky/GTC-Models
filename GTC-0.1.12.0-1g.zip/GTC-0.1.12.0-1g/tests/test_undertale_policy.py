from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from gentc_ai.integration.undertale_agent import UndertalePilot, UndertaleRuntime
from gentc_ai.integration.undertale_learning import UndertaleLearningMemory
from gentc_ai.integration.undertale_policy import (
    INPUT_SIZE, HIDDEN_1, HIDDEN_2, OUTPUT_SIZE, POLICY_ACTIONS, UndertalePolicyNetwork,
)


class UndertalePolicyNetworkTests(unittest.TestCase):
    def test_encoder_has_fixed_finite_shape(self):
        features = UndertalePolicyNetwork.encode_state([0, 4, 8] * 48, "sans_battle", {
            "width": 320, "height": 240,
            "battle_visible": True,
            "soul": {"x": 100, "y": 120, "mode": "blue"},
            "arena": {"left": 50, "right": 270, "top": 70, "bottom": 190},
            "hazard_pixels": 123,
        })
        self.assertEqual(len(features), INPUT_SIZE)
        self.assertTrue(all(0.0 <= value <= 1.0 for value in features))
        self.assertEqual(INPUT_SIZE, 172)

    def test_encoder_includes_prior_action_and_recent_feedback(self):
        from gentc_ai.integration.undertale_policy import POLICY_ACTIONS
        vector = UndertalePolicyNetwork.encode_state(
            [0] * 144, "overworld", {"width": 320, "height": 240},
            previous_action="right", no_progress_streak=10, last_reward=-0.5,
            last_danger_delta=0.25)
        context_start = 153
        action_index = POLICY_ACTIONS.index("right")
        action_context = vector[context_start:context_start + len(POLICY_ACTIONS)]
        self.assertEqual(len(vector), 172)
        self.assertEqual(action_context[action_index], 1.0)
        self.assertEqual(sum(action_context), 1.0)
        self.assertAlmostEqual(vector[-3], 0.2)
        self.assertAlmostEqual(vector[-2], -0.5)
        self.assertAlmostEqual(vector[-1], 0.25)

    def test_architecture_is_larger_than_prior_single_hidden_layer(self):
        with tempfile.TemporaryDirectory() as tmp:
            network = UndertalePolicyNetwork(Path(tmp) / "model.json")
            status = network.status()
            self.assertEqual(status["architecture"], "172-128-96-16")
            self.assertGreater(status["parameters"], 35000)
            self.assertEqual(OUTPUT_SIZE, len(POLICY_ACTIONS))
            self.assertFalse(network.is_active)

    def test_training_gates_network_and_persists_weights(self):
        with tempfile.TemporaryDirectory() as tmp:
            model_path = Path(tmp) / "model.json"
            network = UndertalePolicyNetwork(model_path, minimum_samples=20, minimum_actions=3)
            samples = []
            for i in range(24):
                action = ("left", "right", "up")[i % 3]
                state = [0.0] * INPUT_SIZE
                state[i % INPUT_SIZE] = 1.0
                samples.append({"features": state, "action": action,
                                "target": (-0.2 if i % 2 else 0.5), "weight": 1.0})
            result = network.fit(samples, total_examples=24, epochs=1)
            self.assertTrue(result["trained"])
            self.assertTrue(network.is_active)
            self.assertTrue(model_path.exists())
            scores = network.predict([0.0] * INPUT_SIZE)
            self.assertEqual(set(scores), set(POLICY_ACTIONS))
            restored = UndertalePolicyNetwork(model_path, minimum_samples=20, minimum_actions=3)
            self.assertTrue(restored.is_active)
            self.assertEqual(restored.training_samples, 24)
            self.assertEqual(restored.training_updates, 1)

    def test_v2_model_migrates_and_preserves_existing_weights(self):
        import json
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "model.json"
            w1 = [[0.0] * 171 for _ in range(HIDDEN_1)]
            w1[0][0] = 0.123
            w1[0][168] = 0.456
            w2 = [[0.0] * HIDDEN_1 for _ in range(HIDDEN_2)]
            w3 = [[0.0] * HIDDEN_2 for _ in range(15)]
            w3[0][0] = 0.789
            legacy = {
                "schema_version": 2, "input_size": 171, "hidden_1": HIDDEN_1,
                "hidden_2": HIDDEN_2, "output_size": 15,
                "w1": w1, "b1": [0.0] * HIDDEN_1,
                "w2": w2, "b2": [0.0] * HIDDEN_2,
                "w3": w3, "b3": [0.0] * 15,
                "training_samples": 120, "trained_actions": ["left", "right", "up"],
                "training_updates": 8,
            }
            path.write_text(json.dumps(legacy), encoding="utf-8")
            network = UndertalePolicyNetwork(path)
            self.assertEqual(network.status()["architecture"], "172-128-96-16")
            self.assertAlmostEqual(network.w1[0][0], 0.123)
            self.assertAlmostEqual(network.w1[0][168], 0.0)
            self.assertAlmostEqual(network.w1[0][169], 0.456)
            self.assertAlmostEqual(network.w3[0][0], 0.789)
            self.assertEqual(network.training_samples, 120)
            self.assertEqual(network.training_updates, 8)
            self.assertIn("menu", POLICY_ACTIONS)
            self.assertIn("migrated", network.load_warning or "")
            saved = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(saved["schema_version"], 3)
            self.assertEqual(saved["input_size"], 172)

    def test_bad_model_file_falls_back_without_crashing(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "model.json"
            path.write_text("{bad json", encoding="utf-8")
            network = UndertalePolicyNetwork(path)
            self.assertFalse(network.is_active)
            self.assertIsNotNone(network.load_warning)
            self.assertTrue((Path(tmp) / "model.legacy-backup.json").exists())


class UndertalePersistentTimelineTests(unittest.TestCase):
    def test_policy_examples_and_key_timeline_are_persistent(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "undertale.sqlite3"
            memory = UndertaleLearningMemory(path)
            features = [0.25] * INPUT_SIZE
            memory.record("overworld", "s1", "right", "s2", 0.5, 0.2,
                          {"feedback": "test"}, policy_features=features)
            memory.record_demonstration("overworld", "s1", "left", "s2", 0.2, 0.1,
                                        {"keys": ["left"]}, policy_features=features)
            memory.record_human_key_event("overworld", "s1", "left", "down", ["left"], [0] * 144,
                                          {"elapsed_since_agent_start_s": 0.2})
            memory.record_human_key_event("overworld", "s2", "left", "up", [], [1] * 144,
                                          {"elapsed_since_agent_start_s": 0.3})
            self.assertEqual(memory.policy_example_count(), 2)
            batch = memory.policy_training_examples(limit=32)
            self.assertEqual(len(batch), 2)
            self.assertEqual({item["source"] for item in batch}, {"human_demo", "autonomous_reward"})
            stats = memory.stats()
            self.assertEqual(stats["human_key_events"], 2)
            self.assertEqual(stats["policy_examples_persistent"], 2)
            memory.close()
            restored = UndertaleLearningMemory(path)
            self.assertEqual(restored.policy_example_count(), 2)
            self.assertEqual(restored.stats()["human_key_events"], 2)
            restored.close()

    def test_legacy_153_feature_examples_remain_trainable(self):
        with tempfile.TemporaryDirectory() as tmp:
            memory = UndertaleLearningMemory(Path(tmp) / "undertale.sqlite3")
            try:
                memory.db.execute(
                    "INSERT INTO policy_examples(ts,mode,action,features_json,target,source,sample_weight) VALUES(?,?,?,?,?,?,?)",
                    (1.0, "overworld", "right", __import__("json").dumps([0.0] * 153), 0.2, "autonomous_reward", 1.0))
                memory.db.commit()
                batch = memory.policy_training_examples(limit=32)
                self.assertEqual(len(batch), 1)
                self.assertEqual(len(batch[0]["features"]), INPUT_SIZE)
                self.assertEqual(batch[0]["features"][153], 1.0)  # prior action = none
                self.assertEqual(batch[0]["features"][-3:], [0.0, 0.0, 0.0])
            finally:
                memory.close()

    def test_f7_pauses_and_f8_enables_without_toggle_semantics(self):
        with tempfile.TemporaryDirectory() as tmp, patch(
            "gentc_ai.integration.undertale_agent._local_data_dir", return_value=Path(tmp)
        ):
            pilot = UndertalePilot(UndertaleRuntime())
            try:
                pilot._apply_hotkey("f8")
                self.assertTrue(pilot.armed)
                pilot._apply_hotkey("f8")
                self.assertTrue(pilot.armed, "repeated F8 must not switch autonomy off")
                pilot._apply_hotkey("f7")
                self.assertFalse(pilot.armed)
                pilot._apply_hotkey("f7")
                self.assertFalse(pilot.armed, "repeated F7 must keep human-learning mode active")
                pilot._apply_hotkey("f8")
                self.assertTrue(pilot.armed)
            finally:
                pilot.memory.close()


if __name__ == "__main__":
    unittest.main()
