from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from gentc_ai.core.agent_brain import AgentBrain, SimulatedEmotionModel
from gentc_ai.core.semantic_layer import COMMON_SEMANTICS, SemanticActionLayer
from gentc_ai.learning.reflective_learner import ReflectiveLearner


class SimulatedEmotionTests(unittest.TestCase):
    def test_event_changes_bounded_state(self):
        model = SimulatedEmotionModel()
        start = model.initial_state({"trust": 0.9, "frustration": 0.0})
        result = model.apply_event(start, {"kind": "promise_broken"})
        self.assertLess(result["trust"], start["trust"])
        self.assertGreater(result["frustration"], start["frustration"])
        self.assertTrue(all(0.0 <= value <= 1.0 for value in result.values()))

    def test_decay_reduces_transient_emotions_but_trust_decays_slowly(self):
        model = SimulatedEmotionModel()
        state = model.initial_state({"fear": 0.9, "trust": 0.9})
        result = model.decay(state, steps=5)
        self.assertLess(result["fear"], state["fear"])
        self.assertGreater(result["trust"], result["fear"])

    def test_invalid_decay_steps_fall_back_without_exception(self):
        model = SimulatedEmotionModel()
        state = model.initial_state({"fear": 0.8})
        result = model.decay(state, steps="not-a-number")
        self.assertGreaterEqual(result["fear"], 0.0)
        self.assertLessEqual(result["fear"], 1.0)


class AutonomyTests(unittest.TestCase):
    def setUp(self):
        self.profile = {
            "values": {"curiosity": 0.9, "self_preservation": 0.8, "empathy": 0.8, "benevolence": 0.7},
            "ethics": {"forbidden_tags": ["coercion"], "maximum_unconsented_harm": 0.25},
            "autonomy": {
                "goals": {"learn_world": 0.8, "stay_safe": 0.7},
                "minimum_evidence_confidence": 0.5,
                "maximum_risk": 0.65,
            },
        }
        self.world = {
            "goal_priorities": {"learn_world": 0.9, "stay_safe": 0.7},
            "needs": {"curiosity": 0.8, "safety": 0.7, "rest": 0.2},
        }
        self.safe_action = {
            "action": "observe_ridge", "semantic_action": "observe", "preconditions_met": True,
            "evidence_confidence": 0.95, "risk": 0.1, "cost": 0.15,
            "goal_progress": {"learn_world": 0.45, "stay_safe": 0.2},
            "need_effects": {"curiosity": 0.2, "safety": 0.1},
        }

    def test_hard_constraints_override_a_high_goal_score(self):
        bad = {
            "action": "threaten_npc", "semantic_action": "social_interaction",
            "preconditions_met": True, "evidence_confidence": 0.99, "risk": 0.1, "cost": 0.1,
            "tags": ["coercion"], "goal_progress": {"learn_world": 1.0},
        }
        result = AgentBrain(self.profile).choose_action(self.world, [bad, self.safe_action])
        self.assertEqual(result["chosen_action_name"], "observe_ridge")
        self.assertEqual(result["rejected_candidates"][0]["reason"], "forbidden_ethics_tag:coercion")

    def test_missing_preconditions_cannot_be_chosen(self):
        unknown = dict(self.safe_action, action="maybe_move", preconditions_met=False)
        result = AgentBrain(self.profile).choose_action(self.world, [unknown])
        self.assertEqual(result["decision"], "pause_and_observe")
        self.assertEqual(result["rejected_candidates"][0]["reason"], "preconditions_not_verified")

    def test_unknown_risk_or_cost_is_rejected(self):
        candidate = dict(self.safe_action)
        candidate.pop("risk")
        result = AgentBrain(self.profile).choose_action(self.world, [candidate])
        self.assertEqual(result["decision"], "pause_and_observe")
        self.assertEqual(result["rejected_candidates"][0]["reason"], "risk_not_verified_or_out_of_range")

    def test_unconsented_harm_is_rejected(self):
        harmful = dict(self.safe_action, action="take_item", stakeholder_impact=[{"target_id": "npc_1", "harm": 0.8, "benefit": 0.1, "consent": False}])
        result = AgentBrain(self.profile).choose_action(self.world, [harmful])
        self.assertEqual(result["decision"], "pause_and_observe")
        self.assertEqual(result["rejected_candidates"][0]["reason"], "unconsented_harm_above_limit")

    def test_candidate_order_does_not_change_tie_breaking(self):
        first = dict(self.safe_action, action="observe_z")
        second = dict(self.safe_action, action="observe_a")
        result_a = AgentBrain(self.profile).choose_action(self.world, [first, second])
        result_b = AgentBrain(self.profile).choose_action(self.world, [second, first])
        self.assertEqual(result_a["chosen_action_name"], result_b["chosen_action_name"])

    def test_malformed_learning_count_does_not_crash_action_selection(self):
        class BrokenLearner:
            def estimate(self, semantic_action, context_tags):
                return {"count": "not-a-number", "mean_reward": -1.0, "confidence": 1.0}
        result = AgentBrain(self.profile, BrokenLearner()).choose_action(self.world, [self.safe_action])
        self.assertEqual(result["chosen_action_name"], "observe_ridge")
        self.assertEqual(result["ranked_candidates"][0]["score_parts"]["learned_outcome_adjustment"], 0.0)


class SemanticLayerTests(unittest.TestCase):
    def test_known_and_unknown_semantics_are_explicit(self):
        known = SemanticActionLayer.normalize_action({"name": "look_at", "semantic_action": "observe"})
        unknown = SemanticActionLayer.normalize_action({"name": "odd_action", "semantic_action": "magic"})
        self.assertIn("observe", COMMON_SEMANTICS)
        self.assertEqual(known["semantic_action"], "observe")
        self.assertEqual(unknown["semantic_action"], "unknown")
        self.assertFalse(unknown["semantic_mapping_valid"])
        medium = SemanticActionLayer.normalize_action({"name": "attack", "semantic_action": "attack", "risk": "medium"})
        self.assertEqual(medium["risk"], 0.5)

    def test_same_semantics_do_not_claim_identical_game_mechanics(self):
        result = SemanticActionLayer.same_concept(
            {"semantic_action": "resource_gathering", "action": "chop_tree"},
            {"semantic_action": "resource_gathering", "action": "mine_iron"},
        )
        self.assertTrue(result["same_declared_semantic"])
        self.assertFalse(result["mechanics_equivalent"])


class ReflectiveLearnerTests(unittest.TestCase):
    def test_unverified_or_unexecuted_actions_are_not_learned(self):
        with tempfile.TemporaryDirectory() as tmp:
            learner = ReflectiveLearner(Path(tmp))
            ignored = learner.record(
                {"context_tags": ["forest"]}, {"semantic_action": "exploration"},
                {"verified": False, "execution_confirmed": False, "goal_achieved": True},
            )
            self.assertTrue(ignored["ignored"])
            self.assertEqual(learner.estimate("exploration", ["forest"])["count"], 0)

    def test_verified_failure_generates_lesson_and_reduces_expected_reward(self):
        with tempfile.TemporaryDirectory() as tmp:
            learner = ReflectiveLearner(Path(tmp), learning_rate=0.3)
            situation = {"context_tags": ["forest", "poor_visibility"]}
            action = {"action": "scout_area", "semantic_action": "exploration"}
            result = learner.record(situation, action, {
                "verified": True, "execution_confirmed": True,
                "goal_achieved": False, "constraints_respected": True,
                "observed_harm": 0.0, "failure_reason": "target_not_found",
            })
            self.assertTrue(result["stored"])
            estimate = learner.estimate("exploration", ["forest", "poor_visibility"])
            self.assertEqual(estimate["count"], 1)
            self.assertLess(estimate["mean_reward"], 0)
            self.assertEqual(estimate["lessons"][0]["failure_reason"], "target_not_found")
            self.assertTrue(learner.policy_path.exists())
            self.assertTrue(learner.log_path.exists())

    def test_repeated_confirmed_failures_can_change_action_choice(self):
        with tempfile.TemporaryDirectory() as tmp:
            profile = {
                "values": {"curiosity": 0.9, "self_preservation": 0.8, "empathy": 0.7, "benevolence": 0.7},
                "autonomy": {"goals": {"learn_world": 0.85, "stay_safe": 0.65},
                             "maximum_risk": 0.70, "minimum_evidence_confidence": 0.55,
                             "learning_influence": 0.35},
            }
            world = {"goal_priorities": {"learn_world": 0.85, "stay_safe": 0.65},
                     "needs": {"curiosity": 0.85, "safety": 0.60}}
            candidates = [
                {"action": "scout_area", "semantic_action": "exploration", "preconditions_met": True,
                 "evidence_confidence": 0.86, "risk": 0.25, "cost": 0.30,
                 "context_tags": ["forest", "poor_visibility"],
                 "goal_progress": {"learn_world": 0.80, "stay_safe": -0.10},
                 "need_effects": {"curiosity": 0.50}},
                {"action": "observe_from_cover", "semantic_action": "observe", "preconditions_met": True,
                 "evidence_confidence": 0.95, "risk": 0.08, "cost": 0.18,
                 "context_tags": ["forest", "poor_visibility"],
                 "goal_progress": {"learn_world": 0.38, "stay_safe": 0.20},
                 "need_effects": {"curiosity": 0.20, "safety": 0.10}},
            ]
            emotions = SimulatedEmotionModel().initial_state({"curiosity": 0.77, "confidence": 0.35})
            before = AgentBrain(profile).choose_action(world, candidates, emotions)
            learner = ReflectiveLearner(Path(tmp))
            for _ in range(3):
                learner.record(
                    {"context_tags": ["forest", "poor_visibility"]},
                    {"semantic_action": "exploration"},
                    {"verified": True, "execution_confirmed": True, "goal_achieved": False,
                     "constraints_respected": True, "observed_harm": 0.0, "failure_reason": "target_not_found"},
                )
            after = AgentBrain(profile, learner).choose_action(world, candidates, emotions)
            self.assertEqual(before["chosen_action_name"], "scout_area")
            self.assertEqual(after["chosen_action_name"], "observe_from_cover")

    def test_harmful_outcome_creates_lesson_even_if_goal_was_achieved(self):
        with tempfile.TemporaryDirectory() as tmp:
            learner = ReflectiveLearner(Path(tmp))
            result = learner.record(
                {"context_tags": ["village"]}, {"semantic_action": "trade"},
                {"verified": True, "execution_confirmed": True, "goal_achieved": True,
                 "constraints_respected": False, "observed_harm": 0.8},
            )
            self.assertTrue(result["stored"])
            estimate = learner.estimate("trade", ["village"])
            self.assertEqual(estimate["success_rate"], 0.0)
            self.assertEqual(estimate["lessons"][0]["failure_reason"], "unintended_harm")

    def test_constraints_violation_is_penalized_more_than_recoverable_failure(self):
        reward_normal, _ = ReflectiveLearner._calculate_reward({
            "goal_achieved": False, "constraints_respected": True,
            "observed_harm": 0.0, "failure_reason": "target_not_found",
        })
        reward_violation, _ = ReflectiveLearner._calculate_reward({
            "goal_achieved": False, "constraints_respected": False,
            "observed_harm": 1.0, "failure_reason": "unintended_harm",
        })
        self.assertLess(reward_violation, reward_normal)

    def test_data_survives_reload_and_global_estimate_is_available(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)
            learner = ReflectiveLearner(path)
            learner.record(
                {"context_tags": ["forest"]}, {"semantic_action": "resource_gathering"},
                {"verified": True, "execution_confirmed": True, "goal_achieved": True,
                 "constraints_respected": True, "observed_harm": 0.0},
            )
            reloaded = ReflectiveLearner(path)
            self.assertEqual(reloaded.estimate("resource_gathering", ["forest"])["count"], 1)
            self.assertEqual(reloaded.estimate("resource_gathering", ["village"])["count"], 1)
            self.assertEqual(list(path.glob(".reflective_policy_*.tmp")), [])

    def test_corrupt_policy_file_falls_back_without_deleting_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)
            policy = path / "reflective_policy.json"
            policy.write_text("{broken json", encoding="utf-8")
            learner = ReflectiveLearner(path)
            self.assertEqual(learner.load_warning, "policy_file_unreadable_reset_in_memory")
            self.assertEqual(learner.estimate("exploration")["count"], 0)
            self.assertEqual(policy.read_text(encoding="utf-8"), "{broken json")

    def test_non_numeric_learning_rate_uses_default(self):
        with tempfile.TemporaryDirectory() as tmp:
            learner = ReflectiveLearner(Path(tmp), learning_rate="wrong")
            self.assertEqual(learner.learning_rate, 0.20)

    def test_malformed_policy_entries_are_filtered(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)
            (path / "reflective_policy.json").write_text(json.dumps({
                "schema_version": 1, "policies": {"bad": "not-an-object"}, "lessons": "bad-list"
            }), encoding="utf-8")
            learner = ReflectiveLearner(path)
            self.assertEqual(learner.data["policies"], {})
            self.assertEqual(learner.data["lessons"], [])


if __name__ == "__main__":
    unittest.main()
