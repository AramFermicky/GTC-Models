from __future__ import annotations

import unittest
import tempfile
from pathlib import Path
from unittest.mock import patch, Mock

from gentc_ai.integration.undertale_agent import (Frame, analyze_frame, UndertalePilot, UndertaleRuntime,
                                                   _select_game_window_candidate)


def synthetic_battle(width: int = 320, height: int = 240, soul_mode: str = "red") -> Frame:
    buf = bytearray(width * height * 4)
    def paint(x: int, y: int, r: int, g: int, b: int) -> None:
        i = (y * width + x) * 4
        buf[i:i + 4] = bytes((b, g, r, 255))
    left, right = width // 4, width * 3 // 4
    top, bottom = height * 27 // 100, height * 77 // 100
    for x in range(left, right + 1):
        paint(x, top, 255, 255, 255)
        paint(x, bottom, 255, 255, 255)
    for y in range(top, bottom + 1):
        paint(left, y, 255, 255, 255)
        paint(right, y, 255, 255, 255)
    cx, cy = width // 2, height // 2
    color = (255, 0, 0) if soul_mode == "red" else (0, 0, 255)
    for y in range(cy - 3, cy + 4):
        for x in range(cx - 3, cx + 4):
            paint(x, y, *color)
    return Frame(width, height, bytes(buf), width * 2, height * 2)


class UndertaleVisionTests(unittest.TestCase):
    def test_window_selector_prefers_real_game_executable_over_larger_bridge_title(self):
        candidates = [
            {"hwnd": 6750292, "title": "GTC Undertale Bridge --bridge-helper", "pid": 18380,
             "width": 1184, "height": 608, "process_path": r"C:\GTC\python.exe"},
            {"hwnd": 1971266, "title": "UNDERTALE", "pid": 14644,
             "width": 1024, "height": 576, "process_path": r"C:\Games\Undertale\UNDERTALE.exe"},
        ]
        selected, reason = _select_game_window_candidate(
            candidates, target_title="Undertale",
            target_executable=r"C:\Games\Undertale\UNDERTALE.exe", own_pid=18380,
        )
        self.assertEqual(selected["hwnd"], 1971266)
        self.assertEqual(reason, "exact_target_executable_path")

    def test_window_selector_never_uses_other_process_that_copies_game_title(self):
        candidates = [
            {"hwnd": 5, "title": "UNDERTALE - launcher", "pid": 56,
             "width": 1600, "height": 900, "process_path": r"C:\Tools\launcher.exe"},
            {"hwnd": 6, "title": "UNDERTALE", "pid": 66,
             "width": 1024, "height": 576, "process_path": None},
        ]
        selected, reason = _select_game_window_candidate(
            candidates, target_title="Undertale",
            target_executable=r"C:\Games\Undertale\UNDERTALE.exe", own_pid=55,
        )
        self.assertEqual(selected["hwnd"], 6)
        self.assertEqual(reason, "exact_title_process_path_unavailable")

    def test_window_selector_rejects_bridge_process_even_without_helper_marker(self):
        candidates = [
            {"hwnd": 5, "title": "UNDERTALE", "pid": 55,
             "width": 1600, "height": 900, "process_path": r"C:\GTC\gtc_bridge.exe"},
        ]
        selected, reason = _select_game_window_candidate(
            candidates, target_title="Undertale",
            target_executable=r"C:\Games\Undertale\UNDERTALE.exe", own_pid=99,
        )
        self.assertIsNone(selected)
        self.assertEqual(reason, "no_eligible_game_window")

    def test_red_soul_and_arena_detected_from_synthetic_frame(self):
        obs = analyze_frame(synthetic_battle())
        self.assertTrue(obs.battle_visible)
        self.assertEqual(obs.soul["mode"], "red")
        self.assertGreaterEqual(obs.soul["confidence"], 0.5)
        self.assertIsNotNone(obs.arena)
        self.assertLess(obs.arena["left"], obs.soul["x"])
        self.assertGreater(obs.arena["right"], obs.soul["x"])

    def test_blue_soul_is_classified(self):
        obs = analyze_frame(synthetic_battle(soul_mode="blue"))
        self.assertTrue(obs.battle_visible)
        self.assertEqual(obs.soul["mode"], "blue")

    def test_empty_frame_does_not_trigger_battle(self):
        frame = Frame(320, 240, bytes(320 * 240 * 4))
        obs = analyze_frame(frame)
        self.assertFalse(obs.battle_visible)
        self.assertIsNone(obs.soul)

    def test_action_is_from_declared_set(self):
        frame = synthetic_battle()
        obs = analyze_frame(frame)
        pilot = UndertalePilot(UndertaleRuntime())
        try:
            action = pilot.choose_action(frame, obs)
            self.assertIn(action, {"none", "left", "right", "up", "down", "up_left", "up_right", "down_left", "down_right"})
        finally:
            pilot.memory.close()

    def test_human_demo_keys_map_to_available_game_actions(self):
        with tempfile.TemporaryDirectory() as tmp, patch(
            "gentc_ai.integration.undertale_agent._local_data_dir", return_value=Path(tmp)
        ):
            pilot = UndertalePilot(UndertaleRuntime())
            try:
                self.assertEqual(pilot._human_action_names({"right"}, "overworld", "red"), ["right"])
                self.assertEqual(pilot._human_action_names({"z"}, "overworld", "red"), ["interact"])
                self.assertEqual(pilot._human_action_names({"x"}, "overworld", "red"), ["cancel"])
                self.assertEqual(pilot._human_action_names({"c"}, "overworld", "red"), ["menu"])
                self.assertEqual(pilot._human_action_names({"ctrl"}, "overworld", "red"), ["menu"])
                self.assertEqual(pilot._human_action_names({"up", "left"}, "sans_battle", "red"), ["up_left"])
                self.assertEqual(pilot._human_action_names({"up", "left"}, "sans_battle", "blue"), ["left_jump"])
            finally:
                pilot.memory.close()

    def test_runtime_status_is_structured_off_windows(self):
        with patch("gentc_ai.integration.undertale_agent.is_windows_platform", return_value=False):
            result = UndertaleRuntime().status()
        self.assertIn("platform_supported", result)
        self.assertFalse(result["platform_supported"])

    def test_launch_does_not_block_on_window_discovery(self):
        from pathlib import Path
        from gentc_ai.integration import undertale_agent
        runtime = UndertaleRuntime()
        exe = Path("/tmp/UNDERTALE.exe")
        fake_process = Mock()
        fake_process.pid = 12345
        fake_process.poll.return_value = None
        with patch("gentc_ai.integration.undertale_agent.os.name", "nt"), \
             patch("gentc_ai.integration.undertale_agent.locate_undertale_exe", return_value=exe), \
             patch("gentc_ai.integration.undertale_agent.subprocess.Popen", return_value=fake_process) as popen, \
             patch.object(runtime, "_windows", side_effect=AssertionError("window scan must be deferred")):
            result = runtime.launch()
        popen.assert_called_once_with([str(exe)], cwd=str(exe.parent))
        self.assertTrue(result["ok"])
        self.assertEqual(result["pid"], 12345)
        self.assertIsNone(result["window_found"])
        self.assertIn("deferred", result["window_check"])


class UndertaleClientBridgeVersionTests(unittest.TestCase):
    def test_client_refuses_to_connect_to_old_bridge(self):
        from gentc_ai.integration import undertale_client
        with patch.object(undertale_client, "request", return_value={"ok": True, "version": "0.1.12"}), \
             patch("builtins.print") as printer:
            self.assertFalse(undertale_client.wait_for_bridge(seconds=0.1))
        printer.assert_called()



    def test_client_refuses_wrong_game_profile(self):
        from gentc_ai.integration import undertale_client
        from gentc_ai.version import VERSION, BUILD_ID
        payloads = {
            "/health": {"ok": True, "version": VERSION, "build_id": BUILD_ID},
            "/undertale/status": {"service": "visual_game_pilot", "adapter_version": f"{BUILD_ID}-permanent-game-analysis",
                                   "game_profile": {"game_id": "platformer"}},
        }
        with patch.object(undertale_client, "request", side_effect=lambda path, *a, **k: payloads[path]):
            self.assertFalse(undertale_client.wait_for_bridge(seconds=0.1, expected_game_id="other_game"))

    def test_client_refuses_to_connect_to_old_same_version_bridge_build(self):
        from gentc_ai.integration import undertale_client
        from gentc_ai.version import VERSION
        with patch.object(undertale_client, "request", return_value={
            "ok": True, "version": VERSION, "build_id": "0.1.10.29-1r"}), \
             patch("builtins.print") as printer:
            self.assertFalse(undertale_client.wait_for_bridge(seconds=0.1))
        printer.assert_called()


if __name__ == "__main__":
    unittest.main()
