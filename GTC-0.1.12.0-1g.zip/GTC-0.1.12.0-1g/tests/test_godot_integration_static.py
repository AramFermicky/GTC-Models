"""Static integration checks; these do not replace running Godot itself."""
from pathlib import Path
import unittest

PROJECT_ROOT = Path(__file__).resolve().parents[1]
GODOT_SOURCE_FILES = (
    "project.godot",
    "scripts/gtc/GTCGirlLab.gd",
    "scripts/gtc/AnnaNPC.gd",
    "scripts/ui/MainMenu.gd",
    "scenes/main/Main.tscn",
    "scenes/gtc/AnnaNPC.tscn",
)
HAS_GODOT_SOURCE = all((PROJECT_ROOT / item).is_file() for item in GODOT_SOURCE_FILES)


@unittest.skipUnless(HAS_GODOT_SOURCE, "Godot gameplay project files are not included in this GTC source archive")
class GodotIntegrationStaticTests(unittest.TestCase):
    def test_lab_uses_supported_tapered_mesh_not_conemesh(self):
        source = (PROJECT_ROOT / "scripts/gtc/GTCGirlLab.gd").read_text(encoding="utf-8")
        self.assertNotIn("ConeMesh.new()", source)
        self.assertIn("var cone := CylinderMesh.new()", source)
        self.assertIn("cone.top_radius = 0.0", source)

    def test_unused_world_materials_variable_is_removed(self):
        source = (PROJECT_ROOT / "scripts/gtc/GTCGirlLab.gd").read_text(encoding="utf-8")
        self.assertNotIn("_world_materials", source)

    def test_main_scene_instantiates_anna(self):
        scene = (PROJECT_ROOT / "scenes/main/Main.tscn").read_text(encoding="utf-8")
        self.assertIn('path="res://scenes/gtc/AnnaNPC.tscn" id="12_anna"', scene)
        self.assertIn('[node name="AnnaGTC" parent="." instance=ExtResource("12_anna")]', scene)

    def test_anna_is_reachable_after_main_menu_and_has_player_collision(self):
        menu = (PROJECT_ROOT / "scripts/ui/MainMenu.gd").read_text(encoding="utf-8")
        anna_scene = (PROJECT_ROOT / "scenes/gtc/AnnaNPC.tscn").read_text(encoding="utf-8")
        self.assertIn('const GAME_SCENE_PATH: String = "res://scenes/main/Main.tscn"', menu)
        self.assertIn("collision_layer = 3", anna_scene)

    def test_feedback_queue_persists_across_game_sessions(self):
        script = (PROJECT_ROOT / "scripts/gtc/AnnaNPC.gd").read_text(encoding="utf-8")
        self.assertIn('const FEEDBACK_QUEUE_PATH: String = "user://gtc_pending_feedback.json"', script)
        self.assertIn("_load_feedback_queue()", script)
        self.assertIn("_save_feedback_queue()", script)
        self.assertIn("_flush_feedback_queue()", script)
        self.assertIn('"experience_id":', script)

    def test_anna_uses_stable_targets_and_reports_navigation_failures(self):
        script = (PROJECT_ROOT / "scripts/gtc/AnnaNPC.gd").read_text(encoding="utf-8")
        self.assertIn("_stable_object_id(tree_node, \"tree\")", script)
        self.assertIn("_stable_object_id(berry_node, \"food\")", script)
        self.assertIn("_remaining_target_cooldowns()", script)
        self.assertIn("movement_stuck_collision", script)
        self.assertIn("_detour_original_target", script)
        self.assertNotIn("target_value as Vector3", script)

    def test_anna_uses_character_body_and_terrain_collision(self):
        scene = (PROJECT_ROOT / "scenes/gtc/AnnaNPC.tscn").read_text(encoding="utf-8")
        script = (PROJECT_ROOT / "scripts/gtc/AnnaNPC.gd").read_text(encoding="utf-8")
        self.assertIn('[node name="AnnaGTC" type="CharacterBody3D"]', scene)
        self.assertIn("collision_mask = 1", script)
        self.assertIn("floor_snap_length = 0.45", script)
        self.assertIn("move_and_slide()", script)
        self.assertIn("get_terrain_height_at_world", script)


if __name__ == "__main__":
    unittest.main()
