from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from gentc_ai.continuity.world_memory import WorldMemoryStore


IDENTITY = "gtc.god.canon"


def confirmed_outcome(goal: bool = True, harm: float = 0.0) -> dict:
    return {
        "verified": True,
        "execution_confirmed": True,
        "constraints_respected": True,
        "goal_achieved": goal,
        "observed_harm": harm,
        "unexpected_cost": 0.0,
    }


class TestWorldMemoryStore(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.store = WorldMemoryStore(Path(self.temp.name) / "world_memory.sqlite3")

    def tearDown(self) -> None:
        self.temp.cleanup()

    def _register(self, game: str = "gtc_god_world", world: str = "god_world_main", session: str = "session_1") -> None:
        self.store.register_world(identity_id=IDENTITY, game_id=game, world_id=world,
                                  world_name="Test World", game_version="0.1.8",
                                  adapter_version="test-adapter", session_id=session,
                                  summary={"alive_count": 3})

    def test_world_registry_is_idempotent_per_session_and_survives_reopen(self) -> None:
        self._register()
        self._register()
        self._register(session="session_2")
        report = self.store.report(identity_id=IDENTITY)
        self.assertEqual(report["worlds"], 1)
        self.assertEqual(report["sessions"], 2)
        self.assertEqual(report["database_path"], str(Path(self.temp.name) / "world_memory.sqlite3"))
        reopened = WorldMemoryStore(Path(self.temp.name) / "world_memory.sqlite3")
        self.assertEqual(reopened.report(identity_id=IDENTITY)["sessions"], 2)

    def test_only_confirmed_outcome_is_training_eligible(self) -> None:
        self._register()
        safe = self.store.record_experience(
            identity_id=IDENTITY, game_id="gtc_god_world", world_id="god_world_main", session_id="session_1",
            runtime_version="0.1.8", situation={"unrest": 0.2},
            action={"action": "bless", "semantic_action": "care"}, outcome=confirmed_outcome(),
            features=[0.1] * 22,
        )
        self.assertTrue(safe["training_eligible"])
        unverified = self.store.record_experience(
            identity_id=IDENTITY, game_id="gtc_god_world", world_id="god_world_main", session_id="session_1",
            runtime_version="0.1.8", situation={}, action={"action": "smite", "semantic_action": "divine_judgment"},
            outcome={"goal_achieved": True}, features=[0.2] * 22,
        )
        self.assertFalse(unverified["training_eligible"])
        self.assertEqual(len(self.store.get_training_examples(identity_id=IDENTITY, game_id="gtc_god_world")), 1)

    def test_duplicate_experience_ids_are_idempotent_and_not_double_counted(self) -> None:
        self._register()
        first = self.store.record_experience(
            identity_id=IDENTITY, game_id="gtc_god_world", world_id="god_world_main", session_id="session_1",
            runtime_version="0.1.9.2", situation={"need": "rest"},
            action={"action": "rest", "semantic_action": "rest"}, outcome=confirmed_outcome(),
            features=[0.1] * 22, experience_id="same_event_001",
        )
        duplicate = self.store.record_experience(
            identity_id=IDENTITY, game_id="gtc_god_world", world_id="god_world_main", session_id="session_2",
            runtime_version="0.1.9.2", situation={"need": "rest"},
            action={"action": "rest", "semantic_action": "rest"}, outcome=confirmed_outcome(),
            features=[0.1] * 22, experience_id="same_event_001",
        )
        self.assertTrue(first["stored"])
        self.assertFalse(first["duplicate"])
        self.assertFalse(duplicate["stored"])
        self.assertTrue(duplicate["duplicate"])
        self.assertEqual(self.store.count_training_examples(identity_id=IDENTITY, game_id="gtc_god_world"), 1)

    def test_action_estimate_uses_verified_world_history(self) -> None:
        self._register()
        self.store.record_experience(
            identity_id=IDENTITY, game_id="gtc_god_world", world_id="god_world_main", session_id="session_1",
            runtime_version="0.1.8", situation={}, action={"action": "bless", "semantic_action": "care"},
            outcome=confirmed_outcome(goal=True), features=[0.1] * 22,
        )
        estimate = self.store.get_action_estimate(identity_id=IDENTITY, game_id="gtc_god_world",
                                                  world_id="god_world_main", action_name="bless",
                                                  semantic_action="care")
        self.assertTrue(estimate["has_data"])
        self.assertGreater(estimate["mean_reward"], 0)
        self.assertGreater(estimate["confidence"], 0)

    def test_verified_mechanic_is_scoped_and_cross_game_promotion_needs_evidence(self) -> None:
        for game, world in (("game_a", "world_a"), ("game_a", "world_b"), ("game_b", "world_c")):
            self.store.register_world(identity_id=IDENTITY, game_id=game, world_id=world, session_id=f"s_{world}")
            self.store.record_mechanic(identity_id=IDENTITY, game_id=game, world_id=world,
                                       semantic_key="resource_gathering", statement="Gathering a resource costs time.",
                                       scope="world", confidence=0.8, verified=True)
        promotion = self.store.promote_mechanic(identity_id=IDENTITY, semantic_key="resource_gathering",
                                                statement="Gathering a resource costs time.")
        self.assertTrue(promotion["promoted"])
        across_game = self.store.get_mechanics(identity_id=IDENTITY, game_id="game_z", world_id="world_z")
        self.assertTrue(any(item["scope"] == "portable" for item in across_game))

    def test_unverified_mechanics_do_not_appear_in_verified_recall(self) -> None:
        self._register()
        self.store.record_mechanic(identity_id=IDENTITY, game_id="gtc_god_world", world_id="god_world_main",
                                   semantic_key="secret_rule", statement="An unconfirmed guess.",
                                   verified=False, confidence=0.9)
        self.assertEqual(self.store.get_mechanics(identity_id=IDENTITY, game_id="gtc_god_world",
                                                  world_id="god_world_main"), [])

    def test_bad_identifiers_and_nonfinite_values_are_handled(self) -> None:
        with self.assertRaises(ValueError):
            self.store.register_world(identity_id="bad id", game_id="gtc_god_world", world_id="x")
        self._register()
        experience = self.store.record_experience(
            identity_id=IDENTITY, game_id="gtc_god_world", world_id="god_world_main", session_id="session_1",
            runtime_version="0.1.8", situation={}, action={"action": "observe", "semantic_action": "observe"},
            outcome=confirmed_outcome(), features=[float("nan")] * 22,
        )
        examples = self.store.get_training_examples(identity_id=IDENTITY, game_id="gtc_god_world")
        self.assertTrue(experience["training_eligible"])
        self.assertTrue(all(v == 0.0 for v in examples[-1]["features"]))

    def test_confirmed_constraint_violation_is_negative_training_evidence(self) -> None:
        self._register()
        outcome = confirmed_outcome(goal=True)
        outcome["constraints_respected"] = False
        result = self.store.record_experience(
            identity_id=IDENTITY, game_id="gtc_god_world", world_id="god_world_main", session_id="session_1",
            runtime_version="0.1.9.3", situation={"need": "rest"},
            action={"action": "observe", "semantic_action": "observe"}, outcome=outcome,
            features=[0.1] * 22,
        )
        self.assertTrue(result["training_eligible"])
        self.assertLess(result["reward"], 0.0)
        self.assertEqual(self.store.count_training_examples(identity_id=IDENTITY, game_id="gtc_god_world"), 1)



if __name__ == "__main__":
    unittest.main()
