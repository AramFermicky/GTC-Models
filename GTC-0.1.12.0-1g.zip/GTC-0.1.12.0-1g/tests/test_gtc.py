from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from gentc_ai.adapters.contracts import AdapterManifest, validate_snapshot
from gentc_ai.continuity.store import ContinuityStore
from gentc_ai.continuity.extractor import DialogueMemoryExtractor
from gentc_ai.core.decision_engine import DecisionEngine
from gentc_ai.core.intent_parser import IntentParser
from gentc_ai.core.memory_store import MemoryStore
from gentc_ai.core.world_state import WorldStateAnalyzer
from gentc_ai.learning.train import train

PROJECT_ROOT = Path(__file__).resolve().parents[1]


class IntentParserTests(unittest.TestCase):
    def test_chop_trees_request_extracts_count(self):
        intent = IntentParser().parse("Поруби пару деревьев пожалуйста")
        self.assertEqual(intent["intent"], "chop_trees")
        self.assertEqual(intent["target_count"], 2)

    def test_transfer_axe_is_checked_before_tree_request(self):
        intent = IntentParser().parse("Дай топор, чтобы порубить деревья")
        self.assertEqual(intent["intent"], "give_item")
        self.assertEqual(intent["item_id"], "axe")

    def test_wooden_table_is_not_misclassified_as_chopping_trees(self):
        intent = IntentParser().parse("Сделай деревянный стол")
        self.assertEqual(intent["intent"], "general_dialogue")


class DecisionEngineTests(unittest.TestCase):
    def setUp(self):
        self.profile = json.loads((PROJECT_ROOT / "data" / "characters" / "anna.json").read_text(encoding="utf-8"))
        self.intent = {"intent": "chop_trees", "target_count": 2, "raw_text": "Поруби пару деревьев"}
        self.world = {
            "inventory": [],
            "npc_busy": False,
            "nearby_objects": [
                {"id": "tree_01", "type": "tree", "available": True},
                {"id": "tree_02", "type": "tree", "available": True},
            ],
        }

    def test_missing_axe_requests_tool_instead_of_claiming_success(self):
        decision = DecisionEngine().decide(self.intent, self.world, self.profile)
        self.assertEqual(decision["decision"], "request_tool")
        self.assertEqual(decision["status"], "blocked_missing_tool")
        self.assertEqual(decision["plan"], [])

    def test_axe_and_trees_produce_a_plan_not_an_execution_claim(self):
        self.world["inventory"] = ["axe"]
        decision = DecisionEngine().decide(self.intent, self.world, self.profile)
        self.assertEqual(decision["decision"], "accept")
        self.assertEqual(decision["status"], "plan_ready_not_executed")
        self.assertEqual(len(decision["planned_tree_ids"]), 2)
        self.assertEqual([item["action"] for item in decision["plan"]], ["move_to", "chop_tree", "move_to", "chop_tree"])

    def test_partial_tree_availability_is_not_reported_as_full_acceptance(self):
        self.world["inventory"] = ["axe"]
        self.world["nearby_objects"] = [{"id": "tree_01", "type": "tree", "available": True}]
        decision = DecisionEngine().decide(self.intent, self.world, self.profile)
        self.assertEqual(decision["decision"], "accept_partial")
        self.assertEqual(decision["status"], "partial_plan_ready_not_executed")
        self.assertFalse(decision["requested_trees_available"])

    def test_nearby_axe_uses_actual_object_id(self):
        self.world["nearby_objects"].append({"id": "axe_unique_77", "type": "item", "item_id": "axe", "available": True})
        decision = DecisionEngine().decide(self.intent, self.world, self.profile)
        self.assertEqual(decision["decision"], "accept_after_getting_tool")
        self.assertEqual(decision["plan"][0]["target_id"], "axe_unique_77")

    def test_missing_tree_is_reported(self):
        self.world["nearby_objects"] = []
        decision = DecisionEngine().decide(self.intent, self.world, self.profile)
        self.assertEqual(decision["status"], "blocked_no_trees")


class WorldAndMemoryTests(unittest.TestCase):
    def test_world_analyzer_finds_player(self):
        result = WorldStateAnalyzer().analyze({
            "player": {"id": "player", "position": [0, 0, 0]},
            "npcs": [],
            "objects": [],
        })
        self.assertTrue(result["valid"])
        self.assertTrue(result["player_found"])

    def test_memory_store_writes_dialogue_experience_and_event(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = MemoryStore(Path(tmp), "anna")
            store.log_dialogue("player", "Поруби пару деревьев")
            store.log_experience({"state": "no_axe"}, {"decision": "request_tool"}, {"result": "not_executed"})
            store.add_important_event("Игрок попросил помочь с деревьями.")
            self.assertTrue(store.dialogue_path.exists())
            self.assertTrue(store.experience_path.exists())
            self.assertEqual(len(store.load_memory()["important_events"]), 1)


class DialogueMemoryExtractorTests(unittest.TestCase):
    def test_explicit_memory_phrase_creates_candidate(self):
        candidate = DialogueMemoryExtractor().extract_candidate("Запомни, что я не люблю острые блюда.")
        self.assertIsNotNone(candidate)
        self.assertEqual(candidate["category"], "player_requested_memory")
        self.assertTrue(candidate["requires_confirmation"])

    def test_preference_creates_candidate_but_command_does_not(self):
        extractor = DialogueMemoryExtractor()
        candidate = extractor.extract_candidate("Мне нравится чай без сахара")
        self.assertEqual(candidate["category"], "player_preference")
        self.assertIsNone(extractor.extract_candidate("Поруби пару деревьев пожалуйста"))


class ContinuityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.store = ContinuityStore(Path(self.temp.name) / "continuity.sqlite3")
        self.store.register_identity("anna.canon", "Анна", {"continuity_mode": "shared"})
        self.store.register_incarnation("anna.canon", "cabin:anna:main", "cabin_game", "anna", "main")
        self.store.register_incarnation("anna.canon", "forest:anna:alt", "forest_game", "anna", "alt")

    def test_shared_memory_is_visible_across_games_but_game_memory_is_not(self):
        self.store.add_memory(
            "anna.canon", "Игрок ценит честные объяснения.", scope="shared", category="preference",
            source="explicit_player_confirmation", verified=True,
        )
        self.store.add_memory(
            "anna.canon", "В избушке игрок передал топор.", scope="game", game_id="cabin_game",
            category="event", source="confirmed_game_event", verified=True,
        )
        cabin = self.store.get_memories("anna.canon", game_id="cabin_game", incarnation_id="cabin:anna:main")
        forest = self.store.get_memories("anna.canon", game_id="forest_game", incarnation_id="forest:anna:alt")
        self.assertEqual(len(cabin), 2)
        self.assertEqual(len(forest), 1)
        self.assertEqual(forest[0]["scope"], "shared")

    def test_unverified_memory_cannot_be_written_to_shared_scope(self):
        with self.assertRaises(ValueError):
            self.store.add_memory("anna.canon", "Игроку нравится красный цвет.", scope="shared", verified=False)

    def test_dialogue_is_game_scoped_by_default(self):
        self.store.record_dialogue("anna.canon", "cabin_game", "cabin:anna:main", "player", "Поруби деревья.")
        self.assertEqual(self.store.get_recent_dialogue("anna.canon", game_id="forest_game", incarnation_id="forest:anna:alt"), [])
        self.assertEqual(len(self.store.get_recent_dialogue("anna.canon", game_id="forest_game", incarnation_id="forest:anna:alt", include_other_games=True)), 1)

    def test_unverified_experience_cannot_be_marked_training_eligible(self):
        with self.assertRaises(ValueError):
            self.store.record_experience(
                "anna.canon", "cabin_game", "cabin:anna:main", {}, {"action": "chop"}, {},
                training_eligible=True, verified=False,
            )

    def test_candidates_need_promotion_before_becoming_memory(self):
        candidate = self.store.propose_memory(
            "anna.canon", "cabin_game", "cabin:anna:main", "Игрок предпочитает короткие ответы.",
            category="preference", confidence=0.8,
        )
        before = self.store.get_memories("anna.canon", game_id="cabin_game", incarnation_id="cabin:anna:main")
        self.assertEqual(before, [])
        self.store.confirm_memory_candidate(candidate, scope="shared", verified=True)
        after = self.store.get_memories("anna.canon", game_id="forest_game", incarnation_id="forest:anna:alt")
        self.assertEqual(len(after), 1)

    def test_export_import_identity_bundle(self):
        self.store.add_memory("anna.canon", "Общее подтверждённое предпочтение.", scope="shared", verified=True)
        self.store.record_dialogue("anna.canon", "cabin_game", "cabin:anna:main", "player", "Поруби деревья.")
        self.store.record_experience(
            "anna.canon", "cabin_game", "cabin:anna:main",
            {"has_axe": True}, {"action": "chop_tree"}, {"status": "success"},
            semantic_action="resource_gathering", reward=1.0, verified=True,
            training_eligible=True, portable=True,
        )
        with tempfile.TemporaryDirectory() as tmp:
            bundle = self.store.export_identity_bundle(
                "anna.canon", Path(tmp) / "anna.gtc.json",
                include_dialogue=True, include_experiences=True,
            )
            imported = ContinuityStore(Path(tmp) / "imported.sqlite3")
            result = imported.import_identity_bundle(bundle)
            self.assertEqual(result["incarnations_imported"], 2)
            self.assertEqual(result["dialogue_imported"], 1)
            self.assertEqual(result["experiences_imported"], 1)
            memories = imported.get_memories("anna.canon", game_id="forest_game", incarnation_id="forest:anna:alt")
            self.assertEqual(len(memories), 1)
            dialogue = imported.get_recent_dialogue("anna.canon", game_id="cabin_game", incarnation_id="cabin:anna:main")
            self.assertEqual(dialogue[0]["content"], "Поруби деревья.")
            training = imported.get_training_examples(portable_only=True)
            self.assertEqual(len(training), 1)
            self.assertEqual(training[0]["semantic_action"], "resource_gathering")


class AdapterContractTests(unittest.TestCase):
    def test_reference_manifest_loads(self):
        manifest = AdapterManifest.from_file(PROJECT_ROOT / "protocol" / "GTC_GAME_ADAPTER_CONTRACT_V0_1.json")
        self.assertEqual(manifest.game_id, "cabin_game")
        self.assertIn("move_to", manifest.actions)

    def test_adapter_command_rejects_unknown_actions_and_missing_arguments(self):
        manifest = AdapterManifest.from_file(PROJECT_ROOT / "protocol" / "GTC_GAME_ADAPTER_CONTRACT_V0_1.json")
        with self.assertRaises(ValueError):
            manifest.build_command("delete_save", {}, "cmd-1")
        with self.assertRaises(ValueError):
            manifest.build_command("move_to", {}, "cmd-2")
        command = manifest.build_command("move_to", {"target_id": "tree_001"}, "cmd-3")
        self.assertEqual(command["game_id"], "cabin_game")

    def test_generic_snapshot_validation(self):
        example = json.loads((PROJECT_ROOT / "protocol" / "EXAMPLE_SNAPSHOT_CABIN_V0_1.json").read_text(encoding="utf-8"))
        self.assertTrue(validate_snapshot(example, "cabin_game")["valid"])
        snapshot = {
            "protocol_version": "0.1", "game_id": "cabin_game", "session_id": "s1",
            "player": {"id": "player", "position": [0, 0, 0]},
            "characters": [{"id": "anna", "position": [1, 0, 0]}],
            "objects": [{"id": "tree_1", "type": "tree"}],
            "inventories": {"anna": []}, "events": [],
        }
        report = validate_snapshot(snapshot, "cabin_game")
        self.assertTrue(report["valid"], report["issues"])
        self.assertFalse(validate_snapshot(snapshot, "other_game")["valid"])
        # A 2D game can connect through an adapter too; position dimensions are declared by its snapshot.
        snapshot_2d = dict(snapshot)
        snapshot_2d["player"] = {"id": "player", "position": [0, 0]}
        self.assertTrue(validate_snapshot(snapshot_2d, "cabin_game")["valid"])


class LearningPipelineTests(unittest.TestCase):
    def test_training_creates_table_report_and_baseline_metrics(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = train(episodes=150, seed=3, output_dir=Path(tmp))
            self.assertTrue(result["q_table_path"].exists())
            self.assertTrue(result["report_path"].exists())
            report = json.loads(result["report_path"].read_text(encoding="utf-8"))
            self.assertEqual(report["episodes"], 150)
            self.assertGreater(report["state_count"], 0)
            self.assertIn("rule_based_baseline", report["evaluation"])
            self.assertEqual(report["evaluation"]["rule_based_baseline"]["task_completion_rate_when_feasible"], 1.0)


if __name__ == "__main__":
    unittest.main()
