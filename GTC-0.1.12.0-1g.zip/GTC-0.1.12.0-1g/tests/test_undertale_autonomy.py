from __future__ import annotations

import unittest

from gentc_ai.integration.undertale_autonomy import UndertaleSelfModel, evaluate_transition


class RewardShapingTests(unittest.TestCase):
    def test_idle_is_exactly_neutral_and_not_learned(self):
        result = evaluate_transition(mode="overworld", action="none", from_state="a", to_state="a",
                                    visual_delta=0.0, new_scene=False)
        self.assertEqual(result.reward, 0.0)
        self.assertFalse(result.learn)

    def test_first_uncertain_blocked_move_is_neutral(self):
        result = evaluate_transition(mode="overworld", action="left", from_state="room", to_state="room",
                                    visual_delta=0.0, new_scene=False, repeated_blocked=1)
        self.assertEqual(result.reward, 0.0)
        self.assertFalse(result.learn)

    def test_repeated_blocked_move_receives_severe_penalty(self):
        result = evaluate_transition(mode="overworld", action="left", from_state="room", to_state="room",
                                    visual_delta=0.0, new_scene=False, repeated_blocked=2)
        self.assertEqual(result.reward, -0.90)
        self.assertTrue(result.learn)

    def test_new_room_from_movement_is_rewarded_as_weak_progress(self):
        result = evaluate_transition(mode="overworld", action="right", from_state="room-a", to_state="room-b",
                                    visual_delta=0.08, new_scene=True)
        self.assertEqual(result.reward, 0.78)
        self.assertTrue(result.learn)

    def test_damage_and_death_are_strong_only_when_explicitly_labelled(self):
        for outcome in ("damage", "death"):
            result = evaluate_transition(mode="battle", action="right", from_state="battle", to_state="battle",
                                        visual_delta=0.0, new_scene=False, explicit_outcome=outcome)
            self.assertEqual(result.reward, -1.0)
            self.assertTrue(result.learn)

    def test_battle_danger_increase_is_penalized(self):
        result = evaluate_transition(mode="battle", action="left", from_state="battle", to_state="battle",
                                    visual_delta=0.03, new_scene=False, danger_before=0.1, danger_after=0.5,
                                    hazards_before=3, hazards_after=8)
        self.assertLessEqual(result.reward, -0.5)
        self.assertTrue(result.learn)


class RoleReflectionTests(unittest.TestCase):
    def test_self_model_declares_player_role_and_decision_cycle(self):
        result = UndertaleSelfModel().describe("overworld", {"battle_visible": False},
                                                last_action="right", no_progress_streak=2,
                                                blocked_action="left", known_scenes=5, known_transitions=7)
        self.assertEqual(result["identity"], "GenTC AI")
        self.assertEqual(result["role"], "player")
        self.assertEqual(result["known_experience"], {"scenes": 5, "transitions": 7})
        self.assertIn("decision_cycle", result)
        self.assertTrue(result["available_actions"])
        self.assertEqual(result["recent_behavior"]["blocked_action"], "left")


if __name__ == "__main__":
    unittest.main()
