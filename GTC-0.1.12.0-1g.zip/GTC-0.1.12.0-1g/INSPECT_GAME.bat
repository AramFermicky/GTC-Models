@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not defined GTC_MODEL_ROOT set "GTC_MODEL_ROOT=%~dp0"
set "GAME_EXE=%~1"
if not defined GAME_EXE (
  echo [GTC] Usage: INSPECT_GAME.bat "C:\Path\To\Game.exe"
  exit /b 2
)
if not exist "%GAME_EXE%" (
  echo [GTC] Game executable not found: %GAME_EXE%
  exit /b 2
)
call :find_python
if errorlevel 1 (
  echo [GTC] Python 3.11 or newer was not found; static game inspection skipped.
  exit /b 2
)
"%PY_EXE%" -u -m gentc_ai.integration.game_introspection --exe "%GAME_EXE%"
exit /b %errorlevel%

:find_python
set "PY_EXE="
if defined GTC_PYTHON_EXE if exist "%GTC_PYTHON_EXE%" set "PY_EXE=%GTC_PYTHON_EXE%"
if not defined PY_EXE if exist "%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe" set "PY_EXE=%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe"
if not defined PY_EXE for /f "delims=" %%P in ('py -3.14 -c "import sys;print(sys.executable)" 2^>nul') do if not defined PY_EXE set "PY_EXE=%%P"
if not defined PY_EXE for /f "delims=" %%P in ('py -3 -c "import sys;print(sys.executable)" 2^>nul') do if not defined PY_EXE set "PY_EXE=%%P"
if not defined PY_EXE for /f "delims=" %%P in ('where python 2^>nul') do if not defined PY_EXE set "PY_EXE=%%P"
if not defined PY_EXE exit /b 1
"%PY_EXE%" -c "import sys;raise SystemExit(0 if sys.version_info >= (3,11) else 1)" >nul 2>&1
if errorlevel 1 exit /b 1
exit /b 0
