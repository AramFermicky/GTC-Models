@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not defined GTC_MODEL_ROOT set "GTC_MODEL_ROOT=%~dp0"
if /i "%~1"=="--bridge-helper" goto bridge_helper

if /i "%GTC_GENERIC_GAME%"=="1" (
  set "GAME_EXE=%GTC_GAME_EXE%"
  if not defined GAME_EXE (
    echo [GTC] GTC_GAME_EXE is required for generic game mode.
    pause
    exit /b 2
  )
) else (
  set "GAME_EXE=%~dp0Undertale\UNDERTALE.exe"
  if defined GTC_UNDERTALE_EXE if exist "%GTC_UNDERTALE_EXE%" set "GAME_EXE=%GTC_UNDERTALE_EXE%"
)
if not exist "%GAME_EXE%" (
  echo [GTC] The configured game executable was not found.
  echo For Undertale, place UNDERTALE.exe in the Undertale subfolder.
  echo For a different game, choose option 3 in START_GTC.bat.
  pause
  exit /b 2
)
if /i not "%GTC_GENERIC_GAME%"=="1" if not exist "%~dp0Undertale\data.win" if not defined GTC_UNDERTALE_EXE (
  echo [GTC] Warning: data.win is missing from the default Undertale folder.
  echo The game may be incomplete. Continuing because the executable exists.
)
call :find_python
if errorlevel 1 (
  echo [GTC] Python 3.11 or newer was not found.
  echo Checked the Python 3.14 install and Python Install Manager selectors.
  pause
  exit /b 2
)
echo [GTC] Python: %PY_EXE%
start "GTC Undertale Bridge" "%~f0" --bridge-helper
timeout /t 2 /nobreak >nul
if /i "%GTC_GENERIC_GAME%"=="1" (
  echo [GTC] Starting configured game and generic visual agent in PAUSED mode...
) else (
  echo [GTC] Starting Undertale and the whole-game agent in PAUSED mode...
)
"%PY_EXE%" -u -m gentc_ai.integration.undertale_client --launch --start-agent --exe-path "%GAME_EXE%"
if errorlevel 1 (
  echo [GTC] Launch request did not complete. Check the bridge console and run GTC_TOOLS.bat.
) else (
  echo.
  echo [GTC] F7 = manual play / key demonstrations. F8 = autonomous GTC control.
  echo The agent observes the foreground window even while paused.
  echo Static asset scan is in the background; true runtime internals require a game profile/state feed.
)
echo.
pause
exit /b 0

:bridge_helper
call :find_python
if errorlevel 1 (
  echo [GTC] Python was not found. Bridge cannot start.
  pause
  exit /b 2
)
echo [GTC] Undertale bridge using %PY_EXE%
"%PY_EXE%" -u -m gentc_ai.integration.http_server
echo [GTC] Bridge stopped.
pause
exit /b 0

:find_python
set "PY_EXE="
if defined GTC_PYTHON_EXE if exist "%GTC_PYTHON_EXE%" set "PY_EXE=%GTC_PYTHON_EXE%"
if not defined PY_EXE if exist "%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe" set "PY_EXE=%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe"
if not defined PY_EXE if exist "%LOCALAPPDATA%\Python\bin\python.exe" set "PY_EXE=%LOCALAPPDATA%\Python\bin\python.exe"
if not defined PY_EXE for /f "delims=" %%P in ('py -V:3.14 -c "import sys;print(sys.executable)" 2^>nul') do if not defined PY_EXE set "PY_EXE=%%P"
if not defined PY_EXE for /f "delims=" %%P in ('py -3.14 -c "import sys;print(sys.executable)" 2^>nul') do if not defined PY_EXE set "PY_EXE=%%P"
if not defined PY_EXE for /f "delims=" %%P in ('py -3 -c "import sys;print(sys.executable)" 2^>nul') do if not defined PY_EXE set "PY_EXE=%%P"
if not defined PY_EXE for /f "delims=" %%P in ('where python 2^>nul') do if not defined PY_EXE set "PY_EXE=%%P"
if not defined PY_EXE exit /b 1
"%PY_EXE%" -c "import sys;raise SystemExit(0 if sys.version_info >= (3,11) else 1)" >nul 2>&1
if errorlevel 1 (
  set "PY_EXE="
  exit /b 1
)
exit /b 0
