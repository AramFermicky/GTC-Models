"""Standalone GTC maintenance and diagnostic utilities."""
