"""Collect a privacy-conscious GTC diagnostic bundle on Windows or other Python hosts.

No game files, save files, screenshots, or SQLite database contents are copied.
Only selected status fields, table counts, recent action/event metadata, hashes,
and local test output are included. An optional, explicitly confirmed input probe
sends one short LEFT-arrow pulse to a foreground game window.
"""
from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import socket
import sqlite3
import subprocess
import sys
import time
import urllib.error
import urllib.request
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any

BASE_URL = "http://127.0.0.1:8765"


def redact_text(value: str) -> str:
    """Replace common personal directory prefixes with environment-variable tokens."""
    result = str(value)
    candidates = []
    for key in ("LOCALAPPDATA", "APPDATA", "USERPROFILE", "HOME", "TEMP", "TMP"):
        value = os.environ.get(key)
        if value:
            candidates.append((value.rstrip("\\/"), f"%{key}%"))
    for actual, replacement in sorted(candidates, key=lambda item: len(item[0]), reverse=True):
        result = re.sub(re.escape(actual), lambda _match, token=replacement: token,
                        result, flags=re.IGNORECASE)
    return result


def scrub(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): scrub(v) for k, v in value.items()}
    if isinstance(value, list):
        return [scrub(v) for v in value]
    if isinstance(value, str):
        return redact_text(value)
    return value


def write_text(path: Path, content: str) -> None:
    path.write_text(redact_text(content), encoding="utf-8", errors="replace")


def write_json(path: Path, content: Any) -> None:
    path.write_text(json.dumps(scrub(content), ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")


def run_command(args: list[str], timeout: int = 15) -> dict[str, Any]:
    try:
        result = subprocess.run(args, capture_output=True, text=True, errors="replace", timeout=timeout,
                                cwd=str(ROOT), shell=False)
        return {"command": args[0], "returncode": result.returncode,
                "stdout": redact_text(result.stdout[-30000:]),
                "stderr": redact_text(result.stderr[-10000:])}
    except Exception as exc:
        return {"command": args[0] if args else "", "error": f"{type(exc).__name__}: {exc}"}


def http_json(path: str, payload: dict[str, Any] | None = None, timeout: float = 8.0) -> dict[str, Any]:
    headers = {"Accept": "application/json"}
    data = None
    method = "GET"
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
        method = "POST"
    request = urllib.request.Request(BASE_URL + path, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read(1_000_000).decode("utf-8", errors="replace")
            try:
                value = json.loads(raw)
                return {"http_status": response.status, "body": scrub(value)}
            except json.JSONDecodeError:
                return {"http_status": response.status, "body_text": redact_text(raw[:8000])}
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read(8000).decode("utf-8", errors="replace")
        except Exception:
            body = ""
        return {"http_status": exc.code, "error": redact_text(str(exc)), "body": redact_text(body)}
    except Exception as exc:
        return {"error": f"{type(exc).__name__}: {redact_text(str(exc))}"}


def local_data_dir() -> Path:
    override = os.environ.get("GTC_DATA_DIR")
    if override:
        base = Path(override).expanduser()
    elif os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local"))) / "GenTC AI"
    else:
        base = Path.home() / ".local" / "share" / "GenTC AI"
    return base / "worlds" / "undertale"


def collect_database_summary(path: Path) -> dict[str, Any]:
    """Read schema/counts and a small allow-listed sample of event metadata only."""
    report: dict[str, Any] = {"exists": path.exists(), "path": redact_text(str(path))}
    if not path.is_file():
        return report
    try:
        uri = path.resolve().as_uri() + "?mode=ro"
        conn = sqlite3.connect(uri, uri=True, timeout=2)
        conn.row_factory = sqlite3.Row
        try:
            tables = [row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
            report["tables"] = tables
            report["row_counts"] = {}
            for table in tables:
                if table.startswith("sqlite_"):
                    continue
                safe = table.replace('"', '""')
                try:
                    report["row_counts"][table] = int(conn.execute(f'SELECT COUNT(*) FROM "{safe}"').fetchone()[0])
                except sqlite3.Error as exc:
                    report["row_counts"][table] = f"error: {exc}"
            if "runtime_logs" in tables:
                cols = {row[1] for row in conn.execute('PRAGMA table_info("runtime_logs")')}
                wanted = [c for c in ("ts", "mode", "action", "event", "details_json", "observation_json") if c in cols]
                if "ts" in wanted:
                    query = "SELECT " + ",".join(f'"{c}"' for c in wanted) + ' FROM "runtime_logs" ORDER BY "ts" DESC LIMIT 80'
                    entries = []
                    details_allow = {"game_id", "world_id", "adapter_version", "armed", "training_eligible",
                                     "feedback_category", "feedback_explanation", "explicit_game_outcome",
                                     "feedback_quality", "source", "error_type", "stage", "key", "reason"}
                    for row in conn.execute(query):
                        item = {key: row[key] for key in ("ts", "mode", "action", "event") if key in row.keys()}
                        details_raw = row["details_json"] if "details_json" in row.keys() else None
                        if details_raw:
                            try:
                                details = json.loads(details_raw)
                                if isinstance(details, dict):
                                    item["details_summary"] = {k: v for k, v in details.items() if k in details_allow}
                                else:
                                    item["details_summary"] = {"parsed": False}
                            except Exception:
                                item["details_summary"] = {"parsed": False}
                        obs_raw = row["observation_json"] if "observation_json" in row.keys() else None
                        if obs_raw:
                            try:
                                obs = json.loads(obs_raw)
                                item["observation_summary"] = {k: obs.get(k) for k in
                                    ("battle_visible", "scene_confidence", "hazard_pixels", "width", "height", "scene", "state_id") if k in obs}
                            except Exception:
                                item["observation_summary"] = "unparsed"
                        entries.append(item)
                    report["recent_runtime_events"] = scrub(list(reversed(entries)))
        finally:
            conn.close()
    except Exception as exc:
        report["read_error"] = f"{type(exc).__name__}: {exc}"
    return scrub(report)


def collect_tail(path: Path, max_lines: int = 180, max_bytes: int = 150_000) -> str:
    try:
        data = path.read_bytes()[-max_bytes:]
        text = data.decode("utf-8", errors="replace")
        return redact_text("\n".join(text.splitlines()[-max_lines:]))
    except Exception as exc:
        return f"Unable to read file: {type(exc).__name__}: {exc}"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def run_test_suite(folder: Path) -> dict[str, Any]:
    started = time.time()
    compile_result = run_command([sys.executable, "-m", "compileall", "-q", "gentc_ai", "scripts", "tests"], timeout=60)
    write_json(folder / "python_compile_result.json", compile_result)
    test_result = run_command([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"], timeout=120)
    write_json(folder / "python_unittest_result.json", test_result)
    combined = (
        "=== compileall ===\n" + str(compile_result.get("stdout", "")) + "\n" + str(compile_result.get("stderr", "")) +
        "\n=== unittest discover ===\n" + str(test_result.get("stdout", "")) + "\n" + str(test_result.get("stderr", ""))
    )
    write_text(folder / "python_tests.log", combined)
    return {"compile_returncode": compile_result.get("returncode"), "test_returncode": test_result.get("returncode"),
            "duration_seconds": round(time.time() - started, 2),
            "test_output_file": "python_tests.log"}


def optional_input_probe(folder: Path, initial_status: dict[str, Any]) -> dict[str, Any]:
    """Opt-in live input test. Stops/restarts only GTC, never launches or closes the game."""
    if os.name != "nt":
        return {"result": "skipped", "reason": "Windows-only test"}
    if not isinstance(initial_status, dict) or initial_status.get("service") not in {"undertale_visual_pilot", "visual_game_pilot"}:
        return {"result": "skipped", "reason": "Local game-agent bridge status is unavailable; no key was sent"}
    try:
        sys.path.insert(0, str(ROOT))
        from gentc_ai.integration.undertale_agent import WindowsScreen
        from gentc_ai.integration.win32_input import abi_report
        screen = WindowsScreen()
        hwnd = screen.find_window()
        if not hwnd:
            return {"result": "skipped", "reason": "No matching visible game window found"}
    except Exception as exc:
        return {"result": "failed", "error": f"{type(exc).__name__}: {exc}"}

    agent_was_running = bool(initial_status.get("agent_running"))
    agent_stopped = False
    key_down_attempted = False
    result: dict[str, Any] = {
        "result": "started", "window_handle": int(hwnd),
        "foreground_before_focus_wait": screen.is_foreground(hwnd), "abi": abi_report(),
        "warning": "One short LEFT key pulse may move the character; Windows acceptance does not prove the game consumed it.",
    }
    write_json(folder / "input_probe_before.json", result)
    try:
        if agent_was_running:
            stop_response = http_json("/undertale/agent/stop", {}, timeout=15)
            write_json(folder / "input_probe_agent_stop.json", stop_response)
            stop_body = stop_response.get("body")
            stop_ok = isinstance(stop_body, dict) and bool(stop_body.get("ok", False))
            if not stop_ok:
                result = {"result": "skipped", "reason": "Could not cleanly stop agent before isolated input test", "stop": stop_response}
            else:
                agent_stopped = True
        if result.get("result") != "skipped":
            print("\nINPUT PROBE: switch to the game window now. A LEFT arrow pulse lasting 150 ms may move the character.")
            print("Wait until the game is in the foreground. Do not switch to another app during the test.")
            time.sleep(5)
            hwnd2 = screen.find_window()
            if not hwnd2 or int(hwnd2) != int(hwnd) or not screen.is_foreground(hwnd2):
                result.update({"result": "skipped", "reason": "Game window was not foreground after the 5-second focus window",
                               "window_handle_after_wait": int(hwnd2) if hwnd2 else None})
            else:
                before = screen.input_diagnostics()
                send_error = None
                try:
                    key_down_attempted = True
                    screen.key("left", True)
                    time.sleep(0.15)
                except Exception as exc:
                    send_error = f"{type(exc).__name__}: {exc}"
                finally:
                    if key_down_attempted:
                        try:
                            screen.key("left", False)
                        except Exception as exc:
                            send_error = (send_error + "; " if send_error else "") + f"release {type(exc).__name__}: {exc}"
                after = screen.input_diagnostics()
                result.update({"result": "completed", "foreground_after": screen.is_foreground(hwnd),
                               "before": before, "after": after, "send_error": send_error,
                               "interpretation": "Check SendInput result, fallback count, and failed-event count. A reported success only confirms Windows accepted the event, not that the game acted on it."})
    except Exception as exc:
        result.update({"result": "failed", "error": f"{type(exc).__name__}: {exc}"})
    finally:
        if agent_stopped and agent_was_running:
            restart_result = http_json("/undertale/agent/start", {"armed": False}, timeout=15)
            result["agent_restart"] = restart_result
            restart_body = restart_result.get("body")
            if not isinstance(restart_body, dict) or not restart_body.get("ok", False):
                result["agent_restart_warning"] = "The controller may need to be restarted manually; see agent_restart details."
        write_json(folder / "input_probe_result.json", result)
    return scrub(result)


def inspect_windows_desktop(target_title: str | None = None) -> dict[str, Any]:
    """List visible window titles and process IDs without reading or storing screen pixels."""
    if os.name != "nt":
        return {"available": False, "reason": "Windows-only API"}
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        user32.GetForegroundWindow.restype = wintypes.HWND
        user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
        user32.GetWindowTextLengthW.restype = ctypes.c_int
        user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        user32.GetWindowTextW.restype = ctypes.c_int
        user32.IsWindowVisible.argtypes = [wintypes.HWND]
        user32.IsWindowVisible.restype = wintypes.BOOL
        user32.GetClientRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
        user32.GetClientRect.restype = wintypes.BOOL
        user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        user32.GetWindowThreadProcessId.restype = wintypes.DWORD
        user32.EnumWindows.restype = wintypes.BOOL
        foreground_hwnd = user32.GetForegroundWindow()
        needle = (target_title or "Undertale").casefold()
        windows: list[dict[str, Any]] = []

        def describe(hwnd: int) -> dict[str, Any] | None:
            if not user32.IsWindowVisible(hwnd):
                return None
            length = max(0, int(user32.GetWindowTextLengthW(hwnd)))
            if length <= 0:
                return None
            buf = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, buf, len(buf))
            title = buf.value.strip()
            if not title:
                return None
            pid = wintypes.DWORD(0)
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            rect = wintypes.RECT()
            size = None
            if user32.GetClientRect(hwnd, ctypes.byref(rect)):
                size = [int(rect.right - rect.left), int(rect.bottom - rect.top)]
            return {"hwnd": int(hwnd), "title": title[:240], "pid": int(pid.value),
                    "client_size": size, "foreground": int(hwnd) == int(foreground_hwnd)}

        callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        def callback(hwnd: int, _lparam: int) -> bool:
            try:
                info = describe(hwnd)
                if info:
                    info["matches_target_title"] = needle in info["title"].casefold()
                    windows.append(info)
            except Exception:
                pass
            return True
        user32.EnumWindows(callback_type(callback), 0)
        windows.sort(key=lambda x: (not x["matches_target_title"], not x["foreground"], x["title"].casefold()))
        return {"available": True, "foreground_hwnd": int(foreground_hwnd), "target_title_contains": target_title or "Undertale",
                "visible_windows": windows[:100], "matching_windows": [w for w in windows if w["matches_target_title"]][:20],
                "foreground_window": next((w for w in windows if w["foreground"]), None)}
    except Exception as exc:
        return {"available": False, "error": f"{type(exc).__name__}: {exc}"}


def main() -> int:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    outroot = ROOT / "GTC_DIAGNOSTICS_OUTPUT"
    folder = outroot / stamp
    folder.mkdir(parents=True, exist_ok=True)
    print("GenTC AI diagnostic collection")
    print("Working directory:", redact_text(str(ROOT)))
    print("Report folder:", redact_text(str(folder)))

    system = {
        "timestamp_local": datetime.now().isoformat(timespec="seconds"),
        "platform": platform.platform(), "system": platform.system(), "release": platform.release(),
        "machine_architecture": platform.machine(), "python_version": sys.version,
        "python_executable": redact_text(sys.executable), "python_bits": platform.architecture()[0],
        "cwd": redact_text(os.getcwd()), "project_root": redact_text(str(ROOT)),
        "environment_flags": {k: bool(os.environ.get(k)) for k in
            ("GTC_PYTHON_EXE", "GTC_DATA_DIR", "GTC_GAME_PROFILE", "GTC_GENERIC_GAME", "GTC_GAME_ID", "GTC_GAME_EXE")},
    }
    write_json(folder / "system_info.json", system)

    source_candidates = [ROOT / "gentc_ai" / "version.py", ROOT / "gentc_ai" / "integration" / "undertale_agent.py",
                         ROOT / "gentc_ai" / "integration" / "win32_input.py", ROOT / "gentc_ai" / "integration" / "win32_gdi.py",
                         ROOT / "gentc_ai" / "integration" / "undertale_client.py", ROOT / "gentc_ai" / "integration" / "http_server.py",
                         ROOT / "START_GTC.bat", ROOT / "PLAY_UNDERTALE_GTC.bat"]
    source_info = []
    for path in source_candidates:
        if path.is_file():
            source_info.append({"file": str(path.relative_to(ROOT)), "size_bytes": path.stat().st_size, "sha256": sha256(path)})
    write_json(folder / "source_hashes.json", source_info)

    command_results = {}
    if os.name == "nt":
        command_results["windows_ver"] = run_command(["cmd", "/c", "ver"])
        command_results["python_launcher_versions"] = run_command(["cmd", "/c", "py -0p"])
        command_results["python_where"] = run_command(["cmd", "/c", "where python"])
        command_results["netstat_8765"] = run_command(["cmd", "/c", "netstat -ano -p tcp | findstr :8765"])
        for exe in ("python.exe", "pythonw.exe", "UNDERTALE.exe", "cmd.exe"):
            command_results["tasklist_" + exe.replace(".exe", "")] = run_command(["tasklist", "/FI", f"IMAGENAME eq {exe}", "/FO", "CSV", "/NH"])
        ps_cmd = "$ErrorActionPreference='SilentlyContinue'; Get-Process | Where-Object { $_.ProcessName -match 'undertale|python' } | Select-Object ProcessName,Id,MainWindowTitle,Responding | ConvertTo-Json -Compress"
        command_results["window_processes"] = run_command(["powershell", "-NoProfile", "-Command", ps_cmd])
        ps_proc_cmd = "$ErrorActionPreference='SilentlyContinue'; Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('python.exe','pythonw.exe','UNDERTALE.exe') } | Select-Object ProcessId,Name,ExecutablePath,CommandLine | ConvertTo-Json -Compress"
        command_results["python_and_game_process_details"] = run_command(["powershell", "-NoProfile", "-Command", ps_proc_cmd])
    else:
        try:
            with socket.create_connection(("127.0.0.1", 8765), timeout=0.5):
                local_port_open = True
        except OSError:
            local_port_open = False
        command_results["port_test"] = {"port_8765_local": local_port_open}
    write_json(folder / "system_commands.json", command_results)

    endpoints = {}
    for path, timeout in (("/health", 3), ("/undertale/status", 10), ("/undertale/observe", 18),
                          ("/undertale/learning", 10), ("/undertale/introspection", 10)):
        print("Querying local bridge:", path)
        endpoints[path] = http_json(path, timeout=timeout)
        write_json(folder / (path.strip("/").replace("/", "_") + ".json"), endpoints[path])
    status_result = endpoints.get("/undertale/status", {})
    status_body = status_result.get("body", {}) if isinstance(status_result, dict) else {}
    game_profile = status_body.get("game_profile") if isinstance(status_body.get("game_profile"), dict) else {}
    title_hint = game_profile.get("window_title_contains") if isinstance(game_profile, dict) else None
    write_json(folder / "windows_desktop_windows.json", inspect_windows_desktop(str(title_hint) if title_hint else None))
    health_result = endpoints.get("/health", {})
    health_body = health_result.get("body", {}) if isinstance(health_result, dict) else {}
    try:
        sys.path.insert(0, str(ROOT))
        from gentc_ai.version import VERSION as EXPECTED_VERSION, BUILD_ID as EXPECTED_BUILD_ID
    except Exception:
        EXPECTED_VERSION, EXPECTED_BUILD_ID = "unknown", "unknown"
    bridge_alignment = {
        "expected_version": EXPECTED_VERSION, "expected_build_id": EXPECTED_BUILD_ID,
        "observed_version": health_body.get("version") if isinstance(health_body, dict) else None,
        "observed_build_id": health_body.get("build_id") if isinstance(health_body, dict) else None,
    }
    bridge_alignment["version_matches"] = bridge_alignment["observed_version"] == EXPECTED_VERSION
    bridge_alignment["build_id_matches"] = bridge_alignment["observed_build_id"] == EXPECTED_BUILD_ID
    write_json(folder / "bridge_build_comparison.json", bridge_alignment)
    write_json(folder / "endpoint_summary.json", {
        "health": endpoints.get("/health"),
        "bridge_build_comparison": bridge_alignment,
        "status_highlights": {key: status_body.get(key) for key in (
            "ok", "service", "adapter_version", "platform_supported", "game_window_found", "window_handle",
            "agent_running", "agent_armed", "hotkeys", "hotkey_error", "last_hotkey", "agent_mode",
            "window_selection", "frames_seen", "passive_analysis_frames", "last_observation_unix", "input_diagnostics",
            "agent_diagnostics", "last_error", "data_dir") if key in status_body},
        "observe": endpoints.get("/undertale/observe"),
    })

    world_dir = local_data_dir()
    db_file = world_dir / "undertale_experience.sqlite3"
    write_json(folder / "sqlite_summary.json", collect_database_summary(db_file))
    logs = []
    possible_logs = [world_dir / "runtime_diagnostics.jsonl", world_dir / "runtime_diagnostics.jsonl.1",
                     ROOT / "data" / "logs" / "gtc_runtime.log", ROOT / "data" / "logs" / "events.jsonl"]
    for path in possible_logs:
        if path.is_file():
            target = folder / ("tail_" + path.name + ("_backup" if path.name.endswith(".1") else ".txt"))
            write_text(target, collect_tail(path))
            logs.append({"file": redact_text(str(path)), "copied_to": target.name, "size_bytes": path.stat().st_size})
    write_json(folder / "log_files_collected.json", logs)

    print("Running compileall and unit tests...")
    test_summary = run_test_suite(folder)
    write_json(folder / "test_summary.json", test_summary)

    print("\nBase diagnostics collected.")
    print("Bridge build ID:", bridge_alignment.get("observed_build_id", "unknown"),
          "| expected:", bridge_alignment.get("expected_build_id", "unknown"))
    if health_body and not bridge_alignment.get("build_id_matches"):
        print("WARNING: the bridge answering on port 8765 is not this release. This can explain why current source changes have no effect.")
    print("Agent running:", status_body.get("agent_running", "unknown"), "| armed:", status_body.get("agent_armed", "unknown"))
    print("Game window found:", status_body.get("game_window_found", "unknown"))
    selection = status_body.get("window_selection")
    if isinstance(selection, dict):
        selected = selection.get("selected") or {}
        print("Selected game window:", selected.get("title", "none"),
              "| process:", selected.get("process_name", "unknown"),
              "| reason:", selection.get("selection_reason", "unknown"))
    print("Agent stage:", (status_body.get("agent_diagnostics") or {}).get("stage", "unknown"))
    print("Last error:", status_body.get("last_error", "none"))
    print("\nOptional live keyboard probe will stop/restart only the GTC agent, not the game.")
    print("It can move the character a little. To approve a single 150 ms LEFT pulse, type TEST; anything else skips.")
    try:
        answer = input("Input test [type TEST to approve / Enter to skip]: ").strip()
    except EOFError:
        answer = ""
    if answer == "TEST":
        probe = optional_input_probe(folder, status_body)
        write_json(folder / "input_probe_summary.json", probe)
        print("Input probe result:", probe.get("result", "unknown"))
        # Re-query after the optional probe so the archive shows the restarted agent state.
        endpoints_after = {p: http_json(p, timeout=t) for p, t in (("/undertale/status", 10), ("/health", 3))}
        write_json(folder / "post_probe_status.json", endpoints_after)
    else:
        write_json(folder / "input_probe_summary.json", {"result": "skipped_by_user"})

    files = []
    for p in sorted(folder.iterdir()):
        if p.is_file():
            files.append({"name": p.name, "size_bytes": p.stat().st_size})
    write_json(folder / "bundle_contents.json", files)
    archive = ROOT / f"ERRORS_LOG_TESTING_REPORT_{stamp}.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(folder.iterdir()):
            if p.is_file():
                zf.write(p, arcname=f"GTC_DIAGNOSTICS_{stamp}/{p.name}")
    print("\nFinished.")
    print("Diagnostic ZIP:", redact_text(str(archive)))
    print("Attach this ZIP in ChatGPT. It excludes screenshots, game saves, and full database contents.")
    return 0


ROOT = Path(__file__).resolve().parents[1]

if __name__ == "__main__":
    raise SystemExit(main())
