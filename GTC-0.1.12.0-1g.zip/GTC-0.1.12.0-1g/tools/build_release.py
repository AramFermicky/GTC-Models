#!/usr/bin/env python3
"""Build a clean, engine-independent GTC ZIP release using the standard library."""
from __future__ import annotations

import argparse
import sys
import zipfile
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))
from gentc_ai.version import BUILD_ID  # noqa: E402

PACKAGE_ROOT_NAME = f"GTC-{BUILD_ID}"
EXCLUDED_TOP_LEVEL_DIRS = {"god_sandbox", "godot_playground", ".git", ".venv", "venv", "dist", "GTC_DIAGNOSTICS_OUTPUT", "GTC_learning"}
EXCLUDED_FILENAMES = {"q_table.json", "training_report.json"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".sqlite3", ".db"}


def should_include(path: Path, root: Path = PROJECT_ROOT) -> bool:
    """Return False for machine-generated files and engine-specific demo projects."""
    try:
        relative = path.relative_to(root)
    except ValueError:
        return False

    parts = relative.parts
    if not parts or parts[0] in EXCLUDED_TOP_LEVEL_DIRS:
        return False
    if "__pycache__" in parts or any(part.startswith(".") and part != ".gitignore" for part in parts):
        return False
    if path.name in EXCLUDED_FILENAMES or path.suffix.lower() in EXCLUDED_SUFFIXES:
        return False
    # User-generated post-mortem bundles must never be nested into a release ZIP.
    if path.name.startswith("ERRORS_LOG_TESTING_REPORT_") and path.suffix.lower() == ".zip":
        return False
    if path.name.endswith(("-shm", "-wal")):
        return False

    # Runtime logs and per-session experience files are local state, not source.
    if parts[0] == "logs" and path.name != "README.txt":
        return False
    if len(parts) >= 2 and parts[0] == "data" and parts[1] == "logs" and path.name != "README_RU.txt":
        return False
    if path.suffix.lower() == ".jsonl" and (parts[0] == "logs" or (len(parts) > 1 and parts[0] == "data")):
        return False
    return True


def build_release(output: Path, root: Path = PROJECT_ROOT) -> Path:
    output = output.expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        output.unlink()

    candidates = sorted(root.rglob("*"), key=lambda item: item.as_posix().lower())
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=8) as archive:
        for path in candidates:
            if not path.is_file() or not should_include(path, root=root):
                continue
            relative = path.relative_to(root)
            archive_name = (Path(PACKAGE_ROOT_NAME) / relative).as_posix()
            archive.write(path, archive_name)
    return output


def main() -> int:
    parser = argparse.ArgumentParser(description="Create a clean GenTC AI release ZIP")
    parser.add_argument("--out", type=Path, default=PROJECT_ROOT / "dist" / f"{PACKAGE_ROOT_NAME}.zip",
                        help="output ZIP path (default: dist/GTC-<build-id>.zip)")
    args = parser.parse_args()
    result = build_release(args.out)
    print(f"GTC release archive created: {result}")
    print(f"Build ID: {BUILD_ID}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
