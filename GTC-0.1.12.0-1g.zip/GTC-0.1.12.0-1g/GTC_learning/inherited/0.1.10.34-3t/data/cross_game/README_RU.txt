GTC 0.1.9.3 / CROSS-GAME TRANSFER

semantic_action_priors.json содержит осторожные общие оценки семантических типов вроде exploration, rest и social_interaction. transfer_manifest.json описывает, какие игры встречались. Нужен совместимый игровой адаптер; этот файл не позволяет GTC читать любую игру автоматически.
