GTC 0.1.9.3 live learning data.
q_policy.json is the actual persistent Q-learning snapshot, training_status.json is the current summary.
Only confirmed game outcomes are used. Legacy synthetic demo tables are not part of the live policy.
