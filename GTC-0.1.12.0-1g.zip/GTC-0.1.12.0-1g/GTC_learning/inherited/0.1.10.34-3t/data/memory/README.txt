GTC 0.1.9.3 persistent memory.
The live authoritative SQLite database is under the per-user GenTC AI directory. This project folder receives a snapshot after the bridge starts and after confirmed outcomes.
No player training data is bundled in a clean download.
