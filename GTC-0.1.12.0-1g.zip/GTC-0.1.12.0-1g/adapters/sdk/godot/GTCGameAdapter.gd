extends Node
class_name GTCGameAdapter

## Minimal Godot-side bridge example. The game supplies real state and a strict
## allow-list; GTC never receives arbitrary script execution privileges.

@export var gtc_url: String = "http://127.0.0.1:8767"
@export var game_id: String = "my_godot_game"
@export var world_id: String = "main_world"

var _http: HTTPRequest
var _frame_counter: int = 0
var _pending_decision_id: String = ""

func _ready() -> void:
    _http = HTTPRequest.new()
    add_child(_http)

func send_observation(state: Dictionary, available_actions: Array[Dictionary]) -> void:
    _frame_counter += 1
    var payload := {
        "schema_version": 1,
        "game_id": game_id,
        "world_id": world_id,
        "frame_id": str(_frame_counter),
        "captured_at_unix": Time.get_unix_time_from_system(),
        "state": state,
        "available_actions": available_actions,
        "source": "godot_game_plugin"
    }
    # This is a protocol example; connect to the matching generic GTC adapter
    # endpoint once that server route is enabled for the selected game profile.
    var body := JSON.stringify(payload)
    _http.request(gtc_url + "/adapter/observe", ["Content-Type: application/json"], HTTPClient.METHOD_POST, body)

func report_action_result(decision_id: String, command_id: String, before_state: Dictionary,
        after_state: Dictionary, goal_achieved: bool, constraints_respected: bool) -> void:
    var payload := {
        "decision_id": decision_id,
        "command_id": command_id,
        "status": "executed",
        "before_state": before_state,
        "after_state": after_state,
        "goal_achieved": goal_achieved,
        "constraints_respected": constraints_respected,
        "verified": true,
        "execution_confirmed": true
    }
    _http.request(gtc_url + "/adapter/feedback", ["Content-Type: application/json"], HTTPClient.METHOD_POST, JSON.stringify(payload))
