"""Local-first continuity store for a persistent character across games.

Raw dialogue is scoped to a game/incarnation by default. Only memories explicitly
promoted to the verified 'shared' scope are visible across games. No data is sent
anywhere over the network by this module.
"""
from __future__ import annotations

import json
import re
import sqlite3
from contextlib import contextmanager
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

SCOPES = {"shared", "game", "incarnation"}
_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def _validate_id(value: str, label: str) -> str:
    if not isinstance(value, str) or not _ID_PATTERN.fullmatch(value):
        raise ValueError(f"{label} должен содержать 1–128 символов: латиницу, цифры, '.', '_', ':' или '-'.")
    return value


class ContinuityStore:
    """SQLite storage for a canon identity and its game-specific incarnations."""

    SCHEMA_VERSION = 1

    def __init__(self, db_path: Path | str):
        self.db_path = Path(db_path).expanduser()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=15.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA busy_timeout = 15000")
        return conn

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        """Commit/rollback and always close each connection (including on exceptions)."""
        conn = self._connect()
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def _initialize(self) -> None:
        with self._connection() as conn:
            conn.execute("PRAGMA journal_mode = WAL")
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS metadata (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS identities (
                    identity_id TEXT PRIMARY KEY,
                    canonical_name TEXT NOT NULL,
                    profile_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS incarnations (
                    incarnation_id TEXT PRIMARY KEY,
                    identity_id TEXT NOT NULL REFERENCES identities(identity_id),
                    game_id TEXT NOT NULL,
                    character_id TEXT NOT NULL,
                    variant_id TEXT NOT NULL DEFAULT 'default',
                    profile_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    UNIQUE(game_id, character_id, variant_id)
                );
                CREATE INDEX IF NOT EXISTS idx_incarnations_identity
                    ON incarnations(identity_id);
                CREATE TABLE IF NOT EXISTS memories (
                    memory_id TEXT PRIMARY KEY,
                    identity_id TEXT NOT NULL REFERENCES identities(identity_id),
                    scope TEXT NOT NULL CHECK(scope IN ('shared', 'game', 'incarnation')),
                    game_id TEXT,
                    incarnation_id TEXT,
                    category TEXT NOT NULL,
                    content TEXT NOT NULL,
                    source TEXT NOT NULL,
                    confidence REAL NOT NULL CHECK(confidence >= 0.0 AND confidence <= 1.0),
                    verified INTEGER NOT NULL DEFAULT 0,
                    metadata_json TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_memories_identity_scope
                    ON memories(identity_id, scope, game_id, incarnation_id, verified);
                CREATE TABLE IF NOT EXISTS dialogue_events (
                    event_id TEXT PRIMARY KEY,
                    identity_id TEXT NOT NULL REFERENCES identities(identity_id),
                    game_id TEXT NOT NULL,
                    incarnation_id TEXT NOT NULL,
                    speaker TEXT NOT NULL,
                    content TEXT NOT NULL,
                    metadata_json TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_dialogue_context
                    ON dialogue_events(identity_id, game_id, incarnation_id, created_at);
                CREATE TABLE IF NOT EXISTS experience_events (
                    experience_id TEXT PRIMARY KEY,
                    identity_id TEXT NOT NULL REFERENCES identities(identity_id),
                    game_id TEXT NOT NULL,
                    incarnation_id TEXT NOT NULL,
                    situation_json TEXT NOT NULL,
                    action_json TEXT NOT NULL,
                    result_json TEXT NOT NULL,
                    semantic_action TEXT,
                    reward REAL,
                    verified INTEGER NOT NULL DEFAULT 0,
                    training_eligible INTEGER NOT NULL DEFAULT 0,
                    portable INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_experience_training
                    ON experience_events(training_eligible, verified, portable, semantic_action);
                CREATE TABLE IF NOT EXISTS memory_candidates (
                    candidate_id TEXT PRIMARY KEY,
                    identity_id TEXT NOT NULL REFERENCES identities(identity_id),
                    game_id TEXT NOT NULL,
                    incarnation_id TEXT NOT NULL,
                    content TEXT NOT NULL,
                    category TEXT NOT NULL,
                    source_event_id TEXT,
                    confidence REAL NOT NULL CHECK(confidence >= 0.0 AND confidence <= 1.0),
                    status TEXT NOT NULL CHECK(status IN ('pending', 'confirmed', 'rejected')),
                    metadata_json TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL
                );
                """
            )
            conn.execute(
                "INSERT INTO metadata(key, value) VALUES('schema_version', ?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (str(self.SCHEMA_VERSION),),
            )

    def register_identity(
        self, identity_id: str, canonical_name: str, profile: dict[str, Any] | None = None,
        *, overwrite_profile: bool = False,
    ) -> None:
        identity_id = _validate_id(identity_id, "identity_id")
        canonical_name = str(canonical_name).strip()
        if not canonical_name:
            raise ValueError("canonical_name не может быть пустым.")
        now = _now()
        with self._connection() as conn:
            if overwrite_profile:
                conn.execute(
                    """INSERT INTO identities(identity_id, canonical_name, profile_json, created_at, updated_at)
                       VALUES(?, ?, ?, ?, ?)
                       ON CONFLICT(identity_id) DO UPDATE SET
                         canonical_name=excluded.canonical_name,
                         profile_json=excluded.profile_json,
                         updated_at=excluded.updated_at""",
                    (identity_id, canonical_name, _json(profile or {}), now, now),
                )
            else:
                # Registering another game/variation must not silently overwrite
                # the shared canon profile owned by the identity_id.
                conn.execute(
                    "INSERT OR IGNORE INTO identities(identity_id, canonical_name, profile_json, created_at, updated_at) VALUES(?, ?, ?, ?, ?)",
                    (identity_id, canonical_name, _json(profile or {}), now, now),
                )

    def register_incarnation(
        self,
        identity_id: str,
        incarnation_id: str,
        game_id: str,
        character_id: str,
        variant_id: str = "default",
        profile: dict[str, Any] | None = None,
    ) -> None:
        identity_id = _validate_id(identity_id, "identity_id")
        incarnation_id = _validate_id(incarnation_id, "incarnation_id")
        game_id = _validate_id(game_id, "game_id")
        character_id = _validate_id(character_id, "character_id")
        variant_id = _validate_id(variant_id, "variant_id")
        now = _now()
        with self._connection() as conn:
            exists = conn.execute("SELECT 1 FROM identities WHERE identity_id=?", (identity_id,)).fetchone()
            if not exists:
                raise ValueError(f"Сначала зарегистрируйте identity_id={identity_id!r}.")
            conn.execute(
                """INSERT INTO incarnations
                   (incarnation_id, identity_id, game_id, character_id, variant_id, profile_json, created_at, updated_at)
                   VALUES(?, ?, ?, ?, ?, ?, ?, ?)
                   ON CONFLICT(incarnation_id) DO UPDATE SET
                     identity_id=excluded.identity_id,
                     game_id=excluded.game_id,
                     character_id=excluded.character_id,
                     variant_id=excluded.variant_id,
                     profile_json=excluded.profile_json,
                     updated_at=excluded.updated_at""",
                (incarnation_id, identity_id, game_id, character_id, variant_id, _json(profile or {}), now, now),
            )

    def add_memory(
        self,
        identity_id: str,
        content: str,
        *,
        scope: str,
        category: str = "event",
        game_id: str | None = None,
        incarnation_id: str | None = None,
        source: str = "manual",
        confidence: float = 1.0,
        verified: bool = False,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        identity_id = _validate_id(identity_id, "identity_id")
        if scope not in SCOPES:
            raise ValueError(f"scope должен быть одним из {sorted(SCOPES)}.")
        content = str(content).strip()
        if not content:
            raise ValueError("Содержимое воспоминания не может быть пустым.")
        confidence = float(confidence)
        if not 0.0 <= confidence <= 1.0:
            raise ValueError("confidence должен быть от 0 до 1.")
        if scope == "shared":
            if not verified:
                raise ValueError("Общее воспоминание требует verified=True: неопроверенные факты нельзя переносить между играми.")
            game_id = None
            incarnation_id = None
        elif scope == "game":
            if not game_id:
                raise ValueError("Для scope='game' необходимо указать game_id.")
            game_id = _validate_id(game_id, "game_id")
            incarnation_id = None
        else:
            if not game_id or not incarnation_id:
                raise ValueError("Для scope='incarnation' нужны game_id и incarnation_id.")
            game_id = _validate_id(game_id, "game_id")
            incarnation_id = _validate_id(incarnation_id, "incarnation_id")

        memory_id = str(uuid.uuid4())
        now = _now()
        with self._connection() as conn:
            identity_exists = conn.execute("SELECT 1 FROM identities WHERE identity_id=?", (identity_id,)).fetchone()
            if not identity_exists:
                raise ValueError(f"Неизвестная личность: {identity_id!r}.")
            existing = conn.execute(
                """SELECT memory_id FROM memories WHERE identity_id=? AND scope=?
                   AND COALESCE(game_id, '')=COALESCE(?, '')
                   AND COALESCE(incarnation_id, '')=COALESCE(?, '')
                   AND lower(content)=lower(?) LIMIT 1""",
                (identity_id, scope, game_id, incarnation_id, content),
            ).fetchone()
            if existing:
                return str(existing["memory_id"])
            conn.execute(
                """INSERT INTO memories
                   (memory_id, identity_id, scope, game_id, incarnation_id, category, content,
                    source, confidence, verified, metadata_json, created_at)
                   VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (memory_id, identity_id, scope, game_id, incarnation_id, str(category), content,
                 str(source), confidence, int(verified), _json(metadata or {}), now),
            )
        return memory_id

    def get_memories(
        self,
        identity_id: str,
        *,
        game_id: str,
        incarnation_id: str,
        limit: int = 50,
        verified_only: bool = True,
    ) -> list[dict[str, Any]]:
        identity_id = _validate_id(identity_id, "identity_id")
        game_id = _validate_id(game_id, "game_id")
        incarnation_id = _validate_id(incarnation_id, "incarnation_id")
        limit = max(1, min(int(limit), 500))
        verified_clause = "AND verified=1" if verified_only else ""
        with self._connection() as conn:
            rows = conn.execute(
                f"""SELECT * FROM memories
                    WHERE identity_id=? AND (
                      scope='shared' OR
                      (scope='game' AND game_id=?) OR
                      (scope='incarnation' AND game_id=? AND incarnation_id=?)
                    ) {verified_clause}
                    ORDER BY CASE scope WHEN 'shared' THEN 0 WHEN 'game' THEN 1 ELSE 2 END,
                             confidence DESC, created_at DESC
                    LIMIT ?""",
                (identity_id, game_id, game_id, incarnation_id, limit),
            ).fetchall()
        return [self._memory_row(row) for row in rows]

    @staticmethod
    def _memory_row(row: sqlite3.Row) -> dict[str, Any]:
        result = dict(row)
        result["verified"] = bool(result["verified"])
        result["metadata"] = json.loads(result.pop("metadata_json"))
        return result

    def record_dialogue(
        self,
        identity_id: str,
        game_id: str,
        incarnation_id: str,
        speaker: str,
        content: str,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        identity_id = _validate_id(identity_id, "identity_id")
        game_id = _validate_id(game_id, "game_id")
        incarnation_id = _validate_id(incarnation_id, "incarnation_id")
        content = str(content).strip()
        if not content:
            raise ValueError("Текст сообщения не может быть пустым.")
        event_id = str(uuid.uuid4())
        with self._connection() as conn:
            conn.execute(
                """INSERT INTO dialogue_events
                   (event_id, identity_id, game_id, incarnation_id, speaker, content, metadata_json, created_at)
                   VALUES(?, ?, ?, ?, ?, ?, ?, ?)""",
                (event_id, identity_id, game_id, incarnation_id, str(speaker), content,
                 _json(metadata or {}), _now()),
            )
        return event_id

    def get_recent_dialogue(
        self,
        identity_id: str,
        *,
        game_id: str,
        incarnation_id: str,
        limit: int = 20,
        include_other_games: bool = False,
    ) -> list[dict[str, Any]]:
        identity_id = _validate_id(identity_id, "identity_id")
        game_id = _validate_id(game_id, "game_id")
        incarnation_id = _validate_id(incarnation_id, "incarnation_id")
        limit = max(1, min(int(limit), 200))
        with self._connection() as conn:
            if include_other_games:
                rows = conn.execute(
                    "SELECT * FROM dialogue_events WHERE identity_id=? ORDER BY created_at DESC LIMIT ?",
                    (identity_id, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    """SELECT * FROM dialogue_events WHERE identity_id=? AND game_id=? AND incarnation_id=?
                       ORDER BY created_at DESC LIMIT ?""",
                    (identity_id, game_id, incarnation_id, limit),
                ).fetchall()
        result = []
        for row in reversed(rows):
            item = dict(row)
            item["metadata"] = json.loads(item.pop("metadata_json"))
            result.append(item)
        return result

    def record_experience(
        self,
        identity_id: str,
        game_id: str,
        incarnation_id: str,
        situation: dict[str, Any],
        action: dict[str, Any],
        result: dict[str, Any],
        *,
        semantic_action: str | None = None,
        reward: float | None = None,
        verified: bool = False,
        training_eligible: bool = False,
        portable: bool = False,
    ) -> str:
        identity_id = _validate_id(identity_id, "identity_id")
        game_id = _validate_id(game_id, "game_id")
        incarnation_id = _validate_id(incarnation_id, "incarnation_id")
        if training_eligible and not verified:
            raise ValueError("Опыт нельзя включать в обучающий набор до подтверждения результата.")
        if portable and not semantic_action:
            raise ValueError("Для переноса опыта между играми нужна общая semantic_action.")
        experience_id = str(uuid.uuid4())
        with self._connection() as conn:
            conn.execute(
                """INSERT INTO experience_events
                   (experience_id, identity_id, game_id, incarnation_id, situation_json, action_json,
                    result_json, semantic_action, reward, verified, training_eligible, portable, created_at)
                   VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (experience_id, identity_id, game_id, incarnation_id, _json(situation), _json(action),
                 _json(result), semantic_action, reward, int(verified), int(training_eligible),
                 int(portable), _now()),
            )
        return experience_id

    def get_training_examples(self, *, portable_only: bool = False, game_id: str | None = None) -> list[dict[str, Any]]:
        clauses = ["verified=1", "training_eligible=1"]
        params: list[Any] = []
        if portable_only:
            clauses.extend(["portable=1", "semantic_action IS NOT NULL"])
        if game_id:
            clauses.append("game_id=?")
            params.append(_validate_id(game_id, "game_id"))
        query = "SELECT * FROM experience_events WHERE " + " AND ".join(clauses) + " ORDER BY created_at"
        with self._connection() as conn:
            rows = conn.execute(query, params).fetchall()
        items = []
        for row in rows:
            item = dict(row)
            for field in ("situation_json", "action_json", "result_json"):
                item[field.removesuffix("_json")] = json.loads(item.pop(field))
            for field in ("verified", "training_eligible", "portable"):
                item[field] = bool(item[field])
            items.append(item)
        return items

    def propose_memory(
        self,
        identity_id: str,
        game_id: str,
        incarnation_id: str,
        content: str,
        *,
        category: str = "candidate_fact",
        source_event_id: str | None = None,
        confidence: float = 0.5,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        identity_id = _validate_id(identity_id, "identity_id")
        game_id = _validate_id(game_id, "game_id")
        incarnation_id = _validate_id(incarnation_id, "incarnation_id")
        content = str(content).strip()
        if not content:
            raise ValueError("Кандидат воспоминания не может быть пустым.")
        confidence = float(confidence)
        if not 0 <= confidence <= 1:
            raise ValueError("confidence должен быть от 0 до 1.")
        candidate_id = str(uuid.uuid4())
        with self._connection() as conn:
            conn.execute(
                """INSERT INTO memory_candidates
                   (candidate_id, identity_id, game_id, incarnation_id, content, category,
                    source_event_id, confidence, status, metadata_json, created_at)
                   VALUES(?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?)""",
                (candidate_id, identity_id, game_id, incarnation_id, content, category,
                 source_event_id, confidence, _json(metadata or {}), _now()),
            )
        return candidate_id

    def get_pending_memory_candidates(
        self,
        identity_id: str,
        *,
        game_id: str,
        incarnation_id: str,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        identity_id = _validate_id(identity_id, "identity_id")
        game_id = _validate_id(game_id, "game_id")
        incarnation_id = _validate_id(incarnation_id, "incarnation_id")
        limit = max(1, min(int(limit), 200))
        with self._connection() as conn:
            rows = conn.execute(
                """SELECT * FROM memory_candidates
                   WHERE identity_id=? AND game_id=? AND incarnation_id=? AND status='pending'
                   ORDER BY created_at DESC LIMIT ?""",
                (identity_id, game_id, incarnation_id, limit),
            ).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["metadata"] = json.loads(item.pop("metadata_json"))
            result.append(item)
        return result

    def confirm_memory_candidate(
        self,
        candidate_id: str,
        *,
        scope: str = "incarnation",
        verified: bool = True,
        source: str = "memory_candidate_review",
    ) -> str:
        with self._connection() as conn:
            row = conn.execute("SELECT * FROM memory_candidates WHERE candidate_id=?", (candidate_id,)).fetchone()
            if row is None:
                raise KeyError(f"Кандидат памяти не найден: {candidate_id}")
            if row["status"] != "pending":
                raise ValueError(f"Кандидат уже обработан: status={row['status']}")
        memory_id = self.add_memory(
            row["identity_id"], row["content"], scope=scope, category=row["category"],
            game_id=row["game_id"] if scope != "shared" else None,
            incarnation_id=row["incarnation_id"] if scope == "incarnation" else None,
            source=source, confidence=float(row["confidence"]), verified=verified,
            metadata={"candidate_id": candidate_id, "source_event_id": row["source_event_id"]},
        )
        with self._connection() as conn:
            conn.execute("UPDATE memory_candidates SET status='confirmed' WHERE candidate_id=?", (candidate_id,))
        return memory_id

    def reject_memory_candidate(self, candidate_id: str) -> None:
        with self._connection() as conn:
            result = conn.execute(
                "UPDATE memory_candidates SET status='rejected' WHERE candidate_id=? AND status='pending'",
                (candidate_id,),
            )
            if result.rowcount == 0:
                raise KeyError(f"Ожидающий кандидат памяти не найден: {candidate_id}")

    def export_identity_bundle(
        self,
        identity_id: str,
        destination: Path | str,
        *,
        include_game_memories: bool = True,
        include_dialogue: bool = False,
        include_experiences: bool = False,
    ) -> Path:
        identity_id = _validate_id(identity_id, "identity_id")
        with self._connection() as conn:
            identity = conn.execute("SELECT * FROM identities WHERE identity_id=?", (identity_id,)).fetchone()
            if identity is None:
                raise KeyError(f"Неизвестная личность: {identity_id}")
            incarnations = conn.execute("SELECT * FROM incarnations WHERE identity_id=?", (identity_id,)).fetchall()
            scopes = ("shared", "game", "incarnation") if include_game_memories else ("shared",)
            placeholders = ",".join("?" for _ in scopes)
            memories = conn.execute(
                f"SELECT * FROM memories WHERE identity_id=? AND scope IN ({placeholders})",
                (identity_id, *scopes),
            ).fetchall()
            dialogues = []
            experiences = []
            if include_dialogue:
                dialogues = conn.execute("SELECT * FROM dialogue_events WHERE identity_id=?", (identity_id,)).fetchall()
            if include_experiences:
                experiences = conn.execute("SELECT * FROM experience_events WHERE identity_id=?", (identity_id,)).fetchall()
        bundle: dict[str, Any] = {
            "bundle_schema_version": 1,
            "exported_at_utc": _now(),
            "identity": dict(identity),
            "incarnations": [dict(row) for row in incarnations],
            "memories": [],
            "privacy_notice": "Диалоги и опыт включаются только по явному запросу экспорта.",
        }
        bundle["identity"]["profile"] = json.loads(bundle["identity"].pop("profile_json"))
        for row in memories:
            item = dict(row)
            item["metadata"] = json.loads(item.pop("metadata_json"))
            item["verified"] = bool(item["verified"])
            bundle["memories"].append(item)
        for item in bundle["incarnations"]:
            item["profile"] = json.loads(item.pop("profile_json"))
        if include_dialogue:
            bundle["dialogue"] = []
            for row in dialogues:
                item = dict(row)
                item["metadata"] = json.loads(item.pop("metadata_json"))
                bundle["dialogue"].append(item)
        if include_experiences:
            bundle["experiences"] = []
            for row in experiences:
                item = dict(row)
                for field in ("situation_json", "action_json", "result_json"):
                    item[field.removesuffix("_json")] = json.loads(item.pop(field))
                for field in ("verified", "training_eligible", "portable"):
                    item[field] = bool(item[field])
                bundle["experiences"].append(item)
        destination = Path(destination).expanduser()
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(json.dumps(bundle, ensure_ascii=False, indent=2), encoding="utf-8")
        return destination

    def import_identity_bundle(self, source: Path | str) -> dict[str, int]:
        bundle = json.loads(Path(source).expanduser().read_text(encoding="utf-8"))
        if bundle.get("bundle_schema_version") != 1:
            raise ValueError("Неподдерживаемая версия пакета идентичности.")
        identity = bundle.get("identity")
        if not isinstance(identity, dict):
            raise ValueError("В пакете отсутствует identity.")
        identity_id = _validate_id(identity.get("identity_id", ""), "identity_id")
        self.register_identity(identity_id, identity.get("canonical_name", identity_id), identity.get("profile", {}))
        incarnation_count = 0
        for incarnation in bundle.get("incarnations", []):
            self.register_incarnation(
                identity_id=identity_id,
                incarnation_id=incarnation["incarnation_id"],
                game_id=incarnation["game_id"],
                character_id=incarnation["character_id"],
                variant_id=incarnation.get("variant_id", "default"),
                profile=incarnation.get("profile", {}),
            )
            incarnation_count += 1
        memory_count = 0
        for memory in bundle.get("memories", []):
            self.add_memory(
                identity_id=identity_id,
                content=memory["content"],
                scope=memory["scope"],
                category=memory.get("category", "event"),
                game_id=memory.get("game_id"),
                incarnation_id=memory.get("incarnation_id"),
                source=memory.get("source", "imported_bundle"),
                confidence=float(memory.get("confidence", 1.0)),
                verified=bool(memory.get("verified", False)),
                metadata={**memory.get("metadata", {}), "imported_from_bundle": True},
            )
            memory_count += 1

        dialogue_count = 0
        for item in bundle.get("dialogue", []):
            game_id = _validate_id(item["game_id"], "game_id")
            incarnation_id = _validate_id(item["incarnation_id"], "incarnation_id")
            event_id = str(item.get("event_id") or uuid.uuid4())
            with self._connection() as conn:
                inserted = conn.execute(
                    """INSERT OR IGNORE INTO dialogue_events
                       (event_id, identity_id, game_id, incarnation_id, speaker, content, metadata_json, created_at)
                       VALUES(?, ?, ?, ?, ?, ?, ?, ?)""",
                    (event_id, identity_id, game_id, incarnation_id, str(item["speaker"]),
                     str(item["content"]), _json(item.get("metadata", {})), item.get("created_at", _now())),
                )
                dialogue_count += max(0, inserted.rowcount)

        experience_count = 0
        for item in bundle.get("experiences", []):
            game_id = _validate_id(item["game_id"], "game_id")
            incarnation_id = _validate_id(item["incarnation_id"], "incarnation_id")
            verified = bool(item.get("verified", False))
            eligible = bool(item.get("training_eligible", False))
            portable = bool(item.get("portable", False))
            semantic_action = item.get("semantic_action")
            if eligible and not verified:
                raise ValueError("Bundle contains training experience that is not verified.")
            if portable and not semantic_action:
                raise ValueError("Bundle contains portable experience without semantic_action.")
            experience_id = str(item.get("experience_id") or uuid.uuid4())
            with self._connection() as conn:
                inserted = conn.execute(
                    """INSERT OR IGNORE INTO experience_events
                       (experience_id, identity_id, game_id, incarnation_id, situation_json, action_json,
                        result_json, semantic_action, reward, verified, training_eligible, portable, created_at)
                       VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (experience_id, identity_id, game_id, incarnation_id,
                     _json(item.get("situation", {})), _json(item.get("action", {})),
                     _json(item.get("result", {})), semantic_action, item.get("reward"), int(verified),
                     int(eligible), int(portable), item.get("created_at", _now())),
                )
                experience_count += max(0, inserted.rowcount)
        return {
            "incarnations_imported": incarnation_count,
            "memories_processed": memory_count,
            "dialogue_imported": dialogue_count,
            "experiences_imported": experience_count,
        }
