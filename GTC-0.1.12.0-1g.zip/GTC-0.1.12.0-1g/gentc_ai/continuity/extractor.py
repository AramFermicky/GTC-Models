"""Conservative starter extractor for possible memories in player dialogue.

It only proposes candidates for review. It never makes an automatically extracted
sentence a confirmed/shared memory and never trains a model from a transcript.
"""
from __future__ import annotations

import re
from typing import Any


class DialogueMemoryExtractor:
    _EXPLICIT = re.compile(r"^(?:пожалуйста[,. ]*)?(?:запомни(?:,?\s+что)?|не забывай(?:,?\s+что)?|remember that)\s+(.+)$", re.IGNORECASE)
    _PREFERENCES = (
        (re.compile(r"\bмне не нравится\s+(.+)$", re.IGNORECASE), "Предпочтение игрока: ему не нравится {value}."),
        (re.compile(r"\bя предпочитаю\s+(.+)$", re.IGNORECASE), "Предпочтение игрока: он предпочитает {value}."),
        (re.compile(r"\bмне нравится\s+(.+)$", re.IGNORECASE), "Предпочтение игрока: ему нравится {value}."),
        (re.compile(r"\bя люблю\s+(.+)$", re.IGNORECASE), "Предпочтение игрока: он любит {value}."),
        (re.compile(r"\bя не люблю\s+(.+)$", re.IGNORECASE), "Предпочтение игрока: он не любит {value}."),
        (re.compile(r"\bi prefer\s+(.+)$", re.IGNORECASE), "Player preference: prefers {value}."),
        (re.compile(r"\bi like\s+(.+)$", re.IGNORECASE), "Player preference: likes {value}."),
        (re.compile(r"\bi love\s+(.+)$", re.IGNORECASE), "Player preference: loves {value}."),
    )

    def extract_candidate(self, text: str) -> dict[str, Any] | None:
        raw = " ".join((text or "").strip().split())
        if not raw:
            return None
        explicit = self._EXPLICIT.match(raw)
        if explicit:
            value = explicit.group(1).strip(" .!?,;:")
            if value:
                return {
                    "content": f"Факт, который игрок попросил запомнить: {value}.",
                    "category": "player_requested_memory",
                    "confidence": 0.95,
                    "requires_confirmation": True,
                }
        for pattern, template in self._PREFERENCES:
            match = pattern.search(raw)
            if match:
                value = match.group(1).strip(" .!?,;:")
                if value and len(value) <= 240:
                    return {
                        "content": template.format(value=value),
                        "category": "player_preference",
                        "confidence": 0.72,
                        "requires_confirmation": True,
                    }
        return None
