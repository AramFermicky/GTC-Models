"""Portable model-owned storage paths.

All mutable learning state belongs to the selected model directory, never to a
machine-wide user-data directory. The launcher should set GTC_MODEL_ROOT to the
root of the selected model. Without it, the installed GTC package root is used.
"""
from __future__ import annotations

import os
import shutil
from pathlib import Path


def get_model_root() -> Path:
    override = os.environ.get("GTC_MODEL_ROOT") or os.environ.get("GTC_DATA_DIR")
    root = Path(override).expanduser() if override else Path(__file__).resolve().parents[2]
    return root.resolve()


def get_model_learning_dir(*parts: str) -> Path:
    """Return a directory inside <model-root>/GTC_learning and create it."""
    base = get_model_root() / "GTC_learning"
    for part in parts:
        candidate = Path(str(part))
        if candidate.is_absolute() or any(p in {"..", ""} for p in candidate.parts):
            raise ValueError(f"Unsafe learning path component: {part!r}")
        base = base / candidate
    base.mkdir(parents=True, exist_ok=True)
    return base


def get_shared_data_dir() -> Path:
    """Backward-compatible alias; shared memory is now model-portable."""
    return get_model_learning_dir()


def bootstrap_legacy_learning() -> Path:
    """Copy the previous packaged learning snapshot into the model-owned vault once.

    The source is never modified. The migration marker prevents repeated copies and
    preserves the exact baseline from which a newer runtime continues learning.
    """
    root = get_model_root()
    target = get_model_learning_dir("inherited", "0.1.10.34-3t")
    marker = get_model_learning_dir() / ".legacy_import_0_1_10_34_3t.done"
    if marker.exists():
        return target
    package_root = Path(__file__).resolve().parents[2]
    packaged_sources = [root / "data", package_root / "data"]
    for packaged_source in packaged_sources:
        for name in ("memory", "learning", "models", "cross_game", "portable"):
            src = packaged_source / name
            dst = target / "data" / name
            if src.is_dir() and not dst.exists():
                shutil.copytree(src, dst, dirs_exist_ok=True)

    legacy_sources: list[Path] = []
    legacy_override = os.environ.get("GTC_DATA_DIR")
    if legacy_override:
        legacy_sources.append(Path(legacy_override).expanduser())
    if os.name == "nt":
        legacy_root = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA")
        if legacy_root:
            legacy_sources.append(Path(legacy_root) / "GenTC AI")
    else:
        xdg = os.environ.get("XDG_DATA_HOME")
        legacy_sources.append((Path(xdg).expanduser() / "gentc_ai") if xdg else Path.home() / ".local" / "share" / "gentc_ai")
    for source in legacy_sources:
        if source.resolve() in {root.resolve(), (root / "GTC_learning").resolve()}:
            continue
        for name in ("memory", "learning", "models", "cross_game", "portable", "worlds", "continuity.sqlite3"):
            src = source / name
            dst = target / "legacy_machine_data" / source.name / name
            if src.is_dir() and not dst.exists():
                shutil.copytree(src, dst, dirs_exist_ok=True)
            elif src.is_file() and not dst.exists():
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
    marker.write_text("Imported legacy packaged and machine learning data; all future writes are model-owned. Sources preserved.\n", encoding="utf-8")
    return target
