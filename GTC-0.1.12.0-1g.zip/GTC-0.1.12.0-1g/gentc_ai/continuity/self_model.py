"""Persistent, inspectable self-model for GenTC's game-agent prototype.

This is an explicit state model (identity, goals, known capabilities and measured
outcomes), not a claim that the agent is conscious.
"""
from __future__ import annotations

import json
import math
import shutil
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _finite(value: Any, default: float = 0.0) -> float:
    try:
        value = float(value)
    except (TypeError, ValueError, OverflowError):
        return default
    return value if math.isfinite(value) else default


class SelfModelStore:
    """Tracks the agent's own identity, action history and calibrated self-knowledge."""

    SCHEMA_VERSION = 1
    MAX_LOG = 48

    def __init__(self, path: Path | str, *, identity_id: str, profile: dict[str, Any] | None = None,
                 runtime_version: str = "GTC-0.1.9") -> None:
        self.path = Path(path)
        self.identity_id = str(identity_id)
        self.runtime_version = str(runtime_version)
        self._lock = threading.RLock()
        profile = profile if isinstance(profile, dict) else {}
        goals = profile.get("goals", [])
        if isinstance(goals, dict):
            goal_names = [str(k) for k in goals]
        elif isinstance(goals, list):
            goal_names = [str(x.get("id", x.get("name", "goal"))) if isinstance(x, dict) else str(x) for x in goals]
        else:
            goal_names = ["stay_safe", "learn_world", "maintain_relationships"]
        values = profile.get("values", {}) if isinstance(profile.get("values"), dict) else {}
        self._data: dict[str, Any] = {
            "schema_version": self.SCHEMA_VERSION,
            "identity_id": self.identity_id,
            "runtime_version_last_seen": self.runtime_version,
            "self_description": "Автономный игровой агент с целями, ограниченной памятью и измеряемым опытом.",
            "not_a_consciousness_claim": True,
            "core_values": {str(k): max(0.0, min(1.0, _finite(v, 0.5))) for k, v in values.items()},
            "goals": goal_names[:64],
            "known_capabilities": [
                "оценивать доступные действия из снимка мира",
                "предлагать действия из списка, разрешённого игровым адаптером",
                "учиться на проверенных результатах",
                "хранить игровой опыт между запусками",
            ],
            "known_limits": [
                "не знает состояние, которого нет в снимке мира",
                "не исполняет действия сам: исполнение и подтверждение принадлежат Godot",
                "ответы чата используют шаблоны; локальная языковая модель не подключена",
                "численная нейросеть оценивает полезность действий и не является общей языковой моделью",
            ],
            "decision_count": 0,
            "confirmed_outcomes": 0,
            "action_statistics": {},
            "game_capabilities": {},
            "recent_reflections": [],
            "last_decision": None,
            "last_outcome": None,
            "updated_at_utc": _now(),
        }
        self.load_warning: str | None = None
        self._load()

    def _backup_source(self, label: str) -> None:
        if not self.path.exists():
            return
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        backup = self.path.with_name(f"{self.path.stem}.{label}-{stamp}{self.path.suffix}")
        try:
            shutil.copy2(self.path, backup)
        except OSError:
            # Keep original untouched even if the optional diagnostic backup fails.
            pass

    def _load(self) -> None:
        if not self.path.exists():
            self._save()
            return
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(raw, dict) or raw.get("schema_version") != self.SCHEMA_VERSION or raw.get("identity_id") != self.identity_id:
                self.load_warning = "self_model_schema_or_identity_mismatch_fresh_baseline_used"
                self._backup_source("incompatible")
                return
            for key in ("decision_count", "confirmed_outcomes"):
                self._data[key] = max(0, int(raw.get(key, 0)))
            for key in ("action_statistics", "game_capabilities", "last_decision", "last_outcome"):
                value = raw.get(key)
                if key == "last_decision" or key == "last_outcome":
                    self._data[key] = value if isinstance(value, (dict, type(None))) else None
                else:
                    self._data[key] = value if isinstance(value, dict) else {}
            self._data["recent_reflections"] = [x for x in raw.get("recent_reflections", []) if isinstance(x, dict)][-self.MAX_LOG:]
            for key in ("self_description", "core_values", "goals", "known_capabilities", "known_limits"):
                if key in raw and isinstance(raw[key], type(self._data[key])):
                    self._data[key] = raw[key]
            self._data["runtime_version_last_seen"] = self.runtime_version
            self._data["updated_at_utc"] = _now()
            self._save()
        except (OSError, UnicodeDecodeError, json.JSONDecodeError, TypeError, ValueError):
            self.load_warning = "self_model_unreadable_fresh_baseline_used"
            self._backup_source("corrupt")

    def _save(self) -> None:
        with self._lock:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self._data["updated_at_utc"] = _now()
            tmp = self.path.with_name(self.path.name + f".{uuid.uuid4().hex}.tmp")
            try:
                tmp.write_text(json.dumps(self._data, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
                tmp.replace(self.path)
            finally:
                try:
                    tmp.unlink(missing_ok=True)
                except OSError:
                    pass

    def record_decision(self, *, action: str, reason: str, context_tags: list[str] | None = None) -> None:
        with self._lock:
            self._data["decision_count"] += 1
            self._data["last_decision"] = {
                "action": str(action)[:100], "reason": str(reason)[:200],
                "context_tags": [str(x)[:64] for x in (context_tags or [])[:16]], "at_utc": _now(),
            }
            self._save()

    def record_available_capabilities(
        self, *, game_id: str, world_id: str, actions: list[str], object_types: list[str],
        runtime_version: str | None = None,
    ) -> None:
        """Record only what the current game's adapter says is available/observable."""
        game = str(game_id or "unknown")[:64]
        world = str(world_id or "unknown")[:96]
        action_names = sorted({str(x)[:96] for x in actions if str(x)})[:128]
        object_names = sorted({str(x)[:96] for x in object_types if str(x)})[:128]
        with self._lock:
            games = self._data.setdefault("game_capabilities", {})
            game_record = games.setdefault(game, {"worlds": {}, "observations": 0})
            world_record = game_record.setdefault("worlds", {}).setdefault(world, {
                "actions": {}, "object_types": {}, "observations": 0,
            })
            now = _now()
            world_record["observations"] = max(0, int(world_record.get("observations", 0))) + 1
            world_record["last_seen_utc"] = now
            game_record["observations"] = max(0, int(game_record.get("observations", 0))) + 1
            game_record["last_seen_utc"] = now
            for name in action_names:
                entry = world_record["actions"].setdefault(name, {"observations": 0})
                entry["observations"] = max(0, int(entry.get("observations", 0))) + 1
                entry["last_seen_utc"] = now
            for name in object_names:
                entry = world_record["object_types"].setdefault(name, {"observations": 0})
                entry["observations"] = max(0, int(entry.get("observations", 0))) + 1
                entry["last_seen_utc"] = now
            world_record["runtime_version"] = str(runtime_version or self.runtime_version)[:64]
            # Keep the self-model inspectable: bound worlds and games while retaining
            # the most recently observed contexts.
            if len(game_record["worlds"]) > 128:
                ordered_worlds = sorted(game_record["worlds"].items(), key=lambda pair: str(pair[1].get("last_seen_utc", "")), reverse=True)
                game_record["worlds"] = dict(ordered_worlds[:128])
            if len(games) > 64:
                ordered_games = sorted(games.items(), key=lambda pair: str(pair[1].get("last_seen_utc", "")), reverse=True)
                self._data["game_capabilities"] = dict(ordered_games[:64])
            self._save()

    def record_outcome(self, *, action: str, outcome: dict[str, Any], reward: float) -> bool:
        if not isinstance(outcome, dict):
            return False
        # A confirmed violation is still a confirmed experience and must shape self-calibration.
        if not (outcome.get("verified") is True and outcome.get("execution_confirmed") is True):
            return False
        name = str(action)[:100] or "unknown"
        reward = max(-1.0, min(1.0, _finite(reward)))
        goal_achieved = outcome.get("goal_achieved") is True
        observed_harm = max(0.0, min(1.0, _finite(outcome.get("observed_harm", 0.0))))
        with self._lock:
            stats = self._data["action_statistics"].setdefault(name, {"tries": 0, "successes": 0, "failures": 0, "mean_reward": 0.0})
            tries = int(stats.get("tries", 0)) + 1
            old_mean = _finite(stats.get("mean_reward", 0.0))
            stats["tries"] = tries
            constraint_ok = outcome.get("constraints_respected") is True
            safe_success = goal_achieved and observed_harm <= 0 and constraint_ok
            stats["successes"] = int(stats.get("successes", 0)) + int(safe_success)
            stats["failures"] = int(stats.get("failures", 0)) + int(not safe_success)
            stats["mean_reward"] = old_mean + (reward - old_mean) / tries
            stats["success_rate"] = stats["successes"] / tries
            self._data["confirmed_outcomes"] += 1
            self._data["last_outcome"] = {"action": name, "goal_achieved": goal_achieved,
                "observed_harm": observed_harm, "constraints_respected": constraint_ok,
                "reward": reward, "at_utc": _now()}
            if not constraint_ok:
                lesson = f"Действие «{name}» нарушило ограничение; не повторяй его без изменения предпосылок и проверки допустимых альтернатив."
            elif observed_harm > 0:
                lesson = f"Пересмотри условия действия «{name}»: подтверждён вред ({observed_harm:.2f}), даже если часть цели достигнута."
            elif goal_achieved:
                lesson = f"Действие «{name}» принесло подтверждённый успех; повторять его стоит только в похожих обстоятельствах."
            else:
                lesson = f"Действие «{name}» не достигло цели; проверь предпосылки и альтернативы перед повтором."
            self._data["recent_reflections"].append({"lesson": lesson, "action": name,
                "reward": reward, "context": str(outcome.get("outcome_summary", outcome.get("failure_reason", "")))[:180], "at_utc": _now()})
            self._data["recent_reflections"] = self._data["recent_reflections"][-self.MAX_LOG:]
            self._save()
            return True

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return json.loads(json.dumps(self._data, ensure_ascii=False, allow_nan=False))
