"""Append-only, version-aware knowledge ledger implementing the GTC 1+2=3 rule.

1 = inherited confirmed knowledge; 2 = new confirmed experience; 3 = a
consolidated view. Original records are never overwritten. A newer model build
wins the default recall ordering, while confidence and independent support
remain visible so recency cannot silently turn a guess into truth.
"""
from __future__ import annotations

import json
import re
import sqlite3
import threading
from contextlib import contextmanager
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _version_key(value: str) -> tuple[int, ...]:
    nums = re.findall(r"\d+", str(value))
    return tuple(int(x) for x in nums[:8]) or (0,)


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False, default=str)


class VersionedKnowledgeStore:
    SCHEMA_VERSION = 1

    def __init__(self, path: str | Path, *, current_version: str):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.current_version = str(current_version)
        self._lock = threading.RLock()
        self._initialize()

    @contextmanager
    def _connect(self):
        conn = sqlite3.connect(str(self.path), timeout=15.0)
        conn.row_factory = sqlite3.Row
        try:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA foreign_keys=ON")
            with conn:
                yield conn
        finally:
            conn.close()

    def _initialize(self) -> None:
        with self._connect() as conn:
            conn.execute("""CREATE TABLE IF NOT EXISTS knowledge (
                record_id TEXT PRIMARY KEY,
                identity_id TEXT NOT NULL,
                game_id TEXT NOT NULL,
                semantic_key TEXT NOT NULL,
                statement TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                source_version TEXT NOT NULL,
                source_kind TEXT NOT NULL,
                verified INTEGER NOT NULL,
                confidence REAL NOT NULL,
                support_count INTEGER NOT NULL DEFAULT 1,
                supersedes_id TEXT,
                active INTEGER NOT NULL DEFAULT 1,
                created_at_utc TEXT NOT NULL
            )""")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_knowledge_recall ON knowledge(identity_id, semantic_key, active)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_knowledge_version ON knowledge(source_version)")
            conn.execute("PRAGMA user_version=1")

    def add(self, *, identity_id: str, game_id: str, semantic_key: str, statement: str,
            payload: dict[str, Any] | None = None, verified: bool, confidence: float,
            source_kind: str = "verified_experience", source_version: str | None = None,
            supersedes_id: str | None = None, record_id: str | None = None) -> dict[str, Any]:
        if not verified:
            return {"stored": False, "reason": "unverified_knowledge_rejected"}
        identity, game, semantic, text = (str(identity_id).strip(), str(game_id).strip(),
                                           str(semantic_key).strip(), str(statement).strip())
        if not all((identity, game, semantic, text)):
            raise ValueError("identity_id, game_id, semantic_key and statement are required")
        conf = max(0.0, min(1.0, float(confidence)))
        version = str(source_version or self.current_version)
        rid = str(record_id or uuid.uuid4().hex)
        now = datetime.now(timezone.utc).isoformat()
        with self._lock, self._connect() as conn:
            existing = conn.execute("SELECT record_id FROM knowledge WHERE record_id=?", (rid,)).fetchone()
            if existing:
                return {"stored": False, "duplicate": True, "record_id": rid}
            if supersedes_id:
                # Supersession is an explicit overlay, not deletion. It may only
                # replace the same semantic fact and never a newer model build.
                prior = conn.execute(
                    "SELECT identity_id,semantic_key,source_version FROM knowledge WHERE record_id=?",
                    (str(supersedes_id),),
                ).fetchone()
                if prior is None or prior["identity_id"] != identity or prior["semantic_key"] != semantic:
                    raise ValueError("superseded_record_must_match_identity_and_semantic_key")
                if _version_key(version) < _version_key(str(prior["source_version"])):
                    raise ValueError("older_build_cannot_supersede_newer_knowledge")
                conn.execute("UPDATE knowledge SET active=0 WHERE record_id=? AND identity_id=?",
                             (str(supersedes_id), identity))
            conn.execute("""INSERT INTO knowledge(record_id,identity_id,game_id,semantic_key,statement,
                payload_json,source_version,source_kind,verified,confidence,support_count,supersedes_id,active,created_at_utc)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,1,?)""",
                (rid, identity, game, semantic, text, _json(payload or {}), version,
                 str(source_kind), 1, conf, 1, supersedes_id, now))
        return {"stored": True, "record_id": rid, "source_version": version, "priority": _version_key(version)}

    def recall(self, *, identity_id: str, semantic_key: str, game_id: str | None = None,
               limit: int = 20, include_superseded: bool = False) -> list[dict[str, Any]]:
        clauses = ["identity_id=?", "semantic_key=?"]
        args: list[Any] = [str(identity_id), str(semantic_key)]
        if not include_superseded:
            clauses.append("active=1")
        if game_id:
            clauses.append("(game_id=? OR game_id='*')")
            args.append(str(game_id))
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM knowledge WHERE " + " AND ".join(clauses), args).fetchall()
        records = []
        for row in rows:
            item = dict(row)
            item["payload"] = json.loads(item.pop("payload_json"))
            item["verified"] = bool(item["verified"])
            item["active"] = bool(item["active"])
            item["version_priority"] = _version_key(item["source_version"])
            records.append(item)
        # Version provenance is the first ranking key; verification/confidence/support
        # break ties within a build. Older records remain available for explicit recall.
        records.sort(key=lambda r: (r["version_priority"], r["verified"], r["confidence"],
                                    r["support_count"], r["created_at_utc"]), reverse=True)
        return records[:max(0, min(int(limit), 500))]

    def consolidate(self, *, identity_id: str, semantic_key: str, statement: str,
                     payload: dict[str, Any] | None = None, confidence: float = 1.0,
                     source_version: str | None = None) -> dict[str, Any]:
        prior = self.recall(identity_id=identity_id, semantic_key=semantic_key, limit=500)
        support = len(prior)
        return self.add(identity_id=identity_id, game_id="*", semantic_key=semantic_key,
                        statement=statement, payload={**(payload or {}), "combined_records": support,
                        "rule": "1+2=3"}, verified=True, confidence=confidence,
                        source_kind="consolidated", source_version=source_version)

    def report(self) -> dict[str, Any]:
        with self._connect() as conn:
            total = int(conn.execute("SELECT COUNT(*) FROM knowledge").fetchone()[0])
            active = int(conn.execute("SELECT COUNT(*) FROM knowledge WHERE active=1").fetchone()[0])
            versions = [str(row[0]) for row in conn.execute("SELECT DISTINCT source_version FROM knowledge ORDER BY source_version")]
        return {"records": total, "active_records": active, "versions": versions,
                "current_version": self.current_version, "database_path": str(self.path),
                "policy": "newer verified build first; immutable history; explicit supersession"}
