"""Persistent, version-independent world and mechanic memory for GenTC AI.

This store records world visits, adapter-described mechanics, and action outcomes.
Only outcomes confirmed by the game can enter the training set. Data stays local.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$")
_MECHANIC_SCOPES = {"world", "game"}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def _safe_id(value: Any, label: str) -> str:
    if not isinstance(value, str) or not _ID_RE.fullmatch(value):
        raise ValueError(f"{label}: допустимы 1–128 букв латиницы, цифр, '.', '_', ':' или '-'.")
    return value


def _clamp(value: Any, low: float = 0.0, high: float = 1.0, default: float = 0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return default
    if not math.isfinite(number):
        return default
    return max(low, min(high, number))


def _key(*parts: str) -> str:
    return hashlib.sha256("\x1f".join(parts).encode("utf-8")).hexdigest()


class WorldMemoryStore:
    """SQLite ledger for world history, learned mechanics, and confirmed outcomes."""

    SCHEMA_VERSION = 1

    def __init__(self, db_path: Path | str):
        self.db_path = Path(db_path).expanduser()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=15.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA busy_timeout=15000")
        return conn

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        conn = self._connect()
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def _initialize(self) -> None:
        with self._connection() as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS metadata (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS worlds (
                    world_key TEXT PRIMARY KEY,
                    identity_id TEXT NOT NULL,
                    game_id TEXT NOT NULL,
                    world_id TEXT NOT NULL,
                    world_name TEXT NOT NULL,
                    game_version TEXT NOT NULL,
                    adapter_version TEXT NOT NULL,
                    first_seen TEXT NOT NULL,
                    last_seen TEXT NOT NULL,
                    visit_count INTEGER NOT NULL DEFAULT 0,
                    summary_json TEXT NOT NULL DEFAULT '{}',
                    UNIQUE(identity_id, game_id, world_id)
                );
                CREATE TABLE IF NOT EXISTS sessions (
                    session_key TEXT PRIMARY KEY,
                    session_id TEXT NOT NULL,
                    world_key TEXT NOT NULL REFERENCES worlds(world_key),
                    runtime_version TEXT NOT NULL,
                    started_at TEXT NOT NULL,
                    last_seen TEXT NOT NULL,
                    UNIQUE(session_id, world_key)
                );
                CREATE TABLE IF NOT EXISTS mechanic_knowledge (
                    knowledge_id TEXT PRIMARY KEY,
                    identity_id TEXT NOT NULL,
                    scope TEXT NOT NULL CHECK(scope IN ('world', 'game', 'portable')),
                    game_id TEXT,
                    world_id TEXT,
                    semantic_key TEXT NOT NULL,
                    statement TEXT NOT NULL,
                    conditions_json TEXT NOT NULL DEFAULT '{}',
                    effects_json TEXT NOT NULL DEFAULT '{}',
                    confidence REAL NOT NULL CHECK(confidence >= 0.0 AND confidence <= 1.0),
                    verified INTEGER NOT NULL DEFAULT 0,
                    source TEXT NOT NULL DEFAULT 'adapter',
                    source_version TEXT NOT NULL DEFAULT 'unknown',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_mechanics_lookup
                    ON mechanic_knowledge(identity_id, scope, game_id, world_id, semantic_key, verified);
                CREATE TABLE IF NOT EXISTS experiences (
                    experience_id TEXT PRIMARY KEY,
                    identity_id TEXT NOT NULL,
                    game_id TEXT NOT NULL,
                    world_id TEXT NOT NULL,
                    session_id TEXT NOT NULL,
                    runtime_version TEXT NOT NULL,
                    action_name TEXT NOT NULL,
                    semantic_action TEXT NOT NULL,
                    situation_json TEXT NOT NULL,
                    action_json TEXT NOT NULL,
                    outcome_json TEXT NOT NULL,
                    features_json TEXT NOT NULL DEFAULT '[]',
                    reward REAL,
                    verified INTEGER NOT NULL DEFAULT 0,
                    execution_confirmed INTEGER NOT NULL DEFAULT 0,
                    training_eligible INTEGER NOT NULL DEFAULT 0,
                    portable INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_experiences_world
                    ON experiences(identity_id, game_id, world_id, created_at);
                CREATE INDEX IF NOT EXISTS idx_experiences_training
                    ON experiences(identity_id, training_eligible, verified, portable, semantic_action);
                """
            )
            conn.execute(
                "INSERT INTO metadata(key, value) VALUES('schema_version', ?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (str(self.SCHEMA_VERSION),),
            )

    def register_world(
        self,
        *,
        identity_id: str,
        game_id: str,
        world_id: str,
        world_name: str = "Unnamed world",
        game_version: str = "unknown",
        adapter_version: str = "unknown",
        session_id: str | None = None,
        summary: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        identity_id = _safe_id(identity_id, "identity_id")
        game_id = _safe_id(game_id, "game_id")
        world_id = _safe_id(world_id, "world_id")
        world_name = str(world_name).strip()[:160] or world_id
        game_version = str(game_version or "unknown")[:64]
        adapter_version = str(adapter_version or "unknown")[:96]
        now = _now()
        world_key = _key(identity_id, game_id, world_id)
        session_id = _safe_id(session_id or uuid.uuid4().hex, "session_id")
        summary = summary if isinstance(summary, dict) else {}
        with self._connection() as conn:
            conn.execute(
                """INSERT INTO worlds(world_key, identity_id, game_id, world_id, world_name,
                   game_version, adapter_version, first_seen, last_seen, visit_count, summary_json)
                   VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)
                   ON CONFLICT(identity_id, game_id, world_id) DO UPDATE SET
                     world_name=excluded.world_name, game_version=excluded.game_version,
                     adapter_version=excluded.adapter_version, last_seen=excluded.last_seen,
                     summary_json=excluded.summary_json""",
                (world_key, identity_id, game_id, world_id, world_name, game_version,
                 adapter_version, now, now, _json(summary)),
            )
            conn.execute(
                "INSERT OR IGNORE INTO sessions(session_key, session_id, world_key, runtime_version, started_at, last_seen) "
                "VALUES(?, ?, ?, ?, ?, ?)",
                (_key(session_id, world_key), session_id, world_key, game_version, now, now),
            )
            inserted = conn.execute("SELECT changes() AS n").fetchone()["n"] == 1
            if inserted:
                conn.execute("UPDATE worlds SET visit_count=visit_count+1 WHERE world_key=?", (world_key,))
            else:
                conn.execute(
                    "UPDATE sessions SET last_seen=? WHERE session_id=? AND world_key=?",
                    (now, session_id, world_key),
                )
            world = conn.execute("SELECT * FROM worlds WHERE world_key=?", (world_key,)).fetchone()
        return self._world_row(world)

    @staticmethod
    def _world_row(row: sqlite3.Row) -> dict[str, Any]:
        result = dict(row)
        result["summary"] = json.loads(result.pop("summary_json"))
        return result

    def record_mechanic(
        self,
        *,
        identity_id: str,
        game_id: str,
        world_id: str,
        semantic_key: str,
        statement: str,
        scope: str = "world",
        confidence: float = 1.0,
        verified: bool = False,
        conditions: dict[str, Any] | None = None,
        effects: dict[str, Any] | None = None,
        source: str = "adapter",
        source_version: str = "unknown",
    ) -> str:
        identity_id = _safe_id(identity_id, "identity_id")
        game_id = _safe_id(game_id, "game_id")
        world_id = _safe_id(world_id, "world_id")
        semantic_key = _safe_id(semantic_key, "semantic_key")
        if scope not in _MECHANIC_SCOPES:
            raise ValueError(f"scope должен быть одним из {sorted(_MECHANIC_SCOPES)}")
        statement = str(statement).strip()[:1200]
        if not statement:
            raise ValueError("statement не может быть пустым")
        confidence = _clamp(confidence)
        source_version = str(source_version or "unknown")[:96]
        key_scope_game = game_id
        key_scope_world = None if scope == "game" else world_id
        knowledge_id = _key(identity_id, scope, key_scope_game or "", key_scope_world or "", semantic_key, statement)
        now = _now()
        with self._connection() as conn:
            conn.execute(
                """INSERT INTO mechanic_knowledge(knowledge_id, identity_id, scope, game_id, world_id,
                   semantic_key, statement, conditions_json, effects_json, confidence, verified, source,
                   source_version, created_at, updated_at)
                   VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                   ON CONFLICT(knowledge_id) DO UPDATE SET
                     confidence=CASE WHEN mechanic_knowledge.confidence > excluded.confidence
                                     THEN mechanic_knowledge.confidence ELSE excluded.confidence END,
                     verified=MAX(mechanic_knowledge.verified, excluded.verified),
                     conditions_json=excluded.conditions_json, effects_json=excluded.effects_json,
                     source=excluded.source, source_version=excluded.source_version,
                     updated_at=excluded.updated_at""",
                (knowledge_id, identity_id, scope, key_scope_game, key_scope_world, semantic_key,
                 statement, _json(conditions or {}), _json(effects or {}), confidence, int(verified),
                 str(source)[:80], source_version, now, now),
            )
        return knowledge_id

    def promote_mechanic(self, *, identity_id: str, semantic_key: str, statement: str,
                         minimum_observations: int = 3, minimum_games: int = 2) -> dict[str, Any]:
        """Promote a mechanic only after matching verified observations across multiple games."""
        identity_id = _safe_id(identity_id, "identity_id")
        semantic_key = _safe_id(semantic_key, "semantic_key")
        statement = str(statement).strip()[:1200]
        if not statement:
            raise ValueError("statement не может быть пустым")
        minimum_observations = max(3, min(int(minimum_observations), 10000))
        minimum_games = max(2, min(int(minimum_games), 1000))
        with self._connection() as conn:
            row = conn.execute(
                """SELECT COUNT(*) AS n, COUNT(DISTINCT game_id) AS games,
                          AVG(confidence) AS confidence
                   FROM mechanic_knowledge WHERE identity_id=? AND semantic_key=? AND statement=?
                     AND scope IN ('world', 'game') AND verified=1""",
                (identity_id, semantic_key, statement),
            ).fetchone()
            count, game_count = int(row["n"]), int(row["games"])
            if count < minimum_observations or game_count < minimum_games:
                return {"promoted": False, "observation_count": count, "game_count": game_count,
                        "reason": "need_more_verified_cross_game_observations"}
            confidence = _clamp(row["confidence"], default=0.5)
            portable_id = _key(identity_id, "portable", semantic_key, statement)
            now = _now()
            conn.execute(
                """INSERT INTO mechanic_knowledge(knowledge_id, identity_id, scope, game_id, world_id,
                   semantic_key, statement, conditions_json, effects_json, confidence, verified, source,
                   source_version, created_at, updated_at)
                   VALUES(?, ?, 'portable', NULL, NULL, ?, ?, '{}', '{}', ?, 1, 'cross_game_evidence',
                          'multiple_versions', ?, ?)
                   ON CONFLICT(knowledge_id) DO UPDATE SET confidence=excluded.confidence,
                     updated_at=excluded.updated_at""",
                (portable_id, identity_id, semantic_key, statement, confidence, now, now),
            )
        return {"promoted": True, "observation_count": count, "game_count": game_count,
                "confidence": round(confidence, 4)}

    def get_mechanics(
        self, *, identity_id: str, game_id: str, world_id: str, limit: int = 50,
        verified_only: bool = True,
    ) -> list[dict[str, Any]]:
        identity_id = _safe_id(identity_id, "identity_id")
        game_id = _safe_id(game_id, "game_id")
        world_id = _safe_id(world_id, "world_id")
        limit = max(1, min(int(limit), 500))
        verification = "AND verified=1" if verified_only else ""
        with self._connection() as conn:
            rows = conn.execute(
                f"""SELECT * FROM mechanic_knowledge WHERE identity_id=? AND (
                     scope='portable' OR (scope='game' AND game_id=?) OR
                     (scope='world' AND game_id=? AND world_id=?)) {verification}
                     ORDER BY CASE scope WHEN 'portable' THEN 0 WHEN 'game' THEN 1 ELSE 2 END,
                              confidence DESC, updated_at DESC LIMIT ?""",
                (identity_id, game_id, game_id, world_id, limit),
            ).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["verified"] = bool(item["verified"])
            item["conditions"] = json.loads(item.pop("conditions_json"))
            item["effects"] = json.loads(item.pop("effects_json"))
            result.append(item)
        return result

    @staticmethod
    def reward_from_outcome(outcome: dict[str, Any]) -> float | None:
        # A real executed outcome is learnable even when it broke a constraint:
        # the violation must become strong negative evidence, not disappear from memory.
        verified = outcome.get("verified") is True and outcome.get("execution_confirmed") is True
        if not verified:
            return None
        reward = 0.45 if outcome.get("goal_achieved") is True else -0.18
        if outcome.get("constraints_respected") is not True:
            reward -= 0.75
        reward -= 0.80 * _clamp(outcome.get("observed_harm", 0.0))
        reward -= 0.22 * _clamp(outcome.get("unexpected_cost", 0.0))
        return round(max(-1.0, min(1.0, reward)), 6)

    def record_experience(
        self,
        *,
        identity_id: str,
        game_id: str,
        world_id: str,
        session_id: str,
        runtime_version: str,
        situation: dict[str, Any],
        action: dict[str, Any],
        outcome: dict[str, Any],
        features: list[float] | None = None,
        experience_id: str | None = None,
    ) -> dict[str, Any]:
        identity_id = _safe_id(identity_id, "identity_id")
        game_id = _safe_id(game_id, "game_id")
        world_id = _safe_id(world_id, "world_id")
        session_id = _safe_id(session_id, "session_id")
        if not isinstance(situation, dict) or not isinstance(action, dict) or not isinstance(outcome, dict):
            raise ValueError("situation, action и outcome должны быть объектами")
        action_name = _safe_id(str(action.get("action", "unknown")), "action")
        semantic_action = _safe_id(str(action.get("semantic_action", action_name)), "semantic_action")
        verified = outcome.get("verified") is True
        execution_confirmed = outcome.get("execution_confirmed") is True
        reward = self.reward_from_outcome(outcome)
        training_eligible = reward is not None
        experience_id = _safe_id(experience_id or uuid.uuid4().hex, "experience_id")
        feature_values: list[float] = []
        if isinstance(features, list):
            for value in features[:256]:
                try:
                    number = float(value)
                    feature_values.append(number if math.isfinite(number) else 0.0)
                except (TypeError, ValueError, OverflowError):
                    feature_values.append(0.0)
        now = _now()
        with self._connection() as conn:
            cursor = conn.execute(
                """INSERT OR IGNORE INTO experiences(experience_id, identity_id, game_id, world_id,
                   session_id, runtime_version, action_name, semantic_action, situation_json, action_json,
                   outcome_json, features_json, reward, verified, execution_confirmed, training_eligible,
                   portable, created_at) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)""",
                (experience_id, identity_id, game_id, world_id, session_id, str(runtime_version)[:64],
                 action_name, semantic_action, _json(situation), _json(action), _json(outcome),
                 _json(feature_values), reward, int(verified), int(execution_confirmed),
                 int(training_eligible), now),
            )
            inserted = cursor.rowcount > 0
        return {
            "experience_id": experience_id,
            "stored": inserted,
            "duplicate": not inserted,
            "verified": verified,
            "execution_confirmed": execution_confirmed,
            "training_eligible": training_eligible,
            "reward": reward,
        }

    def count_training_examples(self, *, identity_id: str, game_id: str) -> int:
        """Count all verified, eligible examples for a game without loading feature vectors."""
        identity_id = _safe_id(identity_id, "identity_id")
        game_id = _safe_id(game_id, "game_id")
        with self._connection() as conn:
            row = conn.execute(
                """SELECT COUNT(*) AS n FROM experiences
                   WHERE identity_id=? AND game_id=? AND training_eligible=1
                   AND verified=1 AND execution_confirmed=1 AND reward IS NOT NULL""",
                (identity_id, game_id),
            ).fetchone()
        return int(row["n"])

    def get_training_examples(
        self, *, identity_id: str, game_id: str, limit: int = 256,
    ) -> list[dict[str, Any]]:
        identity_id = _safe_id(identity_id, "identity_id")
        game_id = _safe_id(game_id, "game_id")
        limit = max(1, min(int(limit), 5000))
        with self._connection() as conn:
            rows = conn.execute(
                """SELECT experience_id, action_name, semantic_action, features_json, reward, created_at
                   FROM experiences WHERE identity_id=? AND game_id=? AND training_eligible=1
                   AND verified=1 AND execution_confirmed=1 AND reward IS NOT NULL
                   ORDER BY created_at DESC LIMIT ?""",
                (identity_id, game_id, limit),
            ).fetchall()
        data = []
        for row in reversed(rows):
            item = dict(row)
            item["features"] = json.loads(item.pop("features_json"))
            data.append(item)
        return data

    def get_action_estimate(
        self, *, identity_id: str, game_id: str, world_id: str,
        action_name: str, semantic_action: str, limit: int = 400,
    ) -> dict[str, Any]:
        """Return a conservative reward estimate from this world/game and promoted portable cases."""
        identity_id = _safe_id(identity_id, "identity_id")
        game_id = _safe_id(game_id, "game_id")
        world_id = _safe_id(world_id, "world_id")
        action_name = _safe_id(action_name, "action_name")
        semantic_action = _safe_id(semantic_action, "semantic_action")
        limit = max(1, min(int(limit), 1000))
        with self._connection() as conn:
            rows = conn.execute(
                """SELECT game_id, world_id, action_name, semantic_action, reward, portable
                   FROM experiences WHERE identity_id=? AND training_eligible=1 AND verified=1
                   AND reward IS NOT NULL AND (
                     (game_id=? AND action_name=? ) OR
                     (portable=1 AND semantic_action=?)
                   ) ORDER BY created_at DESC LIMIT ?""",
                (identity_id, game_id, action_name, semantic_action, limit),
            ).fetchall()
        weighted_sum = 0.0
        weight_total = 0.0
        used = 0
        for row in rows:
            if row["game_id"] != game_id and not bool(row["portable"]):
                continue
            if row["game_id"] == game_id and row["world_id"] == world_id:
                weight = 1.0
            elif row["game_id"] == game_id:
                weight = 0.65
            else:
                weight = 0.35
            weighted_sum += float(row["reward"]) * weight
            weight_total += weight
            used += 1
        mean = weighted_sum / weight_total if weight_total else 0.0
        confidence = min(1.0, weight_total / 5.0)
        return {
            "mean_reward": round(mean, 6),
            "confidence": round(confidence, 6),
            "sample_count": used,
            "has_data": used > 0,
        }

    def promote_portable_experience(self, *, identity_id: str, semantic_action: str,
                                    minimum_examples: int = 3, minimum_games: int = 2) -> dict[str, Any]:
        """Promote a semantic action's outcomes only after verified evidence spans games."""
        identity_id = _safe_id(identity_id, "identity_id")
        semantic_action = _safe_id(semantic_action, "semantic_action")
        minimum_examples = max(3, min(int(minimum_examples), 10000))
        minimum_games = max(2, min(int(minimum_games), 1000))
        with self._connection() as conn:
            row = conn.execute(
                """SELECT COUNT(*) AS n, COUNT(DISTINCT game_id) AS games FROM experiences
                   WHERE identity_id=? AND semantic_action=? AND training_eligible=1 AND verified=1
                   AND execution_confirmed=1 AND reward IS NOT NULL""",
                (identity_id, semantic_action),
            ).fetchone()
            count, games = int(row["n"]), int(row["games"])
            if count < minimum_examples or games < minimum_games:
                return {"promoted": False, "example_count": count, "game_count": games,
                        "reason": "need_more_verified_cross_game_evidence"}
            conn.execute(
                """UPDATE experiences SET portable=1 WHERE identity_id=? AND semantic_action=?
                   AND training_eligible=1 AND verified=1 AND execution_confirmed=1""",
                (identity_id, semantic_action),
            )
        return {"promoted": True, "example_count": count, "game_count": games}

    def get_recent_experiences(
        self, *, identity_id: str, game_id: str, world_id: str, limit: int = 20,
    ) -> list[dict[str, Any]]:
        identity_id = _safe_id(identity_id, "identity_id")
        game_id = _safe_id(game_id, "game_id")
        world_id = _safe_id(world_id, "world_id")
        limit = max(1, min(int(limit), 200))
        with self._connection() as conn:
            rows = conn.execute(
                """SELECT experience_id, runtime_version, action_name, semantic_action, reward,
                   verified, execution_confirmed, training_eligible, outcome_json, created_at
                   FROM experiences WHERE identity_id=? AND game_id=? AND world_id=?
                   ORDER BY created_at DESC LIMIT ?""",
                (identity_id, game_id, world_id, limit),
            ).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["verified"] = bool(item["verified"])
            item["execution_confirmed"] = bool(item["execution_confirmed"])
            item["training_eligible"] = bool(item["training_eligible"])
            item["outcome"] = json.loads(item.pop("outcome_json"))
            result.append(item)
        return result

    def recall(self, *, identity_id: str, game_id: str, world_id: str,
               recent_limit: int = 8, mechanic_limit: int = 25) -> dict[str, Any]:
        mechanics = self.get_mechanics(identity_id=identity_id, game_id=game_id,
                                       world_id=world_id, limit=mechanic_limit)
        experiences = self.get_recent_experiences(identity_id=identity_id, game_id=game_id,
                                                   world_id=world_id, limit=recent_limit)
        estimates: dict[str, dict[str, Any]] = {}
        for item in experiences:
            if item.get("training_eligible"):
                action_name = item["action_name"]
                estimates[action_name] = self.get_action_estimate(
                    identity_id=identity_id, game_id=game_id, world_id=world_id,
                    action_name=action_name, semantic_action=item["semantic_action"])
        return {"mechanics": mechanics, "recent_experiences": experiences,
                "action_estimates": estimates}

    def report(self, *, identity_id: str | None = None) -> dict[str, Any]:
        with self._connection() as conn:
            if identity_id is None:
                worlds = conn.execute("SELECT COUNT(*) n FROM worlds").fetchone()["n"]
                sessions = conn.execute("SELECT COUNT(*) n FROM sessions").fetchone()["n"]
                mechanics = conn.execute("SELECT COUNT(*) n FROM mechanic_knowledge WHERE verified=1").fetchone()["n"]
                experiences = conn.execute("SELECT COUNT(*) n FROM experiences").fetchone()["n"]
                verified = conn.execute("SELECT COUNT(*) n FROM experiences WHERE training_eligible=1").fetchone()["n"]
                portable = conn.execute("SELECT COUNT(*) n FROM experiences WHERE portable=1").fetchone()["n"]
            else:
                identity_id = _safe_id(identity_id, "identity_id")
                worlds = conn.execute("SELECT COUNT(*) n FROM worlds WHERE identity_id=?", (identity_id,)).fetchone()["n"]
                sessions = conn.execute("SELECT COUNT(*) n FROM sessions s JOIN worlds w ON w.world_key=s.world_key WHERE w.identity_id=?", (identity_id,)).fetchone()["n"]
                mechanics = conn.execute("SELECT COUNT(*) n FROM mechanic_knowledge WHERE identity_id=? AND verified=1", (identity_id,)).fetchone()["n"]
                experiences = conn.execute("SELECT COUNT(*) n FROM experiences WHERE identity_id=?", (identity_id,)).fetchone()["n"]
                verified = conn.execute("SELECT COUNT(*) n FROM experiences WHERE identity_id=? AND training_eligible=1", (identity_id,)).fetchone()["n"]
                portable = conn.execute("SELECT COUNT(*) n FROM experiences WHERE identity_id=? AND portable=1", (identity_id,)).fetchone()["n"]
        return {"schema_version": self.SCHEMA_VERSION, "worlds": int(worlds), "sessions": int(sessions),
                "verified_mechanics": int(mechanics), "experiences": int(experiences),
                "training_eligible_experiences": int(verified), "portable_experiences": int(portable),
                "database_path": str(self.db_path)}
