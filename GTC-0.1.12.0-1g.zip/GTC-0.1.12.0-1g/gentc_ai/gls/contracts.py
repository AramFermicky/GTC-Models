"""Versioned language-model data contracts, independent of any model vendor."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol, Any
import hashlib, math

@dataclass(frozen=True)
class LanguageExample:
    prompt: str
    response: str
    source: str = "approved_local_corpus"
    quality: float = 0.5
    def __post_init__(self) -> None:
        if not self.prompt.strip() or not self.response.strip(): raise ValueError("prompt and response must be non-empty")
        if len(self.prompt) > 12000 or len(self.response) > 12000: raise ValueError("language sample is too long")
        if not math.isfinite(self.quality) or not 0 <= self.quality <= 1: raise ValueError("quality must be in [0,1]")
    @property
    def fingerprint(self) -> str:
        normalized = "\n".join((self.prompt.strip(), self.response.strip())).casefold()
        return hashlib.sha256(normalized.encode("utf-8")).hexdigest()

@dataclass(frozen=True)
class GenerationRequest:
    prompt: str
    max_tokens: int = 128
    temperature: float = 0.7
    system_prompt: str = ""
    def __post_init__(self) -> None:
        if not self.prompt.strip() or len(self.prompt) > 16000: raise ValueError("prompt is empty or too long")
        if not 1 <= self.max_tokens <= 4096: raise ValueError("max_tokens must be in [1,4096]")
        if not math.isfinite(self.temperature) or not 0 <= self.temperature <= 2: raise ValueError("temperature must be in [0,2]")

@dataclass(frozen=True)
class GenerationResult:
    text: str
    model_id: str
    elapsed_seconds: float
    metadata: dict[str, Any] | None = None

class TextBackend(Protocol):
    def generate(self, request: GenerationRequest) -> GenerationResult: ...
