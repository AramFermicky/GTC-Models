"""GLS (Genetic Learning Speech) data/runtime contracts; no model weights bundled."""
from .contracts import LanguageExample, GenerationRequest, GenerationResult, TextBackend
from .dataset import JsonlDataset
from .checkpoint import CheckpointManager
from .inference import GLSRuntime
from .training import TrainingPlan, split_dataset, evaluate_candidate
__all__ = ["LanguageExample", "GenerationRequest", "GenerationResult", "TextBackend", "JsonlDataset", "CheckpointManager", "GLSRuntime", "TrainingPlan", "split_dataset", "evaluate_candidate"]
