"""Append-only JSONL dataset with per-example deduplication and explicit local path."""
from __future__ import annotations
import json, threading
from pathlib import Path
from .contracts import LanguageExample

class JsonlDataset:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path).expanduser().resolve(); self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._fingerprints = self._load_fingerprints()
    def _load_fingerprints(self) -> set[str]:
        found: set[str] = set()
        if not self.path.exists(): return found
        with self.path.open("r", encoding="utf-8") as stream:
            for line in stream:
                try:
                    value = json.loads(line); fp = str(value.get("fingerprint", ""))
                    if fp: found.add(fp)
                except (json.JSONDecodeError, AttributeError): continue
        return found
    def refresh_fingerprints(self) -> int:
        """Refresh the in-memory index if another process may have appended examples."""
        with self._lock:
            self._fingerprints = self._load_fingerprints()
            return len(self._fingerprints)
    def append(self, example: LanguageExample) -> bool:
        if not isinstance(example, LanguageExample): raise TypeError("example must be LanguageExample")
        item = {"prompt": example.prompt.strip(), "response": example.response.strip(), "source": example.source,
                "quality": example.quality, "fingerprint": example.fingerprint}
        with self._lock:
            if example.fingerprint in self._fingerprints: return False
            with self.path.open("a", encoding="utf-8", newline="\n") as stream:
                stream.write(json.dumps(item, ensure_ascii=False, allow_nan=False) + "\n")
                stream.flush()
            self._fingerprints.add(example.fingerprint)
            return True
    def read_all(self) -> list[LanguageExample]:
        if not self.path.exists(): return []
        result = []
        with self._lock, self.path.open("r", encoding="utf-8") as stream:
            for line in stream:
                try:
                    item = json.loads(line); result.append(LanguageExample(item["prompt"], item["response"], item.get("source", "approved_local_corpus"), float(item.get("quality", 0.5))))
                except (json.JSONDecodeError, KeyError, TypeError, ValueError): continue
        return result
