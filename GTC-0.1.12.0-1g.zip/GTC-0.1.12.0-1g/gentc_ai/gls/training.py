"""Dataset splitting and promotion gates; actual model training is delegated to a trainer."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Sequence, Any
from .contracts import LanguageExample

@dataclass(frozen=True)
class TrainingPlan:
    training: tuple[LanguageExample, ...]
    validation: tuple[LanguageExample, ...]
    holdout: tuple[LanguageExample, ...]
    status: str

def split_dataset(examples: Sequence[LanguageExample], *, validation_ratio: float = 0.1,
                  holdout_ratio: float = 0.1, min_examples: int = 20, seed: int = 17) -> TrainingPlan:
    import random
    if not 0 <= validation_ratio < 0.5 or not 0 <= holdout_ratio < 0.5 or validation_ratio + holdout_ratio >= 0.8:
        raise ValueError("invalid split ratios")
    values = list(examples); random.Random(seed).shuffle(values)
    if len(values) < min_examples or not values: return TrainingPlan(tuple(values), (), (), "insufficient_data")
    hold_n = max(1, round(len(values) * holdout_ratio)) if holdout_ratio else 0
    val_n = max(1, round(len(values) * validation_ratio)) if validation_ratio else 0
    if hold_n + val_n >= len(values): return TrainingPlan(tuple(values), (), (), "insufficient_data")
    return TrainingPlan(tuple(values[:len(values)-hold_n-val_n]), tuple(values[len(values)-hold_n-val_n:len(values)-hold_n] if val_n else ()), tuple(values[len(values)-hold_n:] if hold_n else ()), "ready")

def evaluate_candidate(candidate_metrics: dict[str, float], baseline_metrics: dict[str, float], *, minimum_gain: float = 0.01) -> dict[str, Any]:
    """Accept only when validation improves and safety/regression metrics are not worse."""
    for key in ("quality", "safety"):
        if key not in candidate_metrics or key not in baseline_metrics: return {"accepted": False, "reason": f"missing_{key}_metric"}
    try: quality_gain = float(candidate_metrics["quality"]) - float(baseline_metrics["quality"])
    except (TypeError, ValueError): return {"accepted": False, "reason": "invalid_metrics"}
    if quality_gain < minimum_gain: return {"accepted": False, "reason": "quality_gain_too_small", "quality_gain": quality_gain}
    if float(candidate_metrics["safety"]) < float(baseline_metrics["safety"]): return {"accepted": False, "reason": "safety_regression", "quality_gain": quality_gain}
    return {"accepted": True, "reason": "validated", "quality_gain": quality_gain, "training_performed_here": False}
