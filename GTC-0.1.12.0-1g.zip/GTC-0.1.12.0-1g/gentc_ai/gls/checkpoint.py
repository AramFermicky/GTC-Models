"""Checkpoint metadata and checksums; never claims to train model weights itself."""
from __future__ import annotations
import hashlib, json, math, os
from pathlib import Path
from typing import Any

class CheckpointManager:
    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).expanduser().resolve(); self.root.mkdir(parents=True, exist_ok=True)
    def register(self, model_file: str | Path, *, model_id: str, version: str, metrics: dict[str, float] | None = None) -> Path:
        source = Path(model_file).expanduser().resolve()
        if not source.is_file(): raise FileNotFoundError(source)
        if not model_id or not version: raise ValueError("model_id and version are required")
        digest = hashlib.sha256(source.read_bytes()).hexdigest()
        clean_metrics = {str(k): float(v) for k, v in (metrics or {}).items()}
        if any(not math.isfinite(v) for v in clean_metrics.values()): raise ValueError("metrics must be finite")
        metadata = {"schema_version": 1, "model_id": model_id, "version": version,
                    "weights_file": str(source), "sha256": digest, "metrics": clean_metrics,
                    "weights_copied": False, "registration_only": True}
        target = self.root / (model_id.replace("/", "_").replace("\\", "_") + ".checkpoint.json")
        temp = target.with_suffix(target.suffix + ".tmp")
        with temp.open("w", encoding="utf-8", newline="\n") as stream:
            json.dump(metadata, stream, ensure_ascii=False, indent=2, allow_nan=False); stream.write("\n"); stream.flush(); os.fsync(stream.fileno())
        os.replace(temp, target); return target
    def verify(self, metadata_file: str | Path) -> dict[str, Any]:
        value = json.loads(Path(metadata_file).read_text(encoding="utf-8"))
        weights = Path(value["weights_file"])
        actual = hashlib.sha256(weights.read_bytes()).hexdigest() if weights.is_file() else None
        return {"ok": bool(actual and actual == value.get("sha256")), "expected_sha256": value.get("sha256"), "actual_sha256": actual, "model_id": value.get("model_id"), "version": value.get("version")}
