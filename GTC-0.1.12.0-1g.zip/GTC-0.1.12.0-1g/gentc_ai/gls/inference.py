"""Safe GLS facade: validates requests, isolates backend failures and reports timing."""
from __future__ import annotations
import time
from .contracts import GenerationRequest, GenerationResult, TextBackend

class GLSRuntime:
    def __init__(self, backend: TextBackend | None = None) -> None:
        self.backend = backend; self.calls = 0; self.failures = 0; self.last_error: str | None = None
    def generate(self, request: GenerationRequest) -> GenerationResult:
        if self.backend is None: raise RuntimeError("GLS backend is not installed; the GLS interfaces are available but no language model is loaded")
        started = time.monotonic()
        try:
            result = self.backend.generate(request)
            if not isinstance(result, GenerationResult): raise TypeError("backend must return GenerationResult")
            self.calls += 1; self.last_error = None
            return GenerationResult(result.text, result.model_id, max(result.elapsed_seconds, time.monotonic() - started), result.metadata)
        except Exception as exc:
            self.failures += 1; self.last_error = f"{type(exc).__name__}: {exc}"[:300]
            raise
    def status(self) -> dict[str, object]:
        return {"backend_loaded": self.backend is not None, "calls": self.calls, "failures": self.failures, "last_error": self.last_error}
