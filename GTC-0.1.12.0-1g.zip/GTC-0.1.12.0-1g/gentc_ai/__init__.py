"""GenTC AI — modular local game-agent prototype."""
from gentc_ai.version import VERSION as __version__

__all__ = ["__version__"]
