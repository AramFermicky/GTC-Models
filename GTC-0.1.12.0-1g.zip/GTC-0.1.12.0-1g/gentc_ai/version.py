"""Canonical version metadata shared by the GenTC AI runtime and adapters."""
from __future__ import annotations

VERSION = "0.1.12.0"
BASE_VERSION = "0.1.11.0-1g"
CHANGESET_NUMBER = 1
CHANGESET_KIND = "g"
CHANGESET_SUFFIX = f"{CHANGESET_NUMBER}{CHANGESET_KIND}"
BUILD_ID = f"{VERSION}-{CHANGESET_SUFFIX}"

CHANGE_KINDS = {
    "a": "alternative",
    "b": "beta",
    "g": "generated",
    "r": "routing",
    "t": "testing",
}

if CHANGESET_NUMBER < 1:
    raise RuntimeError("CHANGESET_NUMBER must be a positive integer")
if CHANGESET_KIND not in CHANGE_KINDS:
    raise RuntimeError(f"Unknown CHANGESET_KIND: {CHANGESET_KIND!r}")
