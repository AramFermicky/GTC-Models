"""Game adapter contract for integrating GenTC AI with different game engines."""
from .contracts import AdapterManifest, GameAdapter, validate_snapshot

__all__ = ["AdapterManifest", "GameAdapter", "validate_snapshot"]
