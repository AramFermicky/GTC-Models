"""Engine-agnostic adapter contract and command validation.

A game is not connected automatically just because it exists. It needs an adapter
(or plugin) that exposes world facts and executes an allowlisted set of actions.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol, runtime_checkable

_ACTION_RE = re.compile(r"^[a-z][a-z0-9_]{0,63}$")
_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$")


@runtime_checkable
class GameAdapter(Protocol):
    """Minimal methods an engine-specific connector must provide."""

    def get_manifest(self) -> dict[str, Any]: ...
    def get_snapshot(self) -> dict[str, Any]: ...
    def submit_command(self, command: dict[str, Any]) -> dict[str, Any]: ...
    def poll_results(self) -> list[dict[str, Any]]: ...
    def close(self) -> None: ...


@dataclass(frozen=True)
class AdapterManifest:
    manifest: dict[str, Any]

    @classmethod
    def from_file(cls, path: Path | str) -> "AdapterManifest":
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls.from_dict(raw)

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "AdapterManifest":
        if not isinstance(raw, dict):
            raise ValueError("manifest должен быть JSON-объектом.")
        for field in ("manifest_version", "game_id", "game_name", "protocol_version", "capabilities", "actions"):
            if field not in raw:
                raise ValueError(f"В manifest отсутствует поле {field!r}.")
        if raw["manifest_version"] != 1:
            raise ValueError("Неподдерживаемая версия manifest.")
        if not _ID_RE.fullmatch(str(raw["game_id"])):
            raise ValueError("game_id имеет недопустимый формат.")
        if not isinstance(raw["capabilities"], list) or not all(isinstance(x, str) for x in raw["capabilities"]):
            raise ValueError("capabilities должен быть массивом строк.")
        if not isinstance(raw["actions"], list):
            raise ValueError("actions должен быть массивом.")
        seen: set[str] = set()
        for item in raw["actions"]:
            if not isinstance(item, dict) or not _ACTION_RE.fullmatch(str(item.get("name", ""))):
                raise ValueError("Каждое действие должно иметь корректное имя.")
            if item["name"] in seen:
                raise ValueError(f"Дублирующееся действие: {item['name']}")
            seen.add(item["name"])
            required = item.get("required_args", [])
            if not isinstance(required, list) or not all(isinstance(x, str) for x in required):
                raise ValueError(f"required_args у {item['name']} должен быть массивом строк.")
        return cls(dict(raw))

    @property
    def game_id(self) -> str:
        return str(self.manifest["game_id"])

    @property
    def actions(self) -> dict[str, dict[str, Any]]:
        return {item["name"]: item for item in self.manifest["actions"]}

    def build_command(self, action: str, arguments: dict[str, Any], command_id: str) -> dict[str, Any]:
        if action not in self.actions:
            raise ValueError(f"Действие {action!r} отсутствует в allowlist адаптера.")
        if not _ID_RE.fullmatch(str(command_id)):
            raise ValueError("command_id имеет недопустимый формат.")
        if not isinstance(arguments, dict):
            raise ValueError("arguments должен быть объектом.")
        spec = self.actions[action]
        missing = [key for key in spec.get("required_args", []) if key not in arguments]
        if missing:
            raise ValueError(f"Для {action} не хватает аргументов: {', '.join(missing)}")
        return {
            "protocol_version": self.manifest["protocol_version"],
            "game_id": self.game_id,
            "command_id": command_id,
            "action": action,
            "arguments": arguments,
        }


def validate_snapshot(snapshot: dict[str, Any], expected_game_id: str | None = None) -> dict[str, Any]:
    """Validate the generic adapter snapshot without assuming engine internals."""
    issues: list[str] = []
    if not isinstance(snapshot, dict):
        return {"valid": False, "issues": ["snapshot_must_be_object"]}
    for field in ("protocol_version", "game_id", "session_id", "player", "characters", "objects", "inventories", "events"):
        if field not in snapshot:
            issues.append(f"missing_field:{field}")
    if expected_game_id and snapshot.get("game_id") != expected_game_id:
        issues.append("game_id_mismatch")
    for field in ("characters", "objects", "events"):
        if field in snapshot and not isinstance(snapshot[field], list):
            issues.append(f"{field}_must_be_array")
    if "inventories" in snapshot and not isinstance(snapshot["inventories"], dict):
        issues.append("inventories_must_be_object")
    player = snapshot.get("player")
    if not isinstance(player, dict):
        issues.append("player_must_be_object")
    elif (not player.get("id") or not isinstance(player.get("position"), list)
          or len(player["position"]) not in (2, 3)
          or not all(isinstance(coord, (int, float)) for coord in player["position"])):
        issues.append("player_requires_id_and_2d_or_3d_position")
    for group in ("characters", "objects"):
        items = snapshot.get(group, [])
        if isinstance(items, list):
            identifiers = [item.get("id") for item in items if isinstance(item, dict)]
            if any(not value for value in identifiers):
                issues.append(f"{group}_entry_requires_id")
            if len(identifiers) != len(set(identifiers)):
                issues.append(f"{group}_contains_duplicate_ids")
            if any(not isinstance(item, dict) for item in items):
                issues.append(f"{group}_entries_must_be_objects")
    return {
        "valid": not issues,
        "issues": issues,
        "game_id": snapshot.get("game_id"),
        "character_count": len(snapshot.get("characters", [])) if isinstance(snapshot.get("characters", []), list) else 0,
        "object_count": len(snapshot.get("objects", [])) if isinstance(snapshot.get("objects", []), list) else 0,
    }
