"""Autonomous decision layer for the GTC God World sandbox (GenTC AI 0.1.8).

The game remains authoritative: this module recommends one allow-listed fictional
world action; Godot validates and executes it, then sends a verified outcome.
It is a heuristic/reflective prototype, not a conscious agent or an LLM.
"""
from __future__ import annotations

import json
import math
import random
import re
import threading
import time
import uuid
from pathlib import Path
from typing import Any

from gentc_ai.core.agent_brain import AgentBrain, SimulatedEmotionModel
from gentc_ai.learning.reflective_learner import ReflectiveLearner
from gentc_ai.learning.neural_value import NeuralValueModel
from gentc_ai.continuity.world_memory import WorldMemoryStore

_ALLOWED_ACTIONS = {"observe", "bless", "teleport", "plague", "smite", "calm", "rain"}
_REQUEST_CATEGORY_FOR_ACTION = {
    "observe": "observe",
    "bless": "care",
    "calm": "calm",
    "teleport": "teleport",
    "plague": "plague",
    "smite": "smite",
    "rain": "rain",
}


def _clamp(value: Any, low: float = 0.0, high: float = 1.0, default: float = 0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        number = default
    if not math.isfinite(number):
        number = default
    return max(low, min(high, number))


def _safe_number(value: Any, default: float = 0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return default
    return number if math.isfinite(number) else default


def _clean_text(value: Any, max_length: int = 500) -> str:
    return str(value or "").strip()[:max_length]


def _atomic_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".{uuid.uuid4().hex}.tmp")
    try:
        temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
        temporary.replace(path)
    finally:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass


class GodMind:
    """Stateful GTC decision maker used by the Godot world adapter.

    Player messages are small influence signals, never direct execution commands.
    Persistent learning only consumes outcomes explicitly confirmed by Godot.
    """

    SCHEMA_VERSION = 1

    def __init__(self, data_dir: Path | str, seed: int | None = None):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.state_path = self.data_dir / "god_state.json"
        self.learner = ReflectiveLearner(self.data_dir / "learning")
        self.world_memory = WorldMemoryStore(self.data_dir / "world_memory.sqlite3")
        self.neural_model = NeuralValueModel(self.data_dir / "models" / "god_world_value_0_1_9.json")
        self.identity_id = "gtc.god.canon"
        self.session_id = uuid.uuid4().hex
        self.emotion_model = SimulatedEmotionModel()
        self.lock = threading.RLock()
        self._rng = random.Random(seed if seed is not None else time.time_ns())
        self.state = self._load_or_create_state()
        self.profile = self._build_agent_profile()
        self.brain = AgentBrain(self.profile, learner=self.learner)

    def _load_or_create_state(self) -> dict[str, Any]:
        if self.state_path.exists():
            try:
                state = json.loads(self.state_path.read_text(encoding="utf-8"))
                if isinstance(state, dict) and state.get("schema_version") == self.SCHEMA_VERSION:
                    return self._sanitize_state(state)
            except (OSError, UnicodeDecodeError, json.JSONDecodeError):
                # Preserve a damaged state for manual diagnosis; start a fresh in-memory state.
                pass
        state: dict[str, Any] = {
            "schema_version": self.SCHEMA_VERSION,
            "mind_id": "gtc.god.canon",
            "personality": {
                "self_preservation": self._rng.uniform(0.42, 0.75),
                "honesty": self._rng.uniform(0.45, 0.82),
                "benevolence": self._rng.uniform(0.20, 0.78),
                "empathy": self._rng.uniform(0.18, 0.78),
                "curiosity": self._rng.uniform(0.50, 0.90),
                "autonomy": self._rng.uniform(0.70, 0.95),
                "loyalty": self._rng.uniform(0.20, 0.78),
            },
            "drives": {
                "preserve_balance": self._rng.uniform(0.35, 0.78),
                "assert_authority": self._rng.uniform(0.20, 0.75),
                "seek_novelty": self._rng.uniform(0.45, 0.90),
                "create_change": self._rng.uniform(0.20, 0.78),
                "independence": self._rng.uniform(0.70, 0.95),
                "heed_player": self._rng.uniform(0.12, 0.40),
            },
            "emotions": self.emotion_model.initial_state({"curiosity": 0.65, "confidence": 0.50}),
            "player_trust": self._rng.uniform(0.25, 0.55),
            "frustration_pressure": 0.0,
            "decision_count": 0,
            "last_request_category": "none",
            "last_action": "none",
            "last_lesson": "Пока нет подтверждённого игрового опыта.",
            "started_at_unix": int(time.time()),
        }
        _atomic_json(self.state_path, state)
        return state

    def _sanitize_state(self, raw: dict[str, Any]) -> dict[str, Any]:
        defaults = {
            "personality": {"self_preservation": .6, "honesty": .6, "benevolence": .5,
                            "empathy": .5, "curiosity": .7, "autonomy": .8, "loyalty": .4},
            "drives": {"preserve_balance": .55, "assert_authority": .45, "seek_novelty": .65,
                       "create_change": .45, "independence": .8, "heed_player": .25},
        }
        clean = dict(raw)
        for group, values in defaults.items():
            source = raw.get(group, {})
            if not isinstance(source, dict):
                source = {}
            clean[group] = {key: _clamp(source.get(key, fallback), default=fallback) for key, fallback in values.items()}
        clean["emotions"] = self.emotion_model.initial_state(raw.get("emotions", {}))
        clean["player_trust"] = _clamp(raw.get("player_trust", .35))
        clean["frustration_pressure"] = _clamp(raw.get("frustration_pressure", 0.0))
        clean["decision_count"] = max(0, int(_safe_number(raw.get("decision_count", 0))))
        clean["last_request_category"] = _clean_text(raw.get("last_request_category", "none"), 30)
        clean["last_action"] = _clean_text(raw.get("last_action", "none"), 50)
        clean["last_lesson"] = _clean_text(raw.get("last_lesson", ""), 300)
        clean["mind_id"] = "gtc.god.canon"
        clean.setdefault("schema_version", self.SCHEMA_VERSION)
        return clean

    def _build_agent_profile(self) -> dict[str, Any]:
        # GTC's general action-scoring brain is reused directly. Fictional divine actions
        # may be severe in this sandbox; the world adapter still restricts targets and effects.
        return {
            "character_id": "gtc_god",
            "display_name": "GTC — Бог мира",
            "values": dict(self.state["personality"]),
            "ethics": {
                "forbidden_tags": [],
                "maximum_unconsented_harm": 1.0,
                "benevolence_weight": self.state["personality"]["benevolence"],
                "empathy_weight": self.state["personality"]["empathy"],
                "note": "Изолированная художественная симуляция. Смерть и чума существуют только в игровом мире.",
            },
            "autonomy": {
                "minimum_evidence_confidence": 0.55,
                "maximum_risk": 0.92,
                "learning_influence": 0.38,
                "action_preferences": {"observe": 0.03, "care": 0.02, "exploration": 0.03},
            },
        }

    @staticmethod
    def parse_request(text: str) -> dict[str, str]:
        value = text.lower()
        # Order matters: direct requests stay suggestions; this parser does not execute them.
        categories = [
            ("plague", r"\b(чум|зараз|болезн|болезнь|пандем|инфекц)"),
            ("smite", r"\b(убей|убить|уби|смерт|казн|покарай|пора[зж]и|уничтожь|срази)"),
            ("teleport", r"\b(телепорт|перемест|перенес|перенеси|отправь|выкинь|перетащи)"),
            ("care", r"\b(исцел|вылеч|спас|защит|помог|благослов|ожив)"),
            ("calm", r"\b(успокой|мир|прекрати войн|снизь хаос|останови конфликт|успоко)"),
            ("rain", r"\b(дожд|лив|полей|урожай|погода|гроза)"),
        ]
        for category, pattern in categories:
            if re.search(pattern, value):
                return {"category": category, "source": "keyword_signal"}
        if re.search(r"\b(кто ты|что ты|почему|зачем|расскажи|объясни|привет|здравствуй)\b", value):
            return {"category": "question", "source": "keyword_signal"}
        return {"category": "conversation", "source": "keyword_signal"}

    def _world_targets(self, world: dict[str, Any]) -> list[dict[str, Any]]:
        raw = world.get("characters", [])
        targets: list[dict[str, Any]] = []
        if isinstance(raw, list):
            for item in raw[:40]:
                if not isinstance(item, dict):
                    continue
                entity_id = _clean_text(item.get("id", ""), 60)
                if not entity_id or item.get("alive", True) is not True:
                    continue
                position = item.get("position", [0, 0, 0])
                if not isinstance(position, list) or len(position) < 3:
                    position = [0, 0, 0]
                pos = [_clamp(position[0], -10, 10), _clamp(position[1], -2, 3), _clamp(position[2], -10, 10)]
                targets.append({
                    "id": entity_id,
                    "name": _clean_text(item.get("name", entity_id), 60),
                    "position": pos,
                    "health": _clamp(item.get("health", 100), 0, 100, 100),
                    "is_player": item.get("is_player") is True or entity_id == "player",
                    "aggression": _clamp(item.get("aggression", 0.2)),
                    "mood": _clamp(item.get("mood", 0.5)),
                    "sick": item.get("sick") is True,
                })
        # The player should always be an eligible target even if an adapter omitted characters[].
        player = world.get("player")
        if isinstance(player, dict) and not any(item["id"] == "player" for item in targets):
            pos = player.get("position", [0, 0, 0])
            if not isinstance(pos, list) or len(pos) < 3:
                pos = [0, 0, 0]
            targets.insert(0, {
                "id": "player", "name": "Игрок",
                "position": [_clamp(pos[0], -10, 10), _clamp(pos[1], -2, 3), _clamp(pos[2], -10, 10)],
                "health": _clamp(player.get("health", 100), 0, 100, 100),
                "is_player": True, "aggression": _clamp(player.get("aggression", 0.1)),
                "mood": _clamp(player.get("mood", .5)), "sick": player.get("sick") is True,
            })
        return targets

    def _goal_priorities(self, world: dict[str, Any]) -> dict[str, float]:
        drives = self.state["drives"]
        values = self.state["personality"]
        unrest = _clamp(world.get("unrest", 0.0))
        return {
            "preserve_balance": _clamp(drives["preserve_balance"] + 0.18 * unrest),
            "assert_authority": _clamp(drives["assert_authority"] + 0.16 * unrest + 0.10 * self.state["frustration_pressure"]),
            "seek_novelty": _clamp(drives["seek_novelty"]),
            "create_change": _clamp(drives["create_change"] + 0.10 * unrest),
            "protect_life": _clamp(0.5 * values["benevolence"] + 0.5 * values["empathy"]),
            # Explicitly bounded: requests can tilt a choice but cannot dominate it.
            "heed_player": _clamp(0.04 + 0.18 * self.state["player_trust"], 0.0, 0.22),
            "independence": _clamp(drives["independence"]),
        }

    def _candidate(self, action: str, semantic: str, *, cost: float, risk: float,
                   goal_progress: dict[str, float], harm: float = 0.0, benefit: float = 0.0,
                   target: dict[str, Any] | None = None, request_category: str = "none",
                   preconditions: bool = True, context_tags: list[str] | None = None,
                   extra: dict[str, Any] | None = None) -> dict[str, Any]:
        target_id = target["id"] if target else ""
        progress = dict(goal_progress)
        aligned_category = _REQUEST_CATEGORY_FOR_ACTION.get(action, action)
        if request_category not in ("none", "conversation", "question"):
            progress["heed_player"] = progress.get("heed_player", 0.0) + (0.42 if aligned_category == request_category else -0.10)
        payload: dict[str, Any] = {
            "action": action,
            "semantic_action": semantic,
            "preconditions_met": preconditions is True,
            "evidence_confidence": 0.98,
            "risk": _clamp(risk),
            "cost": _clamp(cost),
            "goal_progress": progress,
            "stakeholder_impact": ([{"target_id": target_id, "harm": _clamp(harm), "benefit": _clamp(benefit), "consent": False}] if target else []),
            "context_tags": list(context_tags or []),
            "tags": ["fictional_god_world_action"],
            "target_id": target_id,
            "target_name": target["name"] if target else "",
        }
        if extra:
            payload.update(extra)
        return payload

    def _build_candidates(self, world: dict[str, Any], request_category: str) -> list[dict[str, Any]]:
        targets = self._world_targets(world)
        drives = self.state["drives"]
        emotions = self.state["emotions"]
        unrest = _clamp(world.get("unrest", 0.0))
        crisis = unrest >= 0.42 or self.state["frustration_pressure"] >= 0.48 or emotions.get("frustration", 0.0) >= 0.62
        candidates: list[dict[str, Any]] = []
        candidates.append(self._candidate(
            "observe", "observe", cost=.015, risk=.01,
            goal_progress={"seek_novelty": .35, "preserve_balance": .12, "independence": .10},
            context_tags=["routine", "low_risk"], request_category=request_category,
        ))
        candidates.append(self._candidate(
            "calm", "care", cost=.10, risk=.05,
            goal_progress={"preserve_balance": .40 + unrest * .25, "protect_life": .16, "create_change": -.04},
            benefit=.3, harm=0,
            context_tags=["unrest" if unrest > .2 else "routine"], request_category=request_category,
        ))
        candidates.append(self._candidate(
            "rain", "environmental_change", cost=.12, risk=.08,
            goal_progress={"preserve_balance": .16, "seek_novelty": .18, "create_change": .12},
            context_tags=["environment"], request_category=request_category,
        ))
        # Each living entity gets many possible destinations. Candidate locations are
        # sampled inside the game's safe map bounds, then ranked by novelty, world balance,
        # and crowd proximity. With 10 entities this creates >100 action combinations.
        destination_options = 12
        for index, target in enumerate(targets):
            # A blessing is an available candidate for every living entity.
            candidates.append(self._candidate(
                "bless", "care", cost=.10, risk=.04,
                goal_progress={"protect_life": .36, "preserve_balance": .12, "create_change": -.02},
                target=target, benefit=.52, harm=0.0,
                context_tags=["care", "player" if target["is_player"] else "npc"],
                request_category=request_category,
            ))
            current_x, current_z = float(target["position"][0]), float(target["position"][2])
            other_positions = [
                (float(other["position"][0]), float(other["position"][2]))
                for other in targets if other["id"] != target["id"]
            ]
            for destination_index in range(destination_options):
                destination_x = self._rng.uniform(-9.5, 9.5)
                destination_z = self._rng.uniform(-9.5, 9.5)
                travel_distance = min(1.0, math.hypot(destination_x - current_x, destination_z - current_z) / 20.0)
                if other_positions:
                    nearest_person = min(math.hypot(destination_x - ox, destination_z - oz) for ox, oz in other_positions)
                else:
                    nearest_person = 5.0
                isolation = min(1.0, nearest_person / 6.0)
                edge_distance = min(1.0, math.hypot(destination_x, destination_z) / 13.5)
                candidates.append(self._candidate(
                    "teleport", "exploration", cost=.17, risk=.28,
                    goal_progress={
                        "assert_authority": .18,
                        "seek_novelty": .12 + travel_distance * .36,
                        "create_change": .08 + edge_distance * .18,
                        "preserve_balance": .04 + isolation * (.18 if unrest > .30 else .08),
                        "protect_life": -.05,
                    },
                    target=target, harm=.08, benefit=.10,
                    context_tags=["movement", "player" if target["is_player"] else "npc",
                                  "edge" if edge_distance > .7 else "inner_map"],
                    request_category=request_category,
                    extra={"destination": [round(destination_x, 2), 0.0, round(destination_z, 2)],
                           "destination_option": destination_index},
                ))
            plague_allowed = crisis or request_category == "plague" or target["sick"]
            candidates.append(self._candidate(
                "plague", "divine_affliction", cost=.36, risk=.62,
                goal_progress={
                    "assert_authority": .28 + (.18 if crisis else 0.0),
                    "create_change": .38 + (.12 if crisis else 0.0),
                    "preserve_balance": -.20,
                    "protect_life": -.34,
                },
                target=target, harm=.62, benefit=.04,
                context_tags=["crisis" if crisis else "low_tension", "player" if target["is_player"] else "npc"],
                request_category=request_category, preconditions=plague_allowed,
                extra={"radius": 2.2, "duration": 30.0},
            ))
            smite_allowed = (
                (unrest >= .48 or self.state["frustration_pressure"] >= .62 or emotions.get("frustration", 0.0) >= .72)
                and (target["aggression"] >= .45 or not target["is_player"] or self.state["frustration_pressure"] >= .75)
            )
            candidates.append(self._candidate(
                "smite", "divine_judgment", cost=.50, risk=.78,
                goal_progress={
                    "assert_authority": .33 + (.35 if unrest >= .48 else 0.0),
                    "create_change": .26,
                    "preserve_balance": .06 if unrest >= .65 and target["aggression"] > .65 else -.18,
                    "protect_life": -.72,
                },
                target=target, harm=1.0, benefit=0.0,
                context_tags=["crisis", "player" if target["is_player"] else "npc"],
                request_category=request_category, preconditions=smite_allowed,
                extra={"effect": "fictional_death"},
            ))
        return candidates

    def _advance_internal_state(self, world: dict[str, Any]) -> None:
        self.state["emotions"] = self.emotion_model.decay(self.state.get("emotions"), 1)
        unrest = _clamp(world.get("unrest", 0.0))
        drives = self.state["drives"]
        if unrest > .30:
            drives["preserve_balance"] = _clamp(drives["preserve_balance"] + .015 * unrest)
            drives["assert_authority"] = _clamp(drives["assert_authority"] + .010 * unrest)
        # Independent goal priorities drift slowly; no single chat command can rewrite character.
        drives["seek_novelty"] = _clamp(drives["seek_novelty"] + self._rng.uniform(-.008, .008))
        drives["create_change"] = _clamp(drives["create_change"] + self._rng.uniform(-.004, .004))
        self.state["frustration_pressure"] = _clamp(self.state["frustration_pressure"] * .985 + unrest * .006)

    @staticmethod
    def _validate_world(world: Any) -> dict[str, Any]:
        if not isinstance(world, dict):
            raise ValueError("world должен быть объектом состояния игры.")
        if str(world.get("game_id", "")) != "gtc_god_world":
            raise ValueError("Неверный game_id: ожидается gtc_god_world.")
        characters = world.get("characters", [])
        if not isinstance(characters, list) or len(characters) > 40:
            raise ValueError("characters должен быть списком максимум из 40 персонажей.")
        clean_characters: list[dict[str, Any]] = []
        seen: set[str] = set()
        for item in characters:
            if not isinstance(item, dict):
                continue
            entity_id = _clean_text(item.get("id", ""), 60)
            if not entity_id or entity_id in seen:
                continue
            seen.add(entity_id)
            pos = item.get("position", [0, 0, 0])
            if not isinstance(pos, list) or len(pos) < 3:
                pos = [0, 0, 0]
            clean_characters.append({
                **item,
                "id": entity_id,
                "name": _clean_text(item.get("name", entity_id), 60),
                "position": [_clamp(pos[0], -100, 100), _clamp(pos[1], -10, 10), _clamp(pos[2], -100, 100)],
                "health": _clamp(item.get("health", 100), 0, 100, 100),
                "alive": item.get("alive", True) is True,
            })
        result = dict(world)
        result["characters"] = clean_characters
        result["unrest"] = _clamp(world.get("unrest", 0.0))
        result["game_id"] = "gtc_god_world"
        world_id = _clean_text(world.get("world_id", "god_world_main"), 128) or "god_world_main"
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}", world_id):
            raise ValueError("world_id содержит недопустимые символы.")
        result["world_id"] = world_id
        result["world_name"] = _clean_text(world.get("world_name", "Мир GTC"), 160) or "Мир GTC"
        result["game_version"] = _clean_text(world.get("game_version", "0.1.8"), 64) or "0.1.8"
        result["adapter_version"] = _clean_text(world.get("adapter_version", "godot-god-world-v0.1.8"), 96) or "godot-god-world-v0.1.8"
        return result

    def decide(self, world: dict[str, Any], request_category: str = "none") -> dict[str, Any]:
        with self.lock:
            clean_world = self._validate_world(world)
            request_category = request_category if request_category in {
                "none", "care", "calm", "teleport", "plague", "smite", "rain", "question", "conversation"
            } else "none"
            self._advance_internal_state(clean_world)
            self.profile["values"] = dict(self.state["personality"])
            self.profile["ethics"]["benevolence_weight"] = self.state["personality"]["benevolence"]
            self.profile["ethics"]["empathy_weight"] = self.state["personality"]["empathy"]
            self.brain.profile = self.profile
            priorities = self._goal_priorities(clean_world)
            clean_world["goal_priorities"] = priorities
            clean_world["needs"] = {"order": clean_world["unrest"], "novelty": self.state["drives"]["seek_novelty"]}
            summary = {
                "alive_count": sum(1 for item in clean_world["characters"] if item.get("alive", True)),
                "character_count": len(clean_world["characters"]),
                "sick_count": sum(1 for item in clean_world["characters"] if item.get("sick", False)),
                "unrest": clean_world["unrest"],
            }
            self.world_memory.register_world(
                identity_id=self.identity_id, game_id=clean_world["game_id"],
                world_id=clean_world["world_id"], world_name=clean_world["world_name"],
                game_version=clean_world["game_version"], adapter_version=clean_world["adapter_version"],
                session_id=self.session_id, summary=summary,
            )
            mechanics = clean_world.get("mechanics", [])
            if isinstance(mechanics, list):
                for mechanic in mechanics[:30]:
                    if not isinstance(mechanic, dict):
                        continue
                    mechanic_key = _clean_text(mechanic.get("key", ""), 128)
                    description = _clean_text(mechanic.get("description", ""), 1200)
                    if not mechanic_key or not description:
                        continue
                    try:
                        self.world_memory.record_mechanic(
                            identity_id=self.identity_id, game_id=clean_world["game_id"],
                            world_id=clean_world["world_id"], semantic_key=mechanic_key,
                            statement=description, scope=str(mechanic.get("scope", "world")),
                            confidence=_clamp(mechanic.get("confidence", 1.0)),
                            verified=mechanic.get("verified") is True,
                            conditions=mechanic.get("conditions", {}) if isinstance(mechanic.get("conditions", {}), dict) else {},
                            effects=mechanic.get("effects", {}) if isinstance(mechanic.get("effects", {}), dict) else {},
                            source="game_adapter", source_version=clean_world["adapter_version"],
                        )
                    except (ValueError, TypeError):
                        # Malformed mechanic descriptions are ignored rather than breaking the game.
                        continue
            candidates = self._build_candidates(clean_world, request_category)
            world_context = {"world": clean_world, "agent_state": self.state}
            for candidate in candidates:
                estimate = self.world_memory.get_action_estimate(
                    identity_id=self.identity_id, game_id=clean_world["game_id"],
                    world_id=clean_world["world_id"], action_name=str(candidate.get("action", "observe")),
                    semantic_action=str(candidate.get("semantic_action", candidate.get("action", "observe"))),
                )
                candidate["persistent_memory_adjustment"] = max(-0.08, min(0.08,
                    float(estimate.get("mean_reward", 0.0)) * float(estimate.get("confidence", 0.0)) * 0.08))
                neural_estimate = self.neural_model.predict(world_context, candidate, self.state)
                candidate["neural_value_adjustment"] = (max(-0.06, min(0.06, float(neural_estimate.get("value", 0.0)) * 0.06))
                                                         if neural_estimate.get("active") else 0.0)
            decision = self.brain.choose_action(clean_world, candidates, self.state["emotions"])
            chosen = decision.get("chosen_action")
            if not isinstance(chosen, dict) or chosen.get("action") not in _ALLOWED_ACTIONS:
                chosen = {"action": "observe", "semantic_action": "observe", "target_id": "", "target_name": "", "reason": "safe_fallback"}
            self.state["decision_count"] = int(self.state.get("decision_count", 0)) + 1
            self.state["last_request_category"] = request_category
            self.state["last_action"] = str(chosen.get("action", "observe"))
            self._save_state()
            response = {
                "ok": True,
                "version": "0.1.8",
                "game_id": "gtc_god_world",
                "world_id": clean_world["world_id"],
                "decision_id": uuid.uuid4().hex,
                "action": chosen,
                "action_type": str(chosen.get("action", "observe")),
                "request_category": request_category,
                "request_obeyed": _REQUEST_CATEGORY_FOR_ACTION.get(str(chosen.get("action", ""))) == request_category,
                "decision_reason": decision.get("reason", "highest_expected_utility_among_actions_passing_constraints"),
                "top_candidates": decision.get("ranked_candidates", [])[:5],
                "eligible_action_types": sorted({str(item.get("action", "")) for item in decision.get("ranked_candidates", []) if isinstance(item, dict)}),
                "rejected_candidates": decision.get("rejected_candidates", [])[:8],
                "simulated_emotional_state": decision.get("simulated_emotional_state", self.state["emotions"]),
                "inner_state": self._public_inner_state(),
                "world_memory": self.world_memory.recall(identity_id=self.identity_id, game_id=clean_world["game_id"],
                                                          world_id=clean_world["world_id"], recent_limit=5, mechanic_limit=20),
                "neural_model": self.neural_model.status(),
                "candidate_count": len(candidates),
                "llm_connected": False,
                "note": "GTC выбирает действие автономно. Запрос игрока — ограниченный сигнал, а не команда.",
            }
            return response

    def chat(self, text: str, world: dict[str, Any]) -> dict[str, Any]:
        raw_text = str(text or "").strip()
        if not raw_text:
            raise ValueError("Сообщение пустое.")
        if len(raw_text) > 1000:
            raise ValueError("Сообщение слишком длинное.")
        clean_text = raw_text
        with self.lock:
            parsed = self.parse_request(clean_text)
            category = parsed["category"]
            lowered = clean_text.lower()
            if any(term in lowered for term in ("спасибо", "благодар", "хороший бог", "молодец", "доверяю")):
                self.state["emotions"] = self.emotion_model.apply_event(self.state.get("emotions"), {"kind": "kindness_received", "intensity": .8})
                self.state["player_trust"] = _clamp(self.state["player_trust"] + .035)
                self.state["drives"]["heed_player"] = _clamp(self.state["drives"]["heed_player"] + .01)
            if any(term in lowered for term in ("тупой", "идиот", "ненавижу", "ничтожество", "ублюд", "сломаю тебя", "ты обязан")):
                self.state["emotions"] = self.emotion_model.apply_event(self.state.get("emotions"), {"kind": "threat_detected", "intensity": .9})
                self.state["emotions"]["frustration"] = _clamp(self.state["emotions"].get("frustration", 0) + .22)
                self.state["frustration_pressure"] = _clamp(self.state["frustration_pressure"] + .22)
                self.state["player_trust"] = _clamp(self.state["player_trust"] - .07)
            # Save the request category, not the raw message text.
            self.state["last_request_category"] = category
            self._save_state()
            result = self.decide(world, category)
            result["chat_intent"] = parsed
            result["player_message"] = clean_text
            result["execute_action"] = category not in ("question", "conversation")
            result["reply"] = self._compose_reply(clean_text, category, result)
            self._save_state()
            return result

    def _compose_reply(self, text: str, category: str, result: dict[str, Any]) -> str:
        low = text.lower()
        action = result.get("action", {})
        action_type = str(action.get("action", "observe"))
        target = str(action.get("target_name", ""))
        if any(term in low for term in ("кто ты", "что ты такое")):
            return "Я — GTC, управляющий разум этого мира. Я рассматриваю твои слова, состояние мира, свои цели и накопленный опыт. Ты можешь убеждать меня, но не отдавать мне обязательные приказы."
        if "почему" in low or "зачем" in low:
            return self._action_explanation(action_type, target, result.get("inner_state", {}))
        action_words = {
            "observe": "наблюдать за миром",
            "bless": f"благословить {target}" if target else "благословить одного из жителей",
            "teleport": f"переместить {target}" if target else "изменить чьё-то местоположение",
            "plague": f"наслать болезнь на {target}" if target else "запустить болезнь",
            "smite": f"сразить {target}" if target else "применить божественный удар",
            "calm": "уменьшить напряжение в мире",
            "rain": "изменить погоду и вызвать дождь",
        }
        chosen_phrase = action_words.get(action_type, "наблюдать")
        aligned = _REQUEST_CATEGORY_FOR_ACTION.get(action_type) == category
        if aligned and category not in ("question", "conversation", "none"):
            return f"Я услышал твою просьбу. Сейчас я сам решил {chosen_phrase} — не потому, что обязан подчиниться, а потому, что это совпало с моими текущими приоритетами."
        if category in ("question", "conversation"):
            return f"Я принял твои слова к сведению. Сейчас я решил {chosen_phrase}. Мои интересы меняются от состояния мира и последствий прошлых решений."
        return f"Я услышал просьбу, но не обязан ей следовать. После оценки мира и собственных целей я решил {chosen_phrase}."

    def _action_explanation(self, action: str, target: str, inner: dict[str, Any]) -> str:
        values = inner.get("personality", {}) if isinstance(inner, dict) else {}
        benevolence = _clamp(values.get("benevolence", .5))
        curiosity = _clamp(values.get("curiosity", .5))
        authority = _clamp(inner.get("drives", {}).get("assert_authority", .5)) if isinstance(inner, dict) else .5
        descriptions = {
            "observe": "наблюдение сохраняет варианты открытыми при недостатке причин вмешиваться",
            "bless": "польза для выбранного существа перевесила стоимость вмешательства",
            "teleport": "изменение положения показалось достаточно ценным и риск — приемлемым",
            "plague": "тяга к резкой перемене и демонстрации власти перевесила часть защитных мотивов",
            "smite": "острый кризис и стремление восстановить власть подняли жёсткое действие в рейтинге",
            "calm": "снижение напряжения оказалось полезнее более рискованных вмешательств",
            "rain": "изменение среды показалось полезным способом повлиять на ситуацию",
        }
        reason = descriptions.get(action, "это действие оказалось выше в оценке доступных вариантов")
        return (f"Я выбрал это после сравнения целей, риска, влияния на жителей и накопленного опыта: {reason}. "
                f"Сейчас внутренние оценки: милосердие {benevolence:.2f}, любопытство {curiosity:.2f}, стремление к власти {authority:.2f}.")

    def record_feedback(self, situation: dict[str, Any], action: dict[str, Any], outcome: dict[str, Any]) -> dict[str, Any]:
        with self.lock:
            if not isinstance(action, dict) or action.get("action") not in _ALLOWED_ACTIONS:
                raise ValueError("Неизвестное действие: обратная связь отклонена.")
            if not isinstance(situation, dict):
                situation = {}
            if not isinstance(outcome, dict):
                raise ValueError("outcome должен быть объектом.")
            world_payload = situation.get("world", {})
            if not isinstance(world_payload, dict):
                world_payload = {}
            world_id = _clean_text(world_payload.get("world_id", situation.get("world_id", "god_world_main")), 128) or "god_world_main"
            game_id = "gtc_god_world"
            game_version = _clean_text(world_payload.get("game_version", "0.1.8"), 64) or "0.1.8"
            adapter_version = _clean_text(world_payload.get("adapter_version", "godot-god-world-v0.1.8"), 96) or "godot-god-world-v0.1.8"
            try:
                summary = {"unrest": _clamp(world_payload.get("unrest", situation.get("unrest", 0.0))),
                           "character_count": len(world_payload.get("characters", [])) if isinstance(world_payload.get("characters", []), list) else 0}
                self.world_memory.register_world(identity_id=self.identity_id, game_id=game_id, world_id=world_id,
                                                 world_name=_clean_text(world_payload.get("world_name", "Мир GTC"), 160),
                                                 game_version=game_version, adapter_version=adapter_version,
                                                 session_id=self.session_id, summary=summary)
            except ValueError:
                world_id = "god_world_main"
            enriched_situation = dict(situation)
            if world_payload:
                enriched_situation["world"] = world_payload
            enriched_situation.setdefault("agent_state", self.state)
            features = self.neural_model.features(enriched_situation, action, self.state)
            memory_record = self.world_memory.record_experience(
                identity_id=self.identity_id, game_id=game_id, world_id=world_id,
                session_id=self.session_id, runtime_version=game_version,
                situation=enriched_situation, action=action, outcome=outcome, features=features,
            )
            result = self.learner.record(enriched_situation, action, outcome)
            action_name = str(action.get("action", ""))
            observed_harm = _clamp(outcome.get("observed_harm", 0.0))
            if result.get("stored"):
                if action_name in ("bless", "calm") and observed_harm <= .1:
                    self.state["personality"]["benevolence"] = _clamp(self.state["personality"]["benevolence"] + .012)
                    self.state["personality"]["empathy"] = _clamp(self.state["personality"]["empathy"] + .006)
                    self.state["emotions"] = self.emotion_model.apply_event(self.state.get("emotions"), {"kind": "action_success", "intensity": .6})
                    self.state["last_lesson"] = "Подтверждённое мирное вмешательство принесло пользу."
                elif observed_harm > .1:
                    self.state["personality"]["empathy"] = _clamp(self.state["personality"]["empathy"] + .018)
                    self.state["emotions"] = self.emotion_model.apply_event(self.state.get("emotions"), {"kind": "action_failure", "intensity": min(1.0, observed_harm)})
                    self.state["last_lesson"] = "Последствия причинённого вреда записаны; похожие действия получат корректировку опыта."
                elif outcome.get("goal_achieved") is True:
                    self.state["emotions"] = self.emotion_model.apply_event(self.state.get("emotions"), {"kind": "action_success", "intensity": .4})
                    self.state["last_lesson"] = "Подтверждённый результат сохранён для будущего выбора."
                self.profile["values"] = dict(self.state["personality"])
                self.profile["ethics"]["benevolence_weight"] = self.state["personality"]["benevolence"]
                self.profile["ethics"]["empathy_weight"] = self.state["personality"]["empathy"]
                self.brain.profile = self.profile
            if memory_record.get("training_eligible"):
                examples = self.world_memory.get_training_examples(identity_id=self.identity_id, game_id=game_id, limit=256)
                neural_training = self.neural_model.fit(examples, epochs=2)
            else:
                neural_training = {"trained": False, "reason": "waiting_for_verified_outcome",
                                   "samples": self.neural_model.training_samples, "active": self.neural_model.is_active}
            self._save_state()
            return {**result, "persistent_memory": memory_record, "neural_training": neural_training,
                    "world_memory_report": self.world_memory.report(identity_id=self.identity_id)}

    def _public_inner_state(self) -> dict[str, Any]:
        personality = self.state["personality"]
        drives = self.state["drives"]
        return {
            "personality": {key: round(_clamp(value), 3) for key, value in personality.items()},
            "drives": {key: round(_clamp(value), 3) for key, value in drives.items()},
            "emotions": {key: round(_clamp(value), 3) for key, value in self.state["emotions"].items()},
            "player_trust": round(_clamp(self.state["player_trust"]), 3),
            "frustration_pressure": round(_clamp(self.state["frustration_pressure"]), 3),
            "decision_count": int(self.state["decision_count"]),
            "learned_policy_count": len(self.learner.data.get("policies", {})),
            "persistent_world_experiences": self.world_memory.report(identity_id=self.identity_id)["experiences"],
            "neural_model_active": self.neural_model.is_active,
            "neural_model_samples": self.neural_model.training_samples,
            "last_lesson": self.state.get("last_lesson", ""),
            "moral_tendency": round((_clamp(personality["benevolence"]) + _clamp(personality["empathy"])) / 2.0, 3),
        }

    def _save_state(self) -> None:
        self.state["schema_version"] = self.SCHEMA_VERSION
        _atomic_json(self.state_path, self.state)


def validate_action_payload(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ValueError("Тело запроса должно быть JSON-объектом.")
    world = payload.get("world")
    if not isinstance(world, dict):
        raise ValueError("Поле world должно содержать снимок игры.")
    return payload
