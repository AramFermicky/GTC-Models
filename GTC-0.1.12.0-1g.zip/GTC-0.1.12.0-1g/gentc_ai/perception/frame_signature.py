"""Fast, deterministic byte-frame signature for deduplicating observations."""
from __future__ import annotations
import hashlib

def frame_signature(buffer: bytes | bytearray | memoryview, width: int, height: int,
                    channels: int = 4, sample_budget: int = 4096) -> str:
    if width <= 0 or height <= 0 or channels < 1 or sample_budget < 16:
        raise ValueError("invalid frame dimensions or sample budget")
    view = memoryview(buffer).cast("B")
    expected = width * height * channels
    if len(view) != expected: raise ValueError(f"frame buffer length {len(view)} != expected {expected}")
    total_pixels = width * height
    stride = max(1, total_pixels // sample_budget)
    digest = hashlib.blake2b(digest_size=16)
    digest.update(width.to_bytes(4, "little")); digest.update(height.to_bytes(4, "little")); digest.update(bytes([channels & 255]))
    pixel_step = stride * channels
    for index in range(0, expected, pixel_step): digest.update(view[index:index+channels])
    return digest.hexdigest()
