"""Engine-independent perception contracts and state fusion."""
from .contracts import Evidence, PerceivedState
from .change_detector import ChangeResult, VisualChangeDetector
from .confidence import combine_confidence
from .fusion import fuse_state_sources
__all__ = ["Evidence", "PerceivedState", "ChangeResult", "VisualChangeDetector", "combine_confidence", "fuse_state_sources"]
