"""Typed, engine-neutral perception data structures."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any

@dataclass(frozen=True)
class Evidence:
    source: str
    confidence: float
    value: Any
    verified: bool = False
    observed_at: float | None = None
    def __post_init__(self) -> None:
        if not self.source: raise ValueError("evidence source is required")
        if not 0.0 <= float(self.confidence) <= 1.0: raise ValueError("confidence must be in [0,1]")

@dataclass(frozen=True)
class PerceivedState:
    game_id: str
    scene_id: str = "unknown"
    mode: str = "unknown"
    values: dict[str, Any] = field(default_factory=dict)
    evidence: tuple[Evidence, ...] = ()
    confidence: float = 0.0
    verified: bool = False
    def __post_init__(self) -> None:
        if not self.game_id: raise ValueError("game_id is required")
        if not 0.0 <= float(self.confidence) <= 1.0: raise ValueError("confidence must be in [0,1]")
