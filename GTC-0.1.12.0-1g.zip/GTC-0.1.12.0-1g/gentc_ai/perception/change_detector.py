"""Track visual change, repeated frames and probable stalling separately."""
from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class ChangeResult:
    changed: bool
    consecutive_unchanged: int
    unchanged_seconds: float
    first_seen: bool
    signature: str

class VisualChangeDetector:
    def __init__(self, *, minimum_interval: float = 0.0) -> None:
        if minimum_interval < 0: raise ValueError("minimum_interval must be non-negative")
        self.minimum_interval = minimum_interval; self._signature: str | None = None
        self._first_unchanged_at: float | None = None; self._last_observed_at: float | None = None
        self._unchanged_count = 0
    def observe(self, signature: str, now: float) -> ChangeResult:
        if not signature: raise ValueError("signature must be non-empty")
        current = float(now)
        if self._last_observed_at is not None and current < self._last_observed_at:
            raise ValueError("timestamps must be monotonic")
        first = self._signature is None
        changed = first or signature != self._signature
        if changed:
            self._first_unchanged_at = current; self._unchanged_count = 0
        elif self._last_observed_at is None or current - self._last_observed_at >= self.minimum_interval:
            self._unchanged_count += 1
        self._signature = signature; self._last_observed_at = current
        start = self._first_unchanged_at if self._first_unchanged_at is not None else current
        return ChangeResult(changed, self._unchanged_count, max(0.0, current - start), first, signature)
    def reset(self) -> None:
        self._signature = None; self._first_unchanged_at = None; self._last_observed_at = None; self._unchanged_count = 0
