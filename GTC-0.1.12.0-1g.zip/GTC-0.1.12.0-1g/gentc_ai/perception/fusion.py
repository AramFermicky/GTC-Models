"""Conservative fusion: fresh verified game state beats visual guesses per field."""
from __future__ import annotations
from typing import Any
import math
from .contracts import Evidence, PerceivedState

def fuse_state_sources(game_id: str, visual: dict[str, Any] | None,
                       external: dict[str, Any] | None) -> PerceivedState:
    values: dict[str, Any] = {}; evidence: list[Evidence] = []
    scene_id = "unknown"; mode = "unknown"; verified = False
    if isinstance(visual, dict):
        visual_values = visual.get("values", visual)
        if isinstance(visual_values, dict): values.update(visual_values)
        scene_id = str(visual.get("scene_id", scene_id)); mode = str(visual.get("mode", mode))
        try:
            visual_confidence = float(visual.get("confidence", 0.25))
        except (TypeError, ValueError, OverflowError):
            visual_confidence = 0.0
        if not math.isfinite(visual_confidence): visual_confidence = 0.0
        evidence.append(Evidence("visual", max(0.0, min(1.0, visual_confidence)), dict(visual), False))
    if isinstance(external, dict) and external.get("available"):
        feed_values = external.get("values", external)
        if isinstance(feed_values, dict):
            trusted = external.get("verified") is True
            for key, value in feed_values.items():
                if key in {"path", "age_seconds", "available", "values", "confidence", "verified"}: continue
                if trusted or key not in values: values[key] = value
            if trusted:
                scene_id = str(feed_values.get("scene_id", scene_id)); mode = str(feed_values.get("mode", mode)); verified = True
            evidence.append(Evidence("game_state_feed", 1.0 if trusted else 0.55, dict(feed_values), trusted))
    confidence = max((e.confidence if e.verified else e.confidence * 0.72 for e in evidence), default=0.0)
    return PerceivedState(game_id=game_id, scene_id=scene_id, mode=mode, values=values,
                          evidence=tuple(evidence), confidence=max(0.0, min(1.0, confidence)), verified=verified)
