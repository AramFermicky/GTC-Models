"""Confidence calculations that prevent weak hints from masquerading as facts."""
from __future__ import annotations
from collections.abc import Iterable
from .contracts import Evidence

def combine_confidence(evidence: Iterable[Evidence], *, verified_floor: float = 0.0) -> float:
    items = list(evidence)
    if not items: return max(0.0, min(1.0, float(verified_floor)))
    # Independent weak evidence accumulates, but never raises confidence to 1 by itself.
    weighted_miss = 1.0
    for item in items:
        reliability = item.confidence * (1.0 if item.verified else 0.72)
        weighted_miss *= 1.0 - max(0.0, min(0.99, reliability))
    combined = 1.0 - weighted_miss
    return max(0.0, min(1.0, max(combined, float(verified_floor))))
