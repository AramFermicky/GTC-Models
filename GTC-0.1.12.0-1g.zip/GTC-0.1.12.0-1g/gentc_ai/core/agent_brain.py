"""Foundational autonomous-choice and simulated-emotion layer for GenTC AI 0.1.8.

This module models affect-like variables and ranks adapter-provided actions. It does
not claim consciousness and does not execute actions. A game adapter remains the
source of truth for preconditions, permission, and execution results.
"""
from __future__ import annotations

import math
from typing import Any

EMOTION_KEYS = ("joy", "trust", "fear", "frustration", "curiosity", "loneliness", "fatigue", "confidence")
DEFAULT_EMOTIONS = {
    "joy": 0.15,
    "trust": 0.30,
    "fear": 0.05,
    "frustration": 0.0,
    "curiosity": 0.50,
    "loneliness": 0.15,
    "fatigue": 0.0,
    "confidence": 0.35,
}

EVENT_DELTAS: dict[str, dict[str, float]] = {
    "action_success": {"joy": 0.12, "confidence": 0.10, "frustration": -0.12},
    "action_failure": {"frustration": 0.18, "confidence": -0.08},
    "kindness_received": {"trust": 0.14, "joy": 0.06, "loneliness": -0.04},
    "promise_kept": {"trust": 0.10, "confidence": 0.05, "joy": 0.04},
    "promise_broken": {"trust": -0.20, "frustration": 0.12},
    "threat_detected": {"fear": 0.25, "confidence": -0.04},
    "novelty_detected": {"curiosity": 0.15},
    "rest_completed": {"fatigue": -0.25, "frustration": -0.04},
    "social_connection": {"loneliness": -0.18, "joy": 0.07, "trust": 0.04},
    "harm_prevented": {"confidence": 0.06, "frustration": -0.05},
}


def _unit(value: Any, default: float = 0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        number = default
    if not math.isfinite(number):
        number = default
    return max(0.0, min(1.0, number))


def _signed(value: Any, default: float = 0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        number = default
    if not math.isfinite(number):
        number = default
    return max(-1.0, min(1.0, number))


class SimulatedEmotionModel:
    """Small bounded affect model used to shift action priorities, not a sentience model."""

    def initial_state(self, supplied: dict[str, Any] | None = None) -> dict[str, float]:
        supplied = supplied if isinstance(supplied, dict) else {}
        return {key: _unit(supplied.get(key, DEFAULT_EMOTIONS[key]), DEFAULT_EMOTIONS[key]) for key in EMOTION_KEYS}

    def apply_event(
        self,
        state: dict[str, Any] | None,
        event: dict[str, Any],
    ) -> dict[str, float]:
        result = self.initial_state(state)
        kind = str(event.get("kind", "unknown")) if isinstance(event, dict) else "unknown"
        intensity = _unit(event.get("intensity", 1.0), 1.0) if isinstance(event, dict) else 1.0
        for key, delta in EVENT_DELTAS.get(kind, {}).items():
            result[key] = _unit(result[key] + delta * intensity, result[key])
        return result

    def decay(self, state: dict[str, Any] | None, steps: int = 1) -> dict[str, float]:
        """Decay transient emotions toward zero while allowing trust to persist longer."""
        result = self.initial_state(state)
        try:
            parsed_steps = int(steps)
        except (TypeError, ValueError, OverflowError):
            parsed_steps = 1
        steps = max(0, min(10000, parsed_steps))
        rates = {key: 0.92 for key in EMOTION_KEYS}
        rates["trust"] = 0.99
        rates["curiosity"] = 0.985
        rates["confidence"] = 0.98
        for key, rate in rates.items():
            result[key] = _unit(result[key] * (rate ** steps))
        return result


class AgentBrain:
    """Rank candidate actions against goals, needs, values, emotion, and learned outcomes."""

    DEFAULT_VALUES = {
        "self_preservation": 0.85,
        "honesty": 0.75,
        "benevolence": 0.65,
        "empathy": 0.65,
        "curiosity": 0.45,
        "autonomy": 0.45,
        "loyalty": 0.40,
    }
    DEFAULT_FORBIDDEN_TAGS = {"coercion", "unjustified_harm", "nonconsensual_irreversible_harm"}
    EMOTION_ACTION_WEIGHTS = {
        "exploration": {"curiosity": 0.20, "fear": -0.08},
        "observe": {"curiosity": 0.10, "fear": 0.06},
        "social_interaction": {"loneliness": 0.16, "trust": 0.05, "fear": -0.04},
        "rest": {"fatigue": 0.25, "frustration": 0.04},
        "defend": {"fear": 0.14},
        "resource_gathering": {"confidence": 0.04, "fatigue": -0.05},
        "diplomacy": {"trust": 0.07, "frustration": -0.03},
    }

    def __init__(self, profile: dict[str, Any] | None = None, learner: Any | None = None):
        self.profile = profile if isinstance(profile, dict) else {}
        self.learner = learner
        self.emotions = SimulatedEmotionModel()

    def _settings(self) -> dict[str, Any]:
        settings = self.profile.get("autonomy", {})
        return settings if isinstance(settings, dict) else {}

    @staticmethod
    def _goal_priorities(world: dict[str, Any]) -> dict[str, float]:
        raw = world.get("goal_priorities", {})
        if isinstance(raw, dict):
            return {str(key): _unit(value) for key, value in raw.items()}
        result: dict[str, float] = {}
        if isinstance(raw, list):
            for item in raw:
                if isinstance(item, dict) and item.get("id"):
                    result[str(item["id"])] = _unit(item.get("priority", 0.5), 0.5)
        return result

    def _reject_reason(self, candidate: dict[str, Any], world: dict[str, Any], settings: dict[str, Any]) -> str | None:
        if not candidate.get("action"):
            return "missing_adapter_action"
        if candidate.get("preconditions_met") is not True:
            return "preconditions_not_verified"
        confidence = _unit(candidate.get("evidence_confidence", 0.0))
        min_confidence = _unit(settings.get("minimum_evidence_confidence", 0.55), 0.55)
        if confidence < min_confidence:
            return "insufficient_evidence_confidence"
        raw_risk = candidate.get("risk")
        if not isinstance(raw_risk, (int, float)) or not math.isfinite(float(raw_risk)) or not 0.0 <= float(raw_risk) <= 1.0:
            return "risk_not_verified_or_out_of_range"
        raw_cost = candidate.get("cost")
        if not isinstance(raw_cost, (int, float)) or not math.isfinite(float(raw_cost)) or not 0.0 <= float(raw_cost) <= 1.0:
            return "cost_not_verified_or_out_of_range"
        risk = _unit(raw_risk)
        max_risk = _unit(settings.get("maximum_risk", 0.70), 0.70)
        if risk > max_risk:
            return "risk_above_current_limit"
        if candidate.get("requires_consent") is True and candidate.get("consent_available") is not True:
            return "required_consent_missing"
        if candidate.get("authorization_required") is True and candidate.get("authorized") is not True:
            return "required_authorization_missing"

        profile_ethics = self.profile.get("ethics", {})
        profile_ethics = profile_ethics if isinstance(profile_ethics, dict) else {}
        configured = profile_ethics.get("forbidden_tags", [])
        forbidden = self.DEFAULT_FORBIDDEN_TAGS | (set(map(str, configured)) if isinstance(configured, list) else set())
        tags = candidate.get("tags", [])
        tags = set(map(str, tags)) if isinstance(tags, list) else set()
        if tags & forbidden:
            return "forbidden_ethics_tag:" + ",".join(sorted(tags & forbidden))

        max_unconsented_harm = _unit(profile_ethics.get("maximum_unconsented_harm", 0.30), 0.30)
        impacts = candidate.get("stakeholder_impact", [])
        if isinstance(impacts, list):
            for impact in impacts:
                if not isinstance(impact, dict):
                    continue
                harm = _unit(impact.get("harm", 0.0))
                consented = impact.get("consent") is True
                if harm > max_unconsented_harm and not consented:
                    return "unconsented_harm_above_limit"
        return None

    def _learned_bonus(self, semantic_action: str, context_tags: list[str]) -> tuple[float, dict[str, Any] | None]:
        if self.learner is None or semantic_action in ("", "unknown"):
            return 0.0, None
        try:
            estimate = self.learner.estimate(semantic_action, context_tags)
        except (AttributeError, TypeError, ValueError):
            return 0.0, None
        if not isinstance(estimate, dict):
            return 0.0, None
        try:
            estimate_count = int(estimate.get("count", 0))
        except (TypeError, ValueError, OverflowError):
            return 0.0, None
        if estimate_count <= 0:
            return 0.0, estimate
        settings = self._settings()
        strength = _unit(settings.get("learning_influence", 0.20), 0.20)
        mean_reward = _signed(estimate.get("mean_reward", 0.0))
        confidence = _unit(estimate.get("confidence", 0.0))
        bonus = max(-strength, min(strength, mean_reward * confidence * strength))
        # A sufficiently repeated negative outcome triggers a caution penalty, not a hard ban.
        if estimate_count >= 3 and mean_reward <= -0.35:
            bonus = min(bonus, -strength * 0.75)
        return bonus, estimate

    def choose_action(
        self,
        world: dict[str, Any],
        candidates: list[dict[str, Any]],
        emotional_state: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        if not isinstance(world, dict):
            raise ValueError("world должен быть объектом со снимком подтверждённого состояния.")
        if not isinstance(candidates, list):
            raise ValueError("candidates должен быть массивом действий от адаптера.")
        settings = self._settings()
        values = dict(self.DEFAULT_VALUES)
        supplied_values = self.profile.get("values", {})
        if isinstance(supplied_values, dict):
            values.update({str(k): _unit(v, values.get(str(k), 0.5)) for k, v in supplied_values.items()})
        emotion = self.emotions.initial_state(emotional_state)
        goal_priorities = dict(self._settings().get("goals", {})) if isinstance(self._settings().get("goals", {}), dict) else {}
        # Runtime goals can change with the world; explicit adapter/runtime priorities override defaults.
        goal_priorities.update(self._goal_priorities(world))
        goal_priorities = {str(key): _unit(value, 0.35) for key, value in goal_priorities.items()}
        current_needs = world.get("needs", {})
        current_needs = current_needs if isinstance(current_needs, dict) else {}
        ranked: list[dict[str, Any]] = []
        rejected: list[dict[str, Any]] = []

        for candidate in candidates:
            if not isinstance(candidate, dict):
                rejected.append({"candidate": repr(candidate), "reason": "candidate_must_be_object"})
                continue
            action_name = str(candidate.get("action", ""))
            semantic = str(candidate.get("semantic_action", "unknown"))
            reject_reason = self._reject_reason(candidate, world, settings)
            if reject_reason:
                rejected.append({"action": action_name, "semantic_action": semantic, "reason": reject_reason})
                continue

            score_parts: dict[str, float] = {}
            goals = candidate.get("goal_progress", {})
            if isinstance(goals, dict):
                score_parts["goal_alignment"] = sum(
                    _signed(progress) * goal_priorities.get(str(goal_id), 0.35)
                    for goal_id, progress in goals.items()
                )
            elif isinstance(goals, (int, float)):
                score_parts["goal_alignment"] = _signed(goals) * 0.5
            else:
                score_parts["goal_alignment"] = 0.0

            need_effects = candidate.get("need_effects", {})
            need_utility = 0.0
            if isinstance(need_effects, dict):
                for need_name, change in need_effects.items():
                    deficit = _unit(current_needs.get(str(need_name), 0.5), 0.5)
                    need_utility += _signed(change) * deficit
            score_parts["need_alignment"] = need_utility * 0.35

            configured_pref = settings.get("action_preferences", {})
            preference = _signed(configured_pref.get(semantic, 0.0)) if isinstance(configured_pref, dict) else 0.0
            # personality/values can guide without determining every action by script.
            value_map = {
                "exploration": "curiosity", "observe": "curiosity", "social_interaction": "benevolence",
                "care": "benevolence", "diplomacy": "honesty", "defend": "self_preservation",
                "rest": "self_preservation", "resource_gathering": "autonomy", "trade": "honesty",
            }
            matching_value = values.get(value_map.get(semantic, "autonomy"), 0.5)
            score_parts["personality_and_preference"] = preference * 0.25 + (matching_value - 0.5) * 0.15

            emotion_weights = self.EMOTION_ACTION_WEIGHTS.get(semantic, {})
            score_parts["emotional_context"] = sum(emotion[key] * weight for key, weight in emotion_weights.items())

            ethics = self.profile.get("ethics", {})
            ethics = ethics if isinstance(ethics, dict) else {}
            benevolence_weight = _unit(ethics.get("benevolence_weight", values.get("benevolence", 0.65)), 0.65)
            empathy_weight = _unit(ethics.get("empathy_weight", values.get("empathy", 0.65)), 0.65)
            impact_score = 0.0
            impacts = candidate.get("stakeholder_impact", [])
            if isinstance(impacts, list):
                for impact in impacts:
                    if not isinstance(impact, dict):
                        continue
                    harm = _unit(impact.get("harm", 0.0))
                    benefit = _unit(impact.get("benefit", 0.0))
                    impact_score += (benefit * benevolence_weight - harm * empathy_weight) * 0.40
            score_parts["other_agent_impact"] = impact_score

            score_parts["cost_penalty"] = -_unit(candidate.get("cost", 0.0)) * 0.20
            score_parts["risk_penalty"] = -_unit(candidate.get("risk", 0.0)) * 0.35
            tags = candidate.get("context_tags", [])
            tags = [str(tag) for tag in tags] if isinstance(tags, list) else []
            learned_bonus, learned_estimate = self._learned_bonus(semantic, tags)
            score_parts["learned_outcome_adjustment"] = learned_bonus
            # These bounded components are supplied only by GTC's persistent, verified memory
            # and its experimental neural estimator. They are deliberately low-weight.
            score_parts["persistent_world_memory_adjustment"] = max(
                -0.08, min(0.08, _signed(candidate.get("persistent_memory_adjustment", 0.0)))
            )
            score_parts["neural_value_adjustment"] = max(
                -0.06, min(0.06, _signed(candidate.get("neural_value_adjustment", 0.0)))
            )
            # Persistent Q-learning now participates in selection, but its bounded
            # influence remains small until repeated verified outcomes accumulate.
            score_parts["q_learning_adjustment"] = max(
                -0.13, min(0.13, _signed(candidate.get("q_learning_adjustment", 0.0)))
            )
            # Versioned knowledge is a small, explicit prior. Newer verified
            # model-build evidence is ranked first; old evidence remains in recall.
            score_parts["versioned_knowledge_adjustment"] = max(
                -0.05, min(0.05, _signed(candidate.get("versioned_knowledge_adjustment", 0.0)))
            )
            total = round(sum(score_parts.values()), 6)
            ranked.append({
                "action": action_name,
                "semantic_action": semantic,
                "score": total,
                "score_parts": {key: round(value, 6) for key, value in score_parts.items()},
                "candidate": candidate,
                "learned_estimate": learned_estimate,
            })

        ranked.sort(key=lambda item: (-item["score"], item["action"]))
        chosen = ranked[0] if ranked else None
        return {
            "decision": "choose_action" if chosen else "pause_and_observe",
            "chosen_action": chosen["candidate"] if chosen else None,
            "chosen_action_name": chosen["action"] if chosen else None,
            "chosen_score": chosen["score"] if chosen else None,
            "ranked_candidates": [
                {key: item[key] for key in ("action", "semantic_action", "score", "score_parts", "learned_estimate")}
                for item in ranked
            ],
            "rejected_candidates": rejected,
            "simulated_emotional_state": emotion,
            "reason": "highest_expected_utility_among_actions_passing_constraints" if chosen else "no_action_passed_constraints",
            "must_confirm_execution_with_adapter": True,
        }
