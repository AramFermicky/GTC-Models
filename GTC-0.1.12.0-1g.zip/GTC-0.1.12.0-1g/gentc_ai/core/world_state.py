"""Validation/diagnostics helpers for world snapshots supplied by adapters."""
from __future__ import annotations

from typing import Any


class WorldStateAnalyzer:
    """Accepts the legacy demo format and the engine-agnostic GTC snapshot."""

    def analyze(self, snapshot: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(snapshot, dict):
            return {"valid": False, "issues": ["snapshot_must_be_object"], "player_found": False,
                    "npc_count": 0, "object_count": 0, "event_count": 0}
        issues: list[str] = []
        if "player" not in snapshot:
            issues.append("missing_required_field:player")
        player = snapshot.get("player")
        if not isinstance(player, dict):
            issues.append("player_must_be_object")
        elif "id" not in player or "position" not in player:
            issues.append("player_requires_id_and_position")

        npcs = snapshot.get("characters", snapshot.get("npcs", []))
        objects = snapshot.get("objects", [])
        events = snapshot.get("events", [])
        if not isinstance(npcs, list):
            issues.append("characters_or_npcs_must_be_array")
            npcs = []
        if not isinstance(objects, list):
            issues.append("objects_must_be_array")
            objects = []
        if not isinstance(events, list):
            issues.append("events_must_be_array")
            events = []
        player_found = isinstance(player, dict) and bool(player.get("id"))
        return {
            "valid": not issues,
            "issues": issues,
            "player_found": player_found,
            "game_id": snapshot.get("game_id"),
            "npc_count": len(npcs),
            "object_count": len(objects),
            "event_count": len(events),
        }
