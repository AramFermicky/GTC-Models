"""Small rule-based intent parser for the offline prototype.

It intentionally handles only a narrow command set. For arbitrary natural-language
requests, a future LLM/NLU adapter should return structured intent candidates that
GTC still validates against the game's real world snapshot and action allowlist.
"""
from __future__ import annotations

import re
from typing import Any


_TREE_VERBS = (
    "сруби", "срубить", "сруб", "поруби", "порубить", "поруб", "наруби", "нарубить",
    "наруб", "рубить", "руби", "спили", "спилить", "валить", "собери дров",
    "cut down", "chop", "fell trees", "gather firewood",
)
_TREE_NOUNS = ("дерев", "tree", "дров", "бревн", "firewood", "logs")
_GIVE_AXE = (
    "я даю топор", "я передаю топор", "передаю топор", "вот тебе топор", "тебе топор",
    "держи топор", "дай топор", "дать топор", "/give axe",
)


def _contains_any(text: str, terms: tuple[str, ...]) -> bool:
    return any(term in text for term in terms)


class IntentParser:
    def parse(self, text: str) -> dict[str, Any]:
        raw = (text or "").strip()
        normalized = raw.casefold().replace("ё", "е")
        if not normalized:
            return {"intent": "empty", "raw_text": raw, "confidence": 1.0}

        # Item-transfer commands must be checked before tree words. Otherwise a
        # phrase such as "дай топор, чтобы порубить деревья" gets misclassified.
        if _contains_any(normalized, _GIVE_AXE):
            return {"intent": "give_item", "item_id": "axe", "raw_text": raw, "confidence": 0.95}

        has_tree_verb = _contains_any(normalized, _TREE_VERBS)
        has_tree_noun = _contains_any(normalized, _TREE_NOUNS)
        if has_tree_verb and has_tree_noun:
            count = 2
            match = re.search(r"(?<!\w)(\d{1,2})(?!\w)", normalized)
            if match:
                try:
                    count = max(1, min(10, int(match.group(1))))
                except ValueError:
                    count = 2
            elif re.search(r"\b(пару|пара|два|две|couple|two)\b", normalized):
                count = 2
            elif re.search(r"\b(одно|один|одну|одно дерево|one)\b", normalized):
                count = 1
            return {
                "intent": "chop_trees",
                "target_count": count,
                "raw_text": raw,
                "confidence": 0.9,
            }

        if any(token in normalized for token in ("привет", "здравствуй", "доброе утро", "добрый день", "hello", "hi there")):
            return {"intent": "greeting", "raw_text": raw, "confidence": 0.85}

        if normalized in {"/status", "статус", "что ты умеешь", "что умеешь"}:
            return {"intent": "status", "raw_text": raw, "confidence": 1.0}

        if normalized in {"/quit", "/exit", "выход", "пока"}:
            return {"intent": "quit", "raw_text": raw, "confidence": 1.0}

        return {"intent": "general_dialogue", "raw_text": raw, "confidence": 0.35}
