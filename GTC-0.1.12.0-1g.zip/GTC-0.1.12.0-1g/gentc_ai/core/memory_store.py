"""Small local memory and experience store for the prototype."""
from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class MemoryStore:
    def __init__(self, root: Path, character_id: str):
        # Character IDs may come from a profile/adapter; do not let them escape
        # the designated data directory or create invalid Windows path names.
        safe_character_id = re.sub(r"[^A-Za-z0-9_.-]", "_", str(character_id)).strip("._")[:96]
        if not safe_character_id:
            raise ValueError("character_id не содержит допустимых символов.")
        self.character_id = safe_character_id
        self.root = root / "Characters" / safe_character_id
        self.root.mkdir(parents=True, exist_ok=True)
        self.dialogue_path = self.root / "dialogue.jsonl"
        self.experience_path = self.root / "experience.jsonl"
        self.memory_path = self.root / "memory.json"
        if not self.memory_path.exists():
            self._write_memory({
                "schema_version": 1,
                "character_id": character_id,
                "updated_at": _now(),
                "important_events": [],
                "player_preferences": [],
                "promises": [],
                "relationship_notes": [],
            })

    def _append_jsonl(self, path: Path, row: dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")

    def _write_memory(self, memory: dict[str, Any]) -> None:
        self.memory_path.write_text(json.dumps(memory, ensure_ascii=False, indent=2), encoding="utf-8")

    def log_dialogue(self, speaker: str, text: str, metadata: dict[str, Any] | None = None) -> None:
        self._append_jsonl(self.dialogue_path, {
            "timestamp_utc": _now(),
            "character_id": self.character_id,
            "speaker": speaker,
            "text": text,
            "metadata": metadata or {},
        })

    def log_experience(self, situation: dict[str, Any], decision: dict[str, Any], result: dict[str, Any]) -> None:
        self._append_jsonl(self.experience_path, {
            "timestamp_utc": _now(),
            "character_id": self.character_id,
            "situation": situation,
            "decision": decision,
            "result": result,
        })

    def add_important_event(self, summary: str, source: str = "game_event", confidence: float = 1.0) -> None:
        memory = self.load_memory()
        event = {
            "timestamp_utc": _now(),
            "summary": summary,
            "source": source,
            "confidence": max(0.0, min(1.0, float(confidence))),
        }
        memory.setdefault("important_events", []).append(event)
        # Keep the saved summary bounded; the full transcript remains in JSONL.
        memory["important_events"] = memory["important_events"][-200:]
        memory["updated_at"] = _now()
        self._write_memory(memory)

    def load_memory(self) -> dict[str, Any]:
        try:
            return json.loads(self.memory_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {
                "schema_version": 1,
                "character_id": self.character_id,
                "updated_at": _now(),
                "important_events": [],
                "player_preferences": [],
                "promises": [],
                "relationship_notes": [],
            }
