"""Game-independent action labels for mapping different mechanics to shared concepts.

An adapter must provide the mapping. This layer deliberately does not guess that two
similarly named actions have identical game effects.
"""
from __future__ import annotations

from typing import Any

COMMON_SEMANTICS = {
    "move", "exploration", "observe", "wait", "rest", "resource_gathering", "crafting",
    "building", "destroy", "social_interaction", "care", "trade", "diplomacy",
    "manage_economy", "research", "recruit", "military_movement", "attack", "defend",
    "consume", "quest_progress", "inventory_management", "unknown",
}


class SemanticActionLayer:
    """Translate adapter-specific action specifications into a compact common vocabulary."""

    @staticmethod
    def normalize_action(action_spec: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(action_spec, dict):
            raise ValueError("Описание действия адаптера должно быть JSON-объектом.")
        action_name = str(action_spec.get("name", ""))
        if not action_name:
            raise ValueError("У действия адаптера отсутствует поле name.")
        declared = str(action_spec.get("semantic_action", "unknown"))
        known = declared in COMMON_SEMANTICS
        risk_value = action_spec.get("risk", "adapter_must_supply")
        if isinstance(risk_value, str):
            risk_value = {"low": 0.20, "medium": 0.50, "high": 0.80}.get(risk_value.casefold(), risk_value)
        return {
            "action": action_name,
            "semantic_action": declared if known else "unknown",
            "semantic_mapping_valid": known,
            "mapping_warning": None if known else f"Адаптер должен сопоставить {action_name!r} с общей семантикой; GTC не будет угадывать.",
            "risk": risk_value,
            "cost": action_spec.get("cost", "adapter_must_supply"),
            "reversible": action_spec.get("reversible", "adapter_must_supply"),
            "requires_consent": bool(action_spec.get("requires_consent", False)),
            "effects": action_spec.get("effects", {}),
        }

    @staticmethod
    def same_concept(left: dict[str, Any], right: dict[str, Any]) -> dict[str, Any]:
        left_semantic = str(left.get("semantic_action", "unknown"))
        right_semantic = str(right.get("semantic_action", "unknown"))
        comparable = left_semantic in COMMON_SEMANTICS - {"unknown"} and left_semantic == right_semantic
        return {
            "same_declared_semantic": comparable,
            "semantic_action": left_semantic if comparable else None,
            "mechanics_equivalent": False,
            "note": (
                "Одинаковая семантическая метка не доказывает одинаковые правила, стоимость или результат; "
                "их надо получать от конкретного игрового адаптера."
            ),
        }
