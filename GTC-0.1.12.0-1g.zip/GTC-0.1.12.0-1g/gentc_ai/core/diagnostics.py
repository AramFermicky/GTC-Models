"""Append-only local diagnostics in JSON Lines format."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class Diagnostics:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def record(self, event: str, details: dict[str, Any] | None = None, level: str = "INFO") -> None:
        row = {
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            "level": level,
            "event": event,
            "details": details or {},
        }
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
