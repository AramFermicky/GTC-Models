"""Core decision and memory components for GenTC AI."""
