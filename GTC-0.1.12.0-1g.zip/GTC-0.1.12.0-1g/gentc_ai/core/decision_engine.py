"""Rule-based decision engine for GTC 0.1.

It plans actions from structured world data and never pretends actions have run
unless a game adapter returns a result. In the current demo, plans are simulated.
"""
from __future__ import annotations

from typing import Any


class DecisionEngine:
    """Rule-based, game-independent decision draft for registered intents.

    Every returned plan is declarative. It is NOT proof of execution: the game
    adapter must validate and execute each command, then return its result.
    """

    @staticmethod
    def _inventory_ids(world: dict[str, Any]) -> set[str]:
        result: set[str] = set()
        for item in world.get("inventory", []):
            if isinstance(item, str):
                result.add(item)
            elif isinstance(item, dict):
                item_id = item.get("item_id", item.get("id"))
                if item_id:
                    result.add(str(item_id))
        return result

    @staticmethod
    def _available_objects(world: dict[str, Any]) -> list[dict[str, Any]]:
        candidates = world.get("nearby_objects", world.get("objects", []))
        if not isinstance(candidates, list):
            return []
        return [obj for obj in candidates if isinstance(obj, dict) and obj.get("available", True)]

    def decide(self, intent: dict[str, Any], world: dict[str, Any], profile: dict[str, Any]) -> dict[str, Any]:
        name = profile.get("display_name", "Персонаж")
        character_id = profile.get("character_id", "unknown")
        permissions = profile.get("permissions", {})
        behavior = profile.get("behavior_profile", {})
        inventory = self._inventory_ids(world)
        nearby_objects = self._available_objects(world)
        available_trees = [obj for obj in nearby_objects if obj.get("type") == "tree"]
        intent_name = intent.get("intent", "unknown")

        if intent_name == "chop_trees":
            try:
                requested = int(intent.get("target_count", 2))
            except (TypeError, ValueError):
                requested = 2
            requested = max(1, min(10, requested))
            base = {"character_id": character_id, "intent": "chop_trees", "target_count": requested}

            if not permissions.get("can_accept_player_requests", True) or not permissions.get("can_chop_trees", False):
                return {**base, "decision": "refuse", "status": "blocked_by_character_profile",
                        "reason": "character_not_permitted",
                        "speech_brief": f"{name} не может или не хочет выполнять это действие согласно профилю персонажа.",
                        "plan": []}

            if world.get("npc_busy", False):
                return {**base, "decision": "defer", "status": "blocked_busy", "reason": "npc_busy",
                        "speech_brief": f"{name} сейчас занята и должна закончить текущее действие либо безопасно прервать его.",
                        "plan": []}

            if not available_trees:
                return {**base, "decision": "request_clarification_or_report", "status": "blocked_no_trees",
                        "reason": "no_available_trees_in_world_snapshot",
                        "speech_brief": f"{name} не видит доступных деревьев. Нужно проверить данные игрового мира.",
                        "plan": []}

            if "axe" not in inventory:
                axe_nearby = next((obj for obj in nearby_objects
                                   if obj.get("type") == "item" and obj.get("item_id", obj.get("id")) == "axe"), None)
                if axe_nearby and permissions.get("can_pick_up_items", False):
                    axe_id = str(axe_nearby.get("id", axe_nearby.get("item_id", "axe")))
                    return {**base, "decision": "accept_after_getting_tool", "status": "requires_tool_pickup",
                            "reason": "axe_available_nearby",
                            "speech_brief": f"{name} согласна помочь и сначала проверит возможность подобрать доступный топор.",
                            "plan": [{"action": "move_to", "target_id": axe_id},
                                     {"action": "pick_up_item", "item_id": "axe", "target_id": axe_id},
                                     {"action": "recheck_request", "intent": "chop_trees", "target_count": requested}]}
                return {**base, "decision": "request_tool", "status": "blocked_missing_tool",
                        "reason": "axe_not_in_inventory_or_nearby",
                        "speech_brief": f"{name} в принципе может помочь, но у неё нет топора. Нужно попросить игрока передать топор или сообщить, где его взять.",
                        "plan": []}

            try:
                willingness = float(behavior.get("willingness_to_help", 50))
            except (TypeError, ValueError):
                willingness = 50.0
            if willingness < 15:
                return {**base, "decision": "refuse_or_negotiate", "status": "declined_by_current_motivation",
                        "reason": "low_willingness_to_help",
                        "speech_brief": f"{name} сейчас не хочет браться за эту просьбу; сформулируй вежливый отказ или предложение позже.",
                        "plan": []}

            selected_trees = available_trees[:requested]
            tree_ids = [str(tree["id"]) for tree in selected_trees if tree.get("id") is not None]
            if len(tree_ids) != len(selected_trees):
                return {**base, "decision": "request_clarification_or_report", "status": "blocked_bad_world_data",
                        "reason": "available_tree_missing_id",
                        "speech_brief": f"{name} не может надёжно выбрать дерево: у объекта отсутствует ID.", "plan": []}
            count_satisfied = len(tree_ids) >= requested
            plan: list[dict[str, Any]] = []
            for tree_id in tree_ids:
                # A plan is sequential: approach one tree, perform its action,
                # then move to the next tree. The engine still confirms every step.
                plan.append({"action": "move_to", "target_id": tree_id})
                plan.append({"action": "chop_tree", "target_id": tree_id})
            if count_satisfied:
                decision_name = "accept"
                status = "plan_ready_not_executed"
                speech = f"{name} согласна помочь. План подготовлен, но выполнение должен подтвердить игровой движок."
            else:
                decision_name = "accept_partial"
                status = "partial_plan_ready_not_executed"
                speech = f"{name} может выполнить только часть просьбы: сейчас доступно деревьев {len(tree_ids)} из {requested}."
            return {**base, "decision": decision_name, "status": status,
                    "reason": "prerequisites_satisfied_in_world_snapshot",
                    "speech_brief": speech, "plan": plan, "planned_tree_ids": tree_ids,
                    "requested_trees_available": count_satisfied, "planned_tree_count": len(tree_ids)}

        if intent_name == "give_item":
            return {"character_id": character_id, "intent": "give_item", "decision": "apply_demo_inventory_update",
                    "status": "demo_only", "reason": "console_simulation_command",
                    "speech_brief": f"{name} получила топор в демонстрационном инвентаре. В настоящей игре изменение должно подтвердить Godot.",
                    "plan": []}
        if intent_name == "greeting":
            return {"character_id": character_id, "intent": "greeting", "decision": "greet",
                    "status": "ready_for_llm", "reason": "greeting_intent_detected",
                    "speech_brief": f"{name} должна поздороваться в соответствии со своим характером.", "plan": []}
        if intent_name == "status":
            return {"character_id": character_id, "intent": "status", "decision": "report_status",
                    "status": "demo", "reason": "status_requested",
                    "speech_brief": "Показывается только состояние демонстрационной песочницы GTC 0.1.", "plan": []}
        return {"character_id": character_id, "intent": intent_name, "decision": "no_game_action",
                "status": "dialogue_only_or_unrecognized", "reason": "no_registered_action_for_intent",
                "speech_brief": f"Передай текст и профиль {name} в будущий LLM-адаптер; не выдавай текст игрока за исполняемую команду.",
                "plan": []}
