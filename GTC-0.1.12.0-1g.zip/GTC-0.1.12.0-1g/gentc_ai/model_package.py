"""Read-only manifest resolver for a selected GenTC model package."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class ModelPackageError(ValueError):
    pass


def load_model_manifest(model_root: str | Path) -> dict[str, Any]:
    root = Path(model_root).expanduser().resolve()
    manifest_path = root / "model.json"
    if not manifest_path.is_file():
        return {"schema_version": 1, "id": root.name, "name": root.name,
                "version": "unknown", "weight_files": {}, "manifest_found": False}
    try:
        value = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ModelPackageError(f"model_manifest_unreadable:{type(exc).__name__}") from exc
    if not isinstance(value, dict) or int(value.get("schema_version", 1)) != 1:
        raise ModelPackageError("model_manifest_schema_unsupported")
    result = dict(value)
    result.setdefault("id", root.name)
    result.setdefault("name", root.name)
    result.setdefault("version", "unknown")
    weights = result.get("weight_files", {})
    if not isinstance(weights, dict):
        raise ModelPackageError("weight_files_must_be_object")
    result["weight_files"] = weights
    result["manifest_found"] = True
    return result


def resolve_model_weight(model_root: str | Path, manifest: dict[str, Any], weight_kind: str) -> Path | None:
    root = Path(model_root).expanduser().resolve()
    relative = manifest.get("weight_files", {}).get(weight_kind)
    if not isinstance(relative, str) or not relative.strip():
        return None
    candidate = Path(relative)
    if candidate.is_absolute() or any(part in {"..", ""} for part in candidate.parts):
        raise ModelPackageError("weight_path_must_be_relative_and_contained")
    resolved = (root / candidate).resolve()
    try:
        resolved.relative_to(root)
    except ValueError as exc:
        raise ModelPackageError("weight_path_escapes_model_root") from exc
    return resolved if resolved.is_file() else None
