"""Correlate proposed game actions with their execution feedback.

A decision is a proposal, not proof that the game executed it. The tracker keeps
one in-flight command per game/world, reuses its command ID while waiting for a
result, and temporarily cautions timed-out commands without turning a timeout
into a negative training label.
"""
from __future__ import annotations

from collections import OrderedDict
from copy import deepcopy
from dataclasses import dataclass, field
import hashlib
import json
import math
import time
import threading
import uuid
from typing import Any, Callable

_VOLATILE_KEYS = {
    "timestamp", "timestamp_ms", "timestamp_utc", "captured_at", "frame_id",
    "sequence", "request_id", "elapsed_seconds", "delta_seconds",
}


def _normalise_state(value: Any) -> Any:
    if isinstance(value, dict):
        return {
            str(key): _normalise_state(item)
            for key, item in sorted(value.items(), key=lambda pair: str(pair[0]))
            if str(key).casefold() not in _VOLATILE_KEYS
        }
    if isinstance(value, list):
        return [_normalise_state(item) for item in value]
    if isinstance(value, float):
        if not math.isfinite(value):
            return str(value)
        return round(value, 2)
    return value


def state_fingerprint(world: dict[str, Any]) -> str:
    """Build a stable state key that ignores frame timestamps and tiny float noise."""
    if not isinstance(world, dict):
        raise ValueError("world должен быть JSON-объектом")
    payload = json.dumps(_normalise_state(world), ensure_ascii=False, sort_keys=True,
                         separators=(",", ":"), default=str)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:24]


def action_key(action: dict[str, Any]) -> tuple[str, str]:
    return str(action.get("action", "")), str(action.get("target_id", ""))


@dataclass
class _Decision:
    decision_id: str
    world_key: str
    state_key: str
    action: dict[str, Any]
    created_at: float
    timeout_seconds: float
    status: str = "pending"
    polls: int = 0
    last_polled_at: float = 0.0
    resolved_at: float | None = None
    details: dict[str, Any] = field(default_factory=dict)

    def export(self, *, reused: bool = False, now: float | None = None) -> dict[str, Any]:
        current = time.monotonic() if now is None else now
        return {
            "decision_id": self.decision_id,
            "world_key": self.world_key,
            "state_key": self.state_key,
            "action": deepcopy(self.action),
            "status": self.status,
            "created_at_monotonic": self.created_at,
            "age_seconds": round(max(0.0, current - self.created_at), 3),
            "timeout_seconds": self.timeout_seconds,
            "poll_count": self.polls,
            "reused": reused,
            "details": deepcopy(self.details),
        }


class DecisionTracker:
    """Small in-memory lifecycle ledger; only verified feedback reaches learning."""

    def __init__(self, *, timeout_seconds: float = 15.0,
                 clock: Callable[[], float] = time.monotonic,
                 history_limit: int = 512) -> None:
        if not math.isfinite(float(timeout_seconds)) or timeout_seconds <= 0:
            raise ValueError("timeout_seconds должен быть конечным положительным числом")
        if history_limit < 16:
            raise ValueError("history_limit должен быть не меньше 16")
        self.timeout_seconds = float(timeout_seconds)
        self.clock = clock
        self.history_limit = int(history_limit)
        self._lock = threading.RLock()
        self._pending: dict[str, _Decision] = {}
        self._history: OrderedDict[str, _Decision] = OrderedDict()
        self._counts = {"created": 0, "reused": 0, "confirmed": 0, "late_confirmed": 0,
                        "timed_out": 0, "duplicate_feedback": 0, "unmatched_feedback": 0}

    def _remember(self, decision: _Decision) -> None:
        self._history[decision.decision_id] = decision
        self._history.move_to_end(decision.decision_id)
        while len(self._history) > self.history_limit:
            self._history.popitem(last=False)

    def get_pending(self, world_key: str) -> dict[str, Any] | None:
        with self._lock:
            now = self.clock()
            decision = self._pending.get(str(world_key))
            if decision is None:
                return None
            if now - decision.created_at >= decision.timeout_seconds:
                decision.status = "timed_out_unconfirmed"
                decision.resolved_at = now
                decision.details["timeout_reason"] = "execution_feedback_not_received"
                self._pending.pop(str(world_key), None)
                self._remember(decision)
                self._counts["timed_out"] += 1
                return None
            decision.polls += 1
            decision.last_polled_at = now
            self._counts["reused"] += 1
            return decision.export(reused=True, now=now)

    def create(self, world_key: str, state_key: str, action: dict[str, Any],
               timeout_seconds: float | None = None) -> dict[str, Any]:
        with self._lock:
            now = self.clock()
            world_key = str(world_key)
            if world_key in self._pending:
                current = self.get_pending(world_key)
                if current is not None:
                    return current
            timeout = self.timeout_seconds if timeout_seconds is None else float(timeout_seconds)
            if not math.isfinite(timeout) or timeout <= 0:
                timeout = self.timeout_seconds
            timeout = max(1.0, min(120.0, timeout))
            decision_id = uuid.uuid4().hex
            action_copy = deepcopy(action)
            action_copy["command_id"] = decision_id
            decision = _Decision(
                decision_id=decision_id,
                world_key=world_key,
                state_key=str(state_key),
                action=action_copy,
                created_at=now,
                timeout_seconds=timeout,
            )
            self._pending[world_key] = decision
            self._counts["created"] += 1
            return decision.export(now=now)

    def cautioned_actions(self, world_key: str, state_key: str) -> set[tuple[str, str]]:
        """Actions that timed out in this unchanged state; no reward/penalty is written."""
        with self._lock:
            self.get_pending(world_key)
            return {
                action_key(item.action)
                for item in self._history.values()
                if item.world_key == str(world_key)
                and item.state_key == str(state_key)
                and item.status == "timed_out_unconfirmed"
            }

    def acknowledge(self, decision_id: str, action_name: str) -> dict[str, Any]:
        with self._lock:
            decision_id = str(decision_id or "")
            now = self.clock()
            if not decision_id:
                self._counts["unmatched_feedback"] += 1
                return {"accepted": False, "reason": "decision_id_missing"}
            for world_key, decision in list(self._pending.items()):
                if decision.decision_id != decision_id:
                    continue
                if action_name and action_key(decision.action)[0] != str(action_name):
                    return {"accepted": False, "reason": "action_name_mismatch", "decision_id": decision_id}
                self._pending.pop(world_key, None)
                decision.status = "confirmed_feedback_received"
                decision.resolved_at = now
                self._remember(decision)
                self._counts["confirmed"] += 1
                return {"accepted": True, "late": False, "decision_id": decision_id,
                        "action": deepcopy(decision.action)}
            history = self._history.get(decision_id)
            if history is not None:
                if action_name and action_key(history.action)[0] != str(action_name):
                    return {"accepted": False, "reason": "action_name_mismatch", "decision_id": decision_id}
                if history.status == "timed_out_unconfirmed":
                    history.status = "late_feedback_received"
                    history.resolved_at = now
                    self._counts["late_confirmed"] += 1
                    return {"accepted": True, "late": True, "decision_id": decision_id,
                            "action": deepcopy(history.action)}
                if history.status in {"confirmed_feedback_received", "late_feedback_received"}:
                    self._counts["duplicate_feedback"] += 1
                    return {"accepted": True, "duplicate": True, "decision_id": decision_id}
            self._counts["unmatched_feedback"] += 1
            return {"accepted": False, "reason": "unknown_decision_id", "decision_id": decision_id}

    def acknowledge_current(self, world_key: str, action_name: str) -> dict[str, Any]:
        with self._lock:
            pending = self.get_pending(world_key)
            if pending is None:
                return {"accepted": False, "reason": "no_pending_decision"}
            return self.acknowledge(pending["decision_id"], action_name)

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            now = self.clock()
            return {
                **self._counts,
                "pending": len(self._pending),
                "pending_decisions": [
                    {"decision_id": item.decision_id, "world_key": item.world_key,
                     "action": action_key(item.action)[0], "target_id": action_key(item.action)[1],
                     "age_seconds": round(max(0.0, now - item.created_at), 3),
                     "timeout_seconds": item.timeout_seconds, "poll_count": item.polls}
                    for item in self._pending.values()
                ],
                "history_size": len(self._history),
            }
