"""Common experience data structure shared by independent learning algorithms."""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any
import math, time, uuid

class Outcome(str, Enum):
    NEUTRAL = "neutral"; PROGRESS = "progress"; DODGE = "dodge"; GOAL_COMPLETED = "goal_completed"
    BLOCKED = "blocked"; MISSED_ATTACK = "missed_attack"; DAMAGE = "damage"; ITEM_MISUSE = "item_misuse"; DEATH = "death"

@dataclass(frozen=True)
class Experience:
    game_id: str
    state_id: str
    action: str
    next_state_id: str
    outcome: Outcome = Outcome.NEUTRAL
    reward: float = 0.0
    confidence: float = 0.0
    verified: bool = False
    features: tuple[float, ...] = ()
    source: str = "autonomous"
    created_at: float = field(default_factory=time.time)
    experience_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    metadata: dict[str, Any] = field(default_factory=dict)
    def __post_init__(self) -> None:
        if not self.game_id or not self.state_id or not self.action or not self.next_state_id: raise ValueError("game_id, states and action are required")
        object.__setattr__(self, "outcome", Outcome(self.outcome))
        if not math.isfinite(float(self.reward)): raise ValueError("reward must be finite")
        if not math.isfinite(float(self.confidence)) or not 0 <= self.confidence <= 1: raise ValueError("confidence must be in [0,1]")
        if any(not math.isfinite(float(v)) for v in self.features): raise ValueError("features must be finite")
