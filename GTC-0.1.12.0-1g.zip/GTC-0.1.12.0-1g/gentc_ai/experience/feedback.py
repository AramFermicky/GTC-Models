"""Reward labels prioritise confirmed outcomes and keep unknown/no-op neutral."""
from __future__ import annotations
from dataclasses import dataclass
from .contracts import Outcome

@dataclass(frozen=True)
class FeedbackAssessment:
    reward: float
    learn: bool
    category: str
    reason: str

_REWARDS = {Outcome.GOAL_COMPLETED: 1.0, Outcome.PROGRESS: 0.45, Outcome.DODGE: 0.2,
            Outcome.BLOCKED: -0.35, Outcome.MISSED_ATTACK: -0.35, Outcome.DAMAGE: -0.65,
            Outcome.ITEM_MISUSE: -0.8, Outcome.DEATH: -1.0, Outcome.NEUTRAL: 0.0}

def assess_outcome(outcome: Outcome | str, *, verified: bool, confidence: float = 1.0) -> FeedbackAssessment:
    label = Outcome(outcome); certainty = max(0.0, min(1.0, float(confidence)))
    if not verified:
        return FeedbackAssessment(0.0, False, "unverified", "Unverified visual heuristics are not treated as ground truth")
    if label == Outcome.NEUTRAL:
        return FeedbackAssessment(0.0, False, "neutral", "No meaningful outcome; no reward or penalty")
    reward = _REWARDS[label] * certainty
    return FeedbackAssessment(reward, certainty >= 0.35, label.value, "Verified outcome scaled by confidence")
