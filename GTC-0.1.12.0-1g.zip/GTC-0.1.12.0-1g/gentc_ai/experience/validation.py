"""Strict validation before experience is allowed into a learner."""
from __future__ import annotations
import math
from .contracts import Experience

def validate_experience(item: Experience, *, max_features: int = 4096, reward_limit: float = 10.0) -> tuple[bool, str]:
    if not isinstance(item, Experience): return False, "not_an_experience"
    if not item.experience_id or len(item.experience_id) > 128: return False, "invalid_experience_id"
    if len(item.features) > max_features: return False, "too_many_features"
    if not math.isfinite(item.reward) or abs(item.reward) > reward_limit: return False, "reward_out_of_range"
    if not 0 <= item.confidence <= 1: return False, "confidence_out_of_range"
    if item.reward != 0 and not item.verified: return False, "unverified_nonzero_reward"
    if item.outcome.value == "neutral" and (item.reward != 0 or item.verified and item.metadata.get("neutral_is_penalty")):
        return False, "neutral_outcome_must_not_be_penalized"
    return True, "valid"
