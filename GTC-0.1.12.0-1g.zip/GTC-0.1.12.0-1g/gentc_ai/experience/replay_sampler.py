"""Bounded prioritized sampling; this sampler never deletes the source history."""
from __future__ import annotations
import random
import math
from collections.abc import Sequence
from typing import TypeVar, Callable
T = TypeVar("T")

class PrioritizedReplaySampler:
    def __init__(self, *, seed: int | None = None, max_sample: int = 256) -> None:
        if max_sample < 1: raise ValueError("max_sample must be positive")
        self.max_sample = max_sample; self._rng = random.Random(seed)
    def sample(self, items: Sequence[T], *, priority: Callable[[T], float], count: int) -> list[T]:
        if count < 0: raise ValueError("count must be non-negative")
        if not items or count == 0: return []
        count = min(count, self.max_sample, len(items)); pool = list(items); result: list[T] = []
        while pool and len(result) < count:
            weights = []
            for item in pool:
                try: weight = float(priority(item))
                except (TypeError, ValueError, OverflowError): weight = 0.0
                weights.append(max(0.001, weight) if math.isfinite(weight) else 0.001)
            selected = self._rng.choices(range(len(pool)), weights=weights, k=1)[0]
            result.append(pool.pop(selected))
        return result
