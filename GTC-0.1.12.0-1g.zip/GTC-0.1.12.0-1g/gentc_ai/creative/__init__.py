"""Isolated, non-executing experiment workspace for creative strategy proposals."""
from .sandbox import ArtifactSandbox
from .experiment import ExperimentSpec, run_experiment_trials
from .evaluation import Evaluation, compare_experiment
__all__ = ["ArtifactSandbox", "ExperimentSpec", "run_experiment_trials", "Evaluation", "compare_experiment"]
