"""Declarative experiments: data-only candidates, with no dynamic Python execution."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable
import math

@dataclass(frozen=True)
class ExperimentSpec:
    experiment_id: str
    strategy: str
    parameters: dict[str, Any] = field(default_factory=dict)
    def __post_init__(self) -> None:
        if not self.experiment_id or not self.strategy: raise ValueError("experiment id and strategy are required")
        if len(self.experiment_id) > 100 or len(self.strategy) > 100: raise ValueError("experiment identifiers are too long")

def run_experiment_trials(spec: ExperimentSpec, evaluator: Callable[[ExperimentSpec, int], dict[str, float]],
                          trials: int = 3) -> dict[str, Any]:
    if trials < 1 or trials > 100: raise ValueError("trials must be between 1 and 100")
    outcomes = []
    for index in range(trials):
        result = evaluator(spec, index)
        if not isinstance(result, dict): raise TypeError("evaluator must return a mapping")
        clean = {str(k): float(v) for k, v in result.items()}
        if any(not math.isfinite(v) for v in clean.values()): raise ValueError("trial metrics must be finite")
        outcomes.append(clean)
    keys = sorted({k for outcome in outcomes for k in outcome})
    means = {k: sum(outcome.get(k, 0.0) for outcome in outcomes) / trials for k in keys}
    return {"experiment_id": spec.experiment_id, "strategy": spec.strategy, "trials": trials,
            "results": outcomes, "means": means, "executed_code": False}
