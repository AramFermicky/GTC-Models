"""Filesystem-scoped artifact area; it stores proposals but never executes them."""
from __future__ import annotations
import json, os
from pathlib import Path
from typing import Any

_ALLOWED = {".json", ".md", ".txt", ".csv"}
class ArtifactSandbox:
    def __init__(self, root: str | Path, *, max_bytes: int = 1_000_000) -> None:
        self.root = Path(root).expanduser().resolve(); self.root.mkdir(parents=True, exist_ok=True)
        if max_bytes < 1: raise ValueError("max_bytes must be positive")
        self.max_bytes = max_bytes
    def _path(self, relative: str | Path) -> Path:
        raw = Path(relative)
        if raw.is_absolute() or any(part in {"..", ""} for part in raw.parts): raise ValueError("path must stay inside sandbox")
        if raw.suffix.lower() not in _ALLOWED: raise ValueError("artifact extension is not allowed")
        target = (self.root / raw).resolve()
        if target != self.root and self.root not in target.parents: raise ValueError("path escapes sandbox")
        return target
    def write_text(self, relative: str | Path, text: str) -> Path:
        if not isinstance(text, str): raise TypeError("artifact text must be a string")
        data = text.encode("utf-8")
        if len(data) > self.max_bytes: raise ValueError("artifact exceeds size limit")
        target = self._path(relative); target.parent.mkdir(parents=True, exist_ok=True)
        temp = target.with_name(target.name + ".tmp")
        try:
            with temp.open("wb") as stream:
                stream.write(data); stream.flush(); os.fsync(stream.fileno())
            os.replace(temp, target)
        finally:
            if temp.exists(): temp.unlink()
        return target
    def write_json(self, relative: str | Path, value: Any) -> Path:
        return self.write_text(relative, json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    def list_artifacts(self) -> list[str]:
        return sorted(p.relative_to(self.root).as_posix() for p in self.root.rglob("*") if p.is_file() and p.suffix.lower() in _ALLOWED)
