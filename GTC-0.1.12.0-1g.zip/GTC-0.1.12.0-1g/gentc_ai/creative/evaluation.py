"""Promote proposals only after repeated evidence beats a baseline."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any
import math

@dataclass(frozen=True)
class Evaluation:
    accepted: bool
    reason: str
    score_delta: float
    risk_delta: float
    sample_count: int

def compare_experiment(candidate: dict[str, Any], baseline: dict[str, Any], *, min_trials: int = 3,
                       min_score_gain: float = 0.05, max_risk_increase: float = 0.0) -> Evaluation:
    trials = int(candidate.get("trials", 0))
    if trials < min_trials: return Evaluation(False, "insufficient_trials", 0.0, 0.0, trials)
    cm, bm = candidate.get("means", {}), baseline.get("means", {})
    try: score_delta = float(cm["score"]) - float(bm["score"]); risk_delta = float(cm["risk"]) - float(bm["risk"])
    except (KeyError, TypeError, ValueError): return Evaluation(False, "missing_score_or_risk_metric", 0.0, 0.0, trials)
    if not math.isfinite(score_delta) or not math.isfinite(risk_delta): return Evaluation(False, "non_finite_metrics", 0.0, 0.0, trials)
    if score_delta < min_score_gain: return Evaluation(False, "score_gain_below_threshold", score_delta, risk_delta, trials)
    if risk_delta > max_risk_increase + 1e-9: return Evaluation(False, "risk_increased_too_much", score_delta, risk_delta, trials)
    return Evaluation(True, "validated_by_repeated_trials", score_delta, risk_delta, trials)
