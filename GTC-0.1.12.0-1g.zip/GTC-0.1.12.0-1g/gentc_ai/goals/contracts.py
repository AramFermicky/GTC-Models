"""Explicit goals with measurable progress and completion state."""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any
import time

class GoalStatus(str, Enum):
    ACTIVE = "active"; PAUSED = "paused"; COMPLETED = "completed"; FAILED = "failed"

@dataclass
class Goal:
    goal_id: str
    description: str
    priority: float = 0.5
    status: GoalStatus = GoalStatus.ACTIVE
    progress: float = 0.0
    created_at: float = field(default_factory=time.time)
    metadata: dict[str, Any] = field(default_factory=dict)
    def __post_init__(self) -> None:
        if not self.goal_id or not self.description: raise ValueError("goal_id and description are required")
        if not 0 <= self.priority <= 1 or not 0 <= self.progress <= 1: raise ValueError("priority and progress must be in [0,1]")
        self.status = GoalStatus(self.status)
