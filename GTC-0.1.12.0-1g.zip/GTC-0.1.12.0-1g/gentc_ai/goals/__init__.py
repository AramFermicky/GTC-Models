"""Priority-based goal tracking independent of any single game engine."""
from .contracts import Goal, GoalStatus
from .manager import GoalManager
from .planner import PlanCandidate, rank_candidates
__all__ = ["Goal", "GoalStatus", "GoalManager", "PlanCandidate", "rank_candidates"]
