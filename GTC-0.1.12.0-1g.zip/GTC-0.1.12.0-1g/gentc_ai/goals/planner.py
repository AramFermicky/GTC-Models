"""Deterministic candidate ranking with explicit risk and uncertainty penalties."""
from __future__ import annotations
from dataclasses import dataclass
import math
from typing import Iterable

@dataclass(frozen=True)
class PlanCandidate:
    action: str
    goal_progress: float = 0.0
    information_gain: float = 0.0
    risk: float = 0.0
    cost: float = 0.0
    confidence: float = 1.0
    def __post_init__(self) -> None:
        if not self.action: raise ValueError("action is required")
        for name in ("goal_progress", "information_gain", "risk", "confidence"):
            value = float(getattr(self, name))
            if not math.isfinite(value) or not 0 <= value <= 1: raise ValueError(f"{name} must be finite and in [0,1]")
        if not math.isfinite(float(self.cost)) or self.cost < 0: raise ValueError("cost must be finite and non-negative")

def rank_candidates(candidates: Iterable[PlanCandidate], *, risk_weight: float = 1.0,
                    uncertainty_weight: float = 0.25, information_weight: float = 0.2) -> list[tuple[PlanCandidate, float]]:
    values = list(candidates)
    def score(item: PlanCandidate) -> float:
        uncertainty = 1.0 - item.confidence
        return item.goal_progress + information_weight * item.information_gain - risk_weight * item.risk - item.cost - uncertainty_weight * uncertainty
    return sorted(((item, score(item)) for item in values), key=lambda pair: (-pair[1], pair[0].action))
