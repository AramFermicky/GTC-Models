"""Thread-safe goal stack that preserves history of completed/failed goals."""
from __future__ import annotations
import threading
from .contracts import Goal, GoalStatus

class GoalManager:
    def __init__(self) -> None: self._lock = threading.RLock(); self._goals: dict[str, Goal] = {}
    def add(self, goal: Goal) -> None:
        with self._lock:
            existing = self._goals.get(goal.goal_id)
            if existing and existing.description != goal.description: raise ValueError("goal id collision")
            self._goals.setdefault(goal.goal_id, goal)
    def update_progress(self, goal_id: str, progress: float) -> Goal:
        if not 0 <= float(progress) <= 1: raise ValueError("progress must be in [0,1]")
        with self._lock:
            goal = self._goals[goal_id]; goal.progress = max(goal.progress, float(progress))
            if goal.progress >= 1.0: goal.status = GoalStatus.COMPLETED
            return goal
    def set_status(self, goal_id: str, status: GoalStatus) -> Goal:
        with self._lock: self._goals[goal_id].status = GoalStatus(status); return self._goals[goal_id]
    def current(self) -> Goal | None:
        with self._lock:
            active = [g for g in self._goals.values() if g.status == GoalStatus.ACTIVE]
            return max(active, key=lambda g: (g.priority, g.progress, -g.created_at), default=None)
    def snapshot(self) -> list[dict[str, object]]:
        with self._lock:
            return [{"goal_id": g.goal_id, "description": g.description, "priority": g.priority,
                     "status": g.status.value, "progress": g.progress, "metadata": dict(g.metadata)}
                    for g in sorted(self._goals.values(), key=lambda x: (-x.priority, x.goal_id))]
