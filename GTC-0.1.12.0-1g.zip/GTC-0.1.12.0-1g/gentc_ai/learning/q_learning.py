"""Small tabular Q-learning agent using only Python's standard library."""
from __future__ import annotations

import random
from typing import Iterable


class QLearningAgent:
    def __init__(self, actions: Iterable[str], alpha: float = 0.18, gamma: float = 0.92, seed: int = 13):
        self.actions = list(actions)
        if not self.actions:
            raise ValueError("Нужен минимум один action.")
        if not 0.0 < alpha <= 1.0:
            raise ValueError("alpha должен находиться в диапазоне (0, 1].")
        if not 0.0 <= gamma <= 1.0:
            raise ValueError("gamma должен находиться в диапазоне [0, 1].")
        self.alpha = alpha
        self.gamma = gamma
        self.q_table: dict[str, dict[str, float]] = {}
        self.random = random.Random(seed)

    def values_for(self, state_key: str) -> dict[str, float]:
        if state_key not in self.q_table:
            self.q_table[state_key] = {action: 0.0 for action in self.actions}
        return self.q_table[state_key]

    def choose_action(self, state_key: str, epsilon: float, fallback_action: str | None = None) -> str:
        """Epsilon-greedy choice; fallback protects cold/unseen states at inference."""
        epsilon = max(0.0, min(1.0, float(epsilon)))
        if self.random.random() < epsilon:
            return self.random.choice(self.actions)
        values = self.values_for(state_key)
        low, high = min(values.values()), max(values.values())
        if fallback_action in self.actions and abs(high - low) < 1e-12:
            return str(fallback_action)
        best_value = high
        best = [action for action, value in values.items() if abs(value - best_value) < 1e-12]
        return self.random.choice(best)

    def update(
        self,
        state_key: str,
        action: str,
        reward: float,
        next_state_key: str,
        terminal: bool,
        available_next_actions: Iterable[str] | None = None,
    ) -> None:
        """One-step Q-learning update; optionally restrict bootstrap to legal next actions."""
        if action not in self.actions:
            raise ValueError(f"Неизвестное действие: {action}")
        if not isinstance(reward, (int, float)):
            raise TypeError("reward должен быть числом.")
        current = self.values_for(state_key)
        old_value = current[action]
        if terminal:
            future = 0.0
        else:
            next_values = self.values_for(next_state_key)
            if available_next_actions is None:
                legal_values = list(next_values.values())
            else:
                legal_names = [str(name) for name in available_next_actions if str(name) in self.actions]
                legal_values = [next_values[name] for name in legal_names]
            future = max(legal_values) if legal_values else 0.0
        target = max(-2.0, min(2.0, float(reward) + self.gamma * future))
        current[action] = max(-2.0, min(2.0, old_value + self.alpha * (target - old_value)))
