"""Verified-outcome learning for GenTC AI 0.1.8.

This is a transparent tabular learner over adapter-defined semantic actions, not
neural-network training. Unverified claims and unexecuted plans are never learned.
"""
from __future__ import annotations

import json
import math
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


_FAILURE_LESSONS = {
    "precondition_missing": "Перед повтором обнови снимок мира и проверь предусловия.",
    "target_not_found": "Объект мог исчезнуть или быть вне доступа; найди актуальную цель заново.",
    "rejected_by_adapter": "Не повторяй команду вслепую; выясни причину отказа адаптера.",
    "goal_not_reached": "Проверь промежуточный результат и сравни альтернативный план.",
    "unintended_harm": "Остановись, пересмотри последствия для затронутых сущностей и снизь риск.",
    "timeout": "Разбей действие на меньшие шаги или проверь, не зависло ли игровое состояние.",
}


def _clamp(value: Any, low: float = -1.0, high: float = 1.0, default: float = 0.0) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        result = default
    if not math.isfinite(result):
        result = default
    return max(low, min(high, result))


def _tags(situation: dict[str, Any]) -> list[str]:
    value = situation.get("context_tags", [])
    if not isinstance(value, list):
        return []
    return sorted({str(item) for item in value if str(item).strip()})[:32]


class ReflectiveLearner:
    """Learns expected outcomes for semantic action/context pairs from verified results."""

    SCHEMA_VERSION = 1

    def __init__(self, data_dir: Path | str, learning_rate: float = 0.20):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.policy_path = self.data_dir / "reflective_policy.json"
        self.log_path = self.data_dir / "reflection_log.jsonl"
        try:
            parsed_rate = float(learning_rate)
        except (TypeError, ValueError, OverflowError):
            parsed_rate = 0.20
        if not math.isfinite(parsed_rate):
            parsed_rate = 0.20
        self.learning_rate = max(0.01, min(1.0, parsed_rate))
        self.load_warning: str | None = None
        if self.policy_path.exists():
            try:
                raw = json.loads(self.policy_path.read_text(encoding="utf-8"))
                if not isinstance(raw, dict) or raw.get("schema_version") != self.SCHEMA_VERSION:
                    self.load_warning = "policy_schema_invalid_reset_in_memory"
                    self.data = self._empty()
                else:
                    self.data = raw
            except (OSError, UnicodeDecodeError, json.JSONDecodeError):
                # Keep the damaged file untouched for diagnosis; use a clean in-memory policy.
                self.load_warning = "policy_file_unreadable_reset_in_memory"
                self.data = self._empty()
        else:
            self.data = self._empty()
        if not isinstance(self.data.get("policies"), dict):
            self.data["policies"] = {}
            self.load_warning = self.load_warning or "policy_collection_invalid_reset_in_memory"
        if not isinstance(self.data.get("lessons"), list):
            self.data["lessons"] = []
            self.load_warning = self.load_warning or "lesson_collection_invalid_reset_in_memory"
        valid_lessons = [item for item in self.data["lessons"] if isinstance(item, dict)]
        if len(valid_lessons) != len(self.data["lessons"]):
            self.load_warning = self.load_warning or "invalid_lesson_records_filtered"
        self.data["lessons"] = valid_lessons
        valid_policies = {
            str(key): value for key, value in self.data["policies"].items() if isinstance(value, dict)
        }
        if len(valid_policies) != len(self.data["policies"]):
            self.load_warning = self.load_warning or "invalid_policy_records_filtered"
        self.data["policies"] = valid_policies

    @staticmethod
    def _empty() -> dict[str, Any]:
        return {"schema_version": 1, "updated_at_utc": None, "policies": {}, "lessons": []}

    @staticmethod
    def _key(semantic_action: str, tags: list[str]) -> str:
        return f"{semantic_action}::{','.join(tags) if tags else '__global__'}"

    @staticmethod
    def _calculate_reward(outcome: dict[str, Any]) -> tuple[float, dict[str, float]]:
        """Compute a bounded reward from observed game facts, not a free-form model score."""
        components: dict[str, float] = {}
        if outcome.get("goal_achieved") is True:
            components["goal"] = 0.70
        elif outcome.get("goal_achieved") is False:
            components["goal"] = -0.40
        elif isinstance(outcome.get("goal_progress"), (int, float)):
            components["goal_progress"] = 0.50 * _clamp(outcome["goal_progress"])
        else:
            components["goal"] = 0.0

        if outcome.get("constraints_respected") is False:
            components["constraint_violation"] = -0.80
        else:
            components["constraint_violation"] = 0.0

        harm = max(0.0, min(1.0, _clamp(outcome.get("observed_harm", 0.0), 0.0, 1.0)))
        components["observed_harm"] = -0.75 * harm
        cost = max(0.0, min(1.0, _clamp(outcome.get("unexpected_cost", 0.0), 0.0, 1.0)))
        components["unexpected_cost"] = -0.20 * cost

        reason = str(outcome.get("failure_reason", ""))
        if reason in {"precondition_missing", "target_not_found", "rejected_by_adapter"}:
            components["recoverable_failure"] = -0.15
        elif reason in {"goal_not_reached", "timeout"}:
            components["recoverable_failure"] = -0.25
        elif reason == "unintended_harm":
            components["recoverable_failure"] = -0.35
        reward = max(-1.0, min(1.0, sum(components.values())))
        return round(reward, 6), {key: round(value, 6) for key, value in components.items()}

    @staticmethod
    def _lesson_for(reason: str) -> str | None:
        return _FAILURE_LESSONS.get(reason)

    def record(self, situation: dict[str, Any], action: dict[str, Any], outcome: dict[str, Any]) -> dict[str, Any]:
        """Record one confirmed outcome. Returns ignored=True if the game has not verified it."""
        if not isinstance(situation, dict) or not isinstance(action, dict) or not isinstance(outcome, dict):
            raise ValueError("situation, action и outcome должны быть объектами.")
        if outcome.get("verified") is not True or outcome.get("execution_confirmed") is not True:
            return {"stored": False, "ignored": True, "reason": "outcome_not_verified_and_executed"}
        semantic = str(action.get("semantic_action", "unknown")).strip()
        if not semantic or semantic == "unknown":
            return {"stored": False, "ignored": True, "reason": "semantic_action_required"}
        if len(semantic) > 100:
            return {"stored": False, "ignored": True, "reason": "semantic_action_too_long"}

        reward, reward_components = self._calculate_reward(outcome)
        context_tags = _tags(situation)
        now = datetime.now(timezone.utc).isoformat()
        reason = str(outcome.get("failure_reason", ""))
        if outcome.get("constraints_respected") is False or not harm_is_low(outcome):
            reason = reason or "unintended_harm"
        elif outcome.get("goal_achieved") is not True and not reason:
            reason = "goal_not_reached"
        keys = [self._key(semantic, context_tags)]
        if context_tags:
            keys.append(self._key(semantic, []))
        for key in dict.fromkeys(keys):
            policies = self.data["policies"]
            stats = policies.setdefault(key, {
                "semantic_action": semantic,
                "context_tags": context_tags if key == keys[0] else [],
                "count": 0,
                "successes": 0,
                "failures": 0,
                "mean_reward": 0.0,
                "ema_reward": 0.0,
                "failure_reasons": {},
                "last_updated_utc": None,
            })
            count_before = int(stats.get("count", 0))
            old_mean = float(stats.get("mean_reward", 0.0))
            stats["count"] = count_before + 1
            stats["mean_reward"] = round(old_mean + (reward - old_mean) / stats["count"], 6)
            old_ema = float(stats.get("ema_reward", 0.0))
            stats["ema_reward"] = round(old_ema + self.learning_rate * (reward - old_ema), 6)
            success = outcome.get("goal_achieved") is True and outcome.get("constraints_respected", True) is True and harm_is_low(outcome)
            stats["successes"] = int(stats.get("successes", 0)) + int(success)
            stats["failures"] = int(stats.get("failures", 0)) + int(not success)
            stats["last_updated_utc"] = now
            if reason:
                reasons = stats.setdefault("failure_reasons", {})
                reasons[reason] = int(reasons.get(reason, 0)) + 1

        lesson_text = self._lesson_for(reason)
        lesson = None
        failed_or_harmful = not (
            outcome.get("goal_achieved") is True
            and outcome.get("constraints_respected", True) is True
            and harm_is_low(outcome)
        )
        if failed_or_harmful and lesson_text:
            lesson = {
                "semantic_action": semantic,
                "context_tags": context_tags,
                "failure_reason": reason,
                "guidance": lesson_text,
                "count": 1,
                "last_updated_utc": now,
            }
            match = next((item for item in self.data["lessons"]
                          if item.get("semantic_action") == semantic
                          and item.get("context_tags") == context_tags
                          and item.get("failure_reason") == reason), None)
            if match:
                match["count"] = int(match.get("count", 1)) + 1
                match["last_updated_utc"] = now
                lesson = match
            else:
                self.data["lessons"].append(lesson)

        self.data["updated_at_utc"] = now
        self._save()
        # Keep the log minimal: no raw dialogue and no full game snapshot.
        log_record = {
            "timestamp_utc": now,
            "semantic_action": semantic,
            "context_tags": context_tags,
            "reward": reward,
            "reward_components": reward_components,
            "goal_achieved": outcome.get("goal_achieved"),
            "failure_reason": reason or None,
            "verified": True,
            "execution_confirmed": True,
        }
        log_written = True
        log_error = None
        try:
            with self.log_path.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(log_record, ensure_ascii=False, allow_nan=False) + "\n")
        except OSError as exc:
            # Policy is already atomically persisted; report the secondary log failure
            # instead of pretending that the whole learning event vanished.
            log_written = False
            log_error = type(exc).__name__
        estimate = self.estimate(semantic, context_tags)
        return {"stored": True, "ignored": False, "reward": reward,
                "reward_components": reward_components, "lesson": lesson, "estimate": estimate,
                "log_written": log_written, "log_error": log_error}

    def estimate(self, semantic_action: str, context_tags: list[str] | None = None) -> dict[str, Any]:
        tags = sorted({str(tag) for tag in (context_tags or []) if str(tag).strip()})
        key = self._key(str(semantic_action), tags)
        stats = self.data["policies"].get(key)
        if not stats and tags:
            stats = self.data["policies"].get(self._key(str(semantic_action), []))
        if not stats:
            return {"semantic_action": str(semantic_action), "count": 0, "mean_reward": 0.0,
                    "confidence": 0.0, "success_rate": 0.0, "lessons": []}
        count = int(stats.get("count", 0))
        lessons = [item for item in self.data["lessons"]
                   if item.get("semantic_action") == semantic_action
                   and (not item.get("context_tags") or item.get("context_tags") == tags)]
        return {
            "semantic_action": str(semantic_action),
            "count": count,
            "mean_reward": float(stats.get("mean_reward", 0.0)),
            "ema_reward": float(stats.get("ema_reward", 0.0)),
            "confidence": round(count / (count + 3.0), 4),
            "success_rate": round(int(stats.get("successes", 0)) / max(1, count), 4),
            "failure_reasons": dict(stats.get("failure_reasons", {})),
            "lessons": list(lessons),
        }

    def _save(self) -> None:
        """Atomically replace the policy file so interruption cannot leave partial JSON."""
        payload = json.dumps(self.data, ensure_ascii=False, indent=2, allow_nan=False)
        temporary_path: Path | None = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="w", encoding="utf-8", newline="\n", dir=self.data_dir,
                prefix=".reflective_policy_", suffix=".tmp", delete=False,
            ) as stream:
                temporary_path = Path(stream.name)
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            temporary_path.replace(self.policy_path)
        except OSError as exc:
            if temporary_path is not None:
                try:
                    temporary_path.unlink(missing_ok=True)
                except OSError:
                    pass
            raise RuntimeError(f"Не удалось безопасно сохранить политику обучения ({type(exc).__name__}).") from exc


def harm_is_low(outcome: dict[str, Any]) -> bool:
    try:
        return float(outcome.get("observed_harm", 0.0)) <= 0.10
    except (TypeError, ValueError):
        return False
