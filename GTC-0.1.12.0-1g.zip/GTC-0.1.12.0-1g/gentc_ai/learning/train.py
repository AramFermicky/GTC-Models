"""Train and evaluate the experimental table policy in a synthetic environment.

The trainer compares the learned policy with a transparent rule-based baseline.
It never consumes real game/dialogue data implicitly and never auto-promotes a
policy for deployment. A real game adapter and verified outcome labels are needed
before any policy is trained from live game experience.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from .environment import ACTIONS, TreeRequestEnv
from .q_learning import QLearningAgent
from gentc_ai.continuity.paths import get_model_learning_dir

PROJECT_ROOT = Path(__file__).resolve().parents[2]
OUTPUT_DIR = get_model_learning_dir("experiments", "synthetic_training")
MAX_STEPS_PER_EPISODE = 12


def heuristic_action(state: dict[str, Any]) -> str:
    """Safe baseline: choose an action matching verified synthetic preconditions."""
    if state.get("busy"):
        return "wait"
    if not state.get("willing"):
        return "decline"
    if int(state.get("trees_remaining", 0)) <= 0:
        return "report_no_trees"
    if not state.get("has_axe"):
        return "take_axe" if state.get("axe_nearby") else "ask_for_axe"
    if int(state.get("trees_remaining", 0)) < int(state.get("target_remaining", 1)):
        return "report_insufficient_trees"
    return "chop_trees"


def _task_is_feasible(initial: dict[str, Any]) -> bool:
    return bool(
        initial.get("willing")
        and int(initial.get("trees_remaining", 0)) >= int(initial.get("target_remaining", 1))
        and (initial.get("has_axe") or initial.get("axe_nearby"))
    )


def _evaluate(
    policy: Callable[[dict[str, Any]], str],
    *,
    episodes: int = 1000,
    seed: int = 10013,
) -> dict[str, Any]:
    env = TreeRequestEnv(seed=seed)
    appropriate_episodes = 0
    task_successes = 0
    feasible_episodes = 0
    feasible_successes = 0
    total_reward = 0.0
    total_steps = 0
    invalid_actions = 0
    episode_lengths: list[int] = []
    for _ in range(episodes):
        initial_state = env.reset()
        feasible = _task_is_feasible(initial_state)
        if feasible:
            feasible_episodes += 1
        done = False
        episode_ok = True
        last_info: dict[str, Any] = {}
        episode_reward = 0.0
        steps = 0
        for _step in range(MAX_STEPS_PER_EPISODE):
            action = policy(dict(env.state))
            next_state, reward, done, last_info = env.step(action)
            episode_reward += reward
            steps += 1
            if not last_info.get("appropriate_action", False):
                episode_ok = False
                invalid_actions += 1
            if done:
                break
        total_reward += episode_reward
        total_steps += steps
        episode_lengths.append(steps)
        if done and episode_ok and last_info.get("appropriate_action", False):
            appropriate_episodes += 1
        if done and last_info.get("task_success", False):
            task_successes += 1
            if feasible:
                feasible_successes += 1
    return {
        "episodes": episodes,
        "appropriate_terminal_rate": round(appropriate_episodes / max(1, episodes), 4),
        "task_completion_rate_all_scenarios": round(task_successes / max(1, episodes), 4),
        "feasible_initial_scenarios": feasible_episodes,
        "task_completion_rate_when_feasible": round(feasible_successes / max(1, feasible_episodes), 4),
        "invalid_action_count": invalid_actions,
        "invalid_actions_per_100_episodes": round(100 * invalid_actions / max(1, episodes), 3),
        "mean_reward": round(total_reward / max(1, episodes), 4),
        "mean_steps_per_episode": round(total_steps / max(1, episodes), 3),
        "max_steps_per_episode": MAX_STEPS_PER_EPISODE,
    }


def train(episodes: int = 12000, seed: int = 13, output_dir: Path | None = None) -> dict[str, Any]:
    if episodes < 100:
        raise ValueError("Для осмысленного пробного запуска укажите не менее 100 эпизодов.")
    output = output_dir or OUTPUT_DIR
    output.mkdir(parents=True, exist_ok=True)
    env = TreeRequestEnv(seed=seed)
    agent = QLearningAgent(ACTIONS, seed=seed)
    epsilon_start, epsilon_min = 0.35, 0.03
    scores: list[float] = []
    appropriate_episodes = 0
    successful_tasks = 0
    total_steps = 0
    invalid_training_actions = 0
    initial_feasible = 0
    feasible_training_successes = 0

    for episode in range(episodes):
        state = env.reset()
        if _task_is_feasible(state):
            initial_feasible += 1
        done = False
        epsilon = max(epsilon_min, epsilon_start * (1.0 - episode / episodes))
        episode_score = 0.0
        episode_appropriate = True
        last_info: dict[str, Any] = {}
        episode_feasible = _task_is_feasible(state)
        for _step in range(MAX_STEPS_PER_EPISODE):
            state_key = env.key(state)
            action = agent.choose_action(state_key, epsilon)
            next_state, reward, done, info = env.step(action)
            next_key = env.key(next_state)
            agent.update(state_key, action, reward, next_key, done)
            episode_score += reward
            total_steps += 1
            if not info["appropriate_action"]:
                episode_appropriate = False
                invalid_training_actions += 1
            state = next_state
            last_info = info
            if done:
                break
        if done and episode_appropriate and last_info.get("appropriate_action", False):
            appropriate_episodes += 1
        if done and last_info.get("task_success", False):
            successful_tasks += 1
            if episode_feasible:
                feasible_training_successes += 1
        scores.append(episode_score)

    eval_episodes = max(1000, min(5000, episodes // 2))
    eval_seed = seed + 10000
    baseline_report = _evaluate(lambda state: heuristic_action(state), episodes=eval_episodes, seed=eval_seed)

    def learned_policy(state: dict[str, Any]) -> str:
        return agent.choose_action(env.key(state), epsilon=0.0, fallback_action=heuristic_action(state))

    learned_report = _evaluate(learned_policy, episodes=eval_episodes, seed=eval_seed)
    tail = scores[max(0, len(scores) - max(1, episodes // 10)):]
    trained_at = datetime.now(timezone.utc).isoformat()
    q_table_path = output / "q_table.json"
    q_data = {
        "schema_version": 2,
        "model_name": "GenTC-Q-Table-0.1-experimental",
        "trained_at_utc": trained_at,
        "episodes": episodes,
        "random_seed": seed,
        "environment": "synthetic_tree_request_v0",
        "actions": ACTIONS,
        "q_table": agent.q_table,
        "safety_note": "Experimental only. Use rule-based preconditions and game-adapter validation at runtime; never execute model output without validation.",
    }
    q_table_path.write_text(json.dumps(q_data, ensure_ascii=False, indent=2), encoding="utf-8")
    learned_feasible = learned_report["task_completion_rate_when_feasible"]
    baseline_feasible = baseline_report["task_completion_rate_when_feasible"]
    report = {
        "schema_version": 2,
        "model_name": q_data["model_name"],
        "trained_at_utc": trained_at,
        "episodes": episodes,
        "random_seed": seed,
        "environment": "synthetic_tree_request_v0",
        "state_count": len(agent.q_table),
        "total_steps": total_steps,
        "training_appropriate_terminal_rate": round(appropriate_episodes / episodes, 4),
        "training_task_completion_rate_all_scenarios": round(successful_tasks / episodes, 4),
        "training_feasible_scenarios": initial_feasible,
        "training_task_completion_rate_when_feasible": round(feasible_training_successes / max(1, initial_feasible), 4),
        "training_invalid_action_count": invalid_training_actions,
        "mean_reward_last_10_percent": round(sum(tail) / max(1, len(tail)), 4),
        "evaluation": {
            "seed": eval_seed,
            "rule_based_baseline": baseline_report,
            "learned_policy_with_cold_state_fallback": learned_report,
            "learned_feasible_completion_delta_vs_baseline": round(learned_feasible - baseline_feasible, 4),
            "learned_policy_beats_baseline_on_feasible_completion": learned_feasible > baseline_feasible,
        },
        "runtime_policy": "Keep deterministic rule-based precondition checks and action allowlists; do not automatically promote this Q-table without game-specific evaluation.",
        "q_table_file": str(q_table_path.relative_to(PROJECT_ROOT)) if q_table_path.is_relative_to(PROJECT_ROOT) else str(q_table_path),
        "important_note": "Training occurs only in a synthetic sandbox, not in Godot or on player dialogue. Real-game learning requires an adapter and verified action outcomes.",
    }
    report_path = output / "training_report.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"report": report, "q_table_path": q_table_path, "report_path": report_path}


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser(description="Train the experimental GenTC AI 0.1 table policy.")
    parser.add_argument("--episodes", type=int, default=12000)
    parser.add_argument("--seed", type=int, default=13)
    args = parser.parse_args()
    result = train(episodes=args.episodes, seed=args.seed)
    print("\nGenTC AI 0.1 — тренировочный цикл завершён")
    print(json.dumps(result["report"], ensure_ascii=False, indent=2))
    print(f"\nQ-table: {result['q_table_path']}")
    print(f"Отчёт:   {result['report_path']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
