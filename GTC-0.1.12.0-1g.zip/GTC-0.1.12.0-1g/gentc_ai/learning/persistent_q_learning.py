"""Persistent, bounded Q-learning for GTC's adapter-grounded game actions.

Exact Q values are scoped by game/world and a compact discretized state. The
semantic prior is shared across games only at low weight (e.g. exploration or
rest), so a success in one game never implies that an unrelated command is legal
in another game. Only verified execution feedback should call update().
"""
from __future__ import annotations

import json
import math
import os
import tempfile
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from gentc_ai.learning.q_learning import QLearningAgent

DEFAULT_ACTIONS = (
    "wander", "approach_player", "forage", "rest", "inspect",
    "return_to_shelter", "avoid_player", "socialize", "observe",
)
SEMANTIC_BY_ACTION = {
    "wander": "exploration", "approach_player": "social_interaction",
    "forage": "resource_gathering", "rest": "rest", "inspect": "exploration",
    "return_to_shelter": "defend", "avoid_player": "defend",
    "socialize": "social_interaction", "observe": "observe",
}


def _finite(value: Any, default: float = 0.0) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        return default
    return result if math.isfinite(result) else default


def _bin(value: Any, thresholds: tuple[float, float] = (0.33, 0.67)) -> int:
    x = max(0.0, min(1.0, _finite(value)))
    return 0 if x < thresholds[0] else (1 if x < thresholds[1] else 2)


class PersistentQPolicy:
    SCHEMA_VERSION = 1
    MAX_STATES = 12000
    MAX_PRIORS = 128

    def __init__(self, path: Path | str, actions: Iterable[str] = DEFAULT_ACTIONS,
                 alpha: float = 0.20, gamma: float = 0.84):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.actions = tuple(dict.fromkeys(str(a) for a in actions))
        if not self.actions:
            raise ValueError("At least one action is required")
        self.agent = QLearningAgent(self.actions, alpha=alpha, gamma=gamma, seed=19023)
        self.stats: dict[str, dict[str, dict[str, Any]]] = {}
        self.semantic_priors: dict[str, dict[str, Any]] = {}
        self.failure_streaks: dict[str, int] = {}
        self.transitions = 0
        self.load_warning: str | None = None
        self._lock = threading.RLock()
        self._load()

    @staticmethod
    def state_key(world: dict[str, Any]) -> str:
        needs = world.get("needs", {}) if isinstance(world.get("needs"), dict) else {}
        terrain = world.get("terrain", {}) if isinstance(world.get("terrain"), dict) else {}
        player_distance = max(0.0, _finite(world.get("player_distance", 99.0), 99.0))
        player_near = 0 if player_distance < 2.5 else (1 if player_distance < 7.0 else 2)
        cold = _bin(world.get("coldness", 0.0))
        terrain_known = 1 if terrain.get("terrain_collision") is True else 0
        objects = world.get("objects", []) if isinstance(world.get("objects"), list) else []
        available_types = {str(o.get("type", "")) for o in objects if isinstance(o, dict) and o.get("available", True)}
        shelter_distance_bin = 2
        position = world.get("position", {}) if isinstance(world.get("position"), dict) else {}
        shelter = next((o for o in objects if isinstance(o, dict) and o.get("type") == "shelter" and o.get("available", True)), None)
        if shelter is not None:
            dx = _finite(shelter.get("x")) - _finite(position.get("x"))
            dz = _finite(shelter.get("z")) - _finite(position.get("z"))
            shelter_distance = math.sqrt(dx * dx + dz * dz)
            shelter_distance_bin = 0 if shelter_distance < 5.0 else (1 if shelter_distance < 15.0 else 2)
        parts = [
            f"food{_bin(needs.get('food', 0.2))}", f"rest{_bin(needs.get('rest', 0.2))}",
            f"social{_bin(needs.get('social', 0.2))}", f"safety{_bin(needs.get('safety', 0.2))}",
            f"curiosity{_bin(needs.get('curiosity', 0.5))}", f"cold{cold}", f"player{player_near}",
            f"shelter{shelter_distance_bin}", f"foodsrc{int('food' in available_types)}",
            f"tree{int('tree' in available_types)}", f"ground{terrain_known}",
        ]
        game_id = str(world.get("game_id", "unknown"))[:64]
        world_id = str(world.get("world_id", "unknown"))[:96]
        return f"{game_id}|{world_id}|" + ":".join(parts)

    def adjustment(self, world: dict[str, Any], action: str, semantic_action: str | None = None) -> float:
        """Return a conservative score bonus in [-0.13, 0.13] for the action ranker."""
        if action not in self.actions:
            return 0.0
        semantic = str(semantic_action or SEMANTIC_BY_ACTION.get(action, "unknown"))
        key = self.state_key(world)
        with self._lock:
            row = self.agent.q_table.get(key, {})
            state_actions = self.stats.get(key, {})
            state_stats = state_actions.get(action, {})
            q_value = max(-2.0, min(2.0, _finite(row.get(action, 0.0)))) / 2.0
            exact_count = max(0, int(state_stats.get("count", 0)))
            exact_conf = exact_count / (exact_count + 4.0)
            state_visits = sum(max(0, int(v.get("count", 0))) for v in state_actions.values() if isinstance(v, dict))
            # UCB-like exploration bonus: actions not yet tested in this situation
            # receive a small temporary boost, which naturally shrinks as evidence grows.
            exploration = math.sqrt(math.log(state_visits + 2.0) / (exact_count + 1.0))
            exploration = max(0.0, min(1.0, exploration / 1.35))
            prior = self.semantic_priors.get(semantic, {})
            prior_count = max(0, int(prior.get("count", 0)))
            prior_mean = max(-1.0, min(1.0, _finite(prior.get("mean_reward", 0.0))))
            prior_conf = prior_count / (prior_count + 8.0)
            combined = 0.55 * q_value * exact_conf + 0.20 * prior_mean * prior_conf + 0.25 * exploration
            return round(max(-0.13, min(0.13, 0.13 * combined)), 6)

    def update(
        self, *, state_key: str, action: str, semantic_action: str, reward: float,
        next_state_key: str, next_actions: Iterable[str], game_id: str,
        success: bool, target_id: str = "", terminal: bool = False,
    ) -> dict[str, Any]:
        if action not in self.actions:
            raise ValueError(f"Unknown action: {action}")
        raw_reward = max(-1.0, min(1.0, _finite(reward)))
        game = str(game_id or "unknown")[:64]
        semantic = str(semantic_action or SEMANTIC_BY_ACTION.get(action, "unknown"))[:96]
        legal_next = [str(a) for a in next_actions if str(a) in self.actions]
        with self._lock:
            state_actions = self.stats.setdefault(state_key, {})
            record = state_actions.setdefault(action, {
                "count": 0, "successes": 0, "failures": 0, "failure_streak": 0,
                "mean_reward": 0.0, "last_reward": 0.0, "last_updated_utc": None,
            })
            streak = max(0, int(record.get("failure_streak", 0)))
            repeat_penalty = 0.0 if success else -min(0.24, 0.06 * streak)
            shaped_reward = max(-1.0, min(1.0, raw_reward + repeat_penalty))
            # Avoid bootstrapping through actions the adapter says are unavailable.
            self.agent.update(state_key, action, shaped_reward, next_state_key,
                              terminal or not legal_next, available_next_actions=legal_next)
            count = int(record.get("count", 0)) + 1
            old_mean = _finite(record.get("mean_reward", 0.0))
            record.update({
                "count": count,
                "successes": int(record.get("successes", 0)) + int(success),
                "failures": int(record.get("failures", 0)) + int(not success),
                "failure_streak": 0 if success else streak + 1,
                "mean_reward": round(old_mean + (shaped_reward - old_mean) / count, 6),
                "last_reward": round(shaped_reward, 6),
                "last_updated_utc": datetime.now(timezone.utc).isoformat(),
            })
            # Global semantic prior deliberately excludes target IDs and game-specific commands.
            prior = self.semantic_priors.setdefault(semantic, {
                "count": 0, "mean_reward": 0.0, "games": {}, "updated_at_utc": None,
            })
            pcount = int(prior.get("count", 0)) + 1
            pmean = _finite(prior.get("mean_reward", 0.0))
            prior["count"] = pcount
            prior["mean_reward"] = round(pmean + (shaped_reward - pmean) / pcount, 6)
            games = prior.setdefault("games", {})
            game_stats = games.setdefault(game, {"count": 0, "mean_reward": 0.0})
            gcount = int(game_stats.get("count", 0)) + 1
            gmean = _finite(game_stats.get("mean_reward", 0.0))
            game_stats["count"] = gcount
            game_stats["mean_reward"] = round(gmean + (shaped_reward - gmean) / gcount, 6)
            prior["updated_at_utc"] = datetime.now(timezone.utc).isoformat()
            self.transitions += 1
            self._trim()
            self._save()
            row = self.agent.q_table.get(state_key, {})
            return {
                "updated": True, "transitions": self.transitions, "q_value": round(_finite(row.get(action, 0.0)), 6),
                "reward_raw": round(raw_reward, 6), "reward_used": round(shaped_reward, 6),
                "repeat_failure_penalty": round(repeat_penalty, 6),
                "state_visits": count, "failure_streak": int(record["failure_streak"]),
                "semantic_prior_count": pcount,
            }

    def _trim(self) -> None:
        if len(self.agent.q_table) <= self.MAX_STATES:
            return
        ranked = []
        for key, acts in self.stats.items():
            newest = max((str(v.get("last_updated_utc", "")) for v in acts.values()), default="")
            ranked.append((newest, key))
        keep = {key for _, key in sorted(ranked, reverse=True)[:self.MAX_STATES]}
        self.agent.q_table = {k: v for k, v in self.agent.q_table.items() if k in keep}
        self.stats = {k: v for k, v in self.stats.items() if k in keep}
        self.failure_streaks = {k: v for k, v in self.failure_streaks.items() if k in keep}
        if len(self.semantic_priors) > self.MAX_PRIORS:
            self.semantic_priors = dict(sorted(
                self.semantic_priors.items(), key=lambda item: int(item[1].get("count", 0)), reverse=True
            )[:self.MAX_PRIORS])

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            state_count = len(self.agent.q_table)
            action_visits = sum(int(item.get("count", 0)) for row in self.stats.values() for item in row.values())
            return {
                "kind": "persistent_tabular_q_learning", "transitions": self.transitions,
                "states": state_count, "action_visits": action_visits,
                "semantic_priors": {k: {"count": int(v.get("count", 0)), "mean_reward": v.get("mean_reward", 0.0),
                                          "games": sorted(v.get("games", {}).keys())}
                                     for k, v in self.semantic_priors.items()},
                "load_warning": self.load_warning, "model_path": str(self.path),
                "alpha": self.agent.alpha, "gamma": self.agent.gamma,
            }

    def export_semantic_priors(self) -> dict[str, Any]:
        with self._lock:
            return {"schema_version": self.SCHEMA_VERSION, "updated_at_utc": datetime.now(timezone.utc).isoformat(),
                    "semantic_priors": self.semantic_priors}

    def _save(self) -> None:
        payload = {
            "schema_version": self.SCHEMA_VERSION, "alpha": self.agent.alpha, "gamma": self.agent.gamma,
            "q_table": self.agent.q_table, "stats": self.stats, "semantic_priors": self.semantic_priors,
            "failure_streaks": self.failure_streaks, "transitions": self.transitions,
            "updated_at_utc": datetime.now(timezone.utc).isoformat(),
        }
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_name(self.path.name + ".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
        os.replace(tmp, self.path)

    def _load(self) -> None:
        if not self.path.exists():
            self._save()
            return
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(raw, dict) or raw.get("schema_version") != self.SCHEMA_VERSION:
                self.load_warning = "q_policy_schema_mismatch_fresh_policy_used"
                return
            q_table = raw.get("q_table", {})
            if isinstance(q_table, dict):
                for key, values in list(q_table.items())[:self.MAX_STATES]:
                    if not isinstance(values, dict):
                        continue
                    cleaned = {a: max(-2.0, min(2.0, _finite(values.get(a, 0.0)))) for a in self.actions}
                    self.agent.q_table[str(key)] = cleaned
            stats = raw.get("stats", {})
            if isinstance(stats, dict):
                for state, actions in list(stats.items())[:self.MAX_STATES]:
                    if isinstance(actions, dict):
                        self.stats[str(state)] = {str(a): v for a, v in actions.items() if a in self.actions and isinstance(v, dict)}
            priors = raw.get("semantic_priors", {})
            if isinstance(priors, dict):
                self.semantic_priors = {str(k): v for k, v in priors.items() if isinstance(v, dict)}
            streaks = raw.get("failure_streaks", {})
            if isinstance(streaks, dict):
                self.failure_streaks = {str(k): max(0, int(v)) for k, v in streaks.items() if str(k)}
            self.transitions = max(0, int(raw.get("transitions", 0)))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError, TypeError, ValueError, OverflowError):
            self.load_warning = "q_policy_unreadable_fresh_policy_used"

