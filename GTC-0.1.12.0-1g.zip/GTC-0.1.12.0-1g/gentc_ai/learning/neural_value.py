"""Small experimental feed-forward neural value model using only the Python stdlib.

This is a first learned value estimator, not a language model or a claim of
consciousness. It is trained only from game-confirmed examples and remains out of
the decision loop until its replay buffer has sufficient coverage.
"""
from __future__ import annotations

import json
import math
import random
import uuid
from pathlib import Path
from typing import Any

_ACTIONS = ("observe", "bless", "teleport", "plague", "smite", "calm", "rain")
_INPUT_SIZE = 22  # 15 numeric world/agent/action signals + 7 action flags
_HIDDEN_SIZE = 60  # 6x wider than the 0.1.8 prototype; still a small value estimator


def _clamp(value: Any, low: float = 0.0, high: float = 1.0, default: float = 0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError):
        return default
    if not math.isfinite(number):
        return default
    return max(low, min(high, number))


def _atomic_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".{uuid.uuid4().hex}.tmp")
    try:
        temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
        temporary.replace(path)
    finally:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass


class NeuralValueModel:
    """A 22→60→1 MLP trained with bounded SGD and a conservative activation gate."""

    SCHEMA_VERSION = 2

    def __init__(self, model_path: Path | str, *, seed: int = 18021,
                 minimum_samples: int = 120, minimum_actions: int = 4):
        self.model_path = Path(model_path)
        self.minimum_samples = max(20, int(minimum_samples))
        self.minimum_actions = max(2, min(len(_ACTIONS), int(minimum_actions)))
        self.load_warning: str | None = None
        self.training_updates = 0
        self.training_samples = 0
        self.trained_action_names: list[str] = []
        self.input_size = _INPUT_SIZE
        self.hidden_size = _HIDDEN_SIZE
        rng = random.Random(seed)
        limit1 = math.sqrt(6 / (self.input_size + self.hidden_size))
        limit2 = math.sqrt(6 / (self.hidden_size + 1))
        self.w1 = [[rng.uniform(-limit1, limit1) for _ in range(self.input_size)] for _ in range(self.hidden_size)]
        self.b1 = [0.0] * self.hidden_size
        self.w2 = [rng.uniform(-limit2, limit2) for _ in range(self.hidden_size)]
        self.b2 = 0.0
        if self.model_path.exists():
            self._load()

    @staticmethod
    def features(situation: dict[str, Any], action: dict[str, Any],
                 agent_state: dict[str, Any] | None = None) -> list[float]:
        """Convert a world snapshot and candidate into a bounded numeric vector."""
        if not isinstance(situation, dict):
            situation = {}
        world = situation.get("world", situation)
        if not isinstance(world, dict):
            world = {}
        state = agent_state if isinstance(agent_state, dict) else situation.get("agent_state", {})
        if not isinstance(state, dict):
            state = {}
        personality = state.get("personality", {}) if isinstance(state.get("personality", {}), dict) else {}
        emotions = state.get("emotions", {}) if isinstance(state.get("emotions", {}), dict) else {}
        characters = world.get("characters", []) if isinstance(world.get("characters", []), list) else []
        characters = [item for item in characters if isinstance(item, dict)]
        denominator = max(1, len(characters))
        alive_ratio = sum(1 for item in characters if item.get("alive", True) is True) / denominator
        sick_ratio = sum(1 for item in characters if item.get("sick", False) is True) / denominator
        aggression = sum(_clamp(item.get("aggression", 0.2)) for item in characters) / denominator
        moods = sum(_clamp(item.get("mood", 0.5)) for item in characters) / denominator
        player = world.get("player", {}) if isinstance(world.get("player", {}), dict) else {}
        if not player:
            player = next((item for item in characters if item.get("is_player") is True or item.get("id") == "player"), {})
        player_health = _clamp(player.get("health", 100.0), 0.0, 100.0, 100.0) / 100.0
        impacts = action.get("stakeholder_impact", []) if isinstance(action.get("stakeholder_impact", []), list) else []
        harm = max((_clamp(item.get("harm", 0.0)) for item in impacts if isinstance(item, dict)), default=0.0)
        benefit = max((_clamp(item.get("benefit", 0.0)) for item in impacts if isinstance(item, dict)), default=0.0)
        vector = [
            _clamp(world.get("unrest", situation.get("unrest", 0.0))),
            _clamp(alive_ratio),
            _clamp(sick_ratio),
            _clamp(aggression),
            _clamp(player_health),
            _clamp(moods),
            _clamp(state.get("player_trust", situation.get("player_trust", 0.35))),
            _clamp(state.get("frustration_pressure", situation.get("frustration_pressure", 0.0))),
            _clamp(personality.get("benevolence", 0.5)),
            _clamp(personality.get("empathy", 0.5)),
            _clamp(personality.get("curiosity", 0.5)),
            _clamp(action.get("risk", 0.0)),
            _clamp(action.get("cost", 0.0)),
            _clamp(harm),
            _clamp(benefit),
        ]
        # The vector has 15 numeric signals plus seven action flags = 22.
        action_name = str(action.get("action", "observe"))
        vector.extend(1.0 if action_name == known else 0.0 for known in _ACTIONS)
        return vector[:_INPUT_SIZE]

    @staticmethod
    def _tanh(value: float) -> float:
        value = max(-15.0, min(15.0, value))
        return math.tanh(value)

    def _forward(self, x: list[float]) -> tuple[list[float], float]:
        hidden = [self._tanh(sum(weight * feature for weight, feature in zip(row, x)) + bias)
                  for row, bias in zip(self.w1, self.b1)]
        output = self._tanh(sum(weight * value for weight, value in zip(self.w2, hidden)) + self.b2)
        return hidden, output

    def predict(self, situation: dict[str, Any], action: dict[str, Any],
                agent_state: dict[str, Any] | None = None) -> dict[str, Any]:
        if not self.is_active:
            return {"value": 0.0, "active": False, "sample_count": self.training_samples,
                    "reason": "waiting_for_verified_coverage"}
        vector = self.features(situation, action, agent_state)
        _, value = self._forward(vector)
        if not math.isfinite(value):
            value = 0.0
        return {"value": round(max(-1.0, min(1.0, value)), 6), "active": True,
                "sample_count": self.training_samples, "reason": "trained_mlp_estimate"}

    @property
    def is_active(self) -> bool:
        return (self.training_samples >= self.minimum_samples and
                len(self.trained_action_names) >= self.minimum_actions)

    def fit(self, examples: list[dict[str, Any]], *, epochs: int = 2, learning_rate: float = 0.015) -> dict[str, Any]:
        valid: list[tuple[list[float], float, str]] = []
        for item in examples[-768:]:
            if not isinstance(item, dict):
                continue
            features = item.get("features")
            reward = item.get("reward")
            if not isinstance(features, list) or len(features) != self.input_size:
                continue
            try:
                x = [float(v) for v in features]
                y = float(reward)
            except (TypeError, ValueError, OverflowError):
                continue
            if not all(math.isfinite(v) for v in x) or not math.isfinite(y):
                continue
            valid.append(([max(-1.0, min(1.0, v)) for v in x], max(-1.0, min(1.0, y)), str(item.get("action_name", "unknown"))))
        if not valid:
            return {"trained": False, "reason": "no_valid_confirmed_examples", "samples": 0,
                    "active": self.is_active}
        epochs = max(1, min(int(epochs), 20))
        rate = max(0.0001, min(float(learning_rate), 0.05))
        losses: list[float] = []
        # Full replay batches reduce catastrophic forgetting; bounded dataset and gradient clipping
        # keep this small enough for an ordinary CPU.
        for _ in range(epochs):
            epoch_loss = 0.0
            for x, target, _name in valid:
                hidden, output = self._forward(x)
                error = output - target
                epoch_loss += 0.5 * error * error
                d_out = error * (1.0 - output * output)
                old_w2 = list(self.w2)
                grad_w2 = [d_out * h for h in hidden]
                grad_b2 = d_out
                d_hidden = [d_out * old_w2[j] * (1.0 - hidden[j] * hidden[j])
                            for j in range(self.hidden_size)]
                for j in range(self.hidden_size):
                    self.w2[j] -= rate * max(-1.0, min(1.0, grad_w2[j]))
                    for i in range(self.input_size):
                        gradient = d_hidden[j] * x[i]
                        self.w1[j][i] -= rate * max(-1.0, min(1.0, gradient))
                    self.b1[j] -= rate * max(-1.0, min(1.0, d_hidden[j]))
                self.b2 -= rate * max(-1.0, min(1.0, grad_b2))
            losses.append(epoch_loss / len(valid))
        self.training_samples = len(valid)
        self.trained_action_names = sorted({name for _, _, name in valid if name in _ACTIONS})
        self.training_updates += 1
        self._save()
        return {"trained": True, "samples": self.training_samples, "actions_covered": self.trained_action_names,
                "loss": round(losses[-1], 6), "active": self.is_active, "training_updates": self.training_updates}

    def status(self) -> dict[str, Any]:
        return {"kind": "small_feed_forward_mlp", "input_size": self.input_size,
                "hidden_size": self.hidden_size, "output_size": 1,
                "training_samples": self.training_samples,
                "actions_covered": list(self.trained_action_names),
                "training_updates": self.training_updates,
                "minimum_samples": self.minimum_samples, "minimum_actions": self.minimum_actions,
                "active_in_decision_loop": self.is_active,
                "load_warning": self.load_warning,
                "model_path": str(self.model_path)}

    def _save(self) -> None:
        _atomic_json(self.model_path, {
            "schema_version": self.SCHEMA_VERSION,
            "input_size": self.input_size,
            "hidden_size": self.hidden_size,
            "w1": self.w1, "b1": self.b1, "w2": self.w2, "b2": self.b2,
            "training_samples": self.training_samples,
            "trained_action_names": self.trained_action_names,
            "training_updates": self.training_updates,
        })

    def _load(self) -> None:
        try:
            raw = json.loads(self.model_path.read_text(encoding="utf-8"))
            if (not isinstance(raw, dict) or raw.get("schema_version") != self.SCHEMA_VERSION or
                    raw.get("input_size") != self.input_size or raw.get("hidden_size") != self.hidden_size):
                self.load_warning = "model_schema_mismatch_fresh_weights_used"
                return
            w1 = raw.get("w1")
            b1 = raw.get("b1")
            w2 = raw.get("w2")
            b2 = raw.get("b2")
            if (not isinstance(w1, list) or len(w1) != self.hidden_size or
                    any(not isinstance(row, list) or len(row) != self.input_size for row in w1) or
                    not isinstance(b1, list) or len(b1) != self.hidden_size or
                    not isinstance(w2, list) or len(w2) != self.hidden_size):
                self.load_warning = "model_shape_invalid_fresh_weights_used"
                return
            numbers = [float(v) for row in w1 for v in row] + [float(v) for v in b1] + [float(v) for v in w2] + [float(b2)]
            if not all(math.isfinite(v) for v in numbers):
                self.load_warning = "model_non_finite_weights_fresh_weights_used"
                return
            self.w1 = [[float(v) for v in row] for row in w1]
            self.b1 = [float(v) for v in b1]
            self.w2 = [float(v) for v in w2]
            self.b2 = float(b2)
            self.training_samples = max(0, int(raw.get("training_samples", 0)))
            names = raw.get("trained_action_names", [])
            self.trained_action_names = sorted({str(v) for v in names if str(v) in _ACTIONS}) if isinstance(names, list) else []
            self.training_updates = max(0, int(raw.get("training_updates", 0)))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError, TypeError, ValueError, OverflowError):
            # Do not overwrite malformed evidence automatically; keep it for diagnosis.
            self.load_warning = "model_unreadable_fresh_weights_used"
