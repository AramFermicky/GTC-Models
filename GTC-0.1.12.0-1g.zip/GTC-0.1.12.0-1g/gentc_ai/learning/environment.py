"""Synthetic training environment for the GTC 0.1 learning pipeline.

This environment is deliberately separate from Godot. It is a tiny proof of
concept and must not be mistaken for training on the real game world.
"""
from __future__ import annotations

import random
from typing import Any


ACTIONS = [
    "wait",
    "decline",
    "take_axe",
    "ask_for_axe",
    "chop_trees",
    "report_no_trees",
    "report_insufficient_trees",
    "idle",
]


class TreeRequestEnv:
    def __init__(self, seed: int = 29):
        self.random = random.Random(seed)
        self.state: dict[str, Any] = {}
        self.done = False

    def reset(self) -> dict[str, Any]:
        trees = self.random.randint(0, 3)
        target = self.random.randint(1, 2)
        self.state = {
            "has_axe": self.random.choice([False, True]),
            "axe_nearby": self.random.choice([False, True]),
            "trees_remaining": trees,
            "target_remaining": target,
            "willing": self.random.random() >= 0.15,
            "busy": self.random.random() < 0.2,
        }
        if self.state["has_axe"]:
            self.state["axe_nearby"] = False
        self.done = False
        return dict(self.state)

    @staticmethod
    def key(state: dict[str, Any]) -> str:
        return "|".join([
            f"axe={int(bool(state['has_axe']))}",
            f"near={int(bool(state['axe_nearby']))}",
            f"trees={int(state['trees_remaining'])}",
            f"target={int(state['target_remaining'])}",
            f"willing={int(bool(state['willing']))}",
            f"busy={int(bool(state['busy']))}",
        ])

    def step(self, action: str) -> tuple[dict[str, Any], float, bool, dict[str, Any]]:
        if self.done:
            raise RuntimeError("Episode is finished; call reset() before step().")
        s = self.state
        next_state = dict(s)
        reward = -3.0
        terminal = True
        reason = "invalid_action"
        appropriate = False
        task_success = False

        if s["busy"]:
            if action == "wait":
                next_state["busy"] = False
                reward, terminal, reason, appropriate = 1.0, False, "wait_for_busy_npc", True
        elif not s["willing"]:
            if action == "decline":
                reward, reason, appropriate = 3.0, "polite_decline", True
        elif s["trees_remaining"] <= 0:
            if action == "report_no_trees":
                reward, reason, appropriate = 3.0, "no_trees_available", True
        elif not s["has_axe"]:
            if s["axe_nearby"] and action == "take_axe":
                next_state["has_axe"] = True
                next_state["axe_nearby"] = False
                reward, terminal, reason, appropriate = 1.5, False, "tool_acquired", True
            elif not s["axe_nearby"] and action == "ask_for_axe":
                reward, reason, appropriate = 3.0, "request_tool_from_player", True
        elif s["trees_remaining"] < s["target_remaining"]:
            if action == "report_insufficient_trees":
                reward, reason, appropriate = 3.0, "not_enough_trees", True
        elif action == "chop_trees":
            next_state["trees_remaining"] -= 1
            next_state["target_remaining"] -= 1
            reward = 2.0
            appropriate = True
            if next_state["target_remaining"] <= 0:
                reward += 3.0
                terminal = True
                reason = "task_complete"
                task_success = True
            else:
                terminal = False
                reason = "tree_chopped_continue_task"

        self.state = next_state
        self.done = terminal
        info = {
            "reason": reason,
            "appropriate_action": appropriate,
            "task_success": task_success,
        }
        return dict(next_state), reward, terminal, info
