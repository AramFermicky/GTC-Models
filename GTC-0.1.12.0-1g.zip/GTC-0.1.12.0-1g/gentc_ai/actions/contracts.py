"""Engine-neutral action request/result contracts."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any
import math, time, uuid

@dataclass(frozen=True)
class ActionRequest:
    action: str
    source: str = "gtc"
    confidence: float = 0.5
    hold_seconds: float = 0.0
    game_id: str = "unknown"
    requires_foreground: bool = True
    metadata: dict[str, Any] = field(default_factory=dict)
    request_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    created_at: float = field(default_factory=time.monotonic)
    def __post_init__(self) -> None:
        if not self.action or not self.action.strip(): raise ValueError("action is required")
        if not self.source: raise ValueError("source is required")
        if not 0 <= float(self.confidence) <= 1: raise ValueError("confidence must be in [0,1]")
        if not math.isfinite(float(self.hold_seconds)) or self.hold_seconds < 0: raise ValueError("hold_seconds must be finite and non-negative")
        if not self.request_id: raise ValueError("request_id is required")

@dataclass(frozen=True)
class ActionResult:
    request_id: str
    accepted: bool
    executed: bool = False
    reason: str = ""
    started_at: float | None = None
    finished_at: float | None = None
    details: dict[str, Any] = field(default_factory=dict)
