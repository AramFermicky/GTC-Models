"""Prevents unknown actions, stale decisions and unbounded key holds."""
from __future__ import annotations
from dataclasses import dataclass
import math
from .contracts import ActionRequest

@dataclass(frozen=True)
class SafetyDecision:
    allowed: bool
    reason: str
    normalized_action: str
    hold_seconds: float

class SafetyGate:
    def __init__(self, allowed_actions: set[str] | list[str], *, max_hold_seconds: float = 0.25,
                 minimum_confidence: float = 0.0, require_foreground: bool = True) -> None:
        if not math.isfinite(float(max_hold_seconds)) or max_hold_seconds <= 0:
            raise ValueError("max_hold_seconds must be finite and positive")
        if not math.isfinite(float(minimum_confidence)) or not 0 <= minimum_confidence <= 1:
            raise ValueError("minimum_confidence must be finite and in [0,1]")
        self.allowed_actions = {str(a).strip().lower() for a in allowed_actions if str(a).strip()}
        self.max_hold_seconds = float(max_hold_seconds); self.minimum_confidence = float(minimum_confidence)
        self.require_foreground = require_foreground
    def evaluate(self, request: ActionRequest, *, foreground: bool, game_id: str | None = None) -> SafetyDecision:
        action = request.action.strip().lower()
        if action not in self.allowed_actions: return SafetyDecision(False, "action_not_allowlisted", action, 0.0)
        if game_id and request.game_id not in {"unknown", game_id}: return SafetyDecision(False, "game_id_mismatch", action, 0.0)
        if self.require_foreground and request.requires_foreground and not foreground:
            return SafetyDecision(False, "target_not_foreground", action, 0.0)
        if request.confidence < self.minimum_confidence: return SafetyDecision(False, "confidence_too_low", action, 0.0)
        if request.hold_seconds > self.max_hold_seconds:
            return SafetyDecision(False, "hold_duration_exceeds_limit", action, 0.0)
        return SafetyDecision(True, "allowed", action, request.hold_seconds)
