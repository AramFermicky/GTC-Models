"""Per-action monotonic cooldowns; avoids repetitive menu and interact spam."""
from __future__ import annotations
import math

class ActionCooldowns:
    def __init__(self) -> None: self._last: dict[str, float] = {}
    def ready(self, action: str, cooldown: float, now: float) -> bool:
        delay, current = float(cooldown), float(now)
        if not math.isfinite(delay) or delay < 0 or not math.isfinite(current):
            raise ValueError("cooldown and timestamp must be finite; cooldown must be non-negative")
        previous = self._last.get(action)
        return previous is None or current - previous >= delay
    def mark(self, action: str, now: float) -> None:
        if not action: raise ValueError("action must be non-empty")
        current = float(now)
        if not math.isfinite(current): raise ValueError("timestamp must be finite")
        previous = self._last.get(action)
        if previous is not None and current < previous: raise ValueError("timestamps must be monotonic per action")
        self._last[action] = current
    def remaining(self, action: str, cooldown: float, now: float) -> float:
        delay, current = float(cooldown), float(now)
        if not math.isfinite(delay) or delay < 0 or not math.isfinite(current):
            raise ValueError("cooldown and timestamp must be finite; cooldown must be non-negative")
        previous = self._last.get(action)
        return 0.0 if previous is None else max(0.0, delay - (current - previous))
