"""Gated action dispatcher with idempotency and explicit failure results."""
from __future__ import annotations
import threading, time
from typing import Callable, Any
from .contracts import ActionRequest, ActionResult
from .safety_gate import SafetyGate
from .cooldowns import ActionCooldowns

class ActionDispatcher:
    def __init__(self, gate: SafetyGate, *, cooldowns: ActionCooldowns | None = None) -> None:
        self.gate = gate; self.cooldowns = cooldowns or ActionCooldowns(); self._lock = threading.RLock()
        self._seen: dict[str, ActionResult] = {}
    def dispatch(self, request: ActionRequest, executor: Callable[[str, float], Any], *,
                 foreground: bool, game_id: str | None = None, cooldown: float = 0.0,
                 now: float | None = None) -> ActionResult:
        current = time.monotonic() if now is None else float(now)
        with self._lock:
            if request.request_id in self._seen: return self._seen[request.request_id]
            decision = self.gate.evaluate(request, foreground=foreground, game_id=game_id)
            if not decision.allowed:
                result = ActionResult(request.request_id, False, False, decision.reason, details={"action": decision.normalized_action})
                self._seen[request.request_id] = result; return result
            if not self.cooldowns.ready(decision.normalized_action, cooldown, current):
                result = ActionResult(request.request_id, False, False, "action_cooldown", details={"action": decision.normalized_action})
                self._seen[request.request_id] = result; return result
            started = time.monotonic()
            try:
                value = executor(decision.normalized_action, decision.hold_seconds)
                self.cooldowns.mark(decision.normalized_action, current)
                result = ActionResult(request.request_id, True, True, "executed_by_adapter", started,
                                      time.monotonic(), {"adapter_result": value})
            except Exception as exc:
                result = ActionResult(request.request_id, True, False, "adapter_error", started,
                                      time.monotonic(), {"error": f"{type(exc).__name__}: {exc}"[:300]})
            self._seen[request.request_id] = result
            # Bound idempotency memory; never evict an executing operation because calls are serialized.
            if len(self._seen) > 2048:
                for key in list(self._seen)[:512]: self._seen.pop(key, None)
            return result
