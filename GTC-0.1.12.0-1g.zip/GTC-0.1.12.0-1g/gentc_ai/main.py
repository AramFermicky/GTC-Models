"""Console prototype for GenTC AI 0.1.8 (Generating To Civilisations AI).

This is a sandbox and contract reference, not yet a live Godot connector.
"""
from __future__ import annotations

import argparse
import json
import tempfile
from pathlib import Path
from typing import Any

from gentc_ai.adapters.contracts import AdapterManifest, validate_snapshot
from gentc_ai.continuity import ContinuityStore, WorldMemoryStore, get_model_root, get_shared_data_dir
from gentc_ai.continuity.extractor import DialogueMemoryExtractor
from gentc_ai.core.agent_brain import AgentBrain, SimulatedEmotionModel
from gentc_ai.core.decision_engine import DecisionEngine
from gentc_ai.core.diagnostics import Diagnostics
from gentc_ai.core.intent_parser import IntentParser
from gentc_ai.core.memory_store import MemoryStore
from gentc_ai.core.world_state import WorldStateAnalyzer
from gentc_ai.learning.train import train as train_policy
from gentc_ai.learning.reflective_learner import ReflectiveLearner

PROJECT_ROOT = Path(__file__).resolve().parents[1]
CHARACTER_PATH = PROJECT_ROOT / "data" / "characters" / "anna.json"
DEFAULT_GAME_ID = "cabin_game"


def load_character(path: Path = CHARACTER_PATH) -> dict[str, Any]:
    profile = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(profile, dict) or not profile.get("character_id"):
        raise ValueError(f"Некорректный JSON-профиль персонажа: {path}")
    return profile


def _register_continuity(store: ContinuityStore, profile: dict[str, Any], game_id: str) -> tuple[str, str]:
    continuity = profile.get("continuity", {})
    character_id = str(profile["character_id"])
    identity_id = str(continuity.get("identity_id", f"{character_id}.core"))
    variant_id = str(continuity.get("variant_id", "default"))
    if game_id == DEFAULT_GAME_ID:
        incarnation_id = str(continuity.get("incarnation_id", f"{game_id}:{character_id}:{variant_id}"))
    else:
        incarnation_id = f"{game_id}:{character_id}:{variant_id}"
    store.register_identity(identity_id, str(profile.get("display_name", character_id)), {
        "continuity_mode": continuity.get("continuity_mode", "shared_identity_with_game_specific_incarnations"),
        "personality_summary": profile.get("identity", {}).get("background", ""),
    })
    store.register_incarnation(
        identity_id=identity_id,
        incarnation_id=incarnation_id,
        game_id=game_id,
        character_id=character_id,
        variant_id=variant_id,
        profile=profile,
    )
    return identity_id, incarnation_id


def _print_memories(store: ContinuityStore, identity_id: str, game_id: str, incarnation_id: str) -> None:
    memories = store.get_memories(identity_id, game_id=game_id, incarnation_id=incarnation_id, limit=30)
    if not memories:
        print("GTC: пока нет подтверждённых воспоминаний, доступных в этой вариации персонажа.")
        return
    print("\nВоспоминания, доступные этой вариации Анны:")
    for index, item in enumerate(memories, 1):
        print(f" {index}. [{item['scope']}/{item['category']}] {item['content']}")


def demo(user_data_dir: Path | None = None, game_id: str = DEFAULT_GAME_ID) -> int:
    profile = load_character()
    character_id = profile["character_id"]
    display_name = profile.get("display_name", character_id)
    # Even explicit test overrides are roots, never direct data directories.
    data_root = Path(user_data_dir).expanduser() if user_data_dir else get_model_root()
    data_dir = data_root if data_root.name.lower() == "gtc_learning" else data_root / "GTC_learning"
    data_dir.mkdir(parents=True, exist_ok=True)
    variant_id = str(profile.get("continuity", {}).get("variant_id", "default"))
    safe_variant = "".join(ch if ch.isalnum() or ch in "_.-" else "_" for ch in variant_id)[:96] or "default"
    memory = MemoryStore(data_dir / "legacy_dialogue_logs" / game_id / safe_variant, character_id)
    diagnostics = Diagnostics(data_dir / "logs" / "gtc_diagnostics.jsonl")
    continuity = ContinuityStore(data_dir / "continuity.sqlite3")
    identity_id, incarnation_id = _register_continuity(continuity, profile, game_id)
    parser = IntentParser()
    memory_extractor = DialogueMemoryExtractor()
    engine = DecisionEngine()
    analyzer = WorldStateAnalyzer()

    # Fake state for the offline console demo only. A game adapter must replace it
    # with a snapshot from the real engine before any action can be executed.
    world: dict[str, Any] = {
        "game_id": game_id,
        "player": {"id": "player", "position": [0.0, 0.0, 0.0], "visible": True},
        "npcs": [{"id": character_id, "position": [1.0, 0.0, 0.0], "state": "idle"}],
        "objects": [
            {"id": "tree_01", "type": "tree", "available": True},
            {"id": "tree_02", "type": "tree", "available": True},
            {"id": "tree_03", "type": "tree", "available": True},
        ],
        "inventory": [],
        "nearby_objects": [
            {"id": "tree_01", "type": "tree", "available": True},
            {"id": "tree_02", "type": "tree", "available": True},
            {"id": "tree_03", "type": "tree", "available": True},
        ],
        "npc_busy": False,
        "mode": "simulation_not_godot",
    }
    snapshot_report = analyzer.analyze(world)
    diagnostics.record("demo_started", {"world_analysis": snapshot_report, "mode": world["mode"], "game_id": game_id})

    print("=" * 70)
    print("GenTC AI 0.1.8 — Generating To Civilisations AI")
    print(f"Персонаж: {display_name} | identity_id: {identity_id}")
    print(f"Вариация: {incarnation_id} | game_id: {game_id}")
    print("Это локальная песочница: реальная игра Godot, голосовой чат и LLM не подключены.")
    print("Попробуйте: «Поруби пару деревьев пожалуйста»")
    print("Выдать топор в демо: «Я передаю топор» или /give axe")
    print("/memories — доступные воспоминания")
    print("/candidates — возможные воспоминания, найденные в диалоге")
    print("/confirm <ID> shared|game|incarnation — подтвердить кандидата")
    print("/reject <ID> — отклонить кандидата")
    print("/remember shared <текст> — напрямую сохранить подтверждённое воспоминание между подключёнными играми")
    print("/remember game <текст> — сохранить факт только для этой игры")
    print("/remember incarnation <текст> — сохранить факт только для этой вариации персонажа")
    print("/quit — выход")
    print("=" * 70)

    while True:
        try:
            text = input("Игрок > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGTC: завершение демо.")
            break
        if not text:
            continue

        # Explicit memory commands demonstrate scope boundaries. Shared memory is
        # written only by the user's explicit command, never from every raw phrase.
        lowered = text.casefold()
        if lowered == "/memories":
            _print_memories(continuity, identity_id, game_id, incarnation_id)
            continue
        if lowered == "/candidates":
            candidates = continuity.get_pending_memory_candidates(identity_id, game_id=game_id, incarnation_id=incarnation_id)
            if not candidates:
                print("GTC: нет ожидающих подтверждения кандидатов в воспоминания.")
            else:
                for item in candidates:
                    print(f"ID: {item['candidate_id']} | confidence={item['confidence']:.2f} | {item['content']}")
                print("Подтверждение: /confirm <ID> shared|game|incarnation")
            continue
        if lowered.startswith("/confirm "):
            parts = text.split(maxsplit=2)
            if len(parts) != 3 or parts[2].casefold() not in {"shared", "game", "incarnation"}:
                print("Использование: /confirm <ID> shared|game|incarnation")
                continue
            try:
                continuity.confirm_memory_candidate(parts[1], scope=parts[2].casefold(), verified=True)
                print(f"GTC: кандидат подтверждён как память области {parts[2].casefold()}.")
            except (ValueError, KeyError) as exc:
                print(f"GTC: не удалось подтвердить кандидата: {exc}")
            continue
        if lowered.startswith("/reject "):
            parts = text.split(maxsplit=1)
            if len(parts) != 2:
                print("Использование: /reject <ID>")
                continue
            try:
                continuity.reject_memory_candidate(parts[1])
                print("GTC: кандидат отклонён.")
            except KeyError as exc:
                print(f"GTC: {exc}")
            continue
        if lowered.startswith("/remember "):
            parts = text.split(maxsplit=2)
            if len(parts) < 3 or parts[1].casefold() not in {"shared", "game", "incarnation"}:
                print("Использование: /remember shared|game|incarnation <текст>")
                continue
            scope, content = parts[1].casefold(), parts[2].strip()
            try:
                continuity.add_memory(
                    identity_id, content, scope=scope, game_id=game_id,
                    incarnation_id=incarnation_id, category="player_confirmed_note",
                    source="explicit_player_command", confidence=1.0, verified=True,
                )
                print(f"GTC: воспоминание сохранено. Область: {scope}.")
                if scope == "shared":
                    print("Оно станет доступно всем играм, использующим тот же identity_id и хранилище GenTC AI.")
            except (ValueError, OSError) as exc:
                print(f"GTC: не удалось сохранить воспоминание: {exc}")
            continue

        intent = parser.parse(text)
        memory.log_dialogue("player", text, {"intent": intent.get("intent"), "demo": True, "game_id": game_id})
        dialogue_event_id = continuity.record_dialogue(
            identity_id, game_id, incarnation_id, "player", text,
            {"intent": intent.get("intent"), "demo": True},
        )
        # Very conservative rule extraction: it creates a pending candidate only.
        # The transcript itself is not turned into confirmed memory or training data.
        candidate = memory_extractor.extract_candidate(text)
        if candidate:
            candidate_id = continuity.propose_memory(
                identity_id, game_id, incarnation_id, candidate["content"],
                category=candidate["category"], source_event_id=dialogue_event_id,
                confidence=candidate["confidence"], metadata={"extracted_by": "rule_based_v0_1"},
            )
            print(
                f"GTC: похоже, это можно запомнить: {candidate['content']}\n"
                f"Кандидат: {candidate_id}\n"
                "Проверь его через /candidates; он пока НЕ считается подтверждённым фактом.\n"
            )
        diagnostics.record("player_input", {"text": text, "intent": intent, "dialogue_event_id": dialogue_event_id})
        if intent.get("intent") == "quit":
            print("GTC: До встречи!")
            break

        if intent.get("intent") == "give_item":
            if "axe" not in world["inventory"]:
                world["inventory"].append("axe")
            decision = engine.decide(intent, world, profile)
            reply = f"{display_name}: Спасибо, теперь у меня есть топор. Могу повторно проверить твою просьбу."
            memory.add_important_event("Игрок передал персонажу топор (событие демонстрационной песочницы).", source="demo_world_event", confidence=1.0)
        else:
            decision = engine.decide(intent, world, profile)
            intent_name = intent.get("intent")
            if intent_name == "chop_trees" and decision["decision"] == "request_tool":
                reply = f"{display_name}: Я могу помочь, но у меня нет топора. Передашь его мне?"
            elif intent_name == "chop_trees" and decision["decision"] == "accept":
                steps = ", ".join(f"{step['action']}({step.get('target_id', '')})" for step in decision.get("plan", []))
                reply = f"{display_name}: Хорошо, план действий подготовлен. План: {steps}. [Демо: Godot не подключён, фактическая рубка не выполнена.]"
            elif intent_name == "chop_trees" and decision["decision"] == "accept_partial":
                reply = f"{display_name}: Я могу срубить только часть деревьев, доступных сейчас. [Демо: план не исполнен.]"
            elif intent_name == "chop_trees" and decision["decision"] == "accept_after_getting_tool":
                reply = f"{display_name}: Я сначала подберу топор, затем повторно проверю просьбу. [Демо: план не исполнен.]"
            elif intent_name == "chop_trees" and decision["decision"] in {"refuse", "refuse_or_negotiate"}:
                reply = f"{display_name}: Сейчас я не могу взяться за это действие."
            elif intent_name == "chop_trees" and decision["decision"] == "defer":
                reply = f"{display_name}: Сейчас я занята. Давай я вернусь к твоей просьбе чуть позже."
            elif intent_name == "greeting":
                reply = f"{display_name}: Привет! Рада тебя видеть. [В v0.1 это шаблон, не ответ LLM.]"
            elif intent_name == "status":
                reply = f"{display_name}: Инвентарь в демо: {world['inventory']}; доступных деревьев: {len([o for o in world['nearby_objects'] if o.get('type') == 'tree' and o.get('available', True)])}."
            else:
                reply = f"{display_name}: Я сохранила твою реплику, но в v0.1 пока нет зарегистрированного действия для неё. Позже её сможет обработать LLM."

        print(f"GTC/решение: {decision['decision']} | статус: {decision['status']}")
        print(f"{reply}\n")
        memory.log_dialogue(display_name, reply, {"intent": intent.get("intent"), "decision": decision["decision"], "demo": True})
        continuity.record_dialogue(
            identity_id, game_id, incarnation_id, display_name, reply,
            {"intent": intent.get("intent"), "decision": decision["decision"], "demo": True},
        )
        situation = {"world_mode": world["mode"], "game_id": game_id, "inventory": list(world["inventory"]), "intent": intent}
        result = {"execution": "not_executed_by_godot", "demo_response": reply, "world_is_simulated": True}
        memory.log_experience(situation, decision, result)
        continuity.record_experience(
            identity_id, game_id, incarnation_id, situation, decision, result,
            semantic_action=decision.get("intent"), reward=None, verified=False,
            training_eligible=False, portable=False,
        )
        if decision.get("status", "").startswith("blocked"):
            diagnostics.record("decision_blocked", decision, level="WARNING")
        else:
            diagnostics.record("decision_made", decision)
    diagnostics.record("demo_stopped", {"character_id": character_id, "identity_id": identity_id})
    print(f"Локальная база общей непрерывности: {data_dir / 'continuity.sqlite3'}")
    print("Сырые диалоги и опыт из демо записаны как непроверенные данные и не допускаются к обучению автоматически.")
    print(f"Диагностика: {data_dir / 'logs' / 'gtc_diagnostics.jsonl'}")
    return 0


def continuity_demo() -> int:
    """Show that one canon identity can have isolated game variations."""
    with tempfile.TemporaryDirectory(prefix="gentc_continuity_demo_") as temp_dir:
        store = ContinuityStore(Path(temp_dir) / "continuity.sqlite3")
        identity_id = "anna.canon"
        store.register_identity(identity_id, "Анна", {"continuity_mode": "shared_canon_multiple_incarnations"})
        store.register_incarnation(identity_id, "cabin_game:anna:classic", "cabin_game", "anna", "classic", {"mood": "shy"})
        store.register_incarnation(identity_id, "forest_game:anna:adventurous", "forest_game", "anna", "adventurous", {"mood": "curious"})
        store.add_memory(
            identity_id, "Игрок ценит честные объяснения, если действие невозможно.", scope="shared",
            category="confirmed_preference", source="explicit_player_confirmation", confidence=1.0, verified=True,
        )
        store.add_memory(
            identity_id, "В избушке игрок однажды передал Анне топор.", scope="game", game_id="cabin_game",
            category="game_event", source="confirmed_game_event", confidence=1.0, verified=True,
        )
        store.record_dialogue(identity_id, "cabin_game", "cabin_game:anna:classic", "player", "Поруби пару деревьев.")
        cabin_memories = store.get_memories(identity_id, game_id="cabin_game", incarnation_id="cabin_game:anna:classic")
        forest_memories = store.get_memories(identity_id, game_id="forest_game", incarnation_id="forest_game:anna:adventurous")
        forest_dialogue = store.get_recent_dialogue(identity_id, game_id="forest_game", incarnation_id="forest_game:anna:adventurous")
        print("GenTC AI 0.1.8 — демонстрация общей личности между играми")
        print("Одна identity_id: anna.canon; две независимые игровые вариации.")
        print("\nПамять в cabin_game:")
        for item in cabin_memories:
            print(f" - [{item['scope']}] {item['content']}")
        print("\nПамять в forest_game:")
        for item in forest_memories:
            print(f" - [{item['scope']}] {item['content']}")
        print(f"\nСырой диалог cabin_game автоматически показан в forest_game? {'Да' if forest_dialogue else 'Нет'}.")
        print("Вывод: подтверждённые shared-воспоминания доступны обоим воплощениям; игровые факты и сырые диалоги изолированы.")
        print("Всё выполнено во временной БД; постоянные пользовательские данные не менялись.")
    return 0


def validate_adapter(manifest_path: Path, snapshot_path: Path | None = None) -> int:
    manifest = AdapterManifest.from_file(manifest_path)
    print(f"Адаптер: {manifest.manifest.get('game_name')} ({manifest.game_id})")
    print(f"Протокол: {manifest.manifest.get('protocol_version')}")
    print(f"Доступных объявленных действий: {len(manifest.actions)}")
    print("Действия:", ", ".join(manifest.actions))
    if snapshot_path:
        report = validate_snapshot(json.loads(snapshot_path.read_text(encoding="utf-8")), manifest.game_id)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0 if report["valid"] else 2
    return 0



def brain_demo() -> int:
    """Demonstrate goal-based autonomy, affect variables, and verified failure correction."""
    profile = load_character()
    candidates = [
        {
            "action": "scout_area", "semantic_action": "exploration",
            "preconditions_met": True, "evidence_confidence": 0.86, "risk": 0.25, "cost": 0.30,
            "context_tags": ["forest", "poor_visibility"],
            "goal_progress": {"learn_world": 0.80, "stay_safe": -0.10},
            "need_effects": {"curiosity": 0.50}, "stakeholder_impact": [],
        },
        {
            "action": "observe_from_cover", "semantic_action": "observe",
            "preconditions_met": True, "evidence_confidence": 0.95, "risk": 0.08, "cost": 0.18,
            "context_tags": ["forest", "poor_visibility"],
            "goal_progress": {"learn_world": 0.38, "stay_safe": 0.20},
            "need_effects": {"curiosity": 0.20, "safety": 0.10}, "stakeholder_impact": [],
        },
        {
            "action": "rest_at_camp", "semantic_action": "rest",
            "preconditions_met": True, "evidence_confidence": 0.99, "risk": 0.02, "cost": 0.08,
            "context_tags": ["camp"],
            "goal_progress": {"stay_safe": 0.12},
            "need_effects": {"rest": 0.60, "safety": 0.10}, "stakeholder_impact": [],
        },
        {
            "action": "intimidate_trader", "semantic_action": "social_interaction",
            "preconditions_met": True, "evidence_confidence": 0.90, "risk": 0.35, "cost": 0.10,
            "tags": ["coercion"], "context_tags": ["village"],
            "goal_progress": {"preserve_resources": 0.20}, "stakeholder_impact": [],
        },
    ]
    world = {
        "goal_priorities": {"stay_safe": 0.65, "learn_world": 0.85, "maintain_relationships": 0.55, "preserve_resources": 0.25},
        "needs": {"safety": 0.60, "curiosity": 0.85, "rest": 0.25, "belonging": 0.30},
        "world_id": "synthetic_brain_demo",
    }
    emotion_model = SimulatedEmotionModel()
    supplied_emotions = profile.get("initial_emotional_state", {})
    state = emotion_model.initial_state(supplied_emotions)
    state = emotion_model.apply_event(state, {"kind": "novelty_detected", "intensity": 0.8})

    with tempfile.TemporaryDirectory(prefix="gentc-reflection-demo-") as tmp:
        learner = ReflectiveLearner(Path(tmp))
        brain_without_learning = AgentBrain(profile)
        before = brain_without_learning.choose_action(world, candidates, state)
        # Synthetic example: the environment confirms the selected exploration failed
        # because the target could not be located. No player dialogue is used.
        scout = candidates[0]
        for _ in range(3):
            learner.record(
                {"context_tags": scout["context_tags"]},
                {"action": scout["action"], "semantic_action": scout["semantic_action"]},
                {"verified": True, "execution_confirmed": True, "goal_achieved": False,
                 "constraints_respected": True, "observed_harm": 0.0, "failure_reason": "target_not_found"},
            )
        brain_with_learning = AgentBrain(profile, learner=learner)
        after = brain_with_learning.choose_action(world, candidates, state)

        print("=" * 68)
        print("GenTC AI 0.1.8 — автономное решение и рефлексия")
        print("Это искусственная демонстрация, а не обучение на реальной игре.")
        print("Эмоциональные переменные — численная модель поведения, не доказательство чувств.")
        print("Эмоциональное состояние:")
        print(json.dumps(state, ensure_ascii=False, indent=2))
        print(f"До опыта: {before['chosen_action_name']} (score={before['chosen_score']})")
        print("Подтверждённый пример: 3 раза не найдена цель разведки в тумане/лесу.")
        print(f"После опыта: {after['chosen_action_name']} (score={after['chosen_score']})")
        estimate = learner.estimate("exploration", ["forest", "poor_visibility"])
        print("Оценка изученного действия:")
        print(json.dumps(estimate, ensure_ascii=False, indent=2))
        print("Отклонённые действия:")
        print(json.dumps(after["rejected_candidates"], ensure_ascii=False, indent=2))
        print("Важно: в настоящей игре этот цикл начнётся только после подтверждённых результатов от адаптера.")
        print("=" * 68)
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(prog="GenTC AI 0.1.8", description="Generating To Civilisations AI 0.1.8 — прототип адаптивного игрового интеллекта")
    subparsers = parser.add_subparsers(dest="command", required=True)
    demo_parser = subparsers.add_parser("demo", help="Запустить интерактивную консольную песочницу")
    demo_parser.add_argument("--game-id", default=DEFAULT_GAME_ID)
    demo_parser.add_argument("--data-dir", type=Path, default=None, help="Переопределить корень модели для тестов; данные всё равно будут в GTC_learning/")
    subparsers.add_parser("continuity-demo", help="Показать одну личность в двух играх с разделением воспоминаний")
    subparsers.add_parser("brain-demo", help="Показать автономный выбор, симулируемые эмоции и коррекцию после ошибок")
    subparsers.add_parser("world-memory-report", help="Показать постоянную память миров GTC между версиями")
    train_parser = subparsers.add_parser("train", help="Обучить тестовую табличную политику в синтетической среде")
    train_parser.add_argument("--episodes", type=int, default=12000)
    train_parser.add_argument("--seed", type=int, default=13)
    adapter_parser = subparsers.add_parser("validate-adapter", help="Проверить manifest игрового адаптера и при необходимости snapshot")
    adapter_parser.add_argument("manifest", type=Path)
    adapter_parser.add_argument("--snapshot", type=Path, default=None)
    export_parser = subparsers.add_parser("export-identity", help="Экспортировать continuity bundle")
    export_parser.add_argument("identity_id")
    export_parser.add_argument("destination", type=Path)
    export_parser.add_argument("--include-game-memories", action="store_true")
    export_parser.add_argument("--include-dialogue", action="store_true", help="Включить сырой диалог (содержит приватные данные)")
    export_parser.add_argument("--include-experiences", action="store_true")
    import_parser = subparsers.add_parser("import-identity", help="Импортировать continuity bundle в локальную БД")
    import_parser.add_argument("source", type=Path)
    args = parser.parse_args()
    if args.command == "demo":
        return demo(user_data_dir=args.data_dir, game_id=args.game_id)
    if args.command == "continuity-demo":
        return continuity_demo()
    if args.command == "brain-demo":
        return brain_demo()
    if args.command == "world-memory-report":
        memory_path = get_shared_data_dir() / "worlds" / "gtc_god_world" / "world_memory.sqlite3"
        store = WorldMemoryStore(memory_path)
        print("GenTC AI 0.1.8 — память миров")
        print(json.dumps(store.report(identity_id="gtc.god.canon"), ensure_ascii=False, indent=2))
        print("Примечание: только verified + execution_confirmed + constraints_respected результаты входят в нейросетевое обучение.")
        return 0
    if args.command == "validate-adapter":
        return validate_adapter(args.manifest, args.snapshot)
    if args.command == "export-identity":
        store = ContinuityStore(get_shared_data_dir() / "continuity.sqlite3")
        destination = store.export_identity_bundle(
            args.identity_id, args.destination,
            include_game_memories=args.include_game_memories,
            include_dialogue=args.include_dialogue,
            include_experiences=args.include_experiences,
        )
        print(f"Identity bundle сохранён: {destination}")
        print(f"Сырые диалоги включены в bundle: {'да' if args.include_dialogue else 'нет (по умолчанию)'}")
        return 0
    if args.command == "import-identity":
        store = ContinuityStore(get_shared_data_dir() / "continuity.sqlite3")
        result = store.import_identity_bundle(args.source)
        print("Identity bundle импортирован:")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    if args.command == "train":
        result = train_policy(episodes=args.episodes, seed=args.seed)
        print("\nGenTC AI 0.1.8 — тренировочный цикл завершён")
        for key, value in result["report"].items():
            print(f"{key}: {value}")
        print(f"\nQ-table: {result['q_table_path']}")
        print(f"Отчёт:   {result['report_path']}")
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
