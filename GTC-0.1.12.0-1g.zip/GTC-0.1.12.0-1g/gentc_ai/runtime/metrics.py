"""Bounded in-memory counters, gauges and latency samples for diagnostics."""
from __future__ import annotations
from collections import deque
import math, threading

class Metrics:
    def __init__(self, sample_limit: int = 512) -> None:
        if sample_limit < 1: raise ValueError("sample_limit must be positive")
        self._lock = threading.Lock(); self._limit = sample_limit
        self._counters: dict[str, int] = {}; self._gauges: dict[str, float] = {}; self._samples: dict[str, deque[float]] = {}

    def increment(self, name: str, amount: int = 1) -> int:
        if amount < 0: raise ValueError("counter increments must be non-negative")
        with self._lock:
            self._counters[name] = self._counters.get(name, 0) + amount
            return self._counters[name]

    def gauge(self, name: str, value: float) -> None:
        number = float(value)
        if not math.isfinite(number): raise ValueError("gauge value must be finite")
        with self._lock: self._gauges[name] = number

    def observe(self, name: str, value: float) -> None:
        number = float(value)
        if not math.isfinite(number) or number < 0: raise ValueError("sample must be finite and non-negative")
        with self._lock: self._samples.setdefault(name, deque(maxlen=self._limit)).append(number)

    def snapshot(self) -> dict[str, object]:
        with self._lock:
            samples = {key: list(values) for key, values in self._samples.items()}
            return {"counters": dict(self._counters), "gauges": dict(self._gauges),
                    "samples": {key: {"count": len(v), "mean": sum(v)/len(v) if v else None,
                                       "max": max(v) if v else None} for key, v in samples.items()}}
