"""Lifecycle supervisor that isolates start/stop failures instead of crashing peers."""
from __future__ import annotations
from typing import Callable
from .contracts import ModuleManifest, ModuleStatus
from .registry import ModuleRegistry
from .event_bus import EventBus
from .health import HealthMonitor

class ModuleSupervisor:
    def __init__(self, registry: ModuleRegistry | None = None, bus: EventBus | None = None,
                 health: HealthMonitor | None = None) -> None:
        self.registry = registry or ModuleRegistry(); self.bus = bus or EventBus(); self.health = health or HealthMonitor()
        self._manifests: dict[str, ModuleManifest] = {}
        self._start: dict[str, Callable[[], object]] = {}; self._stop: dict[str, Callable[[], object]] = {}
    def register(self, manifest: ModuleManifest, start: Callable[[], object] | None = None,
                 stop: Callable[[], object] | None = None) -> None:
        self.registry.register(manifest)
        self._manifests[manifest.module_id] = manifest
        if start: self._start[manifest.module_id] = start
        if stop: self._stop[manifest.module_id] = stop
    def start_all(self, *, include_optional: bool = True) -> list[dict[str, object]]:
        results = []
        states = {item["module_id"]: item["status"] for item in self.registry.snapshot()}
        for module_id in self.registry.startup_order(include_optional=include_optional):
            manifest = self._manifests[module_id]
            unavailable = [dependency for dependency in manifest.requires
                           if states.get(dependency) != ModuleStatus.RUNNING.value]
            if unavailable:
                reason = "dependency_not_running: " + ", ".join(unavailable)
                self.registry.set_status(module_id, ModuleStatus.FAILED, reason)
                states[module_id] = ModuleStatus.FAILED.value
                self.bus.publish("module.blocked", {"module_id": module_id, "reason": reason})
                results.append({"module_id": module_id, "ok": False, "error": reason})
                continue
            self.registry.set_status(module_id, ModuleStatus.STARTING)
            try:
                value = self._start[module_id]() if module_id in self._start else None
                self.registry.set_status(module_id, ModuleStatus.RUNNING)
                states[module_id] = ModuleStatus.RUNNING.value
                self.health.heartbeat(module_id, detail={"startup": "ok"})
                self.bus.publish("module.started", {"module_id": module_id})
                results.append({"module_id": module_id, "ok": True, "result": value})
            except Exception as exc:
                error = f"{type(exc).__name__}: {exc}"[:300]
                self.registry.set_status(module_id, ModuleStatus.FAILED, error)
                states[module_id] = ModuleStatus.FAILED.value
                self.bus.publish("module.failed", {"module_id": module_id, "error": error})
                results.append({"module_id": module_id, "ok": False, "error": error})
                # Fault containment: independent modules may still start.
        return results
    def stop_all(self) -> list[dict[str, object]]:
        results = []
        for item in reversed(self.registry.startup_order()):
            try:
                value = self._stop[item]() if item in self._stop else None
                self.registry.set_status(item, ModuleStatus.STOPPED)
                self.bus.publish("module.stopped", {"module_id": item})
                results.append({"module_id": item, "ok": True, "result": value})
            except Exception as exc:
                self.registry.set_status(item, ModuleStatus.DEGRADED, f"{type(exc).__name__}: {exc}")
                results.append({"module_id": item, "ok": False, "error": str(exc)[:300]})
        return results
