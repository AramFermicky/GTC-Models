"""Deterministic due-task scheduler; callers decide which thread runs due tasks."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Any
import math

@dataclass
class ScheduledTask:
    task_id: str
    interval: float
    callback: Callable[[], Any]
    next_run: float
    enabled: bool = True
    running: bool = False
    last_error: str | None = None

class DueTaskScheduler:
    def __init__(self) -> None: self._tasks: dict[str, ScheduledTask] = {}
    def add(self, task_id: str, interval: float, callback: Callable[[], Any], *, now: float = 0.0) -> None:
        if not task_id or task_id in self._tasks: raise ValueError("task_id must be unique and non-empty")
        interval_value, first_run = float(interval), float(now)
        if not math.isfinite(interval_value) or interval_value <= 0 or not callable(callback):
            raise ValueError("interval must be finite and positive and callback callable")
        if not math.isfinite(first_run): raise ValueError("now must be finite")
        self._tasks[task_id] = ScheduledTask(task_id, interval_value, callback, first_run)
    def cancel(self, task_id: str) -> bool:
        task = self._tasks.get(task_id)
        if task is None: return False
        task.enabled = False; return True
    def run_due(self, now: float) -> list[dict[str, Any]]:
        current = float(now)
        if not math.isfinite(current): raise ValueError("now must be finite")
        results = []
        for task in sorted(self._tasks.values(), key=lambda item: item.task_id):
            if not task.enabled or task.running or current < task.next_run: continue
            task.running = True
            try:
                value = task.callback(); task.last_error = None
                results.append({"task_id": task.task_id, "ok": True, "result": value})
            except Exception as exc:
                task.last_error = f"{type(exc).__name__}: {exc}"[:300]
                results.append({"task_id": task.task_id, "ok": False, "error": task.last_error})
            finally:
                task.running = False; task.next_run = current + task.interval
        return results
    def snapshot(self) -> list[dict[str, Any]]:
        return [{"task_id": t.task_id, "interval": t.interval, "next_run": t.next_run,
                 "enabled": t.enabled, "last_error": t.last_error} for t in sorted(self._tasks.values(), key=lambda x:x.task_id)]
