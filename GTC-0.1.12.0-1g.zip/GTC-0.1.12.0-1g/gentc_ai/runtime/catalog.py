"""Machine-readable inventory of independent system families introduced in GTC 0.1.10.31."""
from __future__ import annotations
import os

_FAMILIES = {
    "runtime": ("Module registry", "Event bus", "Health monitor", "Metrics", "Retry/circuit breaker", "Task scheduler", "Module supervisor"),
    "perception": ("Perception contracts", "Frame signature", "Change/stall detector", "Confidence aggregation", "State fusion"),
    "actions": ("Action contracts", "Safety gate", "Cooldown manager", "Action dispatcher"),
    "goals": ("Goal contracts", "Goal manager", "Candidate planner"),
    "experience": ("Experience contracts", "Verified feedback", "Prioritized replay sampler", "Experience validation"),
    "creative": ("File-scoped artifact sandbox", "Declarative experiments", "Experiment evaluation gate"),
    "gls": ("Language data contracts", "JSONL dataset", "Checkpoint integrity", "Inference interface", "Training/safety split"),
    "collective": ("Compact knowledge message", "Strict exchange validator", "Consent-gated local outbox"),
}

# Resolve this once during import. Runtime tests may temporarily mock os.name to
# simulate an unsupported platform; constructing pathlib.Path during that mock can
# try to instantiate PosixPath on Windows (or WindowsPath on POSIX).
_MODULE_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def module_catalog() -> dict[str, object]:
    root = _MODULE_ROOT
    families = []
    for family, capabilities in _FAMILIES.items():
        folder = os.path.join(root, family)
        available = os.path.isdir(folder)
        try:
            py_count = sum(1 for name in os.listdir(folder)
                           if name.endswith(".py") and os.path.isfile(os.path.join(folder, name))) if available else 0
        except OSError:
            py_count = 0
        families.append({"family": family, "path": f"gentc_ai/{family}/", "available": available,
                         "python_files": py_count,
                         "capabilities": list(capabilities), "auto_started": False})
    return {"schema_version": 1, "status": "contracts_available_optional_components_not_auto_started",
            "family_count": len(families), "component_count": sum(len(x["capabilities"]) for x in families),
            "families": families}
