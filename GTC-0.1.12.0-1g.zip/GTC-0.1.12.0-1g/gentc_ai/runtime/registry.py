"""Dependency-aware registry with deterministic ordering and cycle detection."""
from __future__ import annotations
from .contracts import ModuleManifest, ModuleStatus

class ModuleRegistry:
    def __init__(self) -> None:
        self._manifests: dict[str, ModuleManifest] = {}
        self._states: dict[str, ModuleStatus] = {}
        self._errors: dict[str, str] = {}

    def register(self, manifest: ModuleManifest) -> None:
        if manifest.module_id in self._manifests:
            existing = self._manifests[manifest.module_id]
            if existing != manifest:
                raise ValueError(f"module already registered with a different manifest: {manifest.module_id}")
            return
        self._manifests[manifest.module_id] = manifest
        self._states[manifest.module_id] = ModuleStatus.REGISTERED

    def set_status(self, module_id: str, status: ModuleStatus, error: str | None = None) -> None:
        if module_id not in self._manifests:
            raise KeyError(module_id)
        self._states[module_id] = ModuleStatus(status)
        if error:
            self._errors[module_id] = str(error)[:500]
        elif module_id in self._errors and status != ModuleStatus.FAILED:
            self._errors.pop(module_id, None)

    def startup_order(self, *, include_optional: bool = True) -> list[str]:
        ids = {key for key, value in self._manifests.items() if include_optional or not value.optional}
        for key in ids:
            missing = [dep for dep in self._manifests[key].requires if dep not in self._manifests]
            if missing:
                raise ValueError(f"{key} has missing dependencies: {', '.join(missing)}")
            excluded = [dep for dep in self._manifests[key].requires if dep not in ids]
            if excluded:
                raise ValueError(f"{key} requires excluded modules: {', '.join(excluded)}")
        incoming = {key: set(dep for dep in self._manifests[key].requires if dep in ids) for key in ids}
        result: list[str] = []
        ready = sorted(key for key, deps in incoming.items() if not deps)
        while ready:
            current = ready.pop(0)
            result.append(current)
            for key in sorted(incoming):
                if current in incoming[key]:
                    incoming[key].remove(current)
                    if not incoming[key] and key not in result and key not in ready:
                        ready.append(key)
                        ready.sort()
        if len(result) != len(ids):
            cyclic = sorted(key for key, deps in incoming.items() if deps)
            raise ValueError(f"module dependency cycle detected: {', '.join(cyclic)}")
        return result

    def snapshot(self) -> list[dict[str, object]]:
        return [{"module_id": key, "version": self._manifests[key].version,
                 "requires": list(self._manifests[key].requires), "optional": self._manifests[key].optional,
                 "description": self._manifests[key].description,
                 "status": self._states[key].value, "error": self._errors.get(key)}
                for key in sorted(self._manifests)]
