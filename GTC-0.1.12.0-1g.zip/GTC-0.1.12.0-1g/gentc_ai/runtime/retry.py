"""Bounded retry schedule and a tiny circuit breaker for unreliable adapters."""
from __future__ import annotations
from dataclasses import dataclass
import math
import time

@dataclass(frozen=True)
class RetryPolicy:
    attempts: int = 3
    base_delay: float = 0.1
    max_delay: float = 2.0
    multiplier: float = 2.0
    def __post_init__(self) -> None:
        values = (self.base_delay, self.max_delay, self.multiplier)
        if (self.attempts < 1 or any(not math.isfinite(float(value)) for value in values)
                or self.base_delay < 0 or self.max_delay < 0 or self.multiplier < 1):
            raise ValueError("invalid retry policy")
    def delay_after(self, failed_attempt: int) -> float:
        if failed_attempt < 1: raise ValueError("failed_attempt is one-based")
        return min(self.max_delay, self.base_delay * self.multiplier ** (failed_attempt - 1))

class CircuitBreaker:
    def __init__(self, threshold: int = 3, cooldown: float = 5.0) -> None:
        if threshold < 1 or not math.isfinite(float(cooldown)) or cooldown < 0:
            raise ValueError("invalid circuit breaker settings")
        self.threshold, self.cooldown = threshold, cooldown
        self.failures = 0; self.opened_at: float | None = None
    def allow(self, now: float | None = None) -> bool:
        current = time.monotonic() if now is None else float(now)
        if not math.isfinite(current): raise ValueError("now must be finite")
        if self.opened_at is None: return True
        if current - self.opened_at >= self.cooldown:
            self.opened_at = None; self.failures = 0
            return True
        return False
    def record_success(self) -> None: self.failures = 0; self.opened_at = None
    def record_failure(self, now: float | None = None) -> None:
        self.failures += 1
        if self.failures >= self.threshold and self.opened_at is None:
            current = time.monotonic() if now is None else float(now)
            if not math.isfinite(current): raise ValueError("now must be finite")
            self.opened_at = current
