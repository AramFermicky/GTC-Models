"""Stable contracts shared by independent GenTC AI modules."""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

class ModuleStatus(str, Enum):
    REGISTERED = "registered"
    STARTING = "starting"
    RUNNING = "running"
    DEGRADED = "degraded"
    FAILED = "failed"
    STOPPED = "stopped"

@dataclass(frozen=True)
class ModuleManifest:
    module_id: str
    version: str = "1.0"
    requires: tuple[str, ...] = ()
    optional: bool = True
    description: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.module_id or not self.module_id.strip():
            raise ValueError("module_id must be a non-empty string")
        if self.module_id in self.requires:
            raise ValueError("a module cannot depend on itself")
        if len(set(self.requires)) != len(self.requires):
            raise ValueError("module dependencies must be unique")
