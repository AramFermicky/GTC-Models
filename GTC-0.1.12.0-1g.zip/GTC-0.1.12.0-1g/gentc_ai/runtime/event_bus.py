"""Small synchronous event bus; subscriber faults are isolated from publishers."""
from __future__ import annotations
from collections import deque
from dataclasses import dataclass
import threading, time, uuid
from typing import Any, Callable

@dataclass(frozen=True)
class EventEnvelope:
    event_id: str
    name: str
    created_at: float
    payload: dict[str, Any]

class EventBus:
    def __init__(self, history_limit: int = 256) -> None:
        if history_limit < 1: raise ValueError("history_limit must be positive")
        self._lock = threading.RLock()
        self._subscribers: dict[str, list[Callable[[EventEnvelope], None]]] = {}
        self._history: deque[EventEnvelope] = deque(maxlen=history_limit)
        self._subscriber_errors = 0

    def subscribe(self, name: str, callback: Callable[[EventEnvelope], None]) -> Callable[[], None]:
        if not name or not callable(callback): raise ValueError("event name and callable callback are required")
        with self._lock: self._subscribers.setdefault(name, []).append(callback)
        def unsubscribe() -> None:
            with self._lock:
                callbacks = self._subscribers.get(name, [])
                if callback in callbacks: callbacks.remove(callback)
        return unsubscribe

    def publish(self, name: str, payload: dict[str, Any] | None = None) -> EventEnvelope:
        if not name or not name.strip(): raise ValueError("event name must be non-empty")
        if payload is not None and not isinstance(payload, dict): raise TypeError("payload must be a dict")
        event = EventEnvelope(uuid.uuid4().hex, name, time.time(), dict(payload or {}))
        with self._lock:
            self._history.append(event)
            callbacks = tuple(self._subscribers.get(name, ())) + tuple(self._subscribers.get("*", ()))
        for callback in callbacks:
            try: callback(event)
            except Exception:
                with self._lock: self._subscriber_errors += 1
        return event

    def history(self, name: str | None = None) -> list[EventEnvelope]:
        with self._lock: values = list(self._history)
        return [event for event in values if name is None or event.name == name]

    def status(self) -> dict[str, int]:
        with self._lock:
            return {"history_size": len(self._history), "subscriber_count": sum(map(len, self._subscribers.values())),
                    "subscriber_errors": self._subscriber_errors}
