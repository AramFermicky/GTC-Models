"""Heartbeat and stale-module detection without restarting modules implicitly."""
from __future__ import annotations
import threading, time
from typing import Any

class HealthMonitor:
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._heartbeats: dict[str, float] = {}
        self._details: dict[str, dict[str, Any]] = {}

    def heartbeat(self, module_id: str, *, detail: dict[str, Any] | None = None, now: float | None = None) -> None:
        if not module_id: raise ValueError("module_id must be non-empty")
        with self._lock:
            self._heartbeats[module_id] = time.monotonic() if now is None else float(now)
            self._details[module_id] = dict(detail or {})

    def inspect(self, module_id: str, stale_after: float = 5.0, now: float | None = None) -> dict[str, Any]:
        if stale_after < 0: raise ValueError("stale_after must be non-negative")
        current = time.monotonic() if now is None else float(now)
        with self._lock:
            last = self._heartbeats.get(module_id)
            detail = dict(self._details.get(module_id, {}))
        age = None if last is None else max(0.0, current - last)
        return {"module_id": module_id, "alive": age is not None and age <= stale_after,
                "heartbeat_seen": last is not None, "age_seconds": age, "detail": detail}

    def snapshot(self, stale_after: float = 5.0) -> list[dict[str, Any]]:
        with self._lock: ids = sorted(self._heartbeats)
        return [self.inspect(key, stale_after) for key in ids]
