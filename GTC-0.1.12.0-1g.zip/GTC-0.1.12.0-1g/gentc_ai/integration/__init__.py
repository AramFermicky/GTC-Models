"""Local integration bridges for game engines."""
