"""GTC autonomous girl-character bridge for the Winter Shelter Godot project.

The bridge proposes one action from an allow-list. Godot executes and verifies it.
Only verified execution results enter persistent learning and training data.
No LLM is used by this prototype; dialogue is selected from grounded templates.
"""
from __future__ import annotations

import json
import math
import os
import random
import re
import shutil
import sys
import threading
import traceback
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from gentc_ai.version import VERSION, BUILD_ID
from gentc_ai.model_package import load_model_manifest, resolve_model_weight, ModelPackageError
from gentc_ai.core.agent_brain import AgentBrain, SimulatedEmotionModel
from gentc_ai.continuity.paths import get_model_root, get_model_learning_dir, bootstrap_legacy_learning
from gentc_ai.continuity.world_memory import WorldMemoryStore
from gentc_ai.continuity.versioned_knowledge import VersionedKnowledgeStore
from gentc_ai.continuity.self_model import SelfModelStore
from gentc_ai.learning.reflective_learner import ReflectiveLearner
from gentc_ai.learning.persistent_q_learning import PersistentQPolicy, SEMANTIC_BY_ACTION
from gentc_ai.experience.replay_sampler import PrioritizedReplaySampler
from gentc_ai.experience.decision_tracker import DecisionTracker, action_key, state_fingerprint

PROJECT_ROOT = Path(__file__).resolve().parents[2]
PROFILE_PATH = PROJECT_ROOT / "data" / "characters" / "anna_girl_lab.json"
HOST = "127.0.0.1"
PORT = 8767
MAX_BODY_BYTES = 1_000_000
RUNTIME_VERSION = f"GTC-{BUILD_ID}"
GAME_ID = "winter_shelter"
WORLD_ID = "winter_forest_main"
IDENTITY_ID = "anna.canon"
MODEL_ROOT = get_model_root()
SHARED_GTC_ROOT = get_model_learning_dir()
bootstrap_legacy_learning()
VERSION_DIR = SHARED_GTC_ROOT / "versions" / BUILD_ID
VERSION_DIR.mkdir(parents=True, exist_ok=True)
DATA_DIR = SHARED_GTC_ROOT / "consolidated" / "worlds" / "winter_shelter_anna"
DATA_DIR.mkdir(parents=True, exist_ok=True)
for _legacy_world in SHARED_GTC_ROOT.glob("inherited/*/legacy_machine_data/*/worlds/winter_shelter_anna"):
    if _legacy_world.is_dir():
        for _name in ("world_memory.sqlite3", "girl_state.json", "self_model.json"):
            _source = _legacy_world / _name
            _destination = DATA_DIR / _name
            if _source.is_file() and not _destination.exists():
                shutil.copy2(_source, _destination)
SHARED_LEARNING_DIR = VERSION_DIR / "policies"
SHARED_LEARNING_DIR.mkdir(parents=True, exist_ok=True)
STATE_PATH = DATA_DIR / "girl_state.json"
NETWORK_PATH = VERSION_DIR / "models" / "anna_value_model.json"
LEGACY_NETWORK_PATH = SHARED_GTC_ROOT / "inherited" / "0.1.10.34-3t" / "data" / "models" / "anna_value_model.json"
SESSION_ID = uuid.uuid4().hex

# Human-inspectable exports and diagnostics are also model-owned.
DATA_ROOT = SHARED_GTC_ROOT / "exports"
DATA_MEMORY_DIR = DATA_ROOT / "memory"
DATA_LEARNING_DIR = DATA_ROOT / "learning"
DATA_CROSS_GAME_DIR = DATA_ROOT / "cross_game"
DATA_LOGS_DIR = DATA_ROOT / "logs"
DATA_MODELS_DIR = DATA_ROOT / "models"
DATA_PORTABLE_DIR = DATA_ROOT / "portable" / "winter_shelter"
RUNTIME_LOG_PATH = SHARED_GTC_ROOT / "diagnostics" / "gtc_runtime.log"
EVENTS_LOG_PATH = SHARED_GTC_ROOT / "diagnostics" / "events.jsonl"
for _folder in (DATA_MEMORY_DIR, DATA_LEARNING_DIR, DATA_CROSS_GAME_DIR, DATA_LOGS_DIR, DATA_MODELS_DIR, DATA_PORTABLE_DIR, RUNTIME_LOG_PATH.parent, NETWORK_PATH.parent):
    _folder.mkdir(parents=True, exist_ok=True)

def _seed_version_file(target: Path, relative_parts: tuple[str, ...]) -> None:
    """Seed a new build from the newest older build without modifying its source."""
    if target.exists():
        return
    versions_root = SHARED_GTC_ROOT / "versions"
    candidates = []
    if versions_root.exists():
        for folder in versions_root.iterdir():
            if folder.is_dir() and folder.name != BUILD_ID:
                candidate = folder.joinpath(*relative_parts)
                if candidate.is_file():
                    candidates.append((folder.name, candidate))
    candidates.sort(key=lambda item: tuple(int(x) if x.isdigit() else -1 for x in re.findall(r"\d+", item[0])), reverse=True)
    if candidates:
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(candidates[0][1], target)
    elif relative_parts == ("models", "anna_value_model.json"):
        try:
            package_manifest = load_model_manifest(MODEL_ROOT)
            package_weights = resolve_model_weight(MODEL_ROOT, package_manifest, "character_value_mlp_v1")
        except ModelPackageError as exc:
            package_weights = None
            print(f"[GTC] Model package manifest warning: {exc}", file=sys.stderr)
        if package_weights is None:
            candidates = [LEGACY_NETWORK_PATH, *SHARED_GTC_ROOT.glob("inherited/*/legacy_machine_data/*/worlds/winter_shelter_anna/anna_value_model.json")]
            package_weights = next((item for item in candidates if item.is_file()), None)
        if package_weights is not None:
            shutil.copy2(package_weights, target)
    elif relative_parts == ("policies", "q_policy.json"):
        legacy_candidates = [
            SHARED_GTC_ROOT / "inherited" / "0.1.10.34-3t" / "data" / "learning" / "q_policy.json",
            *SHARED_GTC_ROOT.glob("inherited/*/legacy_machine_data/*/learning/q_policy.json"),
        ]
        legacy_q = next((item for item in legacy_candidates if item.is_file()), None)
        if legacy_q is not None:
            shutil.copy2(legacy_q, target)

_seed_version_file(NETWORK_PATH, ("models", "anna_value_model.json"))
_seed_version_file(SHARED_LEARNING_DIR / "q_policy.json", ("policies", "q_policy.json"))
_RUNTIME_LOG_LOCK = threading.RLock()


def _log_event(event: str, level: str = "INFO", **fields: Any) -> None:
    """Write concise human-readable and structured logs without crashing the AI loop."""
    now = datetime.now(timezone.utc).isoformat()
    record = {"timestamp_utc": now, "runtime_version": RUNTIME_VERSION, "event": str(event), "level": level.upper(), **fields}
    compact = json.dumps(record, ensure_ascii=False, allow_nan=False, default=str)
    line = f"{now} [{level.upper()}] {event}"
    if fields:
        line += " | " + json.dumps(fields, ensure_ascii=False, allow_nan=False, default=str)
    with _RUNTIME_LOG_LOCK:
        try:
            with RUNTIME_LOG_PATH.open("a", encoding="utf-8", newline="\n") as stream:
                stream.write(line + "\n")
            with EVENTS_LOG_PATH.open("a", encoding="utf-8", newline="\n") as stream:
                stream.write(compact + "\n")
        except OSError:
            pass
    print(f"[GTC][{level.upper()}] {event}" + (" | " + json.dumps(fields, ensure_ascii=False, default=str) if fields else ""), flush=True)


def _atomic_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False, default=str), encoding="utf-8")
    tmp.replace(path)


def _export_portable_snapshot() -> None:
    r"""Mirror real live experience, Q values and neural weights into GTC\data subfolders."""
    try:
        import sqlite3
        source_path = DATA_DIR / "world_memory.sqlite3"
        if source_path.exists():
            backup_path = DATA_MEMORY_DIR / "world_memory.sqlite3"
            tmp_db = backup_path.with_name(backup_path.name + ".tmp")
            source = sqlite3.connect(str(source_path), timeout=8.0)
            try:
                target = sqlite3.connect(str(tmp_db), timeout=8.0)
                try:
                    source.backup(target)
                    target.commit()
                finally:
                    target.close()
            finally:
                source.close()
            tmp_db.replace(backup_path)

            # Export actual database rows as JSONL so the directory can be inspected
            # without SQLite tooling. Only this canonical identity's recorded episodes.
            exp_tmp = DATA_MEMORY_DIR / "verified_experiences.jsonl.tmp"
            with sqlite3.connect(str(source_path), timeout=8.0) as conn, exp_tmp.open("w", encoding="utf-8", newline="\n") as stream:
                conn.row_factory = sqlite3.Row
                rows = conn.execute(
                    "SELECT experience_id, game_id, world_id, session_id, runtime_version, action_name, semantic_action, situation_json, action_json, outcome_json, reward, verified, execution_confirmed, training_eligible, portable, created_at FROM experiences WHERE identity_id=? ORDER BY created_at ASC",
                    (IDENTITY_ID,),
                )
                for row in rows:
                    record = dict(row)
                    for source_key, dest_key in (("situation_json", "situation"), ("action_json", "action"), ("outcome_json", "outcome")):
                        try:
                            record[dest_key] = json.loads(record.pop(source_key))
                        except (TypeError, json.JSONDecodeError):
                            record[dest_key] = {}
                    for key in ("verified", "execution_confirmed", "training_eligible", "portable"):
                        record[key] = bool(record.get(key, 0))
                    stream.write(json.dumps(record, ensure_ascii=False, allow_nan=False, default=str) + "\n")
            exp_tmp.replace(DATA_MEMORY_DIR / "verified_experiences.jsonl")

        if "LEARNER" in globals():
            # Make sure an empty policy also exists: empty is an honest zero-sample state.
            if not LEARNER.policy_path.exists():
                LEARNER._save()
            for src, dst in ((LEARNER.policy_path, DATA_LEARNING_DIR / "reflective_policy.json"),
                             (LEARNER.log_path, DATA_LEARNING_DIR / "lesson_log.jsonl")):
                if src.exists():
                    tmp = dst.with_name(dst.name + ".tmp")
                    shutil.copy2(src, tmp)
                    tmp.replace(dst)
        if "Q_POLICY" in globals():
            _atomic_json(DATA_LEARNING_DIR / "q_policy.json", {
                "schema_version": Q_POLICY.SCHEMA_VERSION, "alpha": Q_POLICY.agent.alpha,
                "gamma": Q_POLICY.agent.gamma, "q_table": Q_POLICY.agent.q_table,
                "stats": Q_POLICY.stats, "semantic_priors": Q_POLICY.semantic_priors,
                "transitions": Q_POLICY.transitions, "updated_at_utc": datetime.now(timezone.utc).isoformat(),
                "source": "live shared GTC policy; safe snapshot",
            })
            _atomic_json(DATA_CROSS_GAME_DIR / "semantic_action_priors.json", Q_POLICY.export_semantic_priors())
            _atomic_json(DATA_CROSS_GAME_DIR / "transfer_manifest.json", {
                "runtime_version": RUNTIME_VERSION, "identity_id": IDENTITY_ID,
                "transfer_rule": "Only semantic outcome priors transfer. Exact Q rows remain game/world-specific.",
                "semantic_prior_count": len(Q_POLICY.semantic_priors),
                "games_observed": sorted({g for p in Q_POLICY.semantic_priors.values() for g in p.get("games", {})}),
                "updated_at_utc": datetime.now(timezone.utc).isoformat(),
            })
        if STATE_PATH.exists():
            shutil.copy2(STATE_PATH, DATA_MEMORY_DIR / "girl_state.json")
        if "SELF_MODEL" in globals():
            shutil.copy2(SELF_MODEL.path, DATA_MEMORY_DIR / "self_model.json")
        if NETWORK_PATH.exists():
            shutil.copy2(NETWORK_PATH, DATA_MODELS_DIR / "anna_value_model.json")
        if "MEMORY" in globals():
            report = MEMORY.report(identity_id=IDENTITY_ID)
        else:
            report = {"experiences": 0, "training_eligible_experiences": 0}
        network = NETWORK.status() if "NETWORK" in globals() and hasattr(NETWORK, "status") else {
            "active": NETWORK.active, "samples": NETWORK.samples, "updates": NETWORK.updates,
            "hidden_units": NETWORK.hidden_size,
            "parameter_count": NETWORK.input_size * NETWORK.hidden_size + NETWORK.hidden_size + NETWORK.hidden_size + 1,
        } if "NETWORK" in globals() else {}
        _atomic_json(DATA_LEARNING_DIR / "training_status.json", {
            "runtime_version": RUNTIME_VERSION, "identity_id": IDENTITY_ID,
            "confirmed_actions": int(STATE.get("confirmed_actions", 0)) if "STATE" in globals() else 0,
            "memory_report": report, "q_learning": Q_POLICY.snapshot() if "Q_POLICY" in globals() else {},
            "neural_network": network, "reflective_learning": LEARNER.estimate("exploration", []) if "LEARNER" in globals() else {},
            "versioned_knowledge": KNOWLEDGE.report() if "KNOWLEDGE" in globals() else {},
            "updated_at_utc": datetime.now(timezone.utc).isoformat(),
        })
        manifest = {
            "runtime_version": RUNTIME_VERSION, "game_id": GAME_ID, "identity_id": IDENTITY_ID,
            "authoritative_store": str(DATA_DIR), "shared_q_store": str(SHARED_LEARNING_DIR / "q_policy.json"),
            "project_data_is_snapshot": True, "memory_records": report.get("experiences", 0),
            "eligible_training_records": report.get("training_eligible_experiences", 0),
            "versioned_knowledge": KNOWLEDGE.report() if "KNOWLEDGE" in globals() else {},
            "updated_at_utc": datetime.now(timezone.utc).isoformat(),
            "note": "Files are real snapshots of recorded experience. They are zero until the game sends completed, confirmed actions.",
        }
        _atomic_json(DATA_MEMORY_DIR / "manifest.json", manifest)
        _atomic_json(DATA_PORTABLE_DIR / "manifest.json", manifest)
        # Backward-compatible portability exports for older project documentation.
        for src, dst_name in ((DATA_MEMORY_DIR / "world_memory.sqlite3", "world_memory.sqlite3"),
                              (STATE_PATH, "girl_state.json"), (NETWORK_PATH, "anna_value_model.json")):
            if src.exists():
                dst = DATA_PORTABLE_DIR / dst_name
                tmp = dst.with_name(dst.name + ".tmp")
                shutil.copy2(src, tmp)
                tmp.replace(dst)
    except Exception as exc:
        # Persistence is already committed before this export runs. Never let a
        # secondary snapshot/SQLite failure turn a confirmed episode into an HTTP
        # error that the game may retry. The authoritative store remains intact.
        _log_event("snapshot_export_failed", level="ERROR", error=type(exc).__name__, detail=str(exc)[:180])

ALLOWED_ACTIONS = {
    "wander", "approach_player", "forage", "rest", "inspect", "return_to_shelter",
    "avoid_player", "socialize", "observe"
}
SEMANTIC_BY_ACTION = {
    "wander": "exploration", "approach_player": "social_interaction", "forage": "resource_gathering",
    "rest": "rest", "inspect": "exploration", "return_to_shelter": "defend",
    "avoid_player": "defend", "socialize": "social_interaction", "observe": "observe",
}


def _clamp(v: Any, lo: float = 0.0, hi: float = 1.0, default: float = 0.0) -> float:
    try:
        x = float(v)
    except (TypeError, ValueError, OverflowError):
        x = default
    if not math.isfinite(x):
        x = default
    return max(lo, min(hi, x))


def _number(v: Any, default: float = 0.0) -> float:
    try:
        x = float(v)
        return x if math.isfinite(x) else default
    except (TypeError, ValueError, OverflowError):
        return default


def _resolved_world_id(world: dict[str, Any]) -> str:
    """Use a stable, sanitized world ID supplied by the game adapter.

    Keeping IDs separate prevents a laboratory scene's action estimates from being
    confused with the player's real, persistent Winter Shelter world.
    """
    raw: Any = world.get("world_id", WORLD_ID)
    if not isinstance(raw, str):
        return WORLD_ID
    sanitized: str = re.sub(r"[^A-Za-z0-9_.-]+", "_", raw.strip())[:96]
    return sanitized or WORLD_ID


def _load_profile() -> dict[str, Any]:
    data = json.loads(PROFILE_PATH.read_text(encoding="utf-8"))
    if not isinstance(data, dict) or data.get("character_id") != "anna":
        raise RuntimeError("Invalid girl lab character profile")
    return data


PROFILE = _load_profile()
LEARNER = ReflectiveLearner(VERSION_DIR / "reflective")
KNOWLEDGE = VersionedKnowledgeStore(SHARED_GTC_ROOT / "knowledge.sqlite3", current_version=RUNTIME_VERSION)
EMOTIONS = SimulatedEmotionModel()
MEMORY = WorldMemoryStore(DATA_DIR / "world_memory.sqlite3")
_PROFILE_INITIAL_EMOTIONS = PROFILE.get("initial_emotional_state", {})
_state_lock = threading.RLock()
_feedback_lock = threading.RLock()
_network_lock = threading.RLock()
_training_lock = threading.RLock()
_training_executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="GTC-Learning")
_training_future = None
_REPLAY_SAMPLER = PrioritizedReplaySampler(seed=11001, max_sample=768)
DECISION_TRACKER = DecisionTracker(timeout_seconds=15.0)


def _load_state() -> dict[str, Any]:
    default = {
        "schema_version": 1,
        "identity_id": IDENTITY_ID,
        "emotions": EMOTIONS.initial_state(_PROFILE_INITIAL_EMOTIONS),
        "confirmed_actions": 0,
        "last_action": "observe",
        "last_outcome": None,
        "updated_at_utc": None,
        "network_last_train_total": 0,
    }
    if not STATE_PATH.exists():
        return default
    try:
        raw = json.loads(STATE_PATH.read_text(encoding="utf-8"))
        if not isinstance(raw, dict) or raw.get("schema_version") != 1:
            return default
        result = dict(default)
        result.update(raw)
        result["emotions"] = EMOTIONS.initial_state(result.get("emotions"))
        result["confirmed_actions"] = max(0, int(result.get("confirmed_actions", 0)))
        return result
    except (OSError, json.JSONDecodeError, UnicodeDecodeError, TypeError, ValueError):
        # Preserve damaged file for diagnostics; recover in memory rather than crashing.
        return default


def _save_state() -> None:
    with _state_lock:
        STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
        state = dict(STATE)
        state["updated_at_utc"] = datetime.now(timezone.utc).isoformat()
        tmp = STATE_PATH.with_suffix(".tmp")
        tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
        tmp.replace(STATE_PATH)


def _train_network_batch(examples: list[dict[str, Any]], total_examples: int) -> dict[str, Any]:
    """Train away from the game feedback request so input/decision latency stays low."""
    try:
        with _network_lock:
            result = NETWORK.fit(examples, epochs=3, rate=0.012)
        if result.get("trained"):
            with _state_lock:
                STATE["network_last_train_total"] = max(int(STATE.get("network_last_train_total", 0)), int(total_examples))
            _save_state()
            _export_portable_snapshot()
        _log_event("background_training_completed", trained=bool(result.get("trained")),
                   samples=int(result.get("samples", 0)), updates=int(result.get("training_updates", 0)))
        return result
    except Exception as exc:
        _log_event("background_training_failed", level="ERROR", error=type(exc).__name__, detail=str(exc)[:160])
        return {"trained": False, "reason": "background_training_exception", "error": type(exc).__name__}


def _queue_network_training(examples: list[dict[str, Any]], total_examples: int) -> dict[str, Any]:
    global _training_future
    with _training_lock:
        if _training_future is not None and not _training_future.done():
            return {"trained": False, "queued": False, "reason": "training_batch_already_running",
                    "active": NETWORK.active, "samples": NETWORK.samples, "updates": NETWORK.updates}
        _training_future = _training_executor.submit(_train_network_batch, examples, total_examples)
    return {"trained": False, "queued": True, "reason": "background_training_queued",
            "total_verified_examples": int(total_examples), "active": NETWORK.active,
            "samples": NETWORK.samples, "updates": NETWORK.updates}


STATE = _load_state()


def _objects(world: dict[str, Any]) -> list[dict[str, Any]]:
    value = world.get("objects", [])
    return [x for x in value if isinstance(x, dict)] if isinstance(value, list) else []


def _object(world: dict[str, Any], object_id: str) -> dict[str, Any] | None:
    return next((o for o in _objects(world) if str(o.get("id", "")) == object_id and o.get("available", True)), None)


def _nearest(world: dict[str, Any], kind: str) -> dict[str, Any] | None:
    pos = world.get("position", {}) if isinstance(world.get("position"), dict) else {}
    px, pz = _number(pos.get("x")), _number(pos.get("z"))
    cooldowns = world.get("target_cooldowns", {}) if isinstance(world.get("target_cooldowns", {}), dict) else {}
    found = [
        o for o in _objects(world)
        if o.get("type") == kind and o.get("available", True)
        and _number(cooldowns.get(str(o.get("id", "")), 0.0)) <= 0.0
    ]
    found.sort(key=lambda o: (_number(o.get("x"))-px)**2 + (_number(o.get("z"))-pz)**2)
    return found[0] if found else None


class CharacterValueNetwork:
    """Small persistent MLP value estimator specialized for this character's action vocabulary."""
    ACTIONS = tuple(sorted(ALLOWED_ACTIONS))
    SCHEMA = 3

    def __init__(self, path: Path):
        self.path = path
        self.input_size = 13 + len(self.ACTIONS)
        self.hidden_size = 96  # Expanded capacity for GTC 0.1.9.3; migrated from the 60-unit model when possible.
        self.samples = 0
        self.minimum_samples = 240
        self.minimum_actions = 5
        self.covered_actions: list[str] = []
        rng = random.Random(18021)
        lim1 = math.sqrt(6 / (self.input_size + self.hidden_size))
        lim2 = math.sqrt(6 / (self.hidden_size + 1))
        self.w1 = [[rng.uniform(-lim1, lim1) for _ in range(self.input_size)] for _ in range(self.hidden_size)]
        self.b1 = [0.0] * self.hidden_size
        self.w2 = [rng.uniform(-lim2, lim2) for _ in range(self.hidden_size)]
        self.b2 = 0.0
        self.updates = 0
        self.warning = None
        if path.exists():
            self._load()

    @staticmethod
    def features(situation: dict[str, Any], action: dict[str, Any], agent_state: dict[str, Any] | None = None) -> list[float]:
        world = situation.get("world", situation)
        world = world if isinstance(world, dict) else {}
        needs = world.get("needs", {}) if isinstance(world.get("needs"), dict) else {}
        emotions = (agent_state or {}).get("emotions", {}) if isinstance((agent_state or {}).get("emotions", {}), dict) else {}
        num = lambda v: max(0.0, min(1.0, _number(v)))
        vals = [
            num(needs.get("food", 0.2)), num(needs.get("rest", 0.2)), num(needs.get("social", 0.2)),
            num(needs.get("safety", 0.2)), num(needs.get("curiosity", 0.5)),
            max(0.0, min(1.0, _number(world.get("player_distance", 10.0)) / 20.0)),
            num(world.get("coldness", 0.0)), num(emotions.get("trust", 0.3)), num(emotions.get("fear", 0.05)),
            num(emotions.get("fatigue", 0.0)), num(emotions.get("curiosity", 0.5)), num(emotions.get("loneliness", 0.2)),
            num(action.get("risk", 0.1)),
        ]
        name = str(action.get("action", "observe"))
        vals.extend(1.0 if name == known else 0.0 for known in CharacterValueNetwork.ACTIONS)
        return vals

    @staticmethod
    def _tanh(x: float) -> float:
        return math.tanh(max(-15.0, min(15.0, x)))

    def _forward(self, x: list[float]) -> tuple[list[float], float]:
        h = [self._tanh(sum(w*f for w, f in zip(row, x)) + b) for row, b in zip(self.w1, self.b1)]
        y = self._tanh(sum(w*v for w, v in zip(self.w2, h)) + self.b2)
        return h, y

    @property
    def active(self) -> bool:
        return self.samples >= self.minimum_samples and len(self.covered_actions) >= self.minimum_actions

    def predict(self, situation: dict[str, Any], action: dict[str, Any], state: dict[str, Any]) -> float:
        if not self.active:
            return 0.0
        _, value = self._forward(self.features(situation, action, state))
        return max(-1.0, min(1.0, value)) if math.isfinite(value) else 0.0

    def fit(self, examples: list[dict[str, Any]], epochs: int = 2, rate: float = 0.012) -> dict[str, Any]:
        valid = []
        for e in examples[-768:]:
            if not isinstance(e, dict) or not isinstance(e.get("features"), list):
                continue
            try:
                x = [float(v) for v in e["features"]]
                y = float(e["reward"])
            except (TypeError, ValueError, OverflowError):
                continue
            if len(x) != self.input_size or not all(math.isfinite(v) for v in x) or not math.isfinite(y):
                continue
            valid.append(([max(-1., min(1., v)) for v in x], max(-1., min(1., y)), str(e.get("action_name", ""))))
        if not valid:
            return {"trained": False, "reason": "no_verified_examples", "active": self.active}
        for _ in range(max(1, min(6, int(epochs)))):
            for x, target, _name in valid:
                hidden, output = self._forward(x)
                d_out = (output - target) * (1.0-output*output)
                old_w2 = list(self.w2)
                d_hidden = [d_out*old_w2[j]*(1-hidden[j]*hidden[j]) for j in range(self.hidden_size)]
                for j in range(self.hidden_size):
                    self.w2[j] -= rate*max(-1., min(1., d_out*hidden[j]))
                    for i in range(self.input_size):
                        self.w1[j][i] -= rate*max(-1., min(1., d_hidden[j]*x[i]))
                    self.b1[j] -= rate*max(-1., min(1., d_hidden[j]))
                self.b2 -= rate*max(-1., min(1., d_out))
        self.samples = len(valid)
        self.covered_actions = sorted({name for _, _, name in valid if name in self.ACTIONS})
        self.updates += 1
        self._save()
        return {"trained": True, "samples": self.samples, "action_coverage": self.covered_actions,
                "updates": self.updates, "active": self.active, "minimum_samples": self.minimum_samples,
                "minimum_actions": self.minimum_actions}

    def _save(self) -> None:
        payload = {"schema_version": self.SCHEMA, "input_size": self.input_size, "hidden_size": self.hidden_size,
                   "w1": self.w1, "b1": self.b1, "w2": self.w2, "b2": self.b2,
                   "samples": self.samples, "covered_actions": self.covered_actions, "updates": self.updates}
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
        tmp.replace(self.path)

    def _load(self) -> None:
        try:
            d = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(d, dict) or d.get("input_size") != self.input_size:
                self.warning = "model_schema_mismatch_fresh_weights_used"
                return
            old_hidden = int(d.get("hidden_size", 0))
            old_schema = int(d.get("schema_version", 0))
            w1, b1, w2 = d["w1"], d["b1"], d["w2"]
            if old_schema == 2 and old_hidden == 60 and self.hidden_size == 96:
                # Preserve the learned 60-unit subnetwork during a capacity upgrade.
                # Added output weights are zero, so newly initialized neurons do not
                # suddenly corrupt the former model's prediction before more training.
                if len(w1) != old_hidden or any(len(row) != self.input_size for row in w1) or len(b1) != old_hidden or len(w2) != old_hidden:
                    self.warning = "legacy_model_shape_invalid_fresh_weights_used"
                    return
                legacy_numbers = [float(v) for row in w1 for v in row] + [float(v) for v in b1] + [float(v) for v in w2] + [float(d["b2"])]
                if not all(math.isfinite(v) for v in legacy_numbers):
                    self.warning = "legacy_model_has_nonfinite_weights_fresh_weights_used"
                    return
                self.w1[:old_hidden] = [[float(v) for v in row] for row in w1]
                self.b1[:old_hidden] = [float(v) for v in b1]
                self.w2 = [float(v) for v in w2] + [0.0] * (self.hidden_size - old_hidden)
                self.b2 = float(d["b2"])
                self.samples = max(0, int(d.get("samples", 0)))
                self.covered_actions = [a for a in d.get("covered_actions", []) if a in self.ACTIONS]
                self.updates = max(0, int(d.get("updates", 0)))
                self.warning = "model_migrated_60_to_96_hidden_units"
                self._save()
                return
            if old_schema != self.SCHEMA or old_hidden != self.hidden_size:
                self.warning = "model_schema_mismatch_fresh_weights_used"
                return
            if len(w1) != self.hidden_size or any(len(row) != self.input_size for row in w1) or len(b1) != self.hidden_size or len(w2) != self.hidden_size:
                self.warning = "model_shape_invalid_fresh_weights_used"
                return
            all_numbers = [float(v) for row in w1 for v in row] + [float(v) for v in b1] + [float(v) for v in w2] + [float(d["b2"])]
            if not all(math.isfinite(v) for v in all_numbers):
                self.warning = "model_has_nonfinite_weights_fresh_weights_used"
                return
            self.w1, self.b1, self.w2, self.b2 = w1, b1, w2, float(d["b2"])
            self.samples = max(0, int(d.get("samples", 0)))
            self.covered_actions = [a for a in d.get("covered_actions", []) if a in self.ACTIONS]
            self.updates = max(0, int(d.get("updates", 0)))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError, KeyError, TypeError, ValueError, OverflowError):
            self.warning = "model_unreadable_fresh_weights_used"


# Keep model weights in a version-independent path. Migrate the 0.1.9 filename once,
# preserving the original file as a rollback copy.
if not NETWORK_PATH.exists() and LEGACY_NETWORK_PATH.exists():
    try:
        shutil.copy2(LEGACY_NETWORK_PATH, NETWORK_PATH)
    except OSError:
        pass
NETWORK = CharacterValueNetwork(NETWORK_PATH)
Q_POLICY = PersistentQPolicy(SHARED_LEARNING_DIR / "q_policy.json", actions=ALLOWED_ACTIONS, alpha=0.22, gamma=0.86)
SELF_MODEL = SelfModelStore(DATA_DIR / "self_model.json", identity_id=IDENTITY_ID,
                            profile=PROFILE, runtime_version=RUNTIME_VERSION)
BRAIN = AgentBrain(PROFILE, LEARNER)


def _ensure_world_registered(world: dict[str, Any]) -> None:
    world_id: str = _resolved_world_id(world)
    MEMORY.register_world(
        identity_id=IDENTITY_ID, game_id=GAME_ID, world_id=world_id,
        world_name=str(world.get("world_name", world_id))[:160], game_version="Godot 4.7.x",
        adapter_version=f"GTC-Girl-Bridge-{BUILD_ID}", session_id=SESSION_ID,
        summary={"npc": "anna", "area": str(world.get("world_name", world_id))[:160], "world_snapshot": "adapter supplied"},
    )


def _candidate(action: str, semantic: str, *, risk: float = 0.1, cost: float = 0.1,
               goals: dict[str, float] | None = None, needs: dict[str, float] | None = None,
               target_id: str = "", context: list[str] | None = None, benefit: float = 0.0) -> dict[str, Any]:
    c = {
        "action": action, "semantic_action": semantic, "preconditions_met": True,
        "evidence_confidence": 0.92, "risk": risk, "cost": cost,
        "context_tags": context or ["winter_forest", "girl_npc"],
        "goal_progress": goals or {}, "need_effects": needs or {}, "stakeholder_impact": [], "tags": [],
    }
    if target_id:
        c["target_id"] = target_id
    if benefit > 0:
        c["stakeholder_impact"] = [{"harm": 0.0, "benefit": benefit, "consent": True}]
    return c


def _versioned_knowledge_adjustment(semantic_key: str) -> float:
    """Use the newest versioned verified outcomes as a bounded decision prior."""
    try:
        records = KNOWLEDGE.recall(identity_id=IDENTITY_ID, semantic_key=str(semantic_key),
                                   game_id=GAME_ID, limit=24)
    except Exception as exc:
        _log_event("versioned_knowledge_recall_failed", level="WARNING", error=type(exc).__name__)
        return 0.0
    weighted_total = 0.0
    weight_sum = 0.0
    for index, record in enumerate(records):
        payload = record.get("payload", {})
        outcome = payload.get("outcome", {}) if isinstance(payload, dict) else {}
        achieved = outcome.get("goal_achieved") if isinstance(outcome, dict) else None
        if not isinstance(achieved, bool):
            continue
        confidence = max(0.0, min(1.0, _number(record.get("confidence", 0.0))))
        # Recall is already ordered by source version. Keep older lessons useful,
        # but let same/newer-version evidence exert more influence.
        version_weight = 1.0 if str(record.get("source_version", "")) == RUNTIME_VERSION else 0.72
        rank_weight = 1.0 / (1.0 + index * 0.06)
        weight = confidence * version_weight * rank_weight
        weighted_total += (1.0 if achieved else -1.0) * weight
        weight_sum += weight
    if weight_sum <= 0.0:
        return 0.0
    return max(-0.05, min(0.05, (weighted_total / weight_sum) * 0.05))


def _make_candidates(world: dict[str, Any], request_intent: str = "") -> list[dict[str, Any]]:
    needs = world.get("needs", {}) if isinstance(world.get("needs"), dict) else {}
    hunger = _clamp(needs.get("food", 0.15)); tired = _clamp(needs.get("rest", 0.15))
    lonely = _clamp(needs.get("social", 0.15)); fear = _clamp(needs.get("safety", 0.10))
    curiosity = _clamp(needs.get("curiosity", 0.60))
    distance = max(0.0, _number(world.get("player_distance", 10.0), 10.0))
    player = _object(world, "player")
    shelter = _object(world, "shelter")
    berries = _nearest(world, "food")
    tree = _nearest(world, "tree")
    waypoint = _object(world, str(world.get("wander_target_id", "path_a")))
    contexts = ["winter_forest", "girl_npc"]
    if distance < 4: contexts.append("near_player")
    if tired > 0.55: contexts.append("fatigue_high")
    if hunger > 0.55: contexts.append("hunger_high")
    if world.get("coldness", 0.0) > 0.45: contexts.append("cold_weather")
    goals = world.get("goal_priorities", {}) if isinstance(world.get("goal_priorities"), dict) else {}
    candidates: list[dict[str, Any]] = []
    candidates.append(_candidate("wander", "exploration", risk=0.08, cost=0.12,
        goals={"learn_world": 0.34, "stay_safe": 0.04}, needs={"curiosity": 0.35},
        target_id=str(waypoint.get("id", "path_a")) if waypoint else "", context=contexts))
    candidates.append(_candidate("rest", "rest", risk=0.01, cost=0.04,
        goals={"stay_safe": 0.08}, needs={"rest": 0.70}, context=contexts))
    candidates.append(_candidate("observe", "observe", risk=0.01, cost=0.03,
        goals={"learn_world": 0.18, "stay_safe": 0.12}, needs={"curiosity": 0.15, "safety": 0.12}, context=contexts))
    if player and distance > 1.55:
        candidates.append(_candidate("approach_player", "social_interaction", risk=0.12, cost=0.10,
            goals={"maintain_relationships": 0.28, "learn_world": 0.04}, needs={"social": 0.42},
            target_id="player", context=contexts, benefit=0.04))
    if player and distance <= 4.0:
        candidates.append(_candidate("socialize", "social_interaction", risk=0.08, cost=0.04,
            goals={"maintain_relationships": 0.34}, needs={"social": 0.55}, context=contexts, benefit=0.08))
    if berries and hunger > 0.18:
        candidates.append(_candidate("forage", "resource_gathering", risk=0.05, cost=0.09,
            goals={"preserve_resources": 0.12, "stay_safe": 0.06}, needs={"food": 0.70},
            target_id=str(berries.get("id", "")), context=contexts))
    if tree:
        candidates.append(_candidate("inspect", "exploration", risk=0.10, cost=0.08,
            goals={"learn_world": 0.43}, needs={"curiosity": 0.28},
            target_id=str(tree.get("id", "tree_a")), context=contexts))
    cold = _clamp(world.get("coldness", 0.0))
    if shelter and (cold > 0.20 or tired > 0.72 or fear > 0.55):
        candidates.append(_candidate("return_to_shelter", "defend", risk=0.04, cost=0.08,
            goals={"stay_safe": 0.36}, needs={"safety": 0.50, "rest": 0.18},
            target_id="shelter", context=contexts))
    if player and (distance < 2.7 or fear > 0.70):
        candidates.append(_candidate("avoid_player", "defend", risk=0.18, cost=0.10,
            goals={"stay_safe": 0.40}, needs={"safety": 0.42}, target_id="away_from_player", context=contexts))

    # Requests are low-weight influences, not direct commands. They never create unavailable actions.
    request_action = {
        "come": "approach_player", "talk": "socialize", "rest": "rest",
        "explore": "inspect", "leave_me": "avoid_player", "observe": "observe",
        "forage": "forage",
    }.get(request_intent, "")
    if request_action:
        for c in candidates:
            if c["action"] == request_action:
                gp = dict(c.get("goal_progress", {}))
                if request_intent == "come" or request_intent == "talk":
                    gp["maintain_relationships"] = _number(gp.get("maintain_relationships", 0.0)) + 0.10
                elif request_intent == "rest": gp["stay_safe"] = _number(gp.get("stay_safe", 0.0)) + 0.10
                elif request_intent == "explore": gp["learn_world"] = _number(gp.get("learn_world", 0.0)) + 0.10
                elif request_intent == "leave_me": gp["stay_safe"] = _number(gp.get("stay_safe", 0.0)) + 0.10
                c["goal_progress"] = gp
                c["requested_by_player"] = True
    # Conservative neural signal is only included after the model has enough confirmed coverage.
    situation = {"world": world, "context_tags": contexts}
    with _state_lock:
        agent_state = dict(STATE)
    # Keep a single read lock around predictions so a concurrent training batch
    # cannot expose half-updated weights to a decision.
    for c in candidates:
        with _network_lock:
            neural_value = NETWORK.predict(situation, c, agent_state)
        c["neural_value_adjustment"] = neural_value * 0.06
        est = MEMORY.get_action_estimate(identity_id=IDENTITY_ID, game_id=GAME_ID, world_id=_resolved_world_id(world),
            action_name=c["action"], semantic_action=c["semantic_action"], limit=120)
        if est.get("has_data"):
            c["persistent_memory_adjustment"] = max(-0.08, min(0.08, _number(est.get("mean_reward", 0.0)) * 0.10))
        else:
            c["persistent_memory_adjustment"] = 0.0
        c["q_learning_adjustment"] = Q_POLICY.adjustment(world, str(c["action"]), str(c["semantic_action"]))
        c["versioned_knowledge_adjustment"] = _versioned_knowledge_adjustment(str(c["semantic_action"]))
    return candidates


def _parse_intent(text: str) -> str:
    t = text.casefold().replace("ё", "е").strip()
    if any(x in t for x in ("иди сюда", "подойди", "ко мне", "следуй за мной", "пойдем со мной", "come here", "follow me")):
        return "come"
    if any(x in t for x in ("поговори", "давай поговорим", "пообщайся", "скажи мне", "talk to me")):
        return "talk"
    if any(x in t for x in ("отдохни", "поспи", "иди спать", "отдохнуть", "rest")):
        return "rest"
    if any(x in t for x in ("исследуй", "осмотри", "изучи", "разведай", "explore")):
        return "explore"
    if any(x in t for x in ("оставь меня", "отстань", "отойди", "не подходи", "leave me alone")):
        return "leave_me"
    if any(x in t for x in ("поищи ягоды", "собери ягоды", "найди еду", "покушай", "forage")):
        return "forage"
    if any(x in t for x in ("осмотрись", "наблюдай", "посмотри вокруг", "observe")):
        return "observe"
    return "dialogue"


def _action_label(action: str) -> str:
    return {
        "wander": "исследовать окрестности", "approach_player": "подойти к тебе",
        "forage": "поискать ягоды и еду", "rest": "отдохнуть",
        "inspect": "изучить ближайший объект", "return_to_shelter": "вернуться к укрытию",
        "avoid_player": "увеличить дистанцию", "socialize": "пообщаться с тобой",
        "observe": "понаблюдать за миром",
    }.get(action, "заняться своими делами")


def _reply(text: str, intent: str, chosen: dict[str, Any] | None, emotions: dict[str, Any]) -> str:
    action = str((chosen or {}).get("action", "observe"))
    why = _action_label(action)
    t = text.casefold()
    if intent == "dialogue":
        if any(q in t for q in ("почему", "зачем", "что делаешь", "что ты делаешь", "что решила")):
            return f"Сейчас я решила {why}. Любопытство, безопасность и моё состояние тоже влияют на выбор, а не только твои просьбы."
        if any(q in t for q in ("привет", "здравствуй", "hello", "hi")):
            return "Привет. Я тебя слышу, но у меня есть и собственные дела — посмотрим, что покажется мне важнее."
        return f"Я услышала тебя. Сейчас мой выбор — {why}. Я учитываю твои слова, но не обязана автоматически им подчиняться."
    if chosen and chosen.get("requested_by_player") and action == {"come":"approach_player","talk":"socialize","rest":"rest","explore":"inspect","leave_me":"avoid_player","forage":"forage","observe":"observe"}.get(intent):
        return f"Хорошо, сейчас я решила {why}. Это мой выбор в текущих обстоятельствах, а не безусловное подчинение."
    return f"Я поняла просьбу, но решила {why}. Сейчас для меня это выглядит важнее; позже я могу пересмотреть решение."


def _record_adapter_knowledge(world: dict[str, Any], candidates: list[dict[str, Any]]) -> None:
    """Remember what the authoritative adapter currently exposes, not guessed abilities."""
    world_id = _resolved_world_id(world)
    object_types = sorted({str(item.get("type", "")) for item in _objects(world) if item.get("type")})
    action_names = sorted({str(item.get("action", "")) for item in candidates if item.get("action")})
    semantic_actions = sorted({str(item.get("semantic_action", "unknown")) for item in candidates if item.get("semantic_action")})
    try:
        SELF_MODEL.record_available_capabilities(
            game_id=str(world.get("game_id", GAME_ID)), world_id=world_id,
            actions=action_names, object_types=object_types, runtime_version=RUNTIME_VERSION,
        )
        for semantic in semantic_actions:
            statement = f"The game adapter exposes the semantic action category '{semantic}' when current preconditions are met."
            MEMORY.record_mechanic(
                identity_id=IDENTITY_ID, game_id=str(world.get("game_id", GAME_ID)), world_id=world_id,
                semantic_key=f"available_action_{semantic}", statement=statement, scope="world",
                confidence=0.85, verified=True,
                conditions={"available_actions": action_names, "observed_object_types": object_types},
                effects={}, source="authoritative_game_adapter", source_version=RUNTIME_VERSION,
            )
    except Exception as exc:
        _log_event("capability_observation_failed", level="WARNING", error=type(exc).__name__)


def _record_confirmed_semantic_outcome(world: dict[str, Any], action: dict[str, Any], outcome: dict[str, Any], reward: float) -> None:
    """Record a scoped outcome pattern and promote only after multiple worlds/games agree."""
    semantic = str(action.get("semantic_action", SEMANTIC_BY_ACTION.get(str(action.get("action", "")), "unknown")))
    if semantic in ("", "unknown"):
        return
    achieved = outcome.get("goal_achieved") is True
    outcome_kind = "success" if achieved else "failure"
    key = f"outcome_{semantic}_{outcome_kind}"
    statement = (
        f"An action in semantic category '{semantic}' achieved its declared goal under verified execution."
        if achieved else
        f"An action in semantic category '{semantic}' did not achieve its declared goal under verified execution."
    )
    world_id = _resolved_world_id(world)
    game_id = str(world.get("game_id", GAME_ID))
    try:
        MEMORY.record_mechanic(
            identity_id=IDENTITY_ID, game_id=game_id, world_id=world_id,
            semantic_key=key, statement=statement, scope="world", confidence=0.70,
            verified=True, conditions={"action_name": str(action.get("action", "unknown")),
                                       "context_tags": action.get("context_tags", [])},
            effects={"reward": max(-1.0, min(1.0, float(reward))), "observed_harm": _number(outcome.get("observed_harm", 0.0))},
            source="verified_game_feedback", source_version=RUNTIME_VERSION,
        )
        promoted = MEMORY.promote_mechanic(identity_id=IDENTITY_ID, semantic_key=key,
                                            statement=statement, minimum_observations=3, minimum_games=2)
        if promoted.get("promoted"):
            _log_event("cross_game_mechanic_promoted", semantic_action=semantic, outcome=outcome_kind,
                       games=promoted.get("game_count"), observations=promoted.get("observation_count"))
    except Exception as exc:
        _log_event("mechanic_learning_failed", level="WARNING", error=type(exc).__name__)


def _decision_inner_state() -> dict[str, Any]:
    with _state_lock:
        emotions = dict(STATE.get("emotions", {}))
        confirmed = int(STATE.get("confirmed_actions", 0))
    return {
        "emotions": emotions,
        "confirmed_actions": confirmed,
        "learning_samples": MEMORY.count_training_examples(identity_id=IDENTITY_ID, game_id=GAME_ID),
        "neural_network": {
            "active": NETWORK.active, "samples": NETWORK.samples,
            "covered_actions": NETWORK.covered_actions, "updates": NETWORK.updates,
            "hidden_units": NETWORK.hidden_size,
            "parameter_count": NETWORK.input_size * NETWORK.hidden_size + 2 * NETWORK.hidden_size + 1,
        },
        "q_learning": Q_POLICY.snapshot(),
        "self_model": SELF_MODEL.snapshot(),
        "load_warnings": {"reflective_learner": LEARNER.load_warning, "neural_network": NETWORK.warning},
        "decision_lifecycle": DECISION_TRACKER.snapshot(),
    }


def _decision_response(world: dict[str, Any], *, action: dict[str, Any], decision_id: str | None,
                       should_execute: bool, status: str, reason: str,
                       chosen_score: float | None = None, top_candidates: list[dict[str, Any]] | None = None,
                       rejected_candidates: list[dict[str, Any]] | None = None,
                       request_intent: str | None = None, reply: str = "",
                       duplicate: bool = False, age_seconds: float | None = None) -> dict[str, Any]:
    return {
        "ok": True,
        "character_id": "anna",
        "identity_id": IDENTITY_ID,
        "game_id": GAME_ID,
        "world_id": _resolved_world_id(world),
        "decision_id": decision_id,
        "action": action,
        "chosen_score": chosen_score,
        "top_candidates": top_candidates or [],
        "rejected_candidates": rejected_candidates or [],
        "reason": reason,
        "decision_status": status,
        "should_execute": bool(should_execute),
        "duplicate_proposal": bool(duplicate),
        "pending_age_seconds": age_seconds,
        "request_intent": request_intent,
        "request_obeyed": bool(action.get("requested_by_player", False)),
        "reply": reply,
        "inner_state": _decision_inner_state(),
        "must_confirm_execution_with_godot": True,
        "execution_policy": {
            "execute_once": True,
            "deduplicate_by": "decision_id",
            "feedback_required": True,
            "default_timeout_seconds": DECISION_TRACKER.timeout_seconds,
            "timeouts_are_not_training_failures": True,
        },
    }


def choose(world: dict[str, Any], text: str = "") -> dict[str, Any]:
    _ensure_world_registered(world)
    world_key = f"{world.get('game_id', GAME_ID)}:{_resolved_world_id(world)}"
    state_key = state_fingerprint(world)

    # The same in-flight command is returned with the same ID. A game adapter must
    # execute it once, then report its result; polling /think is not a new command.
    pending = DECISION_TRACKER.get_pending(world_key)
    if pending is not None:
        action = pending["action"]
        return _decision_response(
            world, action=action, decision_id=pending["decision_id"], should_execute=False,
            status="awaiting_feedback", reason="same_decision_still_pending",
            top_candidates=[{"action": action.get("action"), "target_id": action.get("target_id", ""),
                             "status": "already_proposed"}],
            duplicate=True, age_seconds=pending.get("age_seconds"),
        )

    intent = _parse_intent(text) if text else ""
    with _state_lock:
        STATE["emotions"] = EMOTIONS.decay(STATE.get("emotions", {}), 1)
        emotions = dict(STATE["emotions"])
    candidates = _make_candidates(world, intent)
    _record_adapter_knowledge(world, candidates)

    # A timed-out action is not labelled as a failure. It is only avoided in the
    # same unchanged state until the world changes or late feedback arrives.
    cautioned = DECISION_TRACKER.cautioned_actions(world_key, state_key)
    eligible = [candidate for candidate in candidates if action_key(candidate) not in cautioned]
    result = BRAIN.choose_action(world, eligible, emotions) if eligible else {
        "decision": "pause_and_observe", "chosen_action": None, "chosen_score": None,
        "ranked_candidates": [], "rejected_candidates": [],
        "reason": "all_available_actions_timed_out_without_feedback",
    }
    chosen = result.get("chosen_action")
    if not isinstance(chosen, dict):
        # This is deliberately non-executable. It tells the adapter that GTC has
        # exhausted unconfirmed options rather than pretending it chose a command.
        fallback = {"action": "observe", "semantic_action": "observe", "preconditions_met": True, "target_id": ""}
        return _decision_response(
            world, action=fallback, decision_id=None, should_execute=False,
            status="adapter_feedback_missing", reason=str(result.get("reason", "no_valid_action")),
            rejected_candidates=result.get("rejected_candidates", []), request_intent=intent or None,
        )

    chosen = dict(chosen)
    if chosen.get("action") not in ALLOWED_ACTIONS:
        fallback = {"action": "observe", "semantic_action": "observe", "preconditions_met": True, "target_id": ""}
        return _decision_response(
            world, action=fallback, decision_id=None, should_execute=False,
            status="invalid_adapter_action", reason="selected_action_not_allowlisted",
            request_intent=intent or None,
        )

    decision = DECISION_TRACKER.create(
        world_key, state_key, chosen,
        timeout_seconds=_number(world.get("action_timeout_seconds", 15.0), 15.0),
    )
    chosen = decision["action"]
    is_new_decision = not bool(decision.get("reused", False))
    if not is_new_decision:
        return _decision_response(
            world, action=chosen, decision_id=decision["decision_id"], should_execute=False,
            status="awaiting_feedback", reason="concurrent_request_reused_existing_decision",
            top_candidates=[{"action": chosen.get("action"), "target_id": chosen.get("target_id", ""),
                             "status": "already_proposed"}],
            duplicate=True, age_seconds=decision.get("age_seconds"),
        )
    SELF_MODEL.record_decision(
        action=str(chosen.get("action", "observe")),
        reason=str(result.get("reason", "highest_expected_utility")),
        context_tags=list(chosen.get("context_tags", [])) if isinstance(chosen.get("context_tags", []), list) else [],
    )
    _log_event(
        "decision", decision_id=decision["decision_id"], action=str(chosen.get("action", "observe")),
        target_id=str(chosen.get("target_id", "")), game_id=str(world.get("game_id", GAME_ID)),
        world_id=_resolved_world_id(world), candidate_count=len(result.get("ranked_candidates", [])),
        q_adjustment=chosen.get("q_learning_adjustment", 0.0),
        reason=str(result.get("reason", "highest_expected_utility")),
        decision_timeout_seconds=decision["timeout_seconds"],
    )
    with _state_lock:
        STATE["last_action"] = str(chosen.get("action", "observe"))
    _save_state()
    reply = _reply(text, intent, chosen, emotions) if text else ""
    return _decision_response(
        world, action=chosen, decision_id=decision["decision_id"], should_execute=True,
        status="proposed", reason=str(result.get("reason", "highest_expected_utility")),
        chosen_score=result.get("chosen_score"), top_candidates=result.get("ranked_candidates", [])[:5],
        rejected_candidates=result.get("rejected_candidates", []), request_intent=intent or None, reply=reply,
    )


def _valid_payload(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict): raise ValueError("body_must_be_object")
    world = payload.get("world")
    if not isinstance(world, dict): raise ValueError("world_snapshot_required")
    if len(json.dumps(world, ensure_ascii=False)) > 900_000: raise ValueError("world_snapshot_too_large")
    if str(world.get("game_id", GAME_ID)) != GAME_ID: raise ValueError("wrong_game_id")
    return payload


def _learning_reward(world_before: dict[str, Any], world_after: dict[str, Any], action: dict[str, Any], outcome: dict[str, Any]) -> tuple[float, dict[str, float]]:
    """Shaped reward: goal progress, needs, safety, cost and verified novelty."""
    components: dict[str, float] = {}
    action_name = str(action.get("action", "observe"))
    success = outcome.get("goal_achieved") is True
    if not success:
        components["goal_failure"] = -0.24
    elif action_name == "observe":
        components["goal_completed"] = 0.10
    elif action_name == "wander":
        components["goal_completed"] = 0.24
    elif action_name == "inspect" and outcome.get("novelty_verified") is not True:
        components["goal_completed"] = 0.12
    else:
        components["goal_completed"] = 0.48
    components["constraint_respected"] = 0.06 if outcome.get("constraints_respected") is True else -0.75
    components["observed_harm"] = -0.90 * max(0.0, min(1.0, _clamp(outcome.get("observed_harm", 0.0))))
    components["unexpected_cost"] = -0.22 * max(0.0, min(1.0, _clamp(outcome.get("unexpected_cost", 0.0))))
    reason = str(outcome.get("failure_reason", ""))
    if reason in {"timeout", "movement_stuck_collision", "blocked"}:
        components["movement_failure"] = -0.18
    elif reason in {"target_not_found", "precondition_missing"}:
        components["invalid_target_or_precondition"] = -0.15
    elif reason == "goal_not_reached":
        components["goal_not_reached"] = -0.10
    before_needs = world_before.get("needs", {}) if isinstance(world_before.get("needs"), dict) else {}
    after_needs = world_after.get("needs", {}) if isinstance(world_after.get("needs"), dict) else {}
    progress = 0.0
    weights = {"food": 0.12, "rest": 0.12, "social": 0.08, "safety": 0.12, "curiosity": 0.05}
    for need, weight in weights.items():
        improvement = _number(before_needs.get(need, 0.0)) - _number(after_needs.get(need, before_needs.get(need, 0.0)))
        contribution = max(-0.35, min(0.35, improvement)) * weight
        if abs(contribution) > 1e-9:
            components[f"need_progress_{need}"] = contribution
            progress += contribution
    if outcome.get("novelty_verified") is True and success and action_name in {"inspect", "wander"}:
        components["verified_novelty"] = 0.06
    if outcome.get("constraints_respected") is not True and outcome.get("execution_confirmed") is True:
        components["confirmed_constraint_violation"] = -0.25
    reward = max(-1.0, min(1.0, sum(components.values())))
    return round(reward, 6), {key: round(value, 6) for key, value in components.items()}


def _process_feedback(payload: dict[str, Any], world: dict[str, Any]) -> dict[str, Any]:
    action = payload.get("action")
    outcome = payload.get("outcome")
    situation = payload.get("situation", {})
    world_before = payload.get("world_before", world)
    agent_state = payload.get("agent_state", {})
    if not isinstance(action, dict) or action.get("action") not in ALLOWED_ACTIONS:
        raise ValueError("invalid_action")
    if not isinstance(outcome, dict) or not isinstance(situation, dict):
        raise ValueError("outcome_and_situation_required")
    if not isinstance(world_before, dict):
        world_before = world
    if not isinstance(agent_state, dict):
        agent_state = {}

    world_key = f"{world_before.get('game_id', GAME_ID)}:{_resolved_world_id(world_before)}"
    raw_decision_id = payload.get("decision_id") or action.get("command_id")
    raw_event_id = payload.get("experience_id")
    if isinstance(raw_decision_id, str) and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}", raw_decision_id):
        decision_feedback = DECISION_TRACKER.acknowledge(raw_decision_id, str(action.get("action", "")))
    elif isinstance(raw_event_id, str) and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}", raw_event_id):
        # Compatibility path for adapters that historically echoed only experience_id.
        decision_feedback = DECISION_TRACKER.acknowledge(raw_event_id, str(action.get("action", "")))
    else:
        decision_feedback = DECISION_TRACKER.acknowledge_current(world_key, str(action.get("action", "")))
    if (not decision_feedback.get("accepted") and decision_feedback.get("reason") == "unknown_decision_id"
            and not action.get("command_id") and not payload.get("decision_id")):
        decision_feedback = DECISION_TRACKER.acknowledge_current(world_key, str(action.get("action", "")))
    if decision_feedback.get("reason") == "action_name_mismatch":
        raise ValueError("decision_action_mismatch")

    decision_matched = decision_feedback.get("accepted") is True
    # A duplicate acknowledgement must not create a second experience, even if
    # an adapter accidentally changes experience_id while retrying the same command.
    if decision_feedback.get("duplicate") is True:
        return {
            "ok": True, "duplicate": True, "decision_id": decision_feedback.get("decision_id"),
            "learning": {"stored": False, "ignored": True, "reason": "duplicate_decision_feedback"},
            "memory": {"stored": False, "duplicate": True},
            "neural": {"trained": False, "reason": "duplicate_decision_feedback", "active": NETWORK.active,
                       "samples": NETWORK.samples, "updates": NETWORK.updates},
            "q_learning": {"updated": False, "reason": "duplicate_decision_feedback"},
            "inner_state": {"emotions": STATE.get("emotions", {}),
                            "confirmed_actions": STATE.get("confirmed_actions", 0),
                            "q_learning": Q_POLICY.snapshot(), "versioned_knowledge": KNOWLEDGE.report(), "self_model": SELF_MODEL.snapshot()},
        }

    # The adapter's `verified` flag is not sufficient by itself: the feedback
    # must correlate with a command that GTC actually proposed. Unmatched reports
    # remain in the audit log/memory as unverified and cannot affect learning.
    if not decision_matched:
        outcome = dict(outcome)
        outcome["verified"] = False
        outcome["execution_confirmed"] = False
        outcome["verification_block_reason"] = "decision_feedback_not_correlated"

    if decision_matched and decision_feedback.get("decision_id"):
        # Use the proposal ID as the durable experience ID so retries cannot
        # bypass deduplication by changing a secondary experience_id field.
        event_id = str(decision_feedback["decision_id"])
    elif isinstance(raw_event_id, str) and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}", raw_event_id):
        event_id = raw_event_id
    elif isinstance(raw_decision_id, str) and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}", raw_decision_id):
        event_id = raw_decision_id
    else:
        event_id = uuid.uuid4().hex
    _log_event("decision_feedback", decision_id=decision_feedback.get("decision_id", raw_decision_id or ""),
               action=str(action.get("action", "unknown")), matched=decision_matched,
               match_reason=str(decision_feedback.get("reason", "matched" if decision_matched else "unmatched")),
               verified=decision_matched and outcome.get("verified") is True,
               execution_confirmed=decision_matched and outcome.get("execution_confirmed") is True)

    world_id_for_experience = _resolved_world_id(world_before)
    features = CharacterValueNetwork.features(
        {"world": world_before}, action,
        {"emotions": agent_state.get("emotions", STATE.get("emotions", {}))},
    )
    memory_result = MEMORY.record_experience(
        identity_id=IDENTITY_ID, game_id=GAME_ID, world_id=world_id_for_experience,
        session_id=SESSION_ID, runtime_version=RUNTIME_VERSION,
        situation={"world": world_before, "context_tags": situation.get("context_tags", [])},
        action=action, outcome=outcome, features=features, experience_id=event_id,
    )
    # A retry after a dropped HTTP response must not double-count a lesson or
    # train twice on the same action. The durable event ID makes feedback idempotent.
    if memory_result.get("duplicate"):
        return {
            "ok": True, "duplicate": True,
            "learning": {"stored": False, "ignored": True, "reason": "duplicate_experience_id"},
            "memory": memory_result,
            "neural": {"trained": False, "reason": "duplicate_experience_id", "active": NETWORK.active,
                       "samples": NETWORK.samples, "updates": NETWORK.updates},
            "q_learning": {"updated": False, "reason": "duplicate_experience_id"},
            "inner_state": {"emotions": STATE.get("emotions", {}),
                            "confirmed_actions": STATE.get("confirmed_actions", 0),
                            "q_learning": Q_POLICY.snapshot(), "versioned_knowledge": KNOWLEDGE.report(), "self_model": SELF_MODEL.snapshot()},
        }

    learner_result = LEARNER.record(situation, action, outcome)
    net_result: dict[str, Any] = {"trained": False, "reason": "outcome_not_verified", "active": NETWORK.active,
                                  "samples": NETWORK.samples, "updates": NETWORK.updates}
    # Execution must be confirmed, but a confirmed rule violation is still valuable negative evidence.
    verified = (outcome.get("verified") is True and outcome.get("execution_confirmed") is True)
    knowledge_result: dict[str, Any] = {"stored": False, "reason": "outcome_not_verified"}
    if verified:
        semantic_key = str(action.get("semantic_action", SEMANTIC_BY_ACTION.get(str(action.get("action", "")), "unknown")))
        goal_ok = outcome.get("goal_achieved") is True
        knowledge_result = KNOWLEDGE.add(
            identity_id=IDENTITY_ID, game_id=GAME_ID, semantic_key=semantic_key,
            statement=f"{action.get('action', 'unknown')} in {GAME_ID}: {'achieved the intended goal' if goal_ok else 'did not achieve the intended goal'}.",
            payload={"action": action, "outcome": outcome, "world_id": world_id_for_experience},
            verified=True, confidence=0.88 if goal_ok and outcome.get("constraints_respected") is True else 0.72,
            source_kind="confirmed_game_feedback", source_version=RUNTIME_VERSION, record_id=event_id,
        )
        with _state_lock:
            STATE["confirmed_actions"] = int(STATE.get("confirmed_actions", 0)) + 1
            event_kind = "action_success" if outcome.get("goal_achieved") is True else "action_failure"
            if _number(outcome.get("observed_harm", 0.0)) > 0.0:
                event_kind = "action_failure"
            STATE["emotions"] = EMOTIONS.apply_event(STATE.get("emotions", {}), {"kind": event_kind, "intensity": 1.0})
            STATE["last_outcome"] = {"action": action.get("action"), "goal_achieved": outcome.get("goal_achieved"),
                                      "reward": memory_result.get("reward"), "experience_id": event_id}

        raw_reward, reward_components = _learning_reward(world_before, world, action, outcome)
        _record_confirmed_semantic_outcome(world, action, outcome, raw_reward)
        before_key = Q_POLICY.state_key(world_before)
        after_key = Q_POLICY.state_key(world)
        try:
            next_candidates = _make_candidates(world)
            next_actions = [str(candidate.get("action", "")) for candidate in next_candidates
                            if candidate.get("preconditions_met") is True]
            q_result = Q_POLICY.update(
                state_key=before_key, action=str(action.get("action", "observe")),
                semantic_action=str(action.get("semantic_action", SEMANTIC_BY_ACTION.get(str(action.get("action", "")), "unknown"))),
                reward=raw_reward, next_state_key=after_key, next_actions=next_actions,
                game_id=str(world.get("game_id", GAME_ID)), success=outcome.get("goal_achieved") is True,
                target_id=str(action.get("target_id", "")), terminal=False,
            )
            q_result["reward_components"] = reward_components
        except Exception as exc:
            q_result = {"updated": False, "error": type(exc).__name__}
            _log_event("q_learning_update_failed", level="ERROR", error=type(exc).__name__)

        # Promote a semantic lesson across worlds only after verified evidence
        # spans multiple games. Native action IDs are never copied to another game.
        semantic_key = str(action.get("semantic_action", SEMANTIC_BY_ACTION.get(str(action.get("action", "")), "unknown")))
        try:
            promotion = MEMORY.promote_portable_experience(
                identity_id=IDENTITY_ID, semantic_action=semantic_key, minimum_examples=3, minimum_games=2,
            )
            if promotion.get("promoted"):
                already_promoted = any(
                    item.get("game_id") == "*" and item.get("source_version") == RUNTIME_VERSION
                    and item.get("source_kind") == "cross_game_promotion"
                    for item in KNOWLEDGE.recall(identity_id=IDENTITY_ID, semantic_key=semantic_key,
                                                 game_id=GAME_ID, limit=100)
                )
                if not already_promoted:
                    estimate = MEMORY.get_action_estimate(
                        identity_id=IDENTITY_ID, game_id=GAME_ID, world_id=world_id_for_experience,
                        action_name=str(action.get("action", "unknown")), semantic_action=semantic_key, limit=500,
                    )
                    mean_reward = _number(estimate.get("mean_reward", 0.0))
                    KNOWLEDGE.add(
                        identity_id=IDENTITY_ID, game_id="*", semantic_key=semantic_key,
                        statement=f"Portable semantic lesson promoted after verified outcomes across {promotion.get('game_count', 0)} games.",
                        payload={"outcome": {"goal_achieved": mean_reward > 0.0, "mean_reward": mean_reward},
                                 "promotion": promotion, "portable_semantic_only": True},
                        verified=True, confidence=max(0.50, min(0.90, _number(estimate.get("confidence", 0.65)))),
                        source_kind="cross_game_promotion", source_version=RUNTIME_VERSION,
                        record_id=f"portable:{semantic_key}:{BUILD_ID}",
                    )
        except Exception as exc:
            _log_event("portable_knowledge_promotion_failed", level="WARNING",
                       semantic_action=semantic_key, error=type(exc).__name__)

        total_examples = MEMORY.count_training_examples(identity_id=IDENTITY_ID, game_id=GAME_ID)
        last_trained_total = max(0, int(STATE.get("network_last_train_total", 0)))
        # Faster incremental replay: first useful batch at 20 verified examples,
        # then every 4 new unique outcomes. Full history remains intact in SQLite.
        should_train = total_examples >= 20 and (NETWORK.updates == 0 or total_examples - last_trained_total >= 4)
        if should_train:
            replay_pool = MEMORY.get_training_examples(identity_id=IDENTITY_ID, game_id=GAME_ID, limit=5000)
            action_counts: dict[str, int] = {}
            for item in replay_pool:
                name = str(item.get("action_name", "unknown"))
                action_counts[name] = action_counts.get(name, 0) + 1
            pool_size = max(1, len(replay_pool))
            position_by_id = {str(item.get("experience_id", index)): index
                              for index, item in enumerate(replay_pool)}
            examples = _REPLAY_SAMPLER.sample(
                replay_pool, count=768,
                priority=lambda item: (1.0 + 0.55 * abs(_number(item.get("reward", 0.0)))
                    + 0.35 / max(1, action_counts.get(str(item.get("action_name", "unknown")), 1)) ** 0.5
                    + 0.20 * (position_by_id.get(str(item.get("experience_id", "")), 0) + 1) / pool_size),
            )
            # Queue the CPU batch so the game receives feedback promptly. The worker
            # commits weights and the training checkpoint after fitting completes.
            net_result = _queue_network_training(examples, total_examples)
        else:
            net_result = {
                "trained": False,
                "reason": "waiting_for_20_examples_or_4_new_outcomes",
                "total_verified_examples": total_examples,
                "next_training_at": 20 if total_examples < 20 else last_trained_total + 4,
                "active": NETWORK.active, "samples": NETWORK.samples, "updates": NETWORK.updates,
            }

        SELF_MODEL.record_outcome(
            action=str(action.get("action", "unknown")), outcome=outcome,
            reward=float(q_result.get("reward_used", raw_reward)),
        )
        _save_state()
        _export_portable_snapshot()
        _log_event("confirmed_outcome", experience_id=event_id, action=str(action.get("action", "unknown")),
                   semantic_action=str(action.get("semantic_action", "unknown")), success=outcome.get("goal_achieved") is True,
                   constraints_respected=outcome.get("constraints_respected") is True,
                   reward=float(q_result.get("reward_used", raw_reward)), reward_components=reward_components,
                   q_value=q_result.get("q_value"), q_transitions=Q_POLICY.transitions,
                   memory_stored=bool(memory_result.get("stored")), knowledge_stored=bool(knowledge_result.get("stored")), neural_trained=bool(net_result.get("trained")))
    net_result["total_verified_examples"] = MEMORY.count_training_examples(identity_id=IDENTITY_ID, game_id=GAME_ID)
    return {"ok": True, "experience_id": event_id, "learning": learner_result,
            "memory": memory_result, "neural": net_result, "q_learning": q_result if verified else {"updated": False, "reason": "unverified_execution"},
            "inner_state": {"emotions": STATE.get("emotions", {}),
                            "confirmed_actions": STATE.get("confirmed_actions", 0),
                            "total_verified_examples": MEMORY.count_training_examples(identity_id=IDENTITY_ID, game_id=GAME_ID),
                            "q_learning": Q_POLICY.snapshot(), "versioned_knowledge": KNOWLEDGE.report(), "self_model": SELF_MODEL.snapshot()}}


def process_request(path: str, payload: dict[str, Any]) -> dict[str, Any]:
    payload = _valid_payload(payload)
    world = payload["world"]
    if path == "/girl/think":
        return choose(world)
    if path == "/girl/chat":
        text = payload.get("text")
        if not isinstance(text, str) or not text.strip():
            raise ValueError("text_required")
        return choose(world, text.strip()[:1500])
    if path == "/girl/feedback":
        with _feedback_lock:
            return _process_feedback(payload, world)
    raise ValueError("unknown_endpoint")

class Handler(BaseHTTPRequestHandler):
    server_version = f"GenTC-Girl-Bridge/{BUILD_ID}"
    def _write(self, status: int, body: dict[str, Any]) -> None:
        raw = json.dumps(body, ensure_ascii=False, allow_nan=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)
    def do_GET(self) -> None:
        if self.path == "/health":
            self._write(200, {"ok": True, "name": "GenTC AI Girl Lab", "version": VERSION, "build_id": BUILD_ID, "service": "girl_character_bridge",
                "llm_connected": False, "identity_id": IDENTITY_ID, "data_dir": str(DATA_DIR),
                "confirmed_actions": STATE.get("confirmed_actions", 0),
                "persistent_training_examples": MEMORY.count_training_examples(identity_id=IDENTITY_ID, game_id=GAME_ID),
                "network_last_train_total": STATE.get("network_last_train_total", 0),
                "neural_network": {"active": NETWORK.active, "samples": NETWORK.samples, "total_verified_examples": MEMORY.count_training_examples(identity_id=IDENTITY_ID, game_id=GAME_ID), "updates": NETWORK.updates,
                    "hidden_units": NETWORK.hidden_size, "parameter_count": NETWORK.input_size * NETWORK.hidden_size + NETWORK.hidden_size + NETWORK.hidden_size + 1,
                    "minimum_samples": NETWORK.minimum_samples, "minimum_actions": NETWORK.minimum_actions,
                    "model_path": str(NETWORK_PATH)},
                "q_learning": Q_POLICY.snapshot(), "versioned_knowledge": KNOWLEDGE.report(),
                "project_data_dir": str(DATA_ROOT), "self_model": SELF_MODEL.snapshot(),
                "decision_lifecycle": DECISION_TRACKER.snapshot(),
                "bind": HOST, "port": PORT}); return
        if self.path == "/diagnostics":
            self._write(200, {"ok": True, "build_id": BUILD_ID,
                "decision_lifecycle": DECISION_TRACKER.snapshot(),
                "confirmed_actions": STATE.get("confirmed_actions", 0),
                "last_action": STATE.get("last_action", "observe"),
                "last_outcome": STATE.get("last_outcome"), "versioned_knowledge": KNOWLEDGE.report(),
                "model_learning_root": str(SHARED_GTC_ROOT)}); return
        if self.path == "/self":
            self._write(200, {"ok": True, "self_model": SELF_MODEL.snapshot(), "data_dir": str(DATA_DIR)}); return
        if self.path == "/memory":
            self._write(200, {"ok": True, "memory": MEMORY.report(identity_id=IDENTITY_ID), "data_dir": str(DATA_DIR),
                "state_path": str(STATE_PATH), "model_path": str(NETWORK_PATH),
                "network_last_train_total": STATE.get("network_last_train_total", 0),
                "neural_network": {"active": NETWORK.active, "samples": NETWORK.samples, "covered_actions": NETWORK.covered_actions,
                                   "updates": NETWORK.updates}, "q_learning": Q_POLICY.snapshot(),
                "versioned_knowledge": KNOWLEDGE.report(), "project_data_dir": str(DATA_ROOT)}); return
        self._write(404, {"ok": False, "error": "not_found"})
    def do_POST(self) -> None:
        if self.path not in {"/girl/think", "/girl/chat", "/girl/feedback"}:
            self._write(404, {"ok": False, "error": "not_found"}); return
        try:
            size = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self._write(400, {"ok": False, "error": "invalid_content_length"}); return
        if size <= 0 or size > MAX_BODY_BYTES:
            self._write(413, {"ok": False, "error": "body_size_out_of_range"}); return
        try:
            raw = self.rfile.read(size).decode("utf-8")
            payload = json.loads(raw)
            result = process_request(self.path, payload)
        except (UnicodeDecodeError, json.JSONDecodeError):
            self._write(400, {"ok": False, "error": "invalid_json"}); return
        except ValueError as exc:
            self._write(400, {"ok": False, "error": str(exc)[:200]}); return
        except Exception as exc:
            print(f"[GTC Girl] Internal exception: {type(exc).__name__}", file=sys.stderr)
            traceback.print_exc(file=sys.stderr)
            self._write(500, {"ok": False, "error": "internal_error"}); return
        self._write(200, result)
    def log_message(self, fmt: str, *args: object) -> None:
        print(f"[GTC Girl] {self.address_string()} - {fmt % args}")


def main() -> int:
    try:
        server = ThreadingHTTPServer((HOST, PORT), Handler)
    except OSError as exc:
        print(f"Could not listen on {HOST}:{PORT}: {type(exc).__name__}", file=sys.stderr)
        print("Check whether port 8767 is already used.", file=sys.stderr)
        return 2
    print("=" * 64)
    _export_portable_snapshot()
    _log_event("server_start", port=PORT, data_dir=str(DATA_DIR), project_data_dir=str(DATA_ROOT),
               q_transitions=Q_POLICY.transitions, neural_samples=NETWORK.samples)
    print(f"GenTC AI {VERSION} ({BUILD_ID}) — AUTONOMOUS LEARNING BRIDGE")
    print(f"HTTP bridge: http://{HOST}:{PORT}")
    print("GET /health | GET /diagnostics | GET /memory | GET /self | POST /girl/think | /girl/chat | /girl/feedback")
    print("No LLM: grounded Russian templates. 96-unit value network and persistent Q-learning update from confirmed game outcomes.")
    print(f"Runtime log: {RUNTIME_LOG_PATH}")
    print(f"Data snapshots: {DATA_ROOT}")
    print(f"Persistent data: {DATA_DIR}")
    print("Only localhost is exposed. Keep this window open while testing; Ctrl+C exits.")
    print("=" * 64)
    try: server.serve_forever()
    except KeyboardInterrupt: print("\nGTC Girl bridge stopped.")
    finally:
        _export_portable_snapshot()
        _log_event("server_stop", q_transitions=Q_POLICY.transitions, neural_samples=NETWORK.samples)
        server.server_close()
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
