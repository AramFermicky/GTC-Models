"""Persistent, screen-only episodic learning for the Undertale adapter.

Feedback is explicitly weak visual feedback, not ground-truth labels. The module
never reads process memory or game saves. A coarse visual signature groups frames
that appear to belong to the same scene; a small experience graph stores actions
and their observed consequences across launches.
"""
from __future__ import annotations

import json
import math
import sqlite3
import time
from collections import OrderedDict, deque
from datetime import datetime
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, TYPE_CHECKING

from gentc_ai.integration.undertale_policy import INPUT_SIZE

if TYPE_CHECKING:
    from gentc_ai.integration.undertale_agent import Frame

GRID_W = 8
GRID_H = 6
SIMILARITY_THRESHOLD = 0.88


@dataclass(frozen=True)
class SceneMatch:
    state_id: str
    is_new: bool
    similarity: float
    features: tuple[int, ...]


def extract_features(frame: Frame) -> tuple[int, ...]:
    """Quantize a small grid of mean colors, suppressing single-sprite noise."""
    out: list[int] = []
    for gy in range(GRID_H):
        y0 = gy * frame.height // GRID_H
        y1 = max(y0 + 1, (gy + 1) * frame.height // GRID_H)
        for gx in range(GRID_W):
            x0 = gx * frame.width // GRID_W
            x1 = max(x0 + 1, (gx + 1) * frame.width // GRID_W)
            rs = gs = bs = count = 0
            # Sample inside each cell instead of processing every pixel.
            step_y = max(1, (y1 - y0) // 12)
            step_x = max(1, (x1 - x0) // 12)
            for y in range(y0, y1, step_y):
                for x in range(x0, x1, step_x):
                    r, g, b = frame.pixel(x, y)
                    rs += r; gs += g; bs += b; count += 1
            n = max(1, count)
            out.extend((round(rs / n / 32), round(gs / n / 32), round(bs / n / 32)))
    return tuple(max(0, min(8, v)) for v in out)


def feature_similarity(a: Iterable[int], b: Iterable[int]) -> float:
    aa, bb = tuple(a), tuple(b)
    if not aa or len(aa) != len(bb):
        return 0.0
    cells = len(aa) // 3
    matches = 0
    for i in range(0, len(aa), 3):
        # Small color changes from animations and the player sprite are tolerated.
        if all(abs(aa[i + j] - bb[i + j]) <= 1 for j in range(3)):
            matches += 1
    return matches / max(1, cells)


def visual_change(a: Iterable[int], b: Iterable[int]) -> float:
    aa, bb = tuple(a), tuple(b)
    if not aa or len(aa) != len(bb):
        return 0.0
    return sum(abs(x - y) for x, y in zip(aa, bb)) / (8.0 * len(aa))


def frame_change(a: Frame | None, b: Frame) -> float:
    """Fraction of sampled screen points whose RGB color changed materially.

    Unlike the coarse scene descriptor, this measure can notice a small player
    sprite moving inside the same room. It remains an unreliable proxy because
    dialogue animation and environmental effects also change pixels.
    """
    if a is None or a.width != b.width or a.height != b.height:
        return 1.0
    cols = min(96, max(32, a.width // 3))
    rows = min(72, max(24, a.height // 3))
    changed = 0
    samples = cols * rows
    for gy in range(rows):
        y = min(a.height - 1, (gy * a.height) // rows)
        for gx in range(cols):
            x = min(a.width - 1, (gx * a.width) // cols)
            ar, ag, ab = a.pixel(x, y)
            br, bg, bb = b.pixel(x, y)
            if abs(ar - br) + abs(ag - bg) + abs(ab - bb) >= 45:
                changed += 1
    return changed / max(1, samples)


class UndertaleLearningMemory:
    """SQLite scene/action experience store with a tiny graph frontier planner."""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(str(self.path), timeout=10.0, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=NORMAL")
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS scenes(
                state_id TEXT PRIMARY KEY,
                features_json TEXT NOT NULL,
                visits INTEGER NOT NULL DEFAULT 0,
                first_seen REAL NOT NULL,
                last_seen REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS action_values(
                state_id TEXT NOT NULL,
                mode TEXT NOT NULL,
                action TEXT NOT NULL,
                visits INTEGER NOT NULL DEFAULT 0,
                mean_reward REAL NOT NULL DEFAULT 0,
                last_reward REAL NOT NULL DEFAULT 0,
                last_seen REAL NOT NULL,
                PRIMARY KEY(state_id, mode, action)
            );
            CREATE TABLE IF NOT EXISTS global_values(
                mode TEXT NOT NULL,
                action TEXT NOT NULL,
                visits INTEGER NOT NULL DEFAULT 0,
                mean_reward REAL NOT NULL DEFAULT 0,
                PRIMARY KEY(mode, action)
            );
            CREATE TABLE IF NOT EXISTS q_values(
                state_id TEXT NOT NULL,
                mode TEXT NOT NULL,
                action TEXT NOT NULL,
                visits INTEGER NOT NULL DEFAULT 0,
                q_value REAL NOT NULL DEFAULT 0,
                last_reward REAL NOT NULL DEFAULT 0,
                last_seen REAL NOT NULL,
                PRIMARY KEY(state_id, mode, action)
            );
            CREATE INDEX IF NOT EXISTS ix_q_values_mode_action ON q_values(mode, action);
            CREATE TABLE IF NOT EXISTS transitions(
                from_state TEXT NOT NULL,
                action TEXT NOT NULL,
                to_state TEXT NOT NULL,
                count INTEGER NOT NULL DEFAULT 0,
                mean_reward REAL NOT NULL DEFAULT 0,
                last_seen REAL NOT NULL,
                PRIMARY KEY(from_state, action, to_state)
            );
            CREATE TABLE IF NOT EXISTS events(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL NOT NULL,
                mode TEXT NOT NULL,
                from_state TEXT NOT NULL,
                action TEXT NOT NULL,
                to_state TEXT NOT NULL,
                reward REAL NOT NULL,
                visual_change REAL NOT NULL,
                details_json TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS ix_events_ts ON events(ts);
            CREATE INDEX IF NOT EXISTS ix_events_state_action ON events(from_state, mode, action, id);
            CREATE TABLE IF NOT EXISTS action_attempts(
                state_id TEXT NOT NULL,
                mode TEXT NOT NULL,
                action TEXT NOT NULL,
                attempts INTEGER NOT NULL DEFAULT 0,
                consecutive_no_progress INTEGER NOT NULL DEFAULT 0,
                last_seen REAL NOT NULL,
                last_change REAL NOT NULL DEFAULT 0,
                last_reward REAL NOT NULL DEFAULT 0,
                PRIMARY KEY(state_id, mode, action)
            );
            CREATE INDEX IF NOT EXISTS ix_attempts_mode_state ON action_attempts(mode, state_id);
            CREATE TABLE IF NOT EXISTS human_demonstrations(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL NOT NULL,
                mode TEXT NOT NULL,
                from_state TEXT NOT NULL,
                action TEXT NOT NULL,
                to_state TEXT NOT NULL,
                visual_change REAL NOT NULL,
                duration REAL NOT NULL DEFAULT 0,
                details_json TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS ix_human_demo_state_mode
                ON human_demonstrations(from_state, mode, action);
            CREATE INDEX IF NOT EXISTS ix_human_demo_mode_action
                ON human_demonstrations(mode, action);
            CREATE TABLE IF NOT EXISTS runtime_logs(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL NOT NULL,
                mode TEXT NOT NULL,
                action TEXT NOT NULL,
                event TEXT,
                observation_json TEXT,
                details_json TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS ix_runtime_logs_ts ON runtime_logs(ts);
            CREATE TABLE IF NOT EXISTS visual_observations(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL NOT NULL,
                source TEXT NOT NULL,
                mode TEXT NOT NULL,
                state_id TEXT NOT NULL,
                feature_signature TEXT NOT NULL,
                visual_delta REAL NOT NULL DEFAULT 0,
                observation_json TEXT NOT NULL,
                context_json TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS ix_visual_observations_ts ON visual_observations(ts);
            CREATE INDEX IF NOT EXISTS ix_visual_observations_state ON visual_observations(state_id, ts);
            CREATE TABLE IF NOT EXISTS metadata(
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS human_key_events(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL NOT NULL,
                mode TEXT NOT NULL,
                state_id TEXT NOT NULL,
                key_name TEXT NOT NULL,
                event_type TEXT NOT NULL,
                held_keys_json TEXT NOT NULL,
                scene_features_json TEXT,
                details_json TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS ix_human_key_events_ts ON human_key_events(ts);
            CREATE TABLE IF NOT EXISTS policy_examples(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL NOT NULL,
                mode TEXT NOT NULL,
                action TEXT NOT NULL,
                features_json TEXT NOT NULL,
                target REAL NOT NULL,
                source TEXT NOT NULL,
                sample_weight REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS ix_policy_examples_mode_action_id
                ON policy_examples(mode, action, id);
            CREATE INDEX IF NOT EXISTS ix_policy_examples_target_id
                ON policy_examples(target, id);
            CREATE INDEX IF NOT EXISTS ix_policy_examples_source_id
                ON policy_examples(source, id);
            CREATE INDEX IF NOT EXISTS ix_scenes_signature ON scenes(features_json);
            CREATE TABLE IF NOT EXISTS blocked_actions(
                state_id TEXT NOT NULL,
                mode TEXT NOT NULL,
                action TEXT NOT NULL,
                count INTEGER NOT NULL DEFAULT 0,
                last_seen REAL NOT NULL,
                PRIMARY KEY(state_id, mode, action)
            );
            CREATE TABLE IF NOT EXISTS self_reflections(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL NOT NULL,
                mode TEXT NOT NULL,
                state_id TEXT NOT NULL,
                objective TEXT NOT NULL,
                candidate_action TEXT NOT NULL,
                reasoning_json TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS ix_self_reflections_ts ON self_reflections(ts);
        """)
        self.db.commit()
        self._import_legacy_observations()
        # The full history stays in SQLite; this bounded cache speeds scene matching.
        self._scene_feature_cache: OrderedDict[str, tuple[int, ...]] = OrderedDict()
        self._scene_cache_limit = 768
        self._load_scene_feature_cache()

    def _load_scene_feature_cache(self) -> None:
        try:
            recent = self.db.execute(
                "SELECT state_id,features_json FROM scenes ORDER BY last_seen DESC LIMIT 512").fetchall()
            frequent = self.db.execute(
                "SELECT state_id,features_json FROM scenes ORDER BY visits DESC,last_seen DESC LIMIT 256").fetchall()
            for row in (*frequent, *recent):
                try:
                    self._cache_scene(str(row["state_id"]), tuple(int(v) for v in json.loads(row["features_json"])))
                except (TypeError, ValueError, json.JSONDecodeError):
                    continue
        except sqlite3.Error:
            self._scene_feature_cache = OrderedDict()

    def _cache_scene(self, state_id: str, features: tuple[int, ...]) -> None:
        self._scene_feature_cache.pop(state_id, None)
        self._scene_feature_cache[state_id] = features
        while len(self._scene_feature_cache) > self._scene_cache_limit:
            self._scene_feature_cache.popitem(last=False)

    def _import_legacy_observations(self) -> None:
        """Merge the old JSONL diagnostic file into SQLite once, then remove the duplicate."""
        legacy_path = self.path.parent / "pilot_observations.jsonl"
        if not legacy_path.is_file():
            return
        marker = self.db.execute("SELECT value FROM metadata WHERE key='legacy_observations_imported'").fetchone()
        if marker:
            return
        try:
            raw_lines = legacy_path.read_text(encoding="utf-8-sig", errors="replace").splitlines()
            imported = 0
            for line in raw_lines:
                if not line.strip():
                    continue
                try:
                    item = json.loads(line)
                except json.JSONDecodeError:
                    item = {"raw_line": line, "legacy_parse_error": True}
                if not isinstance(item, dict):
                    item = {"legacy_value": item}
                ts_value: float = time.time()
                stamp = item.get("timestamp")
                if isinstance(stamp, str):
                    try:
                        ts_value = datetime.fromisoformat(stamp.replace("Z", "+00:00")).timestamp()
                    except ValueError:
                        pass
                observation = item.get("observation")
                self.db.execute(
                    "INSERT INTO runtime_logs(ts,mode,action,event,observation_json,details_json) VALUES(?,?,?,?,?,?)",
                    (ts_value, str(item.get("world_id", "legacy")), str(item.get("action", "none")),
                     str(item.get("event")) if item.get("event") is not None else "legacy_import",
                     json.dumps(observation, ensure_ascii=False) if observation is not None else None,
                     json.dumps(item, ensure_ascii=False)))
                imported += 1
            self.db.execute("INSERT OR REPLACE INTO metadata(key,value) VALUES('legacy_observations_imported',?)",
                            (str(imported),))
            self.db.commit()
        except (OSError, sqlite3.Error) as exc:
            # Preserve the original file if migration cannot be completed.
            self.db.rollback()
            return
        # Source rows are now committed to the same SQLite DB. Delete only after a
        # successful import and marker commit, avoiding two active log locations.
        try:
            legacy_path.unlink()
        except OSError:
            pass

    def close(self) -> None:
        self.db.close()

    def identify(self, frame: Frame) -> SceneMatch:
        features = extract_features(frame)
        signature_json = json.dumps(features)
        # Exact matches query the full persistent history, including old sessions.
        exact = self.db.execute(
            "SELECT state_id FROM scenes WHERE features_json=? ORDER BY last_seen DESC LIMIT 1",
            (signature_json,)).fetchone()
        now = time.time()
        if exact:
            state_id = str(exact["state_id"])
            self._cache_scene(state_id, features)
            self.db.execute("UPDATE scenes SET visits=visits+1,last_seen=? WHERE state_id=?", (now, state_id))
            self.db.commit()
            return SceneMatch(state_id, False, 1.0, features)

        # Approximate matches scan a bounded cache of recent and frequently seen states
        # rather than re-reading/decoding 1,500 SQLite JSON rows on every frame.
        best_id = ""
        best_similarity = 0.0
        for cached_id, other in self._scene_feature_cache.items():
            sim = feature_similarity(features, other)
            if sim > best_similarity:
                best_id, best_similarity = cached_id, sim
                if sim >= 0.999:
                    break
        is_new = not best_id or best_similarity < SIMILARITY_THRESHOLD
        if is_new:
            n = self.db.execute("SELECT COUNT(*) FROM scenes").fetchone()[0] + 1
            state_id = f"scene-{n:06d}"
            self.db.execute("INSERT INTO scenes(state_id,features_json,visits,first_seen,last_seen) VALUES(?,?,?,?,?)",
                            (state_id, signature_json, 0, now, now))
            self._cache_scene(state_id, features)
        else:
            state_id = best_id
            self._cache_scene(state_id, self._scene_feature_cache.get(state_id, features))
            self.db.execute("UPDATE scenes SET visits=visits+1,last_seen=? WHERE state_id=?", (now, state_id))
        self.db.commit()
        return SceneMatch(state_id, is_new, 1.0 if is_new else best_similarity, features)

    def _track_action_attempt(self, state_id: str, mode: str, action: str,
                              to_state: str, reward: float, change: float, learn: bool,
                              now: float) -> None:
        """Track attempts even when their result is neutral; neutral is not a reward label."""
        if not action or action in {"none", "idle", "wait", "observe"}:
            return
        row = self.db.execute(
            "SELECT attempts,consecutive_no_progress,last_seen FROM action_attempts WHERE state_id=? AND mode=? AND action=?",
            (state_id, mode, action)).fetchone()
        attempts = int(row["attempts"]) if row else 0
        consecutive = int(row["consecutive_no_progress"]) if row else 0
        last_seen = float(row["last_seen"]) if row else 0.0
        # Break a stall streak after a meaningful pause; the raw event remains in history.
        if now - last_seen > 18.0:
            consecutive = 0
        no_progress = str(state_id) == str(to_state) and float(change) < 0.003
        if no_progress:
            consecutive += 1
        else:
            consecutive = 0
        last_reward = float(reward) if learn else 0.0
        self.db.execute(
            """INSERT INTO action_attempts(state_id,mode,action,attempts,consecutive_no_progress,last_seen,last_change,last_reward)
               VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(state_id,mode,action) DO UPDATE SET
               attempts=action_attempts.attempts+1,
               consecutive_no_progress=excluded.consecutive_no_progress,
               last_seen=excluded.last_seen,last_change=excluded.last_change,
               last_reward=CASE WHEN excluded.last_reward!=0 THEN excluded.last_reward ELSE action_attempts.last_reward END""",
            (state_id, mode, action, attempts + 1, consecutive, now, float(change), last_reward))

    def action_attempt_stats(self, state_id: str | None, mode: str,
                             actions: list[str]) -> dict[str, dict[str, int | float]]:
        """Return compact state/action attempt history, including neutral actions."""
        if not actions:
            return {}
        modes = ("battle", "sans_battle") if mode == "battle" else (mode,)
        mode_marks = ",".join("?" for _ in modes)
        action_marks = ",".join("?" for _ in actions)
        if state_id:
            rows = self.db.execute(
                f"SELECT action,SUM(attempts) AS attempts,MAX(consecutive_no_progress) AS stalled,MAX(last_change) AS last_change,MAX(last_seen) AS last_seen FROM action_attempts WHERE state_id=? AND mode IN ({mode_marks}) AND action IN ({action_marks}) GROUP BY action",
                (state_id, *modes, *actions)).fetchall()
        else:
            rows = self.db.execute(
                f"SELECT action,SUM(attempts) AS attempts,MAX(consecutive_no_progress) AS stalled,MAX(last_change) AS last_change,MAX(last_seen) AS last_seen FROM action_attempts WHERE mode IN ({mode_marks}) AND action IN ({action_marks}) GROUP BY action",
                (*modes, *actions)).fetchall()
        now = time.time()
        result: dict[str, dict[str, int | float]] = {}
        for row in rows:
            recent_stall = int(row["stalled"] or 0) if now - float(row["last_seen"] or 0) <= 18.0 else 0
            result[str(row["action"])] = {
                "attempts": int(row["attempts"] or 0),
                "consecutive_no_progress": recent_stall,
                "last_change": float(row["last_change"] or 0.0),
                "last_seen": float(row["last_seen"] or 0.0),
            }
        return result

    def resolve_blocked_attempt(self, state_id: str, mode: str, action: str) -> None:
        """Expire an old obstruction hint after the same direction demonstrably moves."""
        # Keep the historical row and all events; only the short-lived avoidance hint expires.
        self.db.execute(
            "UPDATE blocked_actions SET last_seen=? WHERE state_id=? AND mode=? AND action=?",
            (time.time() - 60.0, state_id, mode, action))
        self.db.commit()

    def record_blocked_attempt(self, state_id: str, mode: str, action: str) -> int:
        """Persist a suspected obstruction without assigning reward/penalty yet."""
        now = time.time()
        self.db.execute("""INSERT INTO blocked_actions(state_id,mode,action,count,last_seen)
            VALUES(?,?,?,1,?) ON CONFLICT(state_id,mode,action) DO UPDATE SET
            count=CASE WHEN excluded.last_seen-blocked_actions.last_seen>18.0 THEN 1 ELSE blocked_actions.count+1 END,
            last_seen=excluded.last_seen""", (state_id, mode, action, now))
        self.db.commit()
        row = self.db.execute("SELECT count FROM blocked_actions WHERE state_id=? AND mode=? AND action=?",
                              (state_id, mode, action)).fetchone()
        return int(row["count"]) if row else 1

    def blocked_count(self, state_id: str, mode: str, action: str) -> int:
        row = self.db.execute("SELECT count,last_seen FROM blocked_actions WHERE state_id=? AND mode=? AND action=?",
                              (state_id, mode, action)).fetchone()
        if not row or time.time() - float(row["last_seen"]) > 18.0:
            return 0
        return int(row["count"])

    def record_reflection(self, mode: str, state_id: str, objective: str, candidate_action: str,
                          reasoning: dict) -> None:
        self.db.execute("INSERT INTO self_reflections(ts,mode,state_id,objective,candidate_action,reasoning_json) VALUES(?,?,?,?,?,?)",
                         (time.time(), mode, state_id or "unknown", objective, candidate_action,
                          json.dumps(reasoning, ensure_ascii=False, allow_nan=False)))
        self.db.commit()

    def demonstration_counts(self, state_id: str | None, mode: str,
                             actions: list[str] | None = None) -> dict[str, int]:
        """Count real player demonstrations separately from reward-labelled actions."""
        modes = ("battle", "sans_battle") if mode == "battle" else (mode,)
        placeholders = ",".join("?" for _ in modes)
        if state_id:
            rows = self.db.execute(
                f"SELECT action,COUNT(*) AS n FROM human_demonstrations WHERE from_state=? AND mode IN ({placeholders}) GROUP BY action",
                (state_id, *modes)).fetchall()
        else:
            rows = self.db.execute(
                f"SELECT action,COUNT(*) AS n FROM human_demonstrations WHERE mode IN ({placeholders}) GROUP BY action",
                modes).fetchall()
        result = {str(row["action"]): int(row["n"]) for row in rows}
        if actions is not None:
            return {action: result.get(action, 0) for action in actions}
        return result

    def choose_action(self, state_id: str, mode: str, actions: list[str],
                      neural_scores: dict[str, float] | None = None) -> str:
        if not actions:
            return "none"
        modes = ("battle", "sans_battle") if mode == "battle" else (mode,)
        placeholders = ",".join("?" for _ in modes)
        rows = self.db.execute(f"SELECT action,SUM(visits) AS visits,AVG(mean_reward) AS mean_reward FROM action_values WHERE state_id=? AND mode IN ({placeholders}) GROUP BY action",
                               (state_id, *modes)).fetchall()
        local = {r["action"]: (int(r["visits"]), float(r["mean_reward"])) for r in rows}
        global_rows = self.db.execute(f"SELECT action,SUM(visits) AS visits,AVG(mean_reward) AS mean_reward FROM global_values WHERE mode IN ({placeholders}) GROUP BY action", modes).fetchall()
        global_values = {r["action"]: (int(r["visits"]), float(r["mean_reward"])) for r in global_rows}
        local_total = sum(v[0] for v in local.values())
        local_demo = self.demonstration_counts(state_id, mode, actions)
        global_demo = self.demonstration_counts(None, mode, actions)
        attempt_stats = self.action_attempt_stats(state_id, mode, actions)
        q_estimates = {action: self.q_value_for(state_id, mode, action) for action in actions}
        now_wall = time.time()
        unknown = [a for a in actions if local.get(a, (0, 0.0))[0] == 0
                   and (int(attempt_stats.get(a, {}).get("attempts", 0)) == 0
                        or now_wall - float(attempt_stats.get(a, {}).get("last_seen", 0.0)) > 120.0)]
        # A human demonstration is a useful prior: when an action demonstrated by
        # the player has not yet been tried autonomously in this scene, prefer it.
        # It remains a preference, not proof that the action was optimal.
        if unknown:
            demonstrated_unknown = [a for a in unknown if local_demo.get(a, 0) > 0]
            if demonstrated_unknown:
                return max(demonstrated_unknown, key=lambda a: (local_demo[a], -actions.index(a)))
            if neural_scores:
                return max(unknown, key=lambda a: (float(neural_scores.get(a, 0.0)), -actions.index(a)))
            offset = sum(ord(c) for c in state_id) % len(actions)
            order = actions[offset:] + actions[:offset]
            return next(a for a in order if a in unknown)
        if mode == "overworld":
            frontier_action = self.planned_frontier_action(state_id, actions)
            if frontier_action in actions:
                # Human-provided routing evidence should take priority when it
                # points to the same known frontier action.
                return frontier_action
        total_global = sum(v[0] for v in global_values.values()) + 1
        local_demo_total = sum(local_demo.values())
        global_demo_total = sum(global_demo.values())
        def score(action: str) -> float:
            visits, value = local.get(action, (0, 0.0))
            gv, gvalue = global_values.get(action, (0, 0.0))
            blended = 0.70 * value + 0.30 * gvalue
            ucb = 0.22 * math.sqrt(math.log(local_total + 2) / (visits + 1))
            global_ucb = 0.10 * math.sqrt(math.log(total_global + 2) / (gv + 1))
            local_human_prior = 0.22 * local_demo.get(action, 0) / max(1, local_demo_total)
            global_human_prior = 0.06 * global_demo.get(action, 0) / max(1, global_demo_total)
            neural_prior = max(-1.0, min(1.0, float((neural_scores or {}).get(action, 0.0)))) * 0.14
            q_prior = max(-1.0, min(1.0, float(q_estimates.get(action, (0, 0.0))[1]))) * 0.24
            attempts = attempt_stats.get(action, {})
            attempt_count = int(attempts.get("attempts", 0))
            stall_count = int(attempts.get("consecutive_no_progress", 0))
            last_attempt = float(attempts.get("last_seen", 0.0))
            recent_attempt = now_wall - last_attempt <= 120.0
            # Neutral attempts do not update reward estimates or count as bad rewards.
            # They only shape the *next choice*: avoid repeating the same ineffective
            # input immediately, while allowing old actions to be explored again later.
            attempt_penalty = 0.12 if recent_attempt and stall_count >= 1 else 0.0
            stall_penalty = min(0.90, max(0, stall_count - 1) * 0.42)
            blocked_penalty = min(0.90, 0.35 * self.blocked_count(state_id or "", mode, action))
            return (0.78 * blended + q_prior + ucb + global_ucb + local_human_prior + global_human_prior + neural_prior
                    - attempt_penalty - stall_penalty - blocked_penalty)
        return max(actions, key=score)

    def record_demonstration(self, mode: str, from_state: str, action: str, to_state: str,
                             change: float, duration: float = 0.0,
                             details: dict | None = None,
                             policy_features: Iterable[float] | None = None) -> None:
        """Store a player-shown action as a behavior prior, not as reward ground truth."""
        now = time.time()
        clean_change = max(0.0, min(1.0, float(change)))
        duration = max(0.0, min(120.0, float(duration)))
        payload = dict(details or {})
        payload.update({"source": "human_demonstration", "reward_label": False,
                        "outcome_verified": False})
        self.db.execute(
            "INSERT INTO human_demonstrations(ts,mode,from_state,action,to_state,visual_change,duration,details_json) VALUES(?,?,?,?,?,?,?,?)",
            (now, mode, from_state, action, to_state, clean_change, duration,
             json.dumps(payload, ensure_ascii=False)))
        # Preserve human traversed edges for the existing BFS path planner, without
        # averaging their neutral demonstration reward into autonomous reward values.
        self.db.execute(
            """INSERT INTO transitions(from_state,action,to_state,count,mean_reward,last_seen)
               VALUES(?,?,?,1,0,?) ON CONFLICT(from_state,action,to_state)
               DO UPDATE SET count=transitions.count+1,last_seen=excluded.last_seen""",
            (from_state, action, to_state, now))
        if policy_features is not None:
            try:
                encoded = [float(v) for v in policy_features]
                if len(encoded) == INPUT_SIZE and all(math.isfinite(v) for v in encoded):
                    # Human demonstrations are imitation hints only; they are not
                    # fabricated as successful reward labels.
                    self.db.execute(
                        "INSERT INTO policy_examples(ts,mode,action,features_json,target,source,sample_weight) VALUES(?,?,?,?,?,?,?)",
                        (now, mode, action, json.dumps(encoded), 0.35, "human_demo", 0.25))
            except (TypeError, ValueError, OverflowError):
                pass
        self.db.commit()

    def record_human_key_event(self, mode: str, state_id: str, key_name: str,
                               event_type: str, held_keys: Iterable[str],
                               scene_features: Iterable[int] | None = None,
                               details: dict | None = None) -> None:
        """Persist key-down/up transitions with timestamps and the observed scene."""
        valid_events = {"down", "up"}
        if event_type not in valid_events:
            raise ValueError("event_type must be 'down' or 'up'")
        features_json = json.dumps(list(scene_features)) if scene_features is not None else None
        self.db.execute(
            "INSERT INTO human_key_events(ts,mode,state_id,key_name,event_type,held_keys_json,scene_features_json,details_json) VALUES(?,?,?,?,?,?,?,?)",
            (time.time(), mode, state_id or "unknown", str(key_name), event_type,
             json.dumps(sorted(set(held_keys))), features_json, json.dumps(details or {}, ensure_ascii=False)))
        self.db.commit()

    def policy_example_count(self) -> int:
        return int(self.db.execute("SELECT COUNT(*) FROM policy_examples").fetchone()[0])

    def policy_training_examples(self, limit: int = 256) -> list[dict]:
        """Return bounded prioritized replay without deleting or rewriting history.

        The minibatch combines recent experience, high-magnitude negative/positive
        feedback, and human demonstrations. Priority affects sampling only: it does
        not turn a neutral action into a reward, and original SQLite rows stay intact.
        """
        limit = max(16, min(512, int(limit)))
        lane_size = min(1024, max(64, limit * 3))
        conn = sqlite3.connect(str(self.path), timeout=5.0)
        conn.row_factory = sqlite3.Row
        try:
            lanes = [
                conn.execute(
                    "SELECT id,ts,mode,action,features_json,target,source,sample_weight "
                    "FROM policy_examples ORDER BY id DESC LIMIT ?", (lane_size,)).fetchall(),
                conn.execute(
                    "SELECT id,ts,mode,action,features_json,target,source,sample_weight "
                    "FROM policy_examples WHERE target<=-0.25 ORDER BY target ASC,id DESC LIMIT ?",
                    (lane_size,)).fetchall(),
                conn.execute(
                    "SELECT id,ts,mode,action,features_json,target,source,sample_weight "
                    "FROM policy_examples WHERE target>=0.25 ORDER BY target DESC,id DESC LIMIT ?",
                    (lane_size,)).fetchall(),
                conn.execute(
                    "SELECT id,ts,mode,action,features_json,target,source,sample_weight "
                    "FROM policy_examples WHERE source='human_demo' ORDER BY id DESC LIMIT ?",
                    (lane_size,)).fetchall(),
            ]
        finally:
            conn.close()

        # Merge lanes by primary key. Priority examples may be old; preserve them
        # alongside recent ones without loading the full, indefinitely growing table.
        rows_by_id: dict[int, sqlite3.Row] = {}
        for lane in lanes:
            for row in lane:
                rows_by_id[int(row["id"])] = row
        now = time.time()
        buckets: dict[tuple[str, str, str], list[tuple[float, sqlite3.Row]]] = {}
        for row in rows_by_id.values():
            try:
                target = max(-1.0, min(1.0, float(row["target"])))
                weight = max(0.05, min(1.0, float(row["sample_weight"])))
                age_days = max(0.0, now - float(row["ts"])) / 86400.0
            except (TypeError, ValueError, OverflowError):
                continue
            # A gentle recency component plus magnitude-based prioritization. Human
            # demos stay in their own bucket and retain their imitation-only weight.
            recency = 0.12 / (1.0 + age_days / 14.0)
            priority = abs(target) * weight + recency
            if str(row["source"]) == "human_demo":
                priority += 0.08
            key = (str(row["mode"]), str(row["action"]), str(row["source"]))
            buckets.setdefault(key, []).append((priority, row))

        # Sort each bucket by learning value, then use round-robin selection to stop
        # common actions from drowning rare actions or high-value failure examples.
        bucket_lists: list[list[sqlite3.Row]] = []
        per_bucket = max(2, limit // max(1, len(buckets)) + 2)
        for values in buckets.values():
            values.sort(key=lambda item: (item[0], int(item[1]["id"])), reverse=True)
            bucket_lists.append([row for _priority, row in values[:per_bucket]])
        selected: list[sqlite3.Row] = []
        cursor = 0
        while len(selected) < limit and any(cursor < len(items) for items in bucket_lists):
            for items in bucket_lists:
                if cursor < len(items) and len(selected) < limit:
                    selected.append(items[cursor])
            cursor += 1
        selected.sort(key=lambda row: int(row["id"]))

        result: list[dict] = []
        for row in selected:
            try:
                features = json.loads(row["features_json"])
            except (TypeError, json.JSONDecodeError):
                continue
            # Upgrade old replay vectors in memory; original SQLite rows remain untouched.
            if isinstance(features, list) and len(features) == 171 and INPUT_SIZE == 172:
                features = features[:168] + [0.0] + features[168:]
            elif isinstance(features, list) and len(features) == 153:
                features = features + [1.0] + [0.0] * (INPUT_SIZE - 154)
            result.append({"id": int(row["id"]), "mode": row["mode"], "action": row["action"],
                          "features": features, "target": float(row["target"]),
                          "source": row["source"], "weight": float(row["sample_weight"])})
        return result

    def log_runtime(self, mode: str, action: str, event: str | None = None,
                    observation: dict | None = None, details: dict | None = None) -> None:
        """Keep runtime diagnostics in the same SQLite database as learning."""
        self.db.execute(
            "INSERT INTO runtime_logs(ts,mode,action,event,observation_json,details_json) VALUES(?,?,?,?,?,?)",
            (time.time(), mode, action, event,
             json.dumps(observation, ensure_ascii=False) if observation is not None else None,
             json.dumps(details or {}, ensure_ascii=False)))
        self.db.commit()

    def record_visual_observation(self, *, mode: str, state_id: str, features: Iterable[int],
                                  observation: dict, source: str, visual_delta: float = 0.0,
                                  context: dict | None = None, force: bool = False,
                                  heartbeat_seconds: float = 8.0) -> bool:
        """Persist meaningful visual observations with deduplication and periodic heartbeats.

        Frames are analyzed continuously by the agent, but unchanged screenshots are not
        written repeatedly. This keeps disk use controlled without deleting old evidence.
        """
        now = time.time()
        feature_values = [int(max(0, min(255, int(v)))) for v in features]
        signature = json.dumps(feature_values, separators=(",", ":"))
        row = self.db.execute(
            "SELECT ts,mode,state_id,feature_signature FROM visual_observations ORDER BY id DESC LIMIT 1"
        ).fetchone()
        changed_state = bool(row and (str(row["state_id"]) != str(state_id) or str(row["mode"]) != str(mode)))
        elapsed = now - float(row["ts"]) if row else float("inf")
        sig_changed = bool(row and str(row["feature_signature"]) != signature)
        try:
            delta = max(0.0, min(1.0, float(visual_delta)))
        except (TypeError, ValueError, OverflowError):
            delta = 0.0
        should_insert = force or row is None or changed_state or delta >= 0.025 or (sig_changed and elapsed >= 1.0) or elapsed >= max(1.0, heartbeat_seconds)
        if not should_insert:
            return False
        self.db.execute(
            "INSERT INTO visual_observations(ts,source,mode,state_id,feature_signature,visual_delta,observation_json,context_json) VALUES(?,?,?,?,?,?,?,?)",
            (now, str(source)[:80], str(mode)[:40], str(state_id)[:100], signature, delta,
             json.dumps(observation or {}, ensure_ascii=False, allow_nan=False),
             json.dumps(context or {}, ensure_ascii=False, allow_nan=False)))
        self.db.commit()
        return True

    def control_mapping_report(self, controls: dict[str, str] | None = None) -> dict:
        """Summarize configured semantic bindings alongside evidence from manual demonstrations."""
        bindings = controls or {
            "left": "left", "right": "right", "up": "up", "down": "down",
            "interact": "z", "confirm": "enter", "cancel": "x", "menu": "c",
        }
        result = []
        for action, key in bindings.items():
            row = self.db.execute(
                "SELECT COUNT(*) AS n, COALESCE(AVG(visual_change),0) AS avg_change, COALESCE(AVG(duration),0) AS avg_duration "
                "FROM human_demonstrations WHERE action=?", (str(action),)).fetchone()
            count = int(row["n"] or 0) if row else 0
            result.append({
                "action": str(action), "physical_key": str(key), "demonstrations": count,
                "mean_visual_change": round(float(row["avg_change"] or 0.0), 4) if row else 0.0,
                "mean_hold_seconds": round(float(row["avg_duration"] or 0.0), 3) if row else 0.0,
                "evidence_level": "learned_observation" if count >= 5 else "configured_default_or_sparse_evidence",
                "success_verified": False,
            })
        key_rows = self.db.execute(
            "SELECT key_name,event_type,COUNT(*) AS n FROM human_key_events GROUP BY key_name,event_type ORDER BY n DESC LIMIT 64"
        ).fetchall()
        return {
            "bindings": result,
            "key_event_counts": [{"key": str(r["key_name"]), "event": str(r["event_type"]), "count": int(r["n"])} for r in key_rows],
            "interpretation": "Configured controls are hypotheses; manual key timing and screen effects accumulate evidence but do not prove that an action was successful."
        }

    def q_value_for(self, state_id: str | None, mode: str, action: str) -> tuple[int, float]:
        """Return local/global tabular Q estimates learned with one-step TD updates."""
        modes = ("battle", "sans_battle") if mode == "battle" else (mode,)
        placeholders = ",".join("?" for _ in modes)
        local_visits = 0
        local_q = 0.0
        if state_id:
            rows = self.db.execute(
                f"SELECT visits,q_value FROM q_values WHERE state_id=? AND mode IN ({placeholders}) AND action=?",
                (state_id, *modes, action)).fetchall()
            local_visits = sum(int(row["visits"]) for row in rows)
            if local_visits:
                local_q = sum(float(row["q_value"]) * int(row["visits"]) for row in rows) / local_visits
        # Aggregate globally in SQLite instead of loading every historical state/action
        # row into Python on each decision. This remains quick as the database grows.
        global_row = self.db.execute(
            f"SELECT COALESCE(SUM(visits),0) AS visits, "
            f"COALESCE(SUM(visits*q_value),0.0) AS weighted_q "
            f"FROM q_values WHERE mode IN ({placeholders}) AND action=?",
            (*modes, action)).fetchone()
        global_visits = int(global_row["visits"] or 0) if global_row else 0
        global_q = (float(global_row["weighted_q"] or 0.0) / global_visits if global_visits else 0.0)
        if local_visits and global_visits:
            return local_visits, 0.78 * local_q + 0.22 * global_q
        if local_visits:
            return local_visits, local_q
        return global_visits, global_q

    def max_q_for_state(self, state_id: str | None, mode: str) -> float:
        """Best learned continuation value for a next state; always bounded to [-1, 1]."""
        if not state_id:
            return 0.0
        modes = ("battle", "sans_battle") if mode == "battle" else (mode,)
        placeholders = ",".join("?" for _ in modes)
        row = self.db.execute(
            f"SELECT MAX(q_value) FROM q_values WHERE state_id=? AND mode IN ({placeholders})",
            (state_id, *modes)).fetchone()
        try:
            return max(-1.0, min(1.0, float(row[0] or 0.0)))
        except (TypeError, ValueError, OverflowError):
            return 0.0

    def value_for(self, state_id: str | None, mode: str, action: str) -> tuple[int, float]:
        """Return blended local/global experience, including legacy Sans battle rows."""
        modes = ("battle", "sans_battle") if mode == "battle" else (mode,)
        placeholders = ",".join("?" for _ in modes)
        gv_row = self.db.execute(
            f"SELECT SUM(visits) AS visits,AVG(mean_reward) AS mean_reward FROM global_values WHERE mode IN ({placeholders}) AND action=?",
            (*modes, action)).fetchone()
        gv = int(gv_row["visits"] or 0) if gv_row else 0
        gmean = float(gv_row["mean_reward"] or 0.0) if gv_row else 0.0
        lv = 0
        lmean = 0.0
        if state_id:
            local_row = self.db.execute(
                f"SELECT SUM(visits) AS visits,AVG(mean_reward) AS mean_reward FROM action_values WHERE state_id=? AND mode IN ({placeholders}) AND action=?",
                (state_id, *modes, action)).fetchone()
            if local_row and local_row["visits"]:
                lv = int(local_row["visits"])
                lmean = float(local_row["mean_reward"] or 0.0)
        if lv and gv:
            return lv, 0.70 * lmean + 0.30 * gmean
        if lv:
            return lv, lmean
        return gv, gmean

    def record(self, mode: str, from_state: str, action: str, to_state: str,
               reward: float, change: float, details: dict | None = None,
               policy_features: Iterable[float] | None = None, *, learn: bool = True,
               source: str = "autonomous_reward") -> None:
        now = time.time()
        reward = max(-1.0, min(1.0, float(reward)))
        self._track_action_attempt(from_state, mode, action, to_state, reward, change, learn, now)
        if not learn:
            # Retain the episode as an audit event, but do not let a neutral outcome
            # alter action values, policy weights or exploration pressure.
            self.db.execute("INSERT INTO events(ts,mode,from_state,action,to_state,reward,visual_change,details_json) VALUES(?,?,?,?,?,?,?,?)",
                            (now, mode, from_state, action, to_state, 0.0, float(change),
                             json.dumps({**(details or {}), "learning_update": False}, ensure_ascii=False)))
            self.db.commit()
            return
        detail_payload = dict(details or {})
        outcome = str(detail_payload.get("outcome", "")).strip().lower()
        terminal = bool(detail_payload.get("terminal")) or outcome in {"death", "goal_completed", "terminal"}
        # Explicit user labels describe the just-finished action, not a future
        # state transition. Do not dilute a strong failure/success label by
        # bootstrapping from an unchanged scene's unrelated Q-values.
        same_state_feedback = bool(detail_payload.get("feedback_source")) and from_state == to_state
        next_q = 0.0 if terminal or same_state_feedback else self.max_q_for_state(to_state, mode)
        # TD(0): the immediate reward is joined with an estimate of what follows.
        td_target = max(-1.0, min(1.0, reward + (0.0 if terminal else 0.62 * next_q)))
        row = self.db.execute("SELECT visits,mean_reward FROM action_values WHERE state_id=? AND mode=? AND action=?",
                              (from_state, mode, action)).fetchone()
        visits = int(row["visits"]) if row else 0
        mean = float(row["mean_reward"]) if row else 0.0
        new_mean = mean + (reward - mean) / (visits + 1)
        self.db.execute("""INSERT INTO action_values(state_id,mode,action,visits,mean_reward,last_reward,last_seen)
            VALUES(?,?,?,?,?,?,?) ON CONFLICT(state_id,mode,action) DO UPDATE SET
            visits=excluded.visits,mean_reward=excluded.mean_reward,last_reward=excluded.last_reward,last_seen=excluded.last_seen""",
            (from_state, mode, action, visits + 1, new_mean, reward, now))
        grow = self.db.execute("SELECT visits,mean_reward FROM global_values WHERE mode=? AND action=?", (mode, action)).fetchone()
        gv = int(grow["visits"]) if grow else 0
        gmean = float(grow["mean_reward"]) if grow else 0.0
        self.db.execute("""INSERT INTO global_values(mode,action,visits,mean_reward) VALUES(?,?,?,?)
            ON CONFLICT(mode,action) DO UPDATE SET visits=excluded.visits,mean_reward=excluded.mean_reward""",
            (mode, action, gv + 1, gmean + (reward - gmean) / (gv + 1)))
        edge = self.db.execute("SELECT count,mean_reward FROM transitions WHERE from_state=? AND action=? AND to_state=?",
                               (from_state, action, to_state)).fetchone()
        ec = int(edge["count"]) if edge else 0
        emean = float(edge["mean_reward"]) if edge else 0.0
        self.db.execute("""INSERT INTO transitions(from_state,action,to_state,count,mean_reward,last_seen)
            VALUES(?,?,?,?,?,?) ON CONFLICT(from_state,action,to_state) DO UPDATE SET
            count=excluded.count,mean_reward=excluded.mean_reward,last_seen=excluded.last_seen""",
            (from_state, action, to_state, ec + 1, emean + (reward - emean) / (ec + 1), now))
        self.db.execute("INSERT INTO events(ts,mode,from_state,action,to_state,reward,visual_change,details_json) VALUES(?,?,?,?,?,?,?,?)",
                        (now, mode, from_state, action, to_state, reward, float(change),
                         json.dumps({**detail_payload, "td_target": td_target, "next_state_q": next_q, "terminal": terminal}, ensure_ascii=False)))
        qrow = self.db.execute(
            "SELECT visits,q_value FROM q_values WHERE state_id=? AND mode=? AND action=?",
            (from_state, mode, action)).fetchone()
        q_visits = int(qrow["visits"]) if qrow else 0
        old_q = float(qrow["q_value"]) if qrow else 0.0
        alpha = max(0.12, 0.45 / (1.0 + q_visits * 0.025))
        new_q = max(-1.0, min(1.0, old_q + alpha * (td_target - old_q)))
        self.db.execute(
            """INSERT INTO q_values(state_id,mode,action,visits,q_value,last_reward,last_seen)
               VALUES(?,?,?,?,?,?,?) ON CONFLICT(state_id,mode,action) DO UPDATE SET
               visits=excluded.visits,q_value=excluded.q_value,last_reward=excluded.last_reward,last_seen=excluded.last_seen""",
            (from_state, mode, action, q_visits + 1, new_q, reward, now))
        if policy_features is not None:
            try:
                encoded = [float(v) for v in policy_features]
                if len(encoded) == INPUT_SIZE and all(math.isfinite(v) for v in encoded):
                    self.db.execute(
                        "INSERT INTO policy_examples(ts,mode,action,features_json,target,source,sample_weight) VALUES(?,?,?,?,?,?,?)",
                        (now, mode, action, json.dumps(encoded), td_target, str(source or "autonomous_reward")[:64],
                         0.9 if source == "manual_feedback" else 1.0))
            except (TypeError, ValueError, OverflowError):
                pass
        self.db.commit()

    def planned_frontier_action(self, current: str, actions: list[str]) -> str | None:
        """BFS through observed transitions toward the nearest state with untried actions."""
        if not current or not actions:
            return None
        queue = deque([(current, [])])
        seen = {current}
        best: tuple[float, str] | None = None
        while queue and len(seen) <= 1500:
            state, path = queue.popleft()
            visited_rows = self.db.execute("SELECT action,visits FROM action_values WHERE state_id=? AND mode='overworld'", (state,)).fetchall()
            seen_actions = {r["action"] for r in visited_rows if int(r["visits"]) > 0}
            unknown_count = len([a for a in actions if a not in seen_actions])
            if state != current and unknown_count:
                score = unknown_count / (len(path) + 1)
                if best is None or score > best[0]:
                    best = (score, path[0])
            edges = self.db.execute("SELECT action,to_state FROM transitions WHERE from_state=? ORDER BY count DESC", (state,)).fetchall()
            for edge in edges:
                nxt = edge["to_state"]
                if nxt not in seen:
                    seen.add(nxt)
                    queue.append((nxt, path + [edge["action"]]))
        return best[1] if best else None

    def stats(self) -> dict:
        scenes = self.db.execute("SELECT COUNT(*) FROM scenes").fetchone()[0]
        transitions = self.db.execute("SELECT COUNT(*) FROM transitions").fetchone()[0]
        events = self.db.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        human_demos = self.db.execute("SELECT COUNT(*) FROM human_demonstrations").fetchone()[0]
        runtime_logs = self.db.execute("SELECT COUNT(*) FROM runtime_logs").fetchone()[0]
        visual_observations = self.db.execute("SELECT COUNT(*) FROM visual_observations").fetchone()[0]
        latest_visual = self.db.execute("SELECT ts,mode,state_id,source FROM visual_observations ORDER BY id DESC LIMIT 1").fetchone()
        human_key_events = self.db.execute("SELECT COUNT(*) FROM human_key_events").fetchone()[0]
        policy_examples = self.db.execute("SELECT COUNT(*) FROM policy_examples").fetchone()[0]
        reflections = self.db.execute("SELECT COUNT(*) FROM self_reflections").fetchone()[0]
        blocked = self.db.execute("SELECT COUNT(*) FROM blocked_actions").fetchone()[0]
        action_attempts = self.db.execute("SELECT COUNT(*) FROM action_attempts").fetchone()[0]
        q_entries = self.db.execute("SELECT COUNT(*) FROM q_values").fetchone()[0]
        latest = self.db.execute("SELECT ts,mode,action,reward FROM events ORDER BY id DESC LIMIT 1").fetchone()
        latest_demo = self.db.execute(
            "SELECT ts,mode,action FROM human_demonstrations ORDER BY id DESC LIMIT 1").fetchone()
        top_human = self.db.execute(
            "SELECT mode,action,COUNT(*) AS n FROM human_demonstrations GROUP BY mode,action ORDER BY n DESC LIMIT 8").fetchall()
        return {
            "database": str(self.path), "scenes_known": int(scenes),
            "transitions_known": int(transitions), "experience_records": int(events),
            "human_demonstrations": int(human_demos), "human_key_events": int(human_key_events),
            "visual_observation_records": int(visual_observations),
            "latest_visual_observation": ({"timestamp": latest_visual["ts"], "mode": latest_visual["mode"],
                                           "state_id": latest_visual["state_id"], "source": latest_visual["source"]} if latest_visual else None),
            "policy_examples_persistent": int(policy_examples), "runtime_log_records": int(runtime_logs),
            "self_reflection_records": int(reflections), "blocked_action_states": int(blocked),
            "state_action_attempt_records": int(action_attempts),
            "q_value_entries": int(q_entries),
            "storage_policy": "append_only_history_no_application_record_cap; exact scene signatures indexed across all history; approximate search uses bounded recent sample; replay batch bounded for RAM/latency",
            "human_action_norm": [{"mode": r["mode"], "action": r["action"], "count": int(r["n"])} for r in top_human],
            "latest_human_demonstration": ({"timestamp": latest_demo["ts"], "mode": latest_demo["mode"],
                                            "action": latest_demo["action"]} if latest_demo else None),
            "feedback_quality": "weak_screen_heuristic_not_ground_truth; human actions are demonstration priors, not rewards",
            "latest_experience": ({"timestamp": latest["ts"], "mode": latest["mode"],
                                   "action": latest["action"], "reward": latest["reward"]} if latest else None),
        }
