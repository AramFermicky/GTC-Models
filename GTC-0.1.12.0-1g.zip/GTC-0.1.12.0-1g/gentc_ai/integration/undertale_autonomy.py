"""Role-based self-analysis and conservative reward shaping for Undertale.

The model is inspectable state/goal logic, not a claim of consciousness. It
intentionally distinguishes unknown outcomes from failures: no visual change is
usually neutral, while repeated direction input with no movement is evidence of
an obstruction. Damage/death can only receive strong labels when actually
observable or explicitly confirmed; this screen-only adapter cannot read HP.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

MOVEMENT_ACTIONS = frozenset({
    "left", "right", "up", "down", "up_left", "up_right", "down_left",
    "down_right", "left_jump", "right_jump", "jump",
})
INTERACTION_ACTIONS = frozenset({"interact", "cancel", "confirm"})


@dataclass(frozen=True)
class RewardAssessment:
    reward: float
    learn: bool
    category: str
    explanation: str


def evaluate_transition(*, mode: str, action: str, from_state: str, to_state: str,
                        visual_delta: float, new_scene: bool, danger_before: float = 0.0,
                        danger_after: float = 0.0, hazards_before: int = 0,
                        hazards_after: int = 0, repeated_blocked: int = 0,
                        explicit_outcome: str | None = None) -> RewardAssessment:
    """Return shaped feedback. Scores are bounded and uncertain signals stay weak."""
    # Explicit feedback is the only way this visual adapter may label actual damage,
    # death, item misuse, or task completion with high confidence.
    explicit = (explicit_outcome or "").strip().lower()
    explicit_rewards = {
        "damage": (-1.0, "severe_failure", "Подтверждён полученный урон"),
        "death": (-1.0, "death", "Подтверждено поражение/смерть"),
        "missed_attack": (-0.65, "missed_attack", "Подтверждён пропуск атаки"),
        "item_misuse": (-0.9, "item_misuse", "Подтверждено неудачное использование предмета"),
        "blocked": (-0.9, "blocked_movement", "Подтверждено повторное движение в препятствие"),
        "dodge": (0.65, "successful_dodge", "Подтверждено успешное уклонение"),
        "progress": (0.8, "game_progress", "Подтверждён прогресс по игре"),
        "goal_completed": (1.0, "goal_completed", "Подтверждено выполнение цели"),
    }
    if explicit in explicit_rewards:
        reward, category, explanation = explicit_rewards[explicit]
        return RewardAssessment(reward, True, category, explanation)

    action = str(action or "none")
    delta = max(0.0, min(1.0, float(visual_delta or 0.0)))
    danger_delta = float(danger_after or 0.0) - float(danger_before or 0.0)
    hazard_delta = int(hazards_after or 0) - int(hazards_before or 0)

    # Idle/observation/no-op is neither success nor failure. Do not turn it into a
    # negative training label just because the screen remained stable.
    if action in {"none", "idle", "wait", "observe"}:
        return RewardAssessment(0.0, False, "neutral_noop", "Без награды и штрафа: нет проверяемого результата")

    if mode == "battle":
        # Visual danger is only a proxy, so positive and negative values are bounded.
        penalty = 0.0
        if danger_delta >= 0.12:
            penalty -= min(0.65, 0.30 + danger_delta * 0.9)
        if hazard_delta >= max(4, int(max(0, hazards_before) * 0.35)):
            penalty -= 0.20
        if penalty < 0.0:
            return RewardAssessment(max(-0.85, penalty), True, "visual_risk_increased",
                                    "Видимая опасность возросла; это вероятный, но не подтверждённый сигнал риска")
        if danger_delta <= -0.12 and hazard_delta <= 1:
            return RewardAssessment(0.45, True, "visual_risk_reduced",
                                    "Положение стало визуально безопаснее; сигнал уклонения предварительный")
        return RewardAssessment(0.0, False, "neutral_uncertain_battle",
                                "Нет достаточно уверенного визуального результата")

    # A route/room change is the strongest signal available without game-state APIs.
    if from_state != to_state:
        if action in MOVEMENT_ACTIONS:
            value = 0.78 if new_scene else 0.22
            return RewardAssessment(value, True, "visual_progress", "После движения изменилось распознанное состояние сцены")
        if action == "interact" and new_scene:
            return RewardAssessment(0.10, True, "interaction_changed_scene",
                                    "Взаимодействие изменило сцену, но смысл изменения не подтверждён")
        # Menu/text/dialogue changes must not be mistaken for exploration completion.
        return RewardAssessment(0.0, False, "neutral_ui_change", "Изменилась картинка, но прогресс не подтверждён")

    if action in MOVEMENT_ACTIONS and delta < 0.003:
        if repeated_blocked >= 2:
            return RewardAssessment(-0.90, True, "repeated_blocked_movement",
                                    "Одно и то же направление несколько раз не сдвинуло персонажа; вероятно, стена/препятствие")
        return RewardAssessment(0.0, False, "possible_blocked_movement",
                                "Нет заметного движения: первый случай нейтрален, это ещё не доказанная ошибка")

    # Movement animation inside a room does not itself mean objective completion.
    # Stable/no-op and ineffective interactions remain neutral, not rewarded.
    return RewardAssessment(0.0, False, "neutral_no_verified_progress",
                            "Нет подтверждённого прогресса: действие сохранено как наблюдение, без награды и штрафа")


class UndertaleSelfModel:
    """Inspectable answer to identity, role, capabilities, objectives and unknowns."""

    IDENTITY = "GenTC AI"
    ROLE = "player"
    PRIMARY_GOAL = "Продвигаться по Undertale, исследуя мир и выживая в опасных эпизодах"

    def describe(self, mode: str, observation: dict[str, Any] | None = None, *,
                 last_action: str = "none", no_progress_streak: int = 0,
                 blocked_action: str | None = None, known_scenes: int = 0,
                 known_transitions: int = 0) -> dict[str, Any]:
        obs = observation if isinstance(observation, dict) else {}
        mode = "battle" if mode == "battle" or bool(obs.get("battle_visible")) else "overworld"
        if mode == "battle":
            objective = "Выжить в текущем боевом ходе: выбирать короткое движение к менее опасной области"
            available = ["left", "right", "up", "down", "diagonal movement", "jump when blue soul"]
            decision_question = "Какое короткое движение снижает ближайший визуальный риск?"
        elif blocked_action:
            objective = f"Найти другой проход/способ взаимодействия; избегать повторения заблокированного действия {blocked_action}"
            available = ["left", "right", "up", "down", "interact (Z/Enter)", "cancel (X/Shift/Esc)", "menu (C) when useful"]
            decision_question = "Какое ещё действие может изменить состояние мира, не повторяя заблокированное движение?"
        else:
            objective = "Исследовать текущую комнату, найти переход или значимый объект и не повторять действия без результата"
            available = ["left", "right", "up", "down", "interact (Z/Enter)", "cancel (X/Shift/Esc)", "menu (C) when useful"]
            decision_question = "Какое из доступных действий даст новую информацию или продвижение?"
        return {
            "identity": self.IDENTITY,
            "role": self.ROLE,
            "primary_goal": self.PRIMARY_GOAL,
            "current_mode": mode,
            "current_objective": objective,
            "decision_question": decision_question,
            "available_actions": available,
            "current_observation": {
                "battle_visible": bool(obs.get("battle_visible", False)),
                "soul_mode": ((obs.get("soul") or {}).get("mode") if isinstance(obs.get("soul"), dict) else None),
                "scene_confidence": obs.get("scene_confidence"),
                "hazard_pixels": obs.get("hazard_pixels"),
            },
            "recent_behavior": {"last_action": last_action, "no_progress_streak": max(0, int(no_progress_streak)),
                                "blocked_action": blocked_action},
            "known_experience": {"scenes": int(known_scenes), "transitions": int(known_transitions)},
            "known_limits": [
                "Получает только изображение, не скрытое состояние процесса игры",
                "HP, инвентарь, конкретная смерть и смысл текста могут быть не распознаны надёжно",
                "Награды за визуальные изменения — приблизительные; подтверждённые игровые исходы требуют явного сигнала",
                "Кнопка C может открывать меню, но доступ к содержимому инвентаря и точному состоянию предметов визуальный агент пока не понимает семантически",
            ],
            "decision_cycle": [
                "Наблюдать текущий кадр и отделять бой от исследования",
                "Сверить текущую ситуацию с ролью игрока и главной целью прохождения",
                "Составить список разрешённых действий, не выдумывая отсутствующие игровые функции",
                "Сначала предпочитать неиспробованные действия и известные безопасные маршруты",
                "Коротко выполнить действие, затем сравнить кадр и состояние сцены до/после",
                "Сохранить исход; пересмотреть следующий шаг, если прогресса нет или риск растёт",
            ],
            "reasoning_policy": [
                "Понять, кто я, какова роль и какая ближайшая подцель соответствует главной цели",
                "Оценить знания об игре: известные сцены, переходы, показанные человеком действия и результаты попыток",
                "Не награждать бездействие, повторную бесполезную кнопку или движение без результата",
                "Не штрафовать неизвестный исход; сильный штраф нужен при повторяемом блокировании или подтверждённом вреде",
                "Снижать предпочтение повторённого безрезультатного действия, но давать старым действиям шанс после смены контекста",
                "Считать визуальные изменения слабым доказательством, а не гарантией выполнения цели",
                "Обновлять стратегию по сохранённым последствиям; не объявлять неизвестный исход успехом",
            ],
        }
