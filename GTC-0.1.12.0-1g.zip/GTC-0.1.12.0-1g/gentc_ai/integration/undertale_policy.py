"""Larger persistent policy/value MLP for the Undertale visual pilot.

The model is deliberately bounded and trained only from the screen-derived experience
and player demonstrations stored by UndertaleLearningMemory. It is not a pretrained
LLM and visual rewards remain noisy proxies.
"""
from __future__ import annotations

import json
import math
import random
import threading
import uuid
from pathlib import Path
from typing import Any, Iterable

POLICY_ACTIONS = (
    "none", "left", "right", "up", "down", "up_left", "up_right",
    "down_left", "down_right", "left_jump", "right_jump", "jump",
    "interact", "cancel", "confirm", "menu",
)
SCREEN_FEATURES = 8 * 6 * 3
BASE_CONTEXT_FEATURES = 9
TEMPORAL_CONTEXT_FEATURES = len(POLICY_ACTIONS) + 3
INPUT_SIZE = SCREEN_FEATURES + BASE_CONTEXT_FEATURES + TEMPORAL_CONTEXT_FEATURES  # 172 inputs
HIDDEN_1 = 128
HIDDEN_2 = 96
OUTPUT_SIZE = len(POLICY_ACTIONS)


def _clamp(value: Any, low: float = 0.0, high: float = 1.0, default: float = 0.0) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        return default
    if not math.isfinite(result):
        return default
    return max(low, min(high, result))


def _atomic_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + f".{uuid.uuid4().hex}.tmp")
    try:
        temp.write_text(json.dumps(data, ensure_ascii=False, allow_nan=False), encoding="utf-8")
        temp.replace(path)
    finally:
        temp.unlink(missing_ok=True)


class UndertalePolicyNetwork:
    """172→128→96→16 MLP with temporal context and whole-game menu action."""

    SCHEMA_VERSION = 3

    def __init__(self, path: str | Path, *, seed: int = 1514, minimum_samples: int = 40,
                 minimum_actions: int = 3) -> None:
        self.path = Path(path)
        self.minimum_samples = max(20, int(minimum_samples))
        self.minimum_actions = max(2, int(minimum_actions))
        self._lock = threading.RLock()
        self.training_samples = 0  # Total persistent examples known to this model.
        self.training_updates = 0
        self.trained_actions: list[str] = []
        self.load_warning: str | None = None
        rng = random.Random(seed)
        self.w1 = self._matrix(rng, HIDDEN_1, INPUT_SIZE)
        self.b1 = [0.0] * HIDDEN_1
        self.w2 = self._matrix(rng, HIDDEN_2, HIDDEN_1)
        self.b2 = [0.0] * HIDDEN_2
        self.w3 = self._matrix(rng, OUTPUT_SIZE, HIDDEN_2)
        self.b3 = [0.0] * OUTPUT_SIZE
        if self.path.exists():
            self._load()

    @staticmethod
    def _matrix(rng: random.Random, rows: int, cols: int) -> list[list[float]]:
        limit = math.sqrt(6.0 / (rows + cols))
        return [[rng.uniform(-limit, limit) for _ in range(cols)] for _ in range(rows)]

    @staticmethod
    def encode_state(screen_features: Iterable[int], mode: str,
                     observation: dict[str, Any] | None = None, *,
                     previous_action: str = "none", no_progress_streak: int = 0,
                     last_reward: float = 0.0, last_danger_delta: float = 0.0) -> list[float]:
        """Encode current pixels, player/arena state, previous action and recent feedback."""
        raw = list(screen_features)[:SCREEN_FEATURES]
        raw.extend([0] * (SCREEN_FEATURES - len(raw)))
        vector = [_clamp(value, 0.0, 8.0) / 8.0 for value in raw]
        obs = observation if isinstance(observation, dict) else {}
        soul = obs.get("soul") if isinstance(obs.get("soul"), dict) else {}
        arena = obs.get("arena") if isinstance(obs.get("arena"), dict) else {}
        width = max(1.0, _clamp(obs.get("width", 1), 1.0, 100000.0, 1.0))
        height = max(1.0, _clamp(obs.get("height", 1), 1.0, 100000.0, 1.0))
        sx = _clamp(soul.get("x", 0), 0.0, width) / width if soul else 0.0
        sy = _clamp(soul.get("y", 0), 0.0, height) / height if soul else 0.0
        hazards = _clamp(obs.get("hazard_pixels", obs.get("hazards", 0)), 0.0, 500.0) / 500.0
        aw = _clamp((arena.get("right", 0) - arena.get("left", 0)) / width) if arena else 0.0
        ah = _clamp((arena.get("bottom", 0) - arena.get("top", 0)) / height) if arena else 0.0
        soul_mode = str(soul.get("mode", ""))
        red = 1.0 if soul_mode == "red" else 0.0
        blue = 1.0 if soul_mode == "blue" else 0.0
        battle = 1.0 if mode in {"sans_battle", "battle"} or bool(obs.get("battle_visible")) else 0.0
        overworld = 1.0 - battle
        vector.extend((sx, sy, hazards, aw, ah, red, blue, overworld, battle))
        action_index = POLICY_ACTIONS.index(previous_action) if previous_action in POLICY_ACTIONS else 0
        vector.extend(1.0 if i == action_index else 0.0 for i in range(len(POLICY_ACTIONS)))
        try:
            no_progress = max(0.0, min(50.0, float(no_progress_streak))) / 50.0
        except (TypeError, ValueError, OverflowError):
            no_progress = 0.0
        def signed(value: Any) -> float:
            try:
                num = float(value)
            except (TypeError, ValueError, OverflowError):
                return 0.0
            if not math.isfinite(num):
                return 0.0
            return max(-1.0, min(1.0, num))
        vector.extend((no_progress, signed(last_reward), signed(last_danger_delta)))
        if len(vector) != INPUT_SIZE:
            raise AssertionError(f"Policy state must have {INPUT_SIZE} inputs, got {len(vector)}")
        return vector

    @staticmethod
    def _tanh(x: float) -> float:
        return math.tanh(max(-12.0, min(12.0, x)))

    @staticmethod
    def _forward(x: list[float], w1: list[list[float]], b1: list[float],
                 w2: list[list[float]], b2: list[float],
                 w3: list[list[float]], b3: list[float]) -> tuple[list[float], list[float], list[float]]:
        h1 = [UndertalePolicyNetwork._tanh(sum(w * f for w, f in zip(row, x)) + bias)
              for row, bias in zip(w1, b1)]
        h2 = [UndertalePolicyNetwork._tanh(sum(w * f for w, f in zip(row, h1)) + bias)
              for row, bias in zip(w2, b2)]
        out = [UndertalePolicyNetwork._tanh(sum(w * f for w, f in zip(row, h2)) + bias)
               for row, bias in zip(w3, b3)]
        return h1, h2, out

    @property
    def is_active(self) -> bool:
        return self.training_samples >= self.minimum_samples and len(self.trained_actions) >= self.minimum_actions

    def predict(self, features: Iterable[float]) -> dict[str, float]:
        x = [float(v) for v in features]
        if len(x) != INPUT_SIZE or not all(math.isfinite(v) for v in x):
            return {action: 0.0 for action in POLICY_ACTIONS}
        if not self.is_active:
            return {action: 0.0 for action in POLICY_ACTIONS}
        with self._lock:
            w1, b1, w2, b2, w3, b3 = self.w1, self.b1, self.w2, self.b2, self.w3, self.b3
        _h1, _h2, values = self._forward(x, w1, b1, w2, b2, w3, b3)
        return {name: max(-1.0, min(1.0, values[i])) for i, name in enumerate(POLICY_ACTIONS)}

    @staticmethod
    def upgrade_features(features: list[float]) -> list[float]:
        """Upgrade persisted 153/171-feature records without discarding old experience."""
        if len(features) == INPUT_SIZE:
            return features
        if len(features) == 171 and INPUT_SIZE == 172:
            # New "menu" previous-action bit is inserted just before the 3 temporal signals.
            return features[:168] + [0.0] + features[168:]
        if len(features) == 153:
            # Old models stored only screen/context features. Assume previous action=none.
            return features + [1.0] + [0.0] * (INPUT_SIZE - 154)
        return features

    def fit(self, examples: list[dict[str, Any]], *, total_examples: int,
            epochs: int = 1, learning_rate: float = 0.0025) -> dict[str, Any]:
        """Train on a bounded replay sample; every example remains permanently in SQLite."""
        valid: list[tuple[list[float], int, float, float, str, str]] = []
        for item in examples:
            if not isinstance(item, dict):
                continue
            action = str(item.get("action", ""))
            if action not in POLICY_ACTIONS:
                continue
            try:
                features = self.upgrade_features([float(v) for v in item.get("features", [])])
                target = float(item.get("target", 0.0))
                weight = float(item.get("weight", 1.0))
            except (TypeError, ValueError, OverflowError):
                continue
            if len(features) != INPUT_SIZE or not all(math.isfinite(v) for v in features):
                continue
            if not math.isfinite(target) or not math.isfinite(weight):
                continue
            source = str(item.get("source", ""))
            valid.append((features, POLICY_ACTIONS.index(action), max(-1.0, min(1.0, target)),
                          max(0.05, min(1.0, weight)), action, source))
        if not valid:
            return {"trained": False, "reason": "no_valid_examples", "active": self.is_active}

        with self._lock:
            w1 = [row[:] for row in self.w1]; b1 = self.b1[:]
            w2 = [row[:] for row in self.w2]; b2 = self.b2[:]
            w3 = [row[:] for row in self.w3]; b3 = self.b3[:]
        rate = max(0.0001, min(float(learning_rate), 0.01))
        losses: list[float] = []
        rng = random.Random(self.training_updates + int(total_examples) * 17)
        for _ in range(max(1, min(int(epochs), 3))):
            rng.shuffle(valid)
            total_loss = 0.0
            for x, action_index, target, sample_weight, _name, source in valid:
                h1, h2, out = self._forward(x, w1, b1, w2, b2, w3, b3)
                targets = [0.0] * OUTPUT_SIZE
                output_weights = [0.0] * OUTPUT_SIZE
                targets[action_index] = target
                output_weights[action_index] = sample_weight
                if source == "human_demo":
                    # Human examples tell the network what was selected. Lightly
                    # lower alternate scores but don't claim their outcomes were failures.
                    contrast_weight = min(0.06, sample_weight * 0.20)
                    for output_index in range(OUTPUT_SIZE):
                        if output_index != action_index:
                            targets[output_index] = -0.08
                            output_weights[output_index] = contrast_weight
                d3 = [0.0] * OUTPUT_SIZE
                for output_index in range(OUTPUT_SIZE):
                    if output_weights[output_index] <= 0.0:
                        continue
                    error = out[output_index] - targets[output_index]
                    total_loss += 0.5 * output_weights[output_index] * error * error
                    d3[output_index] = output_weights[output_index] * error * (1.0 - out[output_index] ** 2)
                old_w3 = [row[:] for row in w3]
                old_w2 = [row[:] for row in w2]
                d2 = [sum(d3[o] * old_w3[o][j] for o in range(OUTPUT_SIZE)) * (1.0 - h2[j] ** 2)
                      for j in range(HIDDEN_2)]
                d1 = [sum(old_w2[k][j] * d2[k] for k in range(HIDDEN_2)) * (1.0 - h1[j] ** 2)
                      for j in range(HIDDEN_1)]
                for o in range(OUTPUT_SIZE):
                    if output_weights[o] <= 0.0:
                        continue
                    for j in range(HIDDEN_2):
                        w3[o][j] -= rate * max(-1.0, min(1.0, d3[o] * h2[j]))
                    b3[o] -= rate * max(-1.0, min(1.0, d3[o]))
                for j in range(HIDDEN_2):
                    for k in range(HIDDEN_1):
                        w2[j][k] -= rate * max(-1.0, min(1.0, d2[j] * h1[k]))
                    b2[j] -= rate * max(-1.0, min(1.0, d2[j]))
                for j in range(HIDDEN_1):
                    for k in range(INPUT_SIZE):
                        w1[j][k] -= rate * max(-1.0, min(1.0, d1[j] * x[k]))
                    b1[j] -= rate * max(-1.0, min(1.0, d1[j]))
            losses.append(total_loss / len(valid))
        actions = sorted({action for *_prefix, action, _source in valid})
        with self._lock:
            self.w1, self.b1, self.w2, self.b2, self.w3, self.b3 = w1, b1, w2, b2, w3, b3
            self.training_samples = max(self.training_samples, int(total_examples))
            self.trained_actions = sorted(set(self.trained_actions) | set(actions))
            self.training_updates += 1
            self._save_locked()
        return {"trained": True, "replay_examples": len(valid), "total_persistent_examples": self.training_samples,
                "actions_covered": self.trained_actions, "loss": round(losses[-1], 6),
                "training_updates": self.training_updates, "active": self.is_active}

    def status(self) -> dict[str, Any]:
        return {"kind": "undertale_visual_mlp", "architecture": f"{INPUT_SIZE}-{HIDDEN_1}-{HIDDEN_2}-{OUTPUT_SIZE}",
                "parameters": INPUT_SIZE * HIDDEN_1 + HIDDEN_1 + HIDDEN_1 * HIDDEN_2 + HIDDEN_2 + HIDDEN_2 * OUTPUT_SIZE + OUTPUT_SIZE,
                "training_samples": self.training_samples, "actions_covered": self.trained_actions,
                "training_updates": self.training_updates, "minimum_samples": self.minimum_samples,
                "minimum_actions": self.minimum_actions, "active_in_decision_loop": self.is_active,
                "model_path": str(self.path), "load_warning": self.load_warning}

    def _save_locked(self) -> None:
        _atomic_json(self.path, {"schema_version": self.SCHEMA_VERSION,
            "input_size": INPUT_SIZE, "hidden_1": HIDDEN_1, "hidden_2": HIDDEN_2,
            "output_size": OUTPUT_SIZE, "w1": self.w1, "b1": self.b1,
            "w2": self.w2, "b2": self.b2, "w3": self.w3, "b3": self.b3,
            "training_samples": self.training_samples, "trained_actions": self.trained_actions,
            "training_updates": self.training_updates})

    def _preserve_incompatible_model(self) -> str | None:
        """Keep old/corrupt weights before a later training update writes the new shape."""
        if not self.path.exists():
            return None
        try:
            backup = self.path.with_name(self.path.stem + ".legacy-backup" + self.path.suffix)
            if backup.exists():
                backup = self.path.with_name(self.path.stem + f".legacy-backup-{uuid.uuid4().hex[:8]}" + self.path.suffix)
            self.path.replace(backup)
            return backup.name
        except OSError:
            return None

    def _reject_loaded_model(self, reason: str) -> None:
        backup_name = self._preserve_incompatible_model()
        self.load_warning = reason + (f"; preserved_as={backup_name}" if backup_name else "")

    def _load(self) -> None:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                self._reject_loaded_model("policy_model_root_invalid_fresh_weights_used")
                return
            if (data.get("schema_version") == 2 and
                [data.get(k) for k in ("input_size", "hidden_1", "hidden_2", "output_size")] ==
                [171, HIDDEN_1, HIDDEN_2, 15]):
                # Preserve learned hidden layers and the existing 15 action heads.
                # Insert one zero-weight feature for the new menu action's temporal bit.
                try:
                    migrated_w1 = [row[:168] + [0.0] + row[168:] for row in data["w1"]]
                    if any(len(row) != INPUT_SIZE for row in migrated_w1):
                        raise ValueError("legacy input matrix shape mismatch")
                    migrated_w3 = [row[:] for row in data["w3"]]
                    rng = random.Random(20261022)
                    migrated_w3.append([rng.uniform(-0.01, 0.01) for _ in range(HIDDEN_2)])
                    data = {**data, "schema_version": self.SCHEMA_VERSION, "input_size": INPUT_SIZE,
                            "output_size": OUTPUT_SIZE, "w1": migrated_w1, "w3": migrated_w3,
                            "b3": list(data["b3"]) + [0.0],
                            "trained_actions": list(data.get("trained_actions", []))}
                    # Save only after every shape/finite check below succeeds.
                    migrated_legacy = True
                except (KeyError, TypeError, ValueError):
                    self._reject_loaded_model("legacy_policy_migration_failed_fresh_weights_used")
                    return
            else:
                migrated_legacy = False
            if ([data.get(k) for k in ("schema_version", "input_size", "hidden_1", "hidden_2", "output_size")] !=
                [self.SCHEMA_VERSION, INPUT_SIZE, HIDDEN_1, HIDDEN_2, OUTPUT_SIZE]):
                self._reject_loaded_model("policy_schema_mismatch_fresh_weights_used")
                return
            layers = [("w1", HIDDEN_1, INPUT_SIZE), ("w2", HIDDEN_2, HIDDEN_1), ("w3", OUTPUT_SIZE, HIDDEN_2)]
            for key, rows, cols in layers:
                value = data.get(key)
                if not isinstance(value, list) or len(value) != rows or any(not isinstance(row, list) or len(row) != cols for row in value):
                    self._reject_loaded_model("policy_shape_invalid_fresh_weights_used")
                    return
            for key, size in (("b1", HIDDEN_1), ("b2", HIDDEN_2), ("b3", OUTPUT_SIZE)):
                if not isinstance(data.get(key), list) or len(data[key]) != size:
                    self._reject_loaded_model("policy_bias_shape_invalid_fresh_weights_used")
                    return
            candidate = [data[k] for k in ("w1", "b1", "w2", "b2", "w3", "b3")]
            flat: list[float] = []
            for value in candidate:
                if isinstance(value, list):
                    for item in value:
                        flat.extend(float(v) for v in item) if isinstance(item, list) else flat.append(float(item))
                else:
                    flat.append(float(value))
            if not all(math.isfinite(v) for v in flat):
                self._reject_loaded_model("policy_non_finite_weights_fresh_weights_used")
                return
            self.w1 = [[float(v) for v in row] for row in data["w1"]]
            self.b1 = [float(v) for v in data["b1"]]
            self.w2 = [[float(v) for v in row] for row in data["w2"]]
            self.b2 = [float(v) for v in data["b2"]]
            self.w3 = [[float(v) for v in row] for row in data["w3"]]
            self.b3 = [float(v) for v in data["b3"]]
            self.training_samples = max(0, int(data.get("training_samples", 0)))
            self.training_updates = max(0, int(data.get("training_updates", 0)))
            actions = data.get("trained_actions", [])
            self.trained_actions = sorted({str(v) for v in actions if str(v) in POLICY_ACTIONS}) if isinstance(actions, list) else []
            if migrated_legacy:
                self._save_locked()
                self.load_warning = "policy_schema_v2_migrated_preserving_old_weights_and_replay_history"
        except (OSError, UnicodeDecodeError, json.JSONDecodeError, TypeError, ValueError, OverflowError):
            self._reject_loaded_model("policy_model_unreadable_fresh_weights_used")
