"""Exact-width Win32 INPUT ABI definitions, testable without importing Windows DLLs.

Windows LONG/DWORD/WORD have fixed 32/32/16-bit widths on both Windows x86 and x64.
Using explicit ctypes integer widths avoids the host-dependent size of c_long on Unix.
"""
from __future__ import annotations
import ctypes

DWORD = ctypes.c_uint32
WORD = ctypes.c_uint16
LONG = ctypes.c_int32
ULONG_PTR = ctypes.c_size_t
INPUT_KEYBOARD = 1
KEYEVENTF_KEYUP = 0x0002

class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", LONG), ("dy", LONG), ("mouseData", DWORD), ("dwFlags", DWORD),
                ("time", DWORD), ("dwExtraInfo", ULONG_PTR)]

class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", WORD), ("wScan", WORD), ("dwFlags", DWORD), ("time", DWORD),
                ("dwExtraInfo", ULONG_PTR)]

class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [("uMsg", DWORD), ("wParamL", WORD), ("wParamH", WORD)]

class INPUT_UNION(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT)]

class INPUT(ctypes.Structure):
    _anonymous_ = ("u",)
    _fields_ = [("type", DWORD), ("u", INPUT_UNION)]

def expected_input_size(pointer_size: int | None = None) -> int:
    size = ctypes.sizeof(ctypes.c_void_p) if pointer_size is None else int(pointer_size)
    if size not in (4, 8): raise ValueError("pointer_size must be 4 or 8 bytes")
    return 28 if size == 4 else 40

def abi_report(pointer_size: int | None = None) -> dict[str, object]:
    expected = expected_input_size(pointer_size)
    actual = ctypes.sizeof(INPUT)
    return {"pointer_size": ctypes.sizeof(ctypes.c_void_p) if pointer_size is None else int(pointer_size),
            "input_structure_size": actual, "expected_input_structure_size": expected,
            "valid": actual == expected}

def keyboard_event(vk: int, *, down: bool) -> INPUT:
    if not 0 <= int(vk) <= 0xFFFF: raise ValueError("virtual key code must fit WORD")
    flags = 0 if down else KEYEVENTF_KEYUP
    return INPUT(type=INPUT_KEYBOARD, u=INPUT_UNION(ki=KEYBDINPUT(int(vk), 0, flags, 0, 0)))
