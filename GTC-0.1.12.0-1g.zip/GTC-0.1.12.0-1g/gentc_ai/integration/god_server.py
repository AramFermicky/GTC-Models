"""Loopback HTTP service for the GTC God World 3D sandbox."""
from __future__ import annotations

import json
import sys
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from gentc_ai.god_simulation import GodMind, validate_action_payload
from gentc_ai.continuity.paths import get_shared_data_dir, get_model_learning_dir, bootstrap_legacy_learning
import shutil

PROJECT_ROOT = Path(__file__).resolve().parents[2]
LEGACY_DATA_DIR = PROJECT_ROOT / "data" / "god_sandbox"
HOST = "127.0.0.1"
PORT = 8766
MAX_BODY_BYTES = 1_000_000

def _prepare_persistent_data_dir() -> Path:
    """Use a stable per-user folder so memories survive project/version replacement."""
    bootstrap_legacy_learning()
    target = get_shared_data_dir() / "worlds" / "gtc_god_world"
    target.mkdir(parents=True, exist_ok=True)
    for legacy in get_model_learning_dir("inherited").glob("*/legacy_machine_data/*/worlds/gtc_god_world"):
        if legacy.is_dir():
            for source in legacy.iterdir():
                destination = target / source.name
                if source.is_file() and not destination.exists():
                    shutil.copy2(source, destination)
    # One-time, non-destructive migration from a local v0.1.7 save if found.
    legacy_candidates = [LEGACY_DATA_DIR]
    for base in (PROJECT_ROOT.parent, PROJECT_ROOT.parent.parent):
        try:
            for release_dir in base.glob("GenTC_AI_0.1.7*"):
                legacy_candidates.extend([release_dir / "data" / "god_sandbox",
                                          release_dir / "GenTC_AI_0.1.7" / "data" / "god_sandbox"])
        except OSError:
            pass
    for name in ("god_state.json", "learning"):
        destination = target / name
        if destination.exists():
            continue
        source = next((candidate / name for candidate in legacy_candidates if (candidate / name).exists()), None)
        if source is None:
            continue
        try:
            if source.is_dir():
                shutil.copytree(source, destination)
            else:
                shutil.copy2(source, destination)
        except OSError as exc:
            print(f"[GTC] Legacy migration skipped for {name}: {type(exc).__name__}", file=sys.stderr)
    return target

DATA_DIR = _prepare_persistent_data_dir()
MIND = GodMind(DATA_DIR)


def process_request(path: str, payload: dict[str, Any]) -> dict[str, Any]:
    payload = validate_action_payload(payload)
    world = payload["world"]
    if path == "/god/think":
        return MIND.decide(world, "none")
    if path == "/god/chat":
        text = payload.get("text")
        if not isinstance(text, str):
            raise ValueError("Поле text должно быть строкой.")
        return MIND.chat(text, world)
    if path == "/god/feedback":
        action = payload.get("action")
        outcome = payload.get("outcome")
        situation = payload.get("situation", {})
        if not isinstance(situation, dict):
            situation = {}
        situation.setdefault("world", world)
        situation.setdefault("agent_state", MIND.state)
        return {"ok": True, "learning": MIND.record_feedback(situation, action, outcome),
                "inner_state": MIND._public_inner_state()}
    raise ValueError("unknown_endpoint")


class GodRequestHandler(BaseHTTPRequestHandler):
    server_version = "GenTC-God-World/0.1.8"

    def _write_json(self, status: int, body: dict[str, Any]) -> None:
        raw = json.dumps(body, ensure_ascii=False, allow_nan=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self) -> None:  # noqa: N802
        if self.path == "/health":
            self._write_json(200, {
                "ok": True,
                "name": "GenTC AI God World",
                "version": "0.1.8",
                "service": "god_world_bridge",
                "llm_connected": False,
                "neural_model": MIND.neural_model.status(),
                "persistent_memory": MIND.world_memory.report(identity_id=MIND.identity_id),
                "data_dir": str(DATA_DIR),
                "bind": HOST,
                "port": PORT,
            })
            return
        if self.path == "/world-memory":
            self._write_json(200, {
                "ok": True,
                "memory": MIND.world_memory.report(identity_id=MIND.identity_id),
                "neural_model": MIND.neural_model.status(),
                "identity_id": MIND.identity_id,
            })
            return
        self._write_json(404, {"ok": False, "error": "not_found"})

    def do_POST(self) -> None:  # noqa: N802
        if self.path not in {"/god/think", "/god/chat", "/god/feedback"}:
            self._write_json(404, {"ok": False, "error": "not_found"})
            return
        try:
            content_length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self._write_json(400, {"ok": False, "error": "invalid_content_length"})
            return
        if content_length <= 0 or content_length > MAX_BODY_BYTES:
            self._write_json(413, {"ok": False, "error": "body_size_out_of_range"})
            return
        try:
            raw = self.rfile.read(content_length).decode("utf-8")
            payload = json.loads(raw)
            if not isinstance(payload, dict):
                raise ValueError("Тело запроса должно быть JSON-объектом.")
            result = process_request(self.path, payload)
        except (UnicodeDecodeError, json.JSONDecodeError):
            self._write_json(400, {"ok": False, "error": "invalid_json"})
            return
        except ValueError as exc:
            # Controlled request errors are safe to return; internal exceptions remain private.
            self._write_json(400, {"ok": False, "error": str(exc)[:240]})
            return
        except Exception as exc:  # Keep bridge alive after unexpected errors.
            print(f"[GTC God Bridge] Internal error: {type(exc).__name__}", file=sys.stderr)
            traceback.print_exc(file=sys.stderr)
            self._write_json(500, {"ok": False, "error": "internal_error"})
            return
        self._write_json(200, result)

    def log_message(self, fmt: str, *args: object) -> None:
        print(f"[GTC God Bridge] {self.address_string()} - {fmt % args}")


def main() -> int:
    try:
        server = ThreadingHTTPServer((HOST, PORT), GodRequestHandler)
    except OSError as exc:
        print(f"Cannot open {HOST}:{PORT}: {type(exc).__name__}", file=sys.stderr)
        print("Check whether port 8766 is already in use.", file=sys.stderr)
        return 2
    print("=" * 62)
    print("GenTC AI 0.1.8 - God World local bridge")
    print(f"Address: http://{HOST}:{PORT}")
    print("Endpoints: GET /health | POST /god/think | /god/chat | /god/feedback")
    print("No LLM is connected. World effects are decided and executed locally by Godot.")
    print(f"Persistent world memory: {DATA_DIR / 'world_memory.sqlite3'}")
    print("Memory status: http://127.0.0.1:8766/world-memory")
    print("Bound to localhost only. Stop with Ctrl+C.")
    print("=" * 62)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nGTC God World bridge stopped.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
