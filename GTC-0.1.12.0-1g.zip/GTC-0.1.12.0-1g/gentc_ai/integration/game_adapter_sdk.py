"""Small, engine-neutral contract helpers for game adapters.

The SDK does not inject into arbitrary processes. A game-side plugin/mod or a
permitted external adapter explicitly supplies observations, action manifests,
execution feedback and (optionally) screen frames to GTC.
"""
from __future__ import annotations

import base64
import hashlib
import time
from typing import Any

MAX_FRAME_BYTES = 8 * 1024 * 1024
MAX_ACTIONS = 256
_ALLOWED_FRAME_FORMATS = {"png", "jpeg", "webp", "raw_bgra"}


def validate_action_manifest(actions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    if not isinstance(actions, list) or len(actions) > MAX_ACTIONS:
        raise ValueError("action_manifest_must_be_list_of_at_most_256_items")
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in actions:
        if not isinstance(item, dict):
            raise ValueError("action_manifest_item_must_be_object")
        action_id = str(item.get("id", "")).strip()
        semantic = str(item.get("semantic_action", "unknown")).strip()
        if not action_id or len(action_id) > 96 or action_id in seen:
            raise ValueError("action_id_missing_too_long_or_duplicate")
        if not semantic or len(semantic) > 96:
            raise ValueError("semantic_action_missing_or_too_long")
        seen.add(action_id)
        result.append({
            "id": action_id,
            "semantic_action": semantic,
            "description": str(item.get("description", ""))[:240],
            "preconditions": item.get("preconditions", {}) if isinstance(item.get("preconditions", {}), dict) else {},
            "parameters": item.get("parameters", {}) if isinstance(item.get("parameters", {}), dict) else {},
            "requires_confirmation": bool(item.get("requires_confirmation", False)),
        })
    return result


def build_observation(*, game_id: str, world_id: str, frame_id: str,
                      state: dict[str, Any], available_actions: list[dict[str, Any]],
                      events: list[dict[str, Any]] | None = None,
                      captured_at_unix: float | None = None) -> dict[str, Any]:
    if not all(isinstance(x, str) and x.strip() for x in (game_id, world_id, frame_id)):
        raise ValueError("game_id_world_id_and_frame_id_required")
    if not isinstance(state, dict):
        raise ValueError("state_must_be_object")
    return {
        "schema_version": 1,
        "game_id": game_id[:96],
        "world_id": world_id[:128],
        "frame_id": frame_id[:128],
        "captured_at_unix": float(captured_at_unix if captured_at_unix is not None else time.time()),
        "state": state,
        "available_actions": validate_action_manifest(available_actions),
        "events": [e for e in (events or []) if isinstance(e, dict)][:128],
        "source": "explicit_game_adapter",
    }


def package_screen_frame(frame: bytes, *, width: int, height: int, image_format: str,
                         frame_id: str, captured_at_unix: float | None = None) -> dict[str, Any]:
    if not isinstance(frame, (bytes, bytearray)) or not frame:
        raise ValueError("frame_bytes_required")
    if len(frame) > MAX_FRAME_BYTES:
        raise ValueError("frame_exceeds_8_mib_limit")
    fmt = str(image_format).lower().lstrip(".")
    if fmt not in _ALLOWED_FRAME_FORMATS:
        raise ValueError("unsupported_frame_format")
    w, h = int(width), int(height)
    if not (1 <= w <= 16384 and 1 <= h <= 16384):
        raise ValueError("frame_dimensions_out_of_range")
    return {
        "schema_version": 1,
        "frame_id": str(frame_id)[:128],
        "width": w,
        "height": h,
        "format": fmt,
        "captured_at_unix": float(captured_at_unix if captured_at_unix is not None else time.time()),
        "sha256": hashlib.sha256(frame).hexdigest(),
        "data_base64": base64.b64encode(frame).decode("ascii"),
    }


def build_execution_feedback(*, decision_id: str, command_id: str, status: str,
                              before_state: dict[str, Any], after_state: dict[str, Any],
                              goal_achieved: bool | None, constraints_respected: bool,
                              reason: str = "") -> dict[str, Any]:
    if not decision_id or not command_id:
        raise ValueError("decision_id_and_command_id_required")
    if status not in {"executed", "rejected", "cancelled", "timed_out", "unknown"}:
        raise ValueError("invalid_execution_status")
    verified = status == "executed" and isinstance(after_state, dict) and bool(after_state)
    return {
        "decision_id": str(decision_id), "command_id": str(command_id),
        "status": status, "before_state": before_state if isinstance(before_state, dict) else {},
        "after_state": after_state if isinstance(after_state, dict) else {},
        "goal_achieved": goal_achieved if isinstance(goal_achieved, bool) else None,
        "constraints_respected": bool(constraints_respected),
        "verified": verified, "execution_confirmed": verified,
        "reason": str(reason)[:240],
    }
