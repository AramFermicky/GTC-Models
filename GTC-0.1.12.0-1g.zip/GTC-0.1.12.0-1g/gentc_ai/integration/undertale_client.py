"""Small standard-library client for controlling the local Undertale bridge."""
from __future__ import annotations

import argparse
import json
import time
import urllib.error
import urllib.request
import os
from typing import Any

from gentc_ai.integration.game_introspection import load_game_profile
from gentc_ai.version import VERSION, BUILD_ID

BASE_URL = "http://127.0.0.1:8765"


def request(path: str, payload: dict[str, Any] | None = None, timeout: float = 10.0) -> dict[str, Any]:
    data = None
    headers = {"Accept": "application/json"}
    method = "GET"
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
        method = "POST"
    req = urllib.request.Request(BASE_URL + path, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            body = response.read(1_000_000).decode("utf-8")
    except TimeoutError as exc:
        raise TimeoutError(f"HTTP request {path} timed out after {timeout:g}s; check the bridge console and port 8765.") from exc
    value = json.loads(body)
    if not isinstance(value, dict):
        raise RuntimeError("The bridge returned a non-object JSON response.")
    return value


def wait_for_bridge(seconds: float = 25.0, expected_game_id: str | None = None) -> bool:
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        try:
            response = request("/health", timeout=0.6)
            if response.get("ok"):
                bridge_version = str(response.get("version", "unknown"))
                if bridge_version != VERSION:
                    print(f"[GTC] Wrong bridge version on port 8765: {bridge_version}. Close every old GTC bridge window and start the bridge from this folder.")
                    return False
                bridge_build = str(response.get("build_id", "unknown"))
                if bridge_build != BUILD_ID:
                    print(f"[GTC] Wrong bridge build on port 8765: {bridge_build}. Close old bridge windows and start the bridge from this GTC folder.")
                    return False
                try:
                    status = request("/undertale/status", timeout=1.5)
                    if status.get("service") not in {"undertale_visual_pilot", "visual_game_pilot"}:
                        print("[GTC] This port is not serving the GTC game pilot.")
                        return False
                    actual_game_id = str((status.get("game_profile") or {}).get("game_id", ""))
                    if expected_game_id and actual_game_id != expected_game_id:
                        print(f"[GTC] Wrong game profile on port 8765: bridge={actual_game_id or 'unknown'}, requested={expected_game_id}. Close the old bridge and restart the selected game from START_GTC.bat.")
                        return False
                    adapter_version = str(status.get("adapter_version", ""))
                    if not adapter_version.startswith(BUILD_ID + "-"):
                        print(f"[GTC] Wrong Undertale adapter version: {adapter_version or 'unknown'}. Restart the bridge from this folder.")
                        return False
                    return True
                except urllib.error.HTTPError as exc:
                    if exc.code == 404:
                        print("[GTC] An older bridge is running on port 8765. Close it, then retry.")
                        return False
                except Exception:
                    pass
        except Exception:
            time.sleep(0.3)
            continue
        time.sleep(0.3)
    return False


def main() -> int:
    parser = argparse.ArgumentParser(description="GTC local visual game-agent bridge client")
    parser.add_argument("--launch", action="store_true", help="launch the configured game executable")
    parser.add_argument("--start-agent", action="store_true", help="start the autonomous explorer and battle controller (paused by default)")
    parser.add_argument("--arm", action="store_true", help="start agent with input enabled immediately; it may explore the overworld")
    parser.add_argument("--stop-agent", action="store_true", help="stop the visual pilot")
    parser.add_argument("--arm-agent", action="store_true", help="explicitly enable pilot control")
    parser.add_argument("--pause-agent", action="store_true", help="explicitly pause pilot control")
    parser.add_argument("--toggle-agent", action="store_true", help="toggle pilot control using current status")
    parser.add_argument("--diagnose", action="store_true", help="print status and one screenshot analysis")
    parser.add_argument("--status", action="store_true", help="print bridge and game status")
    parser.add_argument("--learning-report", action="store_true", help="print persistent game learning statistics")
    parser.add_argument("--introspection", action="store_true", help="print static game resource analysis and current profile")
    parser.add_argument("--feedback", choices=("damage", "death", "missed_attack", "item_misuse", "blocked", "dodge", "progress", "goal_completed"), help="record an explicit outcome label for the most recent action")
    parser.add_argument("--observe", action="store_true", help="run one screen observation")
    parser.add_argument("--exe-path", help="path to the configured game .exe (generic mode allows a different filename)")
    args = parser.parse_args()

    expected_game_id = None
    if os.environ.get("GTC_GAME_ID", "").strip() or os.environ.get("GTC_GENERIC_GAME", "").strip():
        try:
            expected_game_id = str(load_game_profile().get("game_id") or "") or None
        except Exception:
            expected_game_id = os.environ.get("GTC_GAME_ID", "").strip() or None
    if not wait_for_bridge(expected_game_id=expected_game_id):
        print("[GTC] Bridge is not responding at http://127.0.0.1:8765.")
        print("[GTC] Start the selected game mode through START_GTC.bat and leave its bridge window running, then retry.")
        return 2
    try:
        if args.launch:
            payload: dict[str, Any] = {}
            if args.exe_path:
                payload["exe_path"] = args.exe_path
            print("[GTC] Sending game-launch request (timeout 20 s)...")
            result = request("/undertale/launch", payload, timeout=20.0)
            print("[GTC] Game launch result:")
            print(json.dumps(result, ensure_ascii=False, indent=2))
        if args.start_agent:
            result = request("/undertale/agent/start", {"armed": bool(args.arm)}, timeout=15.0)
            print("[GTC] Agent result:")
            print(json.dumps(result, ensure_ascii=False, indent=2))
        if args.stop_agent:
            print(json.dumps(request("/undertale/agent/stop", {}, timeout=15.0), ensure_ascii=False, indent=2))
        if args.arm_agent:
            print(json.dumps(request("/undertale/agent/control", {"armed": True}, timeout=15.0), ensure_ascii=False, indent=2))
        if args.pause_agent:
            print(json.dumps(request("/undertale/agent/control", {"armed": False}, timeout=15.0), ensure_ascii=False, indent=2))
        if args.toggle_agent:
            current = request("/undertale/status", timeout=5.0)
            desired = not bool(current.get("agent_armed"))
            print(json.dumps(request("/undertale/agent/control", {"armed": desired}, timeout=15.0), ensure_ascii=False, indent=2))
        if args.observe:
            print(json.dumps(request("/undertale/observe", timeout=15.0), ensure_ascii=False, indent=2))
        if args.learning_report:
            print(json.dumps(request("/undertale/learning", timeout=10.0), ensure_ascii=False, indent=2))
        if args.introspection:
            print(json.dumps(request("/undertale/introspection", timeout=10.0), ensure_ascii=False, indent=2))
        if args.feedback:
            print(json.dumps(request("/undertale/feedback", {"outcome": args.feedback}, timeout=10.0), ensure_ascii=False, indent=2))
        if args.status or args.diagnose or not any((args.launch, args.start_agent, args.stop_agent, args.arm_agent, args.pause_agent, args.toggle_agent, args.observe, args.learning_report, args.introspection, args.feedback, args.diagnose)):
            print("[GTC] Status:")
            print(json.dumps(request("/undertale/status"), ensure_ascii=False, indent=2))
        if args.diagnose:
            print("[GTC] Screen observation:")
            print(json.dumps(request("/undertale/observe", timeout=15.0), ensure_ascii=False, indent=2))
        return 0
    except urllib.error.HTTPError as exc:
        try:
            detail = exc.read().decode("utf-8", errors="replace")
        except Exception:
            detail = str(exc)
        print(f"[GTC] HTTP error {exc.code}: {detail[:600]}")
        return 3
    except Exception as exc:
        print(f"[GTC] Error: {type(exc).__name__}: {exc}")
        return 4


if __name__ == "__main__":
    raise SystemExit(main())
