"""Experimental, non-invasive keyboard/screen adapter for Undertale on Windows.

It does not patch data.win or read/write Undertale's save files. The first release
is a visual pilot: it finds the game window, samples pixels, and selects short
movement inputs from a simple local danger map. It is a whole-game visual agent, not a guaranteed solver.
"""
from __future__ import annotations

import ctypes
import json
import ntpath
import os
import queue
import subprocess
import sys
import threading
import traceback
import time
import uuid
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from gentc_ai.version import BUILD_ID
from gentc_ai.continuity.paths import get_model_learning_dir, bootstrap_legacy_learning
from gentc_ai.core.agent_brain import AgentBrain
from gentc_ai.runtime.catalog import module_catalog
from gentc_ai.integration.undertale_learning import UndertaleLearningMemory, SceneMatch, frame_change, visual_change, extract_features
from gentc_ai.integration.undertale_policy import UndertalePolicyNetwork, POLICY_ACTIONS
from gentc_ai.integration.undertale_autonomy import UndertaleSelfModel, evaluate_transition
from gentc_ai.integration.game_introspection import load_game_profile, inspect_game_install, write_profile_report, read_runtime_state_feed
from gentc_ai.integration.win32_input import INPUT, abi_report, keyboard_event

GAME_PROFILE = load_game_profile()
GAME_ID = str(GAME_PROFILE.get("game_id", "undertale"))
WORLD_ID = f"{GAME_ID}_main"
ADAPTER_VERSION = f"{BUILD_ID}-permanent-game-analysis"
BATTLE_DECISION_INTERVAL = 0.006  # target only; actual interval includes capture and analysis cost
AGENT_LOOP_SLEEP = 0.0005
HUMAN_INPUT_SAMPLE_INTERVAL = 0.005
PASSIVE_OBSERVATION_INTERVAL = 0.18
OBSERVATION_HEARTBEAT_INTERVAL = 8.0
HOST = "127.0.0.1"
PORT = 8765

VK = {
    "left": 0x25, "up": 0x26, "right": 0x27, "down": 0x28,
    "z": 0x5A, "x": 0x58, "c": 0x43, "shift": 0x10,
    "enter": 0x0D, "escape": 0x1B, "ctrl": 0x11,
    "f7": 0x76, "f8": 0x77,
    "w": 0x57, "a": 0x41, "s": 0x53, "d": 0x44,
    "q": 0x51, "e": 0x45, "r": 0x52, "f": 0x46,
    "i": 0x49, "j": 0x4A, "k": 0x4B, "l": 0x4C,
    "space": 0x20, "tab": 0x09, "backspace": 0x08,
    "1": 0x31, "2": 0x32, "3": 0x33, "4": 0x34, "5": 0x35,
    "6": 0x36, "7": 0x37, "8": 0x38, "9": 0x39, "0": 0x30,
}
KEYEVENTF_KEYUP = 0x0002


def is_windows_platform() -> bool:
    """Single platform check so tests can simulate it without mutating the global os module."""
    return os.name == "nt"


def _local_data_dir() -> Path:
    """Game-specific memory inside the selected model's portable GTC_learning vault."""
    bootstrap_legacy_learning()
    target = get_model_learning_dir("worlds", GAME_ID)
    for legacy in get_model_learning_dir("inherited").glob("*/legacy_machine_data/*/worlds/" + GAME_ID):
        if legacy.is_dir():
            for source in legacy.iterdir():
                destination = target / source.name
                if source.is_file() and not destination.exists():
                    import shutil
                    shutil.copy2(source, destination)
    return target


def _project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def locate_undertale_exe(explicit: str | None = None) -> Path | None:
    """Find the configured executable; generic mode is opt-in via the game profile/env."""
    candidates: list[Path] = []
    if explicit:
        candidates.append(Path(explicit).expanduser())
    configured = str(GAME_PROFILE.get("executable_path", "") or "").strip()
    if configured:
        candidates.append(Path(configured).expanduser())
    env_path = os.environ.get("GTC_UNDERTALE_EXE")
    if env_path:
        candidates.append(Path(env_path).expanduser())
    root = _project_root()
    if not GAME_PROFILE.get("generic_mode"):
        candidates.extend([
            root / "Undertale" / "UNDERTALE.exe",
            root / "undertale" / "UNDERTALE.exe",
            root / "UNDERTALE.exe",
            root.parent / "Undertale" / "UNDERTALE.exe",
            root.parent / "undertale" / "UNDERTALE.exe",
            root.parent / "UNDERTALE.exe",
        ])
    for item in candidates:
        try:
            resolved = item.resolve()
        except OSError:
            resolved = item
        if not resolved.is_file() or resolved.suffix.lower() != ".exe":
            continue
        if resolved.name.lower() == "undertale.exe" or GAME_PROFILE.get("generic_mode") or os.environ.get("GTC_GENERIC_GAME") == "1":
            return resolved
    return None


@dataclass(frozen=True)
class Frame:
    width: int
    height: int
    # Each pixel is BGRA, top-down. Coordinates are in the sampled analysis image.
    bgra: bytes
    source_width: int | None = None
    source_height: int | None = None

    def pixel(self, x: int, y: int) -> tuple[int, int, int]:
        if not (0 <= x < self.width and 0 <= y < self.height):
            return (0, 0, 0)
        i = (y * self.width + x) * 4
        b, g, r = self.bgra[i], self.bgra[i + 1], self.bgra[i + 2]
        return (r, g, b)


@dataclass
class Observation:
    width: int
    height: int
    battle_visible: bool
    soul: dict[str, Any] | None
    arena: dict[str, int] | None
    hazards: int
    scene_confidence: float
    captured_at: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "width": self.width, "height": self.height,
            "battle_visible": self.battle_visible,
            "soul": self.soul, "arena": self.arena,
            "hazard_pixels": self.hazards,
            "scene_confidence": round(self.scene_confidence, 3),
            "captured_at": self.captured_at,
        }


def _components_from_mask(mask: bytearray, w: int, h: int, x0: int, y0: int) -> list[dict[str, int]]:
    """Extract compact connected components from one color mask."""
    if not mask or not w or not h or sum(mask) < 5:
        return []
    seen = bytearray(w * h)
    found: list[dict[str, int]] = []
    for start, is_pixel in enumerate(mask):
        if not is_pixel or seen[start]:
            continue
        q = deque([start])
        seen[start] = 1
        min_x = max_x = start % w
        min_y = max_y = start // w
        area = 0
        while q:
            idx = q.popleft()
            yy, xx = divmod(idx, w)
            area += 1
            if xx < min_x: min_x = xx
            if xx > max_x: max_x = xx
            if yy < min_y: min_y = yy
            if yy > max_y: max_y = yy
            for nxt in (idx - 1 if xx else -1, idx + 1 if xx + 1 < w else -1,
                        idx - w if yy else -1, idx + w if yy + 1 < h else -1):
                if nxt >= 0 and mask[nxt] and not seen[nxt]:
                    seen[nxt] = 1
                    q.append(nxt)
        bw = max_x - min_x + 1
        bh = max_y - min_y + 1
        if 5 <= area <= 110 and 3 <= bw <= 20 and 3 <= bh <= 20:
            found.append({"x": x0 + (min_x + max_x) // 2,
                          "y": y0 + (min_y + max_y) // 2,
                          "area": area, "width": bw, "height": bh})
    return found


def _color_components(frame: Frame, x0: int, y0: int, x1: int, y1: int) -> tuple[list[dict[str, int]], list[dict[str, int]]]:
    """Find red and blue candidate blobs with one scan over BGRA pixels."""
    x0 = max(0, min(frame.width, x0)); x1 = max(x0, min(frame.width, x1))
    y0 = max(0, min(frame.height, y0)); y1 = max(y0, min(frame.height, y1))
    w = x1 - x0; h = y1 - y0
    if w <= 0 or h <= 0:
        return [], []
    red_mask = bytearray(w * h)
    blue_mask = bytearray(w * h)
    red_count = blue_count = 0
    pixels = frame.bgra
    for yy in range(h):
        source = ((y0 + yy) * frame.width + x0) * 4
        target = yy * w
        for xx in range(w):
            i = source + xx * 4
            b, g, r = pixels[i], pixels[i + 1], pixels[i + 2]
            if r >= 190 and g <= 65 and b <= 85:
                red_mask[target + xx] = 1
                red_count += 1
            if b >= 205 and r <= 65 and g <= 110:
                blue_mask[target + xx] = 1
                blue_count += 1
    red = _components_from_mask(red_mask, w, h, x0, y0) if red_count >= 5 else []
    blue = _components_from_mask(blue_mask, w, h, x0, y0) if blue_count >= 5 else []
    return red, blue


def _components(frame: Frame, x0: int, y0: int, x1: int, y1: int, kind: str) -> list[dict[str, int]]:
    """Compatibility wrapper retained for adapter tests and diagnostics."""
    red, blue = _color_components(frame, x0, y0, x1, y1)
    return red if kind == "red" else blue


def analyze_frame(frame: Frame) -> Observation:
    """Optimized screen-only battle detector; visual classifications remain heuristic."""
    w, h = frame.width, frame.height
    pixels = frame.bgra
    if w < 80 or h < 80 or len(pixels) < w * h * 4:
        raise ValueError("Invalid screenshot dimensions or pixel buffer.")
    rx0, rx1 = int(w * 0.18), int(w * 0.82)
    ry0, ry1 = int(h * 0.20), int(h * 0.77)
    red_components, blue_components = _color_components(frame, rx0, ry0, rx1, ry1)
    candidates = []
    for kind, components in (("red", red_components), ("blue", blue_components)):
        for comp in components:
            center_dist = abs(comp["x"] - w * 0.5) / w + abs(comp["y"] - h * 0.53) / h
            score = center_dist + abs(comp["area"] - 34) / 260
            candidates.append((score, kind, comp))
    soul = None
    if candidates:
        candidates.sort(key=lambda item: item[0])
        score, kind, comp = candidates[0]
        soul = {"x": comp["x"], "y": comp["y"], "mode": kind,
                "component_pixels": comp["area"], "confidence": round(max(0.05, 1.0 - score), 3)}

    # Most exploration frames have no coloured soul. Return immediately rather than
    # scanning every row/column for a battle arena on ordinary rooms, dialogue and menus.
    if soul is None:
        return Observation(w, h, False, None, None, 0, 0.0,
                           datetime.now(timezone.utc).isoformat())

    # Border detection samples around 200 columns and 150 rows. Direct BGRA indexing
    # avoids allocating RGB tuples for every sampled pixel, while scanning all candidate
    # border rows/columns preserves one-pixel pixel-art outlines.
    xlo, xhi = int(w * 0.15), int(w * 0.85)
    ylo, yhi = int(h * 0.18), int(h * 0.82)
    row_x_step = max(2, (xhi - xlo + 199) // 200)
    col_y_step = max(2, (yhi - ylo + 149) // 150)
    sampled_row_width = max(1, (xhi - xlo + row_x_step - 1) // row_x_step)
    sampled_col_height = max(1, (yhi - ylo + col_y_step - 1) // col_y_step)
    row_threshold = max(8, int(sampled_row_width * 0.22))
    col_threshold = max(8, int(sampled_col_height * 0.22))
    white_row: list[int] = []
    for y in range(ylo, yhi):
        n = 0
        row = y * w * 4
        for x in range(xlo, xhi, row_x_step):
            i = row + x * 4
            if pixels[i + 2] > 215 and pixels[i + 1] > 215 and pixels[i] > 215:
                n += 1
        if n >= row_threshold:
            white_row.append(y)
    white_col: list[int] = []
    for x in range(xlo, xhi):
        col = x * 4
        n = 0
        for y in range(ylo, yhi, col_y_step):
            i = y * w * 4 + col
            if pixels[i + 2] > 215 and pixels[i + 1] > 215 and pixels[i] > 215:
                n += 1
        if n >= col_threshold:
            white_col.append(x)

    arena = None
    if len(white_row) >= 2 and len(white_col) >= 2:
        top, bottom = min(white_row), max(white_row)
        left, right = min(white_col), max(white_col)
        if right - left >= int(w * 0.12) and bottom - top >= int(h * 0.10):
            arena = {"left": left, "top": top, "right": right, "bottom": bottom}
    if arena is None and soul:
        arena = {"left": int(w * 0.25), "top": int(h * 0.28),
                 "right": int(w * 0.75), "bottom": int(h * 0.70), "inferred": 1}

    hazards = 0
    if arena:
        left = max(0, arena["left"] + 3); right = min(w, arena["right"] - 3)
        top = max(0, arena["top"] + 3); bottom = min(h, arena["bottom"] - 3)
        stride = max(2, min(w, h) // 120)
        for y in range(top, bottom, stride):
            row = y * w * 4
            for x in range(left, right, stride):
                i = row + x * 4
                b, g, r = pixels[i], pixels[i + 1], pixels[i + 2]
                white = r > 230 and g > 230 and b > 230
                cyan = b > 195 and g > 115 and r < 125
                if (white or cyan) and not (soul and abs(x - soul["x"]) <= 9 and abs(y - soul["y"]) <= 9):
                    hazards += 1

    visible = bool(soul and arena)
    confidence = 0.0
    if soul:
        confidence += 0.40 * float(soul["confidence"])
    if arena and not arena.get("inferred"):
        confidence += 0.35
    if hazards:
        confidence += 0.10
    if visible:
        confidence += 0.15
    return Observation(w, h, visible, soul, arena, hazards, min(0.99, confidence),
                       datetime.now(timezone.utc).isoformat())


def analyze_profiled_frame(frame: Frame) -> Observation:
    """Run Undertale-specific battle detection only when the selected profile is Undertale."""
    observation = analyze_frame(frame)
    if not bool(GAME_PROFILE.get("battle_detection", False)):
        return Observation(frame.width, frame.height, False, None, None, 0, 0.0,
                           observation.captured_at)
    return observation


def _external_outcome(before: dict[str, Any] | None, after: dict[str, Any] | None) -> str | None:
    """Derive a high-confidence label only from a fresh, explicitly provided game-state feed."""
    if not isinstance(before, dict) or not isinstance(after, dict):
        return None
    if not before.get("available") or not after.get("available"):
        return None
    # Do not turn arbitrary or inferred JSON into a strong RL label. The game-side adapter
    # must explicitly mark the state snapshot as verified.
    if before.get("verified") is not True or after.get("verified") is not True:
        return None
    status = str(after.get("status", "")).strip().casefold().replace("-", "_")
    if after.get("game_over") is True or after.get("defeated") is True or status in {"dead", "death", "defeat", "defeated", "game_over", "game over"}:
        return "death"
    if after.get("victory") is True or after.get("objective_completed") is True or status in {"victory", "complete", "completed", "won", "success", "objective_completed"}:
        return "goal_completed"
    before_hp, after_hp = before.get("health"), after.get("health")
    try:
        if before_hp is not None and after_hp is not None and float(after_hp) < float(before_hp):
            return "damage"
    except (TypeError, ValueError, OverflowError):
        pass
    before_progress, after_progress = before.get("progress"), after.get("progress")
    try:
        if before_progress is not None and after_progress is not None and float(after_progress) > float(before_progress):
            return "progress"
    except (TypeError, ValueError, OverflowError):
        pass
    # Scene changes alone can be menus or dialogs; visual reward shaping handles them weakly.
    return None


def _select_game_window_candidate(
    candidates: list[dict[str, Any]],
    *,
    target_title: str,
    target_executable: str | None,
    own_pid: int | None = None,
) -> tuple[dict[str, Any] | None, str]:
    """Choose the actual game window, not a bridge/console whose title mentions the game.

    Candidates are generated by Win32 enumeration and include process metadata. A known
    target executable outranks title matching; bridge/helper windows and the bridge's own
    process are never eligible. This pure function is independently unit-testable.
    """
    target_title_cf = str(target_title or "").strip().casefold()
    helper_markers = (
        "--bridge-helper", "gtc undertale bridge", "gtc core bridge",
        "gtc multi-adapter bridge", "errors_log_testing",
    )
    target_path = ntpath.normcase(ntpath.normpath(ntpath.expandvars(ntpath.expanduser(str(target_executable))))) if target_executable else None
    target_name = ntpath.basename(target_path).casefold() if target_path else None
    ranked: list[tuple[tuple[int, int, int], dict[str, Any], str]] = []

    for item in candidates:
        title = str(item.get("title", ""))
        title_cf = title.casefold().strip()
        hwnd = item.get("hwnd")
        pid = item.get("pid")
        process_path = item.get("process_path")
        process_path_s = str(process_path).strip() if process_path else ""
        process_name = ntpath.basename(process_path_s).casefold() if process_path_s else ""
        try:
            area = max(0, int(item.get("width", 0))) * max(0, int(item.get("height", 0)))
        except (TypeError, ValueError, OverflowError):
            area = 0
        try:
            pid_int = int(pid) if pid is not None else None
        except (TypeError, ValueError, OverflowError):
            pid_int = None
        if hwnd is None or not title_cf:
            continue
        if own_pid is not None and pid_int == int(own_pid):
            continue
        if any(marker in title_cf for marker in helper_markers):
            continue
        if target_title_cf and target_title_cf not in title_cf:
            continue

        process_rank = 0
        reason = "title_match_fallback"
        if target_name:
            if process_path_s:
                process_path_norm = ntpath.normcase(ntpath.normpath(ntpath.expandvars(ntpath.expanduser(process_path_s))))
                if process_path_norm == target_path:
                    process_rank = 3
                    reason = "exact_target_executable_path"
                elif process_name == target_name:
                    process_rank = 2
                    reason = "target_executable_name"
                else:
                    # Process identity is known and it is not the desired game. Never
                    # send game input to a different process that merely copied its title.
                    continue
            else:
                # When Windows denies process-path access, an exact game-window title is
                # the only conservative fallback. Substring-only matches remain rejected.
                if title_cf != target_title_cf:
                    continue
                process_rank = 1
                reason = "exact_title_process_path_unavailable"
        title_rank = 2 if title_cf == target_title_cf else 1
        ranked.append(((process_rank, title_rank, area), item, reason))

    if not ranked:
        return None, "no_eligible_game_window"
    ranked.sort(key=lambda row: row[0], reverse=True)
    _score, selected, reason = ranked[0]
    return selected, reason


class WindowsScreen:
    """Win32-only capture and keyboard helpers using ctypes; no pip dependencies."""
    def __init__(self) -> None:
        if os.name != "nt":
            raise RuntimeError("Undertale screen control is currently supported only on Windows.")
        self.user32 = ctypes.windll.user32
        self.gdi32 = ctypes.windll.gdi32
        self.kernel32 = ctypes.windll.kernel32
        from ctypes import wintypes
        # Declare pointer-sized return types explicitly; ctypes defaults to a
        # 32-bit C int, which can truncate GDI handles in 64-bit Python.
        self.user32.GetDC.argtypes = [wintypes.HWND]
        self.user32.GetDC.restype = wintypes.HDC
        self.user32.ReleaseDC.argtypes = [wintypes.HWND, wintypes.HDC]
        self.user32.GetForegroundWindow.restype = wintypes.HWND
        self.user32.IsWindow.argtypes = [wintypes.HWND]
        self.user32.IsWindow.restype = wintypes.BOOL
        self.user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        self.user32.GetWindowThreadProcessId.restype = wintypes.DWORD
        self.kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        self.kernel32.OpenProcess.restype = wintypes.HANDLE
        self.kernel32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
        self.kernel32.QueryFullProcessImageNameW.restype = wintypes.BOOL
        self.kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        self.kernel32.CloseHandle.restype = wintypes.BOOL
        self._cached_window: int | None = None
        self._window_search_after = 0.0
        self._last_window_selection: dict[str, Any] = {
            "selected": None, "selection_reason": "not_searched", "candidate_count": 0,
            "candidates": [], "target_title_contains": self.target_window_title if hasattr(self, "target_window_title") else None,
        }
        # Distinguish a selected action from a successfully submitted Win32 event.
        # This telemetry is essential when diagnosing a stationary agent on Windows.
        self.input_stats: dict[str, Any] = {
            "attempted_events": 0,
            "sendinput_successes": 0,
            "keybd_event_fallbacks": 0,
            "failed_events": 0,
            "last_event": None,
            "last_sendinput_result": None,
            "last_error_code": None,
            "input_structure_size": None,
            "expected_input_structure_size": None,
        }
        self.target_window_title = str(GAME_PROFILE.get("window_title_contains", "Undertale") or "Undertale").casefold()
        configured_executable = str(GAME_PROFILE.get("executable_path") or os.environ.get("GTC_GAME_EXE") or "").strip()
        located_executable = locate_undertale_exe()
        self.target_executable_path = str(located_executable) if located_executable else (os.path.expandvars(os.path.expanduser(configured_executable)) if configured_executable else None)
        if not self.target_executable_path and not GAME_PROFILE.get("generic_mode"):
            # The default Undertale profile has an executable identity even if discovery
            # cannot locate the installed file. This prevents choosing a bridge window.
            self.target_executable_path = "UNDERTALE.exe"
        self._last_window_selection["target_title_contains"] = self.target_window_title
        self._last_window_selection["target_executable_name"] = os.path.basename(self.target_executable_path).casefold() if self.target_executable_path else None
        self.user32.GetClientRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
        self.user32.ClientToScreen.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.POINT)]
        self.user32.IsWindowVisible.argtypes = [wintypes.HWND]
        self.user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
        self.user32.GetWindowTextLengthW.restype = ctypes.c_int
        self.user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        # Leave EnumWindows argtypes unspecified so the ctypes callback pointer is
        # accepted across Windows Python builds; its second parameter is always 0.
        self.user32.EnumWindows.restype = wintypes.BOOL
        self.user32.keybd_event.argtypes = [wintypes.BYTE, wintypes.BYTE, wintypes.DWORD, ctypes.c_size_t]
        self.user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
        self.user32.GetAsyncKeyState.restype = ctypes.c_short
        self.user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
        self.user32.SetForegroundWindow.argtypes = [wintypes.HWND]
        self.gdi32.CreateCompatibleDC.argtypes = [wintypes.HDC]
        self.gdi32.CreateCompatibleDC.restype = wintypes.HDC
        self.gdi32.CreateCompatibleBitmap.argtypes = [wintypes.HDC, ctypes.c_int, ctypes.c_int]
        self.gdi32.CreateCompatibleBitmap.restype = wintypes.HBITMAP
        self.gdi32.SelectObject.argtypes = [wintypes.HDC, wintypes.HGDIOBJ]
        self.gdi32.SelectObject.restype = wintypes.HGDIOBJ
        self.gdi32.DeleteObject.argtypes = [wintypes.HGDIOBJ]
        self.gdi32.DeleteDC.argtypes = [wintypes.HDC]
        self.gdi32.BitBlt.argtypes = [wintypes.HDC, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                      wintypes.HDC, ctypes.c_int, ctypes.c_int, wintypes.DWORD]
        self.gdi32.BitBlt.restype = wintypes.BOOL
        self.gdi32.StretchBlt.argtypes = [wintypes.HDC, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                          wintypes.HDC, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                          wintypes.DWORD]
        self.gdi32.StretchBlt.restype = wintypes.BOOL
        self.gdi32.SetStretchBltMode.argtypes = [wintypes.HDC, ctypes.c_int]
        self.gdi32.SetStretchBltMode.restype = ctypes.c_int
        from gentc_ai.integration.win32_gdi import BITMAPINFO
        self.gdi32.GetDIBits.argtypes = [wintypes.HDC, wintypes.HBITMAP, wintypes.UINT, wintypes.UINT,
                                         ctypes.c_void_p, ctypes.POINTER(BITMAPINFO), wintypes.UINT]
        self.gdi32.GetDIBits.restype = ctypes.c_int

    def _process_image_path(self, pid: int) -> str | None:
        """Query the full image path without using psutil or shell commands."""
        from ctypes import wintypes
        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        handle = self.kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, int(pid))
        if not handle:
            return None
        try:
            capacity = wintypes.DWORD(32768)
            buffer = ctypes.create_unicode_buffer(capacity.value)
            if self.kernel32.QueryFullProcessImageNameW(handle, 0, buffer, ctypes.byref(capacity)):
                return buffer.value
            return None
        except (OSError, ValueError, TypeError):
            return None
        finally:
            self.kernel32.CloseHandle(handle)

    def _window_details(self, hwnd: int) -> dict[str, Any] | None:
        from ctypes import wintypes
        if not self.user32.IsWindow(hwnd) or not self.user32.IsWindowVisible(hwnd):
            return None
        n = self.user32.GetWindowTextLengthW(hwnd)
        title_buf = ctypes.create_unicode_buffer(max(1, n + 1))
        self.user32.GetWindowTextW(hwnd, title_buf, len(title_buf))
        title = title_buf.value
        rect = wintypes.RECT()
        if not self.user32.GetClientRect(hwnd, ctypes.byref(rect)):
            return None
        width, height = rect.right - rect.left, rect.bottom - rect.top
        if width < 200 or height < 200:
            return None
        pid_value = wintypes.DWORD(0)
        self.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid_value))
        pid = int(pid_value.value)
        process_path = self._process_image_path(pid) if pid else None
        return {
            "hwnd": int(hwnd), "title": title, "width": int(width), "height": int(height),
            "pid": pid, "process_path": process_path,
            "process_name": os.path.basename(process_path).casefold() if process_path else None,
        }

    def find_window(self) -> int | None:
        """Find the actual game process, never the larger GTC helper console.

        Cache hits are revalidated at least once per second. Previously the title-only
        match sorted by client area; the bridge console's title itself contained
        "Undertale" and its 1184x608 client area beat the 1024x576 game window.
        """
        from ctypes import wintypes
        now = time.monotonic()
        cached = self._cached_window
        if cached and self.user32.IsWindow(cached) and now < self._window_search_after:
            return cached
        if not cached and now < self._window_search_after:
            return None

        candidates: list[dict[str, Any]] = []
        EnumWindowsProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, ctypes.c_ssize_t)

        def callback(hwnd: int, _lparam: int) -> bool:
            if not self.user32.IsWindowVisible(hwnd):
                return True
            # Filter cheap title text before querying the process image path. This avoids
            # opening process handles for every unrelated desktop window on each refresh.
            n = self.user32.GetWindowTextLengthW(hwnd)
            title_buf = ctypes.create_unicode_buffer(max(1, n + 1))
            self.user32.GetWindowTextW(hwnd, title_buf, len(title_buf))
            if self.target_window_title not in title_buf.value.casefold():
                return True
            details = self._window_details(int(hwnd))
            if details:
                candidates.append(details)
            return True

        self.user32.EnumWindows(EnumWindowsProc(callback), 0)
        selected, reason = _select_game_window_candidate(
            candidates, target_title=self.target_window_title,
            target_executable=self.target_executable_path, own_pid=os.getpid(),
        )
        self._cached_window = int(selected["hwnd"]) if selected else None
        self._window_search_after = now + (1.0 if selected else 0.25)
        summary_candidates = []
        for item in candidates[:20]:
            process_path = item.get("process_path")
            summary_candidates.append({
                "hwnd": item["hwnd"], "title": item["title"], "pid": item["pid"],
                "client_size": [item["width"], item["height"]],
                "process_name": item.get("process_name"),
                "process_matches_target": bool(process_path and self.target_executable_path and
                    os.path.basename(str(process_path)).casefold() == os.path.basename(self.target_executable_path).casefold()),
                "foreground": self.is_foreground(int(item["hwnd"])),
            })
        self._last_window_selection = {
            "target_title_contains": self.target_window_title,
            "target_executable_name": os.path.basename(self.target_executable_path).casefold() if self.target_executable_path else None,
            "candidate_count": len(candidates), "candidates": summary_candidates,
            "selected": ({
                "hwnd": selected["hwnd"], "title": selected["title"], "pid": selected["pid"],
                "client_size": [selected["width"], selected["height"]],
                "process_name": selected.get("process_name"),
                "foreground": self.is_foreground(int(selected["hwnd"])),
            } if selected else None),
            "selection_reason": reason,
            "bridge_pid_excluded": os.getpid(),
        }
        return self._cached_window

    def window_selection_summary(self) -> dict[str, Any]:
        """Small, JSON-safe explanation of which window was chosen and why."""
        return dict(self._last_window_selection)

    def is_foreground(self, hwnd: int) -> bool:
        return int(self.user32.GetForegroundWindow()) == int(hwnd)

    def capture(self, hwnd: int) -> Frame:
        from ctypes import wintypes
        from gentc_ai.integration.win32_gdi import BITMAPINFO, BITMAPINFOHEADER, RGBQUAD
        rect = wintypes.RECT()
        if not self.user32.GetClientRect(hwnd, ctypes.byref(rect)):
            raise OSError("GetClientRect failed")
        width, height = rect.right - rect.left, rect.bottom - rect.top
        if width < 80 or height < 80 or width * height > 16_000_000:
            raise RuntimeError(f"Unexpected Undertale client dimensions: {width}x{height}")
        point = wintypes.POINT(0, 0)
        if not self.user32.ClientToScreen(hwnd, ctypes.byref(point)):
            raise OSError("ClientToScreen failed")
        # Scale directly in GDI instead of reading a full-size bitmap and copying every
        # Nth pixel in Python. This removes the expensive per-pixel downsampling loop.
        stride = max(2, (max(width, height) + 639) // 640)
        sampled_width = max(1, width // stride)
        sampled_height = max(1, height // stride)
        screen_dc = self.user32.GetDC(0)
        memory_dc = self.gdi32.CreateCompatibleDC(screen_dc)
        bitmap = self.gdi32.CreateCompatibleBitmap(screen_dc, sampled_width, sampled_height)
        old_obj = self.gdi32.SelectObject(memory_dc, bitmap)
        try:
            # COLORONCOLOR (3) keeps Undertale's sharp pixel-art colors recognizable.
            self.gdi32.SetStretchBltMode(memory_dc, 3)
            # SRCCOPY | CAPTUREBLT includes ordinary desktop content in the client area.
            if not self.gdi32.StretchBlt(memory_dc, 0, 0, sampled_width, sampled_height,
                                         screen_dc, point.x, point.y, width, height,
                                         0x00CC0020 | 0x40000000):
                raise OSError("StretchBlt failed; ensure the game window is visible.")
            # GetDIBits requires the bitmap not to be selected into a DC.
            self.gdi32.SelectObject(memory_dc, old_obj)
            old_obj = None
            header = BITMAPINFOHEADER()
            header.biSize = ctypes.sizeof(BITMAPINFOHEADER)
            header.biWidth = sampled_width
            header.biHeight = -sampled_height  # top-down rows
            header.biPlanes = 1
            header.biBitCount = 32
            header.biCompression = 0
            header.biSizeImage = sampled_width * sampled_height * 4
            info = BITMAPINFO(header, RGBQUAD(0, 0, 0, 0))
            pixels = (ctypes.c_ubyte * (sampled_width * sampled_height * 4))()
            lines = self.gdi32.GetDIBits(memory_dc, bitmap, 0, sampled_height,
                                         ctypes.cast(pixels, ctypes.c_void_p), ctypes.byref(info), 0)
            if lines != sampled_height:
                raise OSError(f"GetDIBits returned {lines} of {sampled_height} rows")
            return Frame(sampled_width, sampled_height, bytes(pixels), width, height)
        finally:
            if old_obj is not None:
                self.gdi32.SelectObject(memory_dc, old_obj)
            self.gdi32.DeleteObject(bitmap)
            self.gdi32.DeleteDC(memory_dc)
            self.user32.ReleaseDC(0, screen_dc)

    def key(self, name: str, down: bool) -> None:
        """Submit a keyboard event using the verified, exact-width Win32 INPUT ABI."""
        from ctypes import wintypes
        vk = VK[name]
        layout = abi_report()
        self.input_stats["input_structure_size"] = layout["input_structure_size"]
        self.input_stats["expected_input_structure_size"] = layout["expected_input_structure_size"]
        if not layout["valid"]:
            message = (f"Invalid Win32 INPUT size: {layout['input_structure_size']}; "
                       f"expected {layout['expected_input_structure_size']} for this process")
            self.input_stats["failed_events"] += 1
            self.input_stats["last_error_code"] = message
            raise RuntimeError(message)

        event = keyboard_event(vk, down=down)
        event_flags = 0 if down else KEYEVENTF_KEYUP
        self.input_stats["attempted_events"] += 1
        self.input_stats["last_event"] = {"key": name, "edge": "down" if down else "up", "at_unix": time.time()}
        try:
            self.user32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int]
            self.user32.SendInput.restype = wintypes.UINT
            sent = int(self.user32.SendInput(1, ctypes.byref(event), ctypes.sizeof(INPUT)))
            self.input_stats["last_sendinput_result"] = sent
            if sent == 1:
                self.input_stats["sendinput_successes"] += 1
                self.input_stats["last_error_code"] = None
                return
            try:
                self.input_stats["last_error_code"] = int(ctypes.windll.kernel32.GetLastError())
            except Exception:
                self.input_stats["last_error_code"] = None
        except Exception as exc:
            self.input_stats["last_error_code"] = f"{type(exc).__name__}: {exc}"

        # Windows does not acknowledge whether the focused application consumed the event.
        # Record legacy fallback use separately; telemetry must not claim movement succeeded.
        try:
            self.user32.keybd_event(vk, 0, event_flags, 0)
            self.input_stats["keybd_event_fallbacks"] += 1
        except Exception as exc:
            self.input_stats["failed_events"] += 1
            self.input_stats["last_error_code"] = f"{type(exc).__name__}: {exc}"

    def input_diagnostics(self) -> dict[str, Any]:
        return dict(self.input_stats)

    def key_down(self, name: str) -> bool:
        return bool(self.user32.GetAsyncKeyState(VK[name]) & 0x8000)

    def focus(self, hwnd: int) -> None:
        self.user32.ShowWindow(hwnd, 9)  # SW_RESTORE
        self.user32.SetForegroundWindow(hwnd)


class UndertaleRuntime:
    def __init__(self) -> None:
        self.lock = threading.RLock()
        self.screen: WindowsScreen | None = None
        self.window: int | None = None
        self.process: subprocess.Popen[Any] | None = None
        self.agent: UndertalePilot | None = None
        self.last_error: str | None = None
        self._diagnostic_lock = threading.RLock()
        try:
            self.diagnostics_path = _local_data_dir() / "runtime_diagnostics.jsonl"
        except Exception:
            self.diagnostics_path = None
        self.game_profile = dict(GAME_PROFILE)
        self.game_profile["controls"] = dict(GAME_PROFILE.get("controls", {}))
        self.game_profile["configured_controls"] = list(GAME_PROFILE.get("configured_controls", []))
        self.game_profile["auto_detected_controls"] = []
        self.game_introspection: dict[str, Any] = {"status": "not_started", "runtime_internals_accessed": False}
        self._inspection_lock = threading.RLock()
        self._inspection_thread: threading.Thread | None = None
        self._inspection_target: str | None = None
        self._load_cached_control_hints()

    def write_diagnostic(self, event: str, **details: Any) -> None:
        """Append bounded-size, structured runtime breadcrumbs for post-mortem reports."""
        path = self.diagnostics_path
        if path is None:
            return
        record = {"ts_unix": time.time(), "event": str(event)[:100], **details}
        try:
            encoded = json.dumps(record, ensure_ascii=False, allow_nan=False, default=str) + "\n"
            with self._diagnostic_lock:
                try:
                    if path.exists() and path.stat().st_size > 2_000_000:
                        backup = path.with_suffix(path.suffix + ".1")
                        try:
                            backup.unlink(missing_ok=True)
                        except OSError:
                            pass
                        try:
                            path.replace(backup)
                        except OSError:
                            pass
                except OSError:
                    pass
                path.parent.mkdir(parents=True, exist_ok=True)
                with path.open("a", encoding="utf-8", newline="\n") as stream:
                    stream.write(encoded)
        except Exception:
            # Diagnostics must never crash the game controller.
            return

    def _load_cached_control_hints(self) -> None:
        """Restore previously inferred controls for generic games unless a user profile owns them."""
        if not self.game_profile.get("generic_mode") or self.game_profile.get("profile_warning"):
            return
        path = _local_data_dir() / "game_controls_learned.json"
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            controls = data.get("controls", {}) if isinstance(data, dict) else {}
            if not isinstance(controls, dict):
                return
            accepted = {str(a): str(k).lower() for a, k in controls.items()
                        if str(a) in self.game_profile["controls"] and str(k).lower() in VK}
            self.game_profile["controls"].update(accepted)
            self.game_profile["auto_detected_controls"] = sorted(accepted)
            self.game_profile["control_learning_source"] = "cached_static_hints"
        except (OSError, UnicodeError, json.JSONDecodeError, AttributeError):
            return

    def _apply_static_control_hints(self, report: dict[str, Any]) -> None:
        """Use static text hints as low-confidence starting candidates in profile-less generic games."""
        if not self.game_profile.get("generic_mode") or self.game_profile.get("profile_warning"):
            report["control_hint_application"] = "not_applied_non_generic_game_or_invalid_profile"
            return
        controls = dict(self.game_profile.get("controls", {}))
        already_configured = set(self.game_profile.get("configured_controls", []))
        inferred = dict((name, controls[name]) for name in self.game_profile.get("auto_detected_controls", [])
                       if name in controls)
        applied: list[dict[str, str]] = []
        for candidate in report.get("candidate_controls", []):
            key = str(candidate.get("key_or_scheme", "")).lower()
            action = str(candidate.get("action", "")).lower()
            if candidate.get("kind") == "movement_scheme" and key == "wasd":
                proposed = {"left": "a", "right": "d", "up": "w", "down": "s"}
                for semantic, physical in proposed.items():
                    if semantic not in already_configured and semantic not in inferred:
                        controls[semantic] = physical
                        inferred[semantic] = physical
                        applied.append({"action": semantic, "key": physical, "source": "WASD movement hint", "confidence": "low"})
                continue
            if action in {"interact", "confirm", "cancel", "menu", "jump", "attack", "inventory", "use_item"} and key in VK:
                if action in already_configured or action in inferred:
                    continue
                controls[action] = key
                inferred[action] = key
                applied.append({"action": action, "key": key,
                                "source": str(candidate.get("source_hint", "static text"))[:120],
                                "confidence": "low"})
        if not applied:
            report["control_hint_application"] = "no_new_usable_hints"
            return
        with self.lock:
            self.game_profile["controls"] = controls
            self.game_profile["auto_detected_controls"] = sorted(inferred)
            self.game_profile["control_learning_source"] = "static_string_hints_low_confidence"
        control_path = _local_data_dir() / "game_controls_learned.json"
        write_profile_report(control_path, {"schema_version": 1, "game_id": GAME_ID,
                                            "source_executable": report.get("executable", {}).get("sampled_sha256"),
                                            "controls": inferred, "applied_hints": applied,
                                            "confidence": "low; autonomous visual feedback must validate effects"})
        report["applied_control_hints"] = applied
        report["control_hint_application"] = "applied_low_confidence_hints_and_saved_for_future_sessions"
        report["learned_controls_path"] = str(control_path)

    def _windows(self) -> WindowsScreen:
        if self.screen is None:
            self.screen = WindowsScreen()
        return self.screen

    def learning_report(self) -> dict[str, Any]:
        with self.lock:
            agent = self.agent
        if agent:
            try:
                report = agent.memory.stats()
                report["policy_network"] = agent.policy_network.status()
                report["permanent_analysis"] = {
                    "running": bool(agent.thread and agent.thread.is_alive()),
                    "frames_seen": int(agent.frames_seen),
                    "passive_analysis_frames": int(agent.passive_frames_seen),
                    "last_observation_unix": agent.last_observation_unix,
                    "observation_interval_seconds": PASSIVE_OBSERVATION_INTERVAL,
                    "player_data_required_for_autonomy": False,
                }
                report["control_mapping"] = agent.memory.control_mapping_report(agent.runtime.game_profile.get("controls", {}))
                report["reinforcement_learning"] = {
                    "method": "tabular Q-learning with one-step temporal-difference targets + visual MLP policy",
                    "q_value_entries": int(report.get("q_value_entries", 0)),
                    "discount_factor": 0.62,
                    "neutral_actions_change_q": False,
                }
                report["last_training_result"] = agent.last_training_result
                report["last_training_error"] = agent.last_training_error
                report["average_loop_ms"] = (round(sum(agent._loop_time_samples) / len(agent._loop_time_samples), 2)
                                              if agent._loop_time_samples else None)
                return report
            except Exception as exc:
                return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
        memory = UndertaleLearningMemory(_local_data_dir() / f"{GAME_ID}_experience.sqlite3")
        try:
            report = memory.stats()
            report["policy_network"] = UndertalePolicyNetwork(_local_data_dir() / f"{GAME_ID}_policy_network.json").status()
            report["control_mapping"] = memory.control_mapping_report(GAME_PROFILE.get("controls", {}))
            return report
        finally:
            memory.close()

    def status(self) -> dict[str, Any]:
        is_windows = is_windows_platform()
        hwnd = None
        if is_windows:
            try:
                hwnd = self._windows().find_window()
            except Exception as exc:
                self.last_error = f"{type(exc).__name__}: {exc}"
        with self.lock:
            return {
                "ok": is_windows,
                "service": "undertale_visual_pilot" if GAME_ID == "undertale" else "visual_game_pilot",
                "adapter_version": ADAPTER_VERSION,
                "game_profile": {key: self.game_profile.get(key) for key in ("game_id", "display_name", "window_title_contains", "generic_mode", "battle_detection", "controls", "source_profile", "profile_warning")},
                "game_introspection": self._introspection_status(),
                "runtime_state_feed": (self.agent.state_feed_status if self.agent else {"available": False, "configured": bool(self.game_profile.get("state_feed_json"))}),
                "platform_supported": is_windows,
                "game_window_found": hwnd is not None,
                "window_handle": hwnd,
                "window_selection": self.screen.window_selection_summary() if self.screen and hasattr(self.screen, "window_selection_summary") else None,
                "agent_running": bool(self.agent and self.agent.thread and self.agent.thread.is_alive()),
                "agent_thread_alive": bool(self.agent and self.agent.thread and self.agent.thread.is_alive()),
                "hotkey_thread_alive": bool(self.agent and self.agent.hotkey_thread and self.agent.hotkey_thread.is_alive()),
                "training_thread_alive": bool(self.agent and self.agent.training_thread and self.agent.training_thread.is_alive()),
                "agent_armed": bool(self.agent and self.agent.armed),
                "hotkeys": (sorted(self.agent.hotkey_registered_names) if self.agent else []),
                "hotkey_error": (self.agent.hotkey_error if self.agent else None),
                "last_hotkey": (self.agent.last_hotkey if self.agent else None),
                "agent_mode": self.agent._last_mode if self.agent else None,
                "last_action": self.agent.last_action if self.agent else None,
                "frames_seen": int(self.agent.frames_seen) if self.agent else 0,
                "passive_analysis_frames": int(self.agent.passive_frames_seen) if self.agent else 0,
                "last_observation_unix": self.agent.last_observation_unix if self.agent else None,
                "observer_active": bool(self.agent and self.agent.thread and self.agent.thread.is_alive()),
                "battle_frames": int(self.agent.battle_frames) if self.agent else 0,
                "exploration_phase": self.agent.explore_phase if self.agent else None,
                "current_reflection": self.agent.current_reflection if self.agent else None,
                "self_analysis": (self.agent.current_reflection.get("self_model") if self.agent and self.agent.current_reflection else None),
                "policy_network": self.agent.policy_network.status() if self.agent else None,
                "policy_training_last_result": self.agent.last_training_result if self.agent else None,
                "policy_training_error": self.agent.last_training_error if self.agent else None,
                "loop_average_ms": (round(sum(self.agent._loop_time_samples) / len(self.agent._loop_time_samples), 2)
                                    if self.agent and self.agent._loop_time_samples else None),
                "target_battle_decision_interval_ms": int(BATTLE_DECISION_INTERVAL * 1000),
                "passive_observation_interval_ms": int(PASSIVE_OBSERVATION_INTERVAL * 1000),
                "control_mapping": (self.agent.memory.control_mapping_report(self.game_profile.get("controls", {})) if self.agent else None),
                "control_scope": "whole_game_generic_movement_exploration; Undertale battle detector enabled only for Undertale profile",
                "control_knowledge": {
                    action: {"physical_key": key,
                             "status": "configured_default_or_profile; manual demos and screen effects refine evidence"}
                    for action, key in self.game_profile.get("controls", {}).items()
                },
                "target_agent_loop_sleep_ms": round(AGENT_LOOP_SLEEP * 1000, 1),
                "input_diagnostics": (self.screen.input_diagnostics() if self.screen else {"initialized": False}),
                "system_modules": module_catalog(),
                "agent_diagnostics": ({
                    "loop_iterations": int(self.agent.loop_iterations),
                    "autonomous_decisions": int(self.agent.autonomous_decisions),
                    "last_loop_unix": self.agent.last_loop_unix,
                    "last_frame_unix": self.agent.last_frame_unix,
                    "last_action_unix": self.agent.last_action_unix,
                    "last_phase": self.agent.explore_phase,
                    "held_keys": sorted(self.agent.held),
                    "foreground_pause_count": int(self.agent.foreground_pause_count),
                    "hotkey_last_received": self.agent.last_hotkey,
                    "hotkey_events_received": int(self.agent.hotkey_events_received),
                    "stage": self.agent.loop_stage,
                    "loop_errors": int(self.agent.loop_errors),
                    "consecutive_loop_errors": int(self.agent.consecutive_loop_errors),
                    "last_error_stage": self.agent.last_error_stage,
                    "last_exception_type": self.agent.last_exception_type,
                    "last_exception_unix": self.agent.last_exception_unix,
                    "last_exception_traceback": self.agent.last_exception_traceback,
                    "last_successful_frame_unix": self.agent.last_successful_frame_unix,
                    "last_successful_action_unix": self.agent.last_successful_action_unix,
                    "armed": bool(self.agent.armed),
                } if self.agent else None),
                "last_error": self.last_error,
                "learning": self.learning_report(),
                "data_dir": str(_local_data_dir()),
            }

    def introspection_report(self) -> dict[str, Any]:
        with self._inspection_lock:
            report = dict(self.game_introspection)
        report["game_profile"] = {key: self.game_profile.get(key) for key in (
            "game_id", "display_name", "window_title_contains", "generic_mode", "battle_detection",
            "controls", "primary_goal", "state_feed_json", "source_profile", "profile_warning")}
        return report

    def _introspection_status(self) -> dict[str, Any]:
        with self._inspection_lock:
            value = dict(self.game_introspection)
        # Return a compact HTTP status, not the full collection of extracted static strings.
        assets = value.get("static_assets", [])
        return {
            "status": value.get("status", "not_started"),
            "game_id": self.game_profile.get("game_id"),
            "executable": (value.get("executable") or {}).get("name"),
            "asset_files_found": value.get("static_asset_files_found"),
            "static_bytes_scanned": value.get("static_bytes_scanned"),
            "control_and_gameplay_hint_count": len(value.get("control_and_gameplay_hints", [])),
            "candidate_control_hint_count": len(value.get("candidate_controls", [])),
            "runtime_internals_accessed": False,
            "report_path": value.get("report_path"),
            "error": value.get("error"),
        }

    def _start_static_introspection(self, exe: Path) -> None:
        """Scan static game resources asynchronously so game launch remains responsive."""
        target = str(exe.resolve())
        with self._inspection_lock:
            if self._inspection_target == target and (
                self.game_introspection.get("status") in {"running", "complete"}
            ):
                return
            self._inspection_target = target
            self.game_introspection = {"status": "running", "runtime_internals_accessed": False,
                                      "executable": {"name": exe.name, "path": target}}

        def worker() -> None:
            try:
                report = inspect_game_install(exe)
                self._apply_static_control_hints(report)
                report_path = _local_data_dir() / "game_introspection.json"
                write_profile_report(report_path, report)
                report["report_path"] = str(report_path)
                with self._inspection_lock:
                    self.game_introspection = report
                with self.lock:
                    agent = self.agent
                if agent:
                    agent.memory.log_runtime("observer", "observe", "static_game_analysis_complete", None,
                                             {"game_id": GAME_ID, "asset_files": report.get("static_asset_files_found", 0),
                                              "hint_count": len(report.get("control_and_gameplay_hints", [])),
                                              "runtime_internals_accessed": False})
                print(f"[GTC] Static game scan complete: {report.get('static_asset_files_found', 0)} asset files, "
                      f"{len(report.get('control_and_gameplay_hints', []))} possible hints.", flush=True)
            except Exception as exc:
                with self._inspection_lock:
                    self.game_introspection = {"status": "error", "error": f"{type(exc).__name__}: {exc}",
                                               "runtime_internals_accessed": False}
        self._inspection_thread = threading.Thread(target=worker, name="GTC-Static-Game-Inspector", daemon=True)
        self._inspection_thread.start()

    def launch(self, explicit: str | None = None) -> dict[str, Any]:
        if os.name != "nt":
            raise RuntimeError("Запуск Undertale доступен только в Windows.")
        exe = locate_undertale_exe(explicit)
        if exe is None:
            if self.game_profile.get("generic_mode"):
                raise FileNotFoundError("Не найден настроенный EXE игры. Проверьте GTC_GAME_EXE или executable_path в профиле.")
            raise FileNotFoundError(
                "Не найден UNDERTALE.exe. Извлеките свою игру в папку Undertale рядом с GTC, "
                "либо задайте переменную GTC_UNDERTALE_EXE."
            )
        # Launch stays short; static file analysis runs asynchronously and never reads saves or process memory.
        self._start_static_introspection(exe)
        with self.lock:
            if self.process and self.process.poll() is None:
                return {"ok": True, "already_running": True, "exe_path": str(exe), "pid": self.process.pid,
                        "static_analysis": "running_or_cached"}
            self.process = subprocess.Popen([str(exe)], cwd=str(exe.parent))
            pid = self.process.pid
        self.last_error = None
        return {"ok": True, "already_running": False, "exe_path": str(exe),
                "pid": pid, "window_found": None,
                "window_check": "deferred; query /undertale/status",
                "static_analysis": "started_in_background"}

    def record_feedback(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Persist an explicit user-confirmed outcome for the last relevant action."""
        if not isinstance(payload, dict):
            raise ValueError("Feedback payload must be a JSON object")
        outcome = str(payload.get("outcome", "")).strip().lower()
        allowed = {"damage", "death", "missed_attack", "item_misuse", "blocked", "dodge", "progress", "goal_completed"}
        if outcome not in allowed:
            raise ValueError("Unsupported feedback outcome")
        with self.lock:
            agent = self.agent
        owns_memory = agent is None
        memory = agent.memory if agent else UndertaleLearningMemory(_local_data_dir() / f"{GAME_ID}_experience.sqlite3")
        try:
            scene = agent._active_scene if agent else None
            state_id = scene.state_id if scene else "user-confirmed-event"
            mode = (agent._last_mode if agent and agent._last_mode in {"battle", "overworld"} else
                    ("battle" if payload.get("mode") == "battle" else "overworld"))
            action = str(payload.get("action") or (agent.last_action if agent else "none"))
            # Don't train the model from a label if no known policy action is attached.
            features = agent._last_policy_features if agent else None
            assessment = evaluate_transition(mode=mode, action=action, from_state=state_id,
                                             to_state=state_id, visual_delta=0.0, new_scene=False,
                                             explicit_outcome=outcome)
            can_train = action in POLICY_ACTIONS and features is not None
            memory.record(mode, state_id, action, state_id, assessment.reward, 0.0,
                          {"feedback_source": "explicit_user_label", "outcome": outcome,
                           "feedback_category": assessment.category,
                           "feedback_explanation": assessment.explanation,
                           "verified_by_user": True},
                          policy_features=features if can_train else None,
                          learn=True, source="manual_feedback")
            memory.log_runtime(mode, action, "explicit_feedback_" + outcome, None,
                               {"reward": assessment.reward, "feedback_source": "user"})
            if agent and can_train:
                agent._queue_policy_training(force=True)
            return {"ok": True, "recorded": True, "outcome": outcome, "action": action,
                    "mode": mode, "reward": assessment.reward,
                    "model_example_added": bool(can_train), "explanation": assessment.explanation,
                    "database": str(memory.path)}
        finally:
            if owns_memory:
                memory.close()

    def observe(self) -> dict[str, Any]:
        if os.name != "nt":
            raise RuntimeError("Снимок экрана Undertale доступен только в Windows.")
        screen = self._windows()
        hwnd = screen.find_window()
        if not hwnd:
            raise RuntimeError("Окно Undertale не найдено. Сначала запустите игру.")
        self.window = hwnd
        frame = screen.capture(hwnd)
        obs = analyze_profiled_frame(frame)
        result_obs = obs.to_dict()
        result_obs["source_width"] = frame.source_width or frame.width
        result_obs["source_height"] = frame.source_height or frame.height
        return {"ok": True, "window_foreground": screen.is_foreground(hwnd),
                "window_selection": screen.window_selection_summary() if hasattr(screen, "window_selection_summary") else None,
                "observation": result_obs}

    def start_agent(self, armed: bool = False) -> dict[str, Any]:
        if os.name != "nt":
            raise RuntimeError("Визуальный игровой контроллер доступен только в Windows.")
        configured_exe = str(self.game_profile.get("executable_path") or os.environ.get("GTC_GAME_EXE") or "").strip()
        exe = Path(configured_exe).expanduser() if configured_exe else locate_undertale_exe()
        if exe and exe.is_file():
            self._start_static_introspection(exe)
        with self.lock:
            if self.agent and self.agent.thread and self.agent.thread.is_alive():
                if armed:
                    self.agent.armed = True
                return {"ok": True, "already_running": True, "armed": self.agent.armed}
            self.agent = UndertalePilot(self)
            self.agent.armed = bool(armed)
            self.agent.start()
        return {"ok": True, "already_running": False, "armed": bool(armed),
                "instructions": "F7 = ручной режим + запись примеров игрока; F8 = автономное управление GTC по всей игре. Награды оцениваются по визуальным признакам и могут быть неточными."}

    def set_agent_armed(self, armed: bool) -> dict[str, Any]:
        """Explicitly arm or pause the existing pilot from the control panel."""
        if os.name != "nt":
            raise RuntimeError("Управление Undertale доступно только в Windows.")
        if not isinstance(armed, bool):
            raise ValueError("Поле armed должно быть boolean.")
        with self.lock:
            agent = self.agent
            if not agent or not (agent.thread and agent.thread.is_alive()):
                if not armed:
                    return {"ok": True, "agent_running": False, "armed": False,
                            "message": "Контроллер не запущен; игра не изменена."}
                agent = UndertalePilot(self)
                self.agent = agent
                agent.armed = True
                agent.start()
                return {"ok": True, "agent_running": True, "armed": True,
                        "message": "Контроллер запущен и включён."}
            agent.armed = armed
            if not armed:
                agent._release_all()
            agent._log(None, "none", "control_panel_enabled" if armed else "control_panel_paused")
        state = "ON" if armed else "PAUSED"
        print(f"[GTC Undertale] Control panel set autonomous control: {state}", flush=True)
        return {"ok": True, "agent_running": True, "armed": armed,
                "message": "Управление включено." if armed else "Управление поставлено на паузу."}

    def stop_agent(self) -> dict[str, Any]:
        with self.lock:
            agent = self.agent
        if not agent:
            return {"ok": True, "stopped": True, "was_running": False}
        agent.stop()
        if not agent.thread or not agent.thread.is_alive():
            try:
                agent.memory.close()
            except Exception:
                pass
            with self.lock:
                if self.agent is agent:
                    self.agent = None
        return {"ok": True, "stopped": True, "was_running": True}


class UndertalePilot:
    ACTION_KEYS = ("left", "right", "up", "down", "z", "x", "c", "shift")

    def __init__(self, runtime: UndertaleRuntime) -> None:
        self.runtime = runtime
        self.thread: threading.Thread | None = None
        self.stop_event = threading.Event()
        self.armed = False
        self.last_observation: dict[str, Any] | None = None
        self.last_action = "none"
        self.frames_seen = 0
        self.passive_frames_seen = 0
        self.last_observation_unix: float | None = None
        self._last_observer_sample_at = 0.0
        self._last_persisted_observation_at = 0.0
        self._passive_previous_features: tuple[int, ...] | None = None
        self._passive_previous_state: str | None = None
        self._passive_previous_mode: str | None = None
        self._passive_previous_frame: Frame | None = None
        self._passive_scene: SceneMatch | None = None
        self._external_game_state: dict[str, Any] | None = None
        self._previous_external_game_state: dict[str, Any] | None = None
        self._last_state_feed_poll = 0.0
        self.state_feed_status: dict[str, Any] = {"available": False, "configured": bool(runtime.game_profile.get("state_feed_json"))}
        self.battle_frames = 0
        self.last_toggle = 0.0
        self.loop_iterations = 0
        self.autonomous_decisions = 0
        self.last_loop_unix: float | None = None
        self.last_frame_unix: float | None = None
        self.last_action_unix: float | None = None
        self.foreground_pause_count = 0
        self._hotkey_was_down = {"f7": False, "f8": False}
        self.hotkey_commands: queue.SimpleQueue[str] = queue.SimpleQueue()
        self.hotkey_ready = threading.Event()
        self.hotkey_thread: threading.Thread | None = None
        self.hotkey_events_received = 0
        self.loop_stage = "not_started"
        self.loop_errors = 0
        self.consecutive_loop_errors = 0
        self.last_error_stage: str | None = None
        self.last_exception_type: str | None = None
        self.last_exception_unix: float | None = None
        self.last_exception_traceback: str | None = None
        self.last_successful_frame_unix: float | None = None
        self.last_successful_action_unix: float | None = None
        self._last_diagnostic_signature: str | None = None
        self._last_diagnostic_log_at = 0.0
        self.hotkey_ids: dict[int, str] = {}
        self.hotkey_registered_names: set[str] = set()
        self.hotkey_error: str | None = None
        self.last_hotkey: str | None = None
        self.held: set[str] = set()
        self.last_position: tuple[int, int] | None = None
        self.previous_hazards: list[tuple[int, int]] = []
        # The controller never blindly confirms dialogue/menu choices; confirm/interact
        # is a selected action, not a background key spammer.
        self.seen_soul_once = False
        self._last_battle_visible_at = 0.0
        self._last_log = 0.0
        self._last_mode = "unknown"
        self.data_dir = _local_data_dir()
        self.memory = UndertaleLearningMemory(self.data_dir / f"{GAME_ID}_experience.sqlite3")
        self.policy_network = UndertalePolicyNetwork(self.data_dir / f"{GAME_ID}_policy_network.json")
        self.training_event = threading.Event()
        self.training_thread: threading.Thread | None = None
        self._last_training_queued_count = -1
        self.last_training_result: dict[str, Any] | None = None
        self.last_training_error: str | None = None
        self._loop_time_samples: deque[float] = deque(maxlen=120)
        self._last_policy_features: list[float] | None = None
        self._last_reward_signal = 0.0
        self._last_danger_delta = 0.0
        self._no_progress_streak = 0
        # While F7 pauses the agent, observe real keyboard timing as demonstrations.
        # No keys are injected while this recorder is active.
        self._human_active_keys: set[str] = set()
        self._human_before_frame: Frame | None = None
        self._human_before_scene: SceneMatch | None = None
        self._human_mode = "overworld"
        self._human_soul_mode = "red"
        self._human_started_at = 0.0
        self._human_before_policy_features: list[float] | None = None
        self._human_session_started = time.time()
        self.explore_phase = "idle"
        self.explore_action: str | None = None
        self.explore_before_state: str | None = None
        self.explore_before_features: tuple[int, ...] | None = None
        self.explore_before_frame: Frame | None = None
        self.explore_before_policy_features: list[float] | None = None
        self.explore_before_game_state: dict[str, Any] | None = None
        self.explore_until = 0.0
        self.explore_before_new = False
        self._active_scene: SceneMatch | None = None
        self._next_scene_refresh = 0.0
        self.battle_pending: dict[str, Any] | None = None
        self._last_exploration_reward = 0.0
        self._blocked_action_hint: str | None = None
        self.self_model = UndertaleSelfModel()
        self.current_reflection: dict[str, Any] = {}
        self._last_reflection_key: tuple[str, str, str] | None = None
        self._last_reflection_time = 0.0
        self._reflection_counts_time = 0.0
        self._reflection_scene_count = 0
        self._reflection_transition_count = 0
        # Use GTC's actual action-ranker. The visual adapter only supplies
        # candidates and cautious, pixel-derived risk estimates.
        self.brain = AgentBrain({
            "autonomy": {
                "minimum_evidence_confidence": 0.50,
                "maximum_risk": 1.0,
                "goals": {"survival": 1.0},
            },
            "values": {"self_preservation": 0.92, "curiosity": 0.25, "autonomy": 0.60},
        })

    def start(self) -> None:
        # F7 reliably selects manual/teaching mode; F8 reliably selects autonomous mode.
        # These are commands, not a toggle: pressing one repeatedly cannot invert state.
        self.hotkey_thread = threading.Thread(
            target=self._hotkey_loop, name="GTC-Undertale-Hotkeys", daemon=True
        )
        self.hotkey_thread.start()
        self.hotkey_ready.wait(timeout=1.0)
        self.training_thread = threading.Thread(target=self._policy_training_loop, name="GTC-Undertale-PolicyTrainer", daemon=True)
        self.training_thread.start()
        self._queue_policy_training(force=True)
        self.thread = threading.Thread(target=self._run, name="GTC-Undertale-Pilot", daemon=True)
        self.thread.start()
        hotkeys = ", ".join(name.upper() for name in sorted(self.hotkey_registered_names))
        if hotkeys:
            print(f"[GTC Undertale] Global hotkeys registered: {hotkeys}", flush=True)
        elif self.hotkey_error:
            print(f"[GTC Undertale] Global hotkeys unavailable ({self.hotkey_error}); F7/F8 polling fallback enabled.", flush=True)

    def _hotkey_loop(self) -> None:
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        MOD_NOREPEAT = 0x4000
        WM_HOTKEY = 0x0312
        PM_REMOVE = 0x0001
        key_specs = ((1, "f8", VK["f8"]), (2, "f7", 0x76))
        registered: list[int] = []
        try:
            user32.RegisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int, wintypes.UINT, wintypes.UINT]
            user32.RegisterHotKey.restype = wintypes.BOOL
            user32.UnregisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int]
            user32.UnregisterHotKey.restype = wintypes.BOOL
            user32.PeekMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND,
                                            wintypes.UINT, wintypes.UINT, wintypes.UINT]
            user32.PeekMessageW.restype = wintypes.BOOL
            # Ensure this native thread has a message queue before RegisterHotKey
            # associates system-wide hotkeys with it.
            warmup_message = wintypes.MSG()
            user32.PeekMessageW(ctypes.byref(warmup_message), None, 0, 0, PM_REMOVE)
            for hotkey_id, name, vk in key_specs:
                if user32.RegisterHotKey(None, hotkey_id, MOD_NOREPEAT, vk):
                    registered.append(hotkey_id)
                    self.hotkey_ids[hotkey_id] = name
                    self.hotkey_registered_names.add(name)
            missing = [name.upper() for hid, name, _ in key_specs if hid not in registered]
            if missing:
                self.hotkey_error = "Could not register " + ", ".join(missing) + "; F7/F8 polling fallback remains active"
            self.hotkey_ready.set()
            message = wintypes.MSG()
            while not self.stop_event.is_set():
                while user32.PeekMessageW(ctypes.byref(message), None, WM_HOTKEY, WM_HOTKEY, PM_REMOVE):
                    name = self.hotkey_ids.get(int(message.wParam))
                    if name:
                        self.last_hotkey = name
                        self.hotkey_events_received += 1
                        self.runtime.write_diagnostic("hotkey_received", key=name, source="RegisterHotKey")
                        self.hotkey_commands.put(name)
                time.sleep(0.01)
        except Exception as exc:
            self.hotkey_error = f"{type(exc).__name__}: {exc}"
            self.runtime.write_diagnostic("hotkey_thread_error", error_type=type(exc).__name__, error=str(exc)[:500])
            self.hotkey_ready.set()
        finally:
            for hotkey_id in registered:
                try:
                    user32.UnregisterHotKey(None, hotkey_id)
                except Exception:
                    pass

    def _queue_policy_training(self, *, force: bool = False) -> None:
        try:
            count = self.memory.policy_example_count()
            if count >= self.policy_network.minimum_samples and (force or count - self._last_training_queued_count >= 8):
                self._last_training_queued_count = count
                self.training_event.set()
        except Exception as exc:
            self.last_training_error = f"{type(exc).__name__}: {exc}"

    def _policy_training_loop(self) -> None:
        """Train in a background worker so SGD does not block game input updates."""
        while not self.stop_event.is_set():
            if not self.training_event.wait(timeout=0.25):
                continue
            self.training_event.clear()
            if self.stop_event.is_set():
                break
            try:
                total = self.memory.policy_example_count()
                if total < self.policy_network.minimum_samples:
                    continue
                examples = self.memory.policy_training_examples(limit=192)
                self.last_training_result = self.policy_network.fit(examples, total_examples=total, epochs=1)
                self.last_training_error = None
                print(f"[GTC Undertale] Policy update: {self.last_training_result}", flush=True)
            except Exception as exc:
                self.last_training_error = f"{type(exc).__name__}: {exc}"
                print(f"[GTC Undertale] Policy training warning: {self.last_training_error}", flush=True)

    def _policy_features(self, frame: Frame, mode: str, obs: Observation,
                         scene: SceneMatch | None = None) -> list[float]:
        base = scene.features if scene is not None else extract_features(frame)
        return self.policy_network.encode_state(
            base, mode, obs.to_dict(), previous_action=self.last_action,
            no_progress_streak=self._no_progress_streak,
            last_reward=self._last_reward_signal, last_danger_delta=self._last_danger_delta)

    def _poll_external_game_state(self, now: float, *, force: bool = False) -> dict[str, Any] | None:
        if not force and now - self._last_state_feed_poll < 0.25:
            return self._external_game_state
        self._last_state_feed_poll = now
        feed_path = str(self.runtime.game_profile.get("state_feed_json") or os.environ.get("GTC_GAME_STATE_JSON", "")).strip()
        if not feed_path:
            self.state_feed_status = {"available": False, "configured": False,
                                      "note": "Set state_feed_json in the game profile to receive live internal state."}
            return None
        value = read_runtime_state_feed(self.runtime.game_profile)
        if isinstance(value, dict) and value.get("available"):
            self._previous_external_game_state = self._external_game_state
            self._external_game_state = value
            self.state_feed_status = {"available": True, "age_seconds": value.get("age_seconds"),
                                      "path": value.get("path"), "fields": sorted(k for k in value if k not in {"path", "age_seconds", "available"})}
            return value
        self.state_feed_status = value if isinstance(value, dict) else {"available": False, "configured": True}
        return None

    def _permanent_observe(self, frame: Frame, obs: Observation, now: float, *, source: str) -> None:
        """Continuously analyze game frames in both manual/F7 and autonomous/F8 modes.

        Full screenshots are never stored. Only compact features, detected state and key
        context are persisted, with meaningful-change/heartbeat deduplication.
        """
        self.passive_frames_seen += 1
        self.last_observation_unix = time.time()
        self.last_observation = obs.to_dict()
        game_state = self._poll_external_game_state(now)
        features = extract_features(frame)
        coarse_delta = visual_change(self._passive_previous_features or (), features) if self._passive_previous_features else 1.0
        mode = "battle" if obs.battle_visible else "overworld"
        # Identify a new state only when visual features move materially or periodically; this avoids
        # committing a duplicate scene visit on every video frame while still noticing slow changes.
        should_identify = (self._passive_scene is None or self._passive_previous_mode != mode
                           or coarse_delta >= 0.025 or now - self._last_persisted_observation_at >= OBSERVATION_HEARTBEAT_INTERVAL)
        scene = self._passive_scene
        if should_identify:
            try:
                scene = self.memory.identify(frame)
                self._passive_scene = scene
            except Exception as exc:
                self.runtime.last_error = f"passive scene analysis failed: {type(exc).__name__}: {exc}"
        if scene is not None:
            try:
                should_write = self.memory.record_visual_observation(
                    mode=mode, state_id=scene.state_id, features=features, observation=obs.to_dict(),
                    source=source, visual_delta=coarse_delta,
                    context={"game_id": GAME_ID, "world_id": WORLD_ID, "armed": self.armed,
                             "last_action": self.last_action, "controls": self.runtime.game_profile.get("controls", {}),
                             "battle_detection_enabled": bool(self.runtime.game_profile.get("battle_detection", False)),
                             "external_game_state": game_state,
                             "runtime_internals_accessed": bool(game_state and game_state.get("available"))},
                    heartbeat_seconds=OBSERVATION_HEARTBEAT_INTERVAL)
                if should_write:
                    self._last_persisted_observation_at = now
            except Exception as exc:
                self.runtime.last_error = f"visual observation write failed: {type(exc).__name__}: {exc}"
            self._reflect(mode, obs, scene, self.last_action or "none", now,
                          rationale=("Continuously inspect the visible game and infer the next useful action"
                                     if not self.armed else "Observe the result of autonomous control and update context"))
        self._passive_previous_features = features
        self._passive_previous_state = scene.state_id if scene else None
        self._passive_previous_mode = mode
        self._passive_previous_frame = frame
        self._last_observer_sample_at = now

    def _reflect(self, mode: str, obs: Observation, scene: SceneMatch | None,
                 candidate_action: str, now: float, *, rationale: str) -> None:
        """Build and persist a compact role/goal/action self-analysis at a bounded rate."""
        scene_id = scene.state_id if scene else "unknown"
        blocked = self._blocked_action_hint
        if now - self._reflection_counts_time >= 1.0:
            try:
                self._reflection_scene_count = int(self.memory.db.execute("SELECT COUNT(*) FROM scenes").fetchone()[0])
                self._reflection_transition_count = int(self.memory.db.execute("SELECT COUNT(*) FROM transitions").fetchone()[0])
                self._reflection_counts_time = now
            except Exception:
                pass
        self_model = self.self_model.describe(
            mode, obs.to_dict(), last_action=self.last_action,
            no_progress_streak=self._no_progress_streak, blocked_action=blocked,
            known_scenes=self._reflection_scene_count,
            known_transitions=self._reflection_transition_count)
        if GAME_ID != "undertale":
            self_model["primary_goal"] = str(self.runtime.game_profile.get("primary_goal") or
                                             f"Продвигаться в игре {self.runtime.game_profile.get('display_name', GAME_ID)}, изучая мир и доступные действия")
            self_model["current_objective"] = str((self._external_game_state or {}).get("objective") or
                                                   "Изучить текущую сцену, проверить доступные действия и найти полезный следующий шаг")
            self_model["decision_question"] = "Какое разрешённое действие с наибольшей вероятностью даст полезную информацию или прогресс?"
        if self._external_game_state and self._external_game_state.get("available"):
            state = self._external_game_state
            self_model["external_game_state"] = {k: state.get(k) for k in
                ("scene_id", "player_position", "health", "max_health", "inventory", "objective",
                 "allowed_actions", "status", "danger", "progress", "game_over", "victory", "objective_completed")}
            self_model["state_source"] = "game-provided JSON feed; fresh file required"
        key = (mode, str(self_model.get("current_objective", "")), candidate_action)
        self.current_reflection = {
            "self_model": self_model,
            "candidate_action": candidate_action,
            "rationale": rationale,
            "external_game_state": self_model.get("external_game_state"),
            "updated_at_monotonic": round(now, 3),
        }
        # Save when the plan/action changes or at most once per second for a stable plan.
        if key != self._last_reflection_key or now - self._last_reflection_time >= 1.0:
            try:
                self.memory.record_reflection(mode, scene_id, key[1], candidate_action, {
                    "identity": self_model.get("identity"), "role": self_model.get("role"),
                    "primary_goal": self_model.get("primary_goal"), "decision_question": self_model.get("decision_question"),
                    "last_action": self.last_action, "no_progress_streak": self._no_progress_streak,
                    "blocked_action": blocked, "rationale": rationale,
                    "known_scenes": self_model.get("known_experience", {}).get("scenes", 0),
                    "known_transitions": self_model.get("known_experience", {}).get("transitions", 0),
                })
                self._last_reflection_key = key
                self._last_reflection_time = now
            except Exception as exc:
                self.runtime.last_error = f"self-reflection write failed: {type(exc).__name__}"

    def stop(self) -> None:
        self.stop_event.set()
        self.armed = False
        self._release_all()
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=1.5)
        self.training_event.set()
        if self.hotkey_thread and self.hotkey_thread.is_alive():
            self.hotkey_thread.join(timeout=0.5)
        if self.training_thread and self.training_thread.is_alive():
            self.training_thread.join(timeout=0.8)

    def _release_all(self) -> None:
        if self.runtime.screen:
            for name in tuple(self.held):
                try:
                    self.runtime.screen.key(name, False)
                except Exception:
                    pass
        self.held.clear()

    def _set_keys(self, names: set[str]) -> None:
        screen = self.runtime._windows()
        for name in self.held - names:
            screen.key(name, False)
        for name in names - self.held:
            screen.key(name, True)
        self.held = set(names)

    @staticmethod
    def _danger(frame: Frame, x: int, y: int, radius: int) -> float:
        total = 0.0
        samples = 0
        pixels = frame.bgra
        width = frame.width
        radius_sq = radius * radius
        for yy in range(max(0, y - radius), min(frame.height, y + radius + 1), 2):
            row = yy * width * 4
            for xx in range(max(0, x - radius), min(width, x + radius + 1), 2):
                if (xx - x) ** 2 + (yy - y) ** 2 > radius_sq:
                    continue
                i = row + xx * 4
                b, g, r = pixels[i], pixels[i + 1], pixels[i + 2]
                if r > 230 and g > 230 and b > 230:
                    total += 2.0
                elif b > 195 and g > 110 and r < 125:
                    total += 1.5
                samples += 1
        return total / max(1, samples)

    def choose_action(self, frame: Frame, obs: Observation,
                      policy_features: list[float] | None = None) -> str:
        """Rank immediate paths with image heuristics, rewards, player examples, and the learned MLP."""
        soul, arena = obs.soul, obs.arena
        if not obs.battle_visible or not soul or not arena:
            return "none"
        x, y = soul["x"], soul["y"]
        mode = soul.get("mode", "red")
        aw = max(30, arena["right"] - arena["left"])
        ah = max(30, arena["bottom"] - arena["top"])
        dx = max(5, int(aw * 0.12))
        dy = max(5, int(ah * 0.12))
        margin = max(8, int(min(aw, ah) * 0.08))
        left, right = arena["left"] + margin, arena["right"] - margin
        top, bottom = arena["top"] + margin, arena["bottom"] - margin
        candidates = [("none", 0, 0)]
        if mode == "blue":
            candidates.extend([("left", -dx, 0), ("right", dx, 0),
                               ("left_jump", -dx, -dy), ("right_jump", dx, -dy), ("jump", 0, -dy)])
        else:
            candidates.extend([("left", -dx, 0), ("right", dx, 0), ("up", 0, -dy), ("down", 0, dy),
                               ("up_left", -dx, -dy), ("up_right", dx, -dy),
                               ("down_left", -dx, dy), ("down_right", dx, dy)])
        brain_candidates: list[dict[str, Any]] = []
        legal_actions = [candidate[0] for candidate in candidates]
        # Neighboring paths share many sample positions; cache danger probes per frame.
        danger_cache: dict[tuple[int, int, int], float] = {}
        def danger_at(px: int, py: int, radius: int) -> float:
            key = (int(px), int(py), int(radius))
            value = danger_cache.get(key)
            if value is None:
                value = self._danger(frame, key[0], key[1], key[2])
                danger_cache[key] = value
            return value
        if policy_features is None:
            policy_features = self._policy_features(frame, "battle", obs, self._active_scene)
        neural_scores = self.policy_network.predict(policy_features)
        demo_local = self.memory.demonstration_counts(
            self._active_scene.state_id if self._active_scene else None, "battle", legal_actions)
        demo_global = self.memory.demonstration_counts(None, "battle", legal_actions)
        local_demo_total = sum(demo_local.values())
        global_demo_total = sum(demo_global.values())
        for name, ox, oy in candidates:
            tx = max(left, min(right, x + ox))
            ty = max(top, min(bottom, y + oy))
            path_risk = 0.0
            # Probe the short path rather than only the destination.
            for step in (0.25, 0.5, 0.75, 1.0):
                px = int(x + (tx - x) * step)
                py = int(y + (ty - y) * step)
                path_risk += danger_at(px, py, max(5, int(min(aw, ah) * 0.055))) * (0.8 + step)
            edge_penalty = 1.0 if tx <= left + 2 or tx >= right - 2 or ty <= top + 2 or ty >= bottom - 2 else 0.0
            movement_cost = 0.010 if name != "none" else 0.0
            inertia_bonus = -0.08 if name == self.last_action else 0.0
            # A bounded two-ply look-ahead: after the candidate move, estimate the
            # least-dangerous immediate continuation still visible in this same frame.
            # It cannot predict moving bones, but it discourages walking into visual traps.
            future_offsets = ((-dx, 0), (dx, 0), (0, -dy), (0, dy), (-dx, -dy),
                              (-dx, dy), (dx, -dy), (dx, dy))
            future_costs: list[float] = []
            for fdx, fdy in future_offsets:
                fx = max(left, min(right, tx + fdx))
                fy = max(top, min(bottom, ty + fdy))
                future_danger = danger_at(fx, fy, max(5, int(min(aw, ah) * 0.055)))
                future_edge = 0.25 if fx <= left + 2 or fx >= right - 2 or fy <= top + 2 or fy >= bottom - 2 else 0.0
                future_costs.append(future_danger + future_edge)
            second_step_risk = min(future_costs, default=0.0)
            # Keep values finite and within AgentBrain's contract. The current path
            # matters more than a hypothetical second step from an unchanged frame.
            estimated_risk = max(0.0, min(1.0,
                (path_risk + edge_penalty + movement_cost + max(0.0, inertia_bonus) + 0.45 * second_step_risk) / 6.0))
            # Waiting is acceptable only when the local view is calm. In active hazard
            # scenes, penalize no-op so the agent deliberately repositions instead of freezing.
            if name == "none" and (obs.hazards > 2 or self._no_progress_streak >= 2):
                estimated_risk = min(1.0, estimated_risk + 0.22)
            active_state_id = self._active_scene.state_id if self._active_scene else None
            learned_visits, learned_value = self.memory.value_for(active_state_id, "battle", name)
            q_visits, q_value = self.memory.q_value_for(active_state_id, "battle", name)
            if learned_visits:
                # Tabular reward values remain bounded because rewards are visual proxies.
                estimated_risk = max(0.0, min(1.0, estimated_risk - max(-0.08, min(0.08, learned_value * 0.16))))
            if q_visits:
                estimated_risk = max(0.0, min(1.0, estimated_risk - max(-0.08, min(0.08, q_value * 0.09))))
            # The larger visual MLP is gated until it has enough persistent examples
            # spanning multiple actions; its influence is intentionally bounded.
            neural_prior = max(-1.0, min(1.0, float(neural_scores.get(name, 0.0))))
            estimated_risk = max(0.0, min(1.0, estimated_risk - 0.10 * neural_prior))
            # Player demonstrations act as a small prior, not proof that an action
            # is safe. The live pixel-risk estimate remains the stronger signal.
            demo_bonus = 0.10 * demo_local.get(name, 0) / max(1, local_demo_total)
            demo_bonus += 0.035 * demo_global.get(name, 0) / max(1, global_demo_total)
            estimated_risk = max(0.0, estimated_risk - demo_bonus)
            brain_candidates.append({
                "action": name,
                "semantic_action": "observe" if name == "none" else "defend",
                "preconditions_met": True,
                "evidence_confidence": max(0.0, min(1.0, obs.scene_confidence)),
                "risk": estimated_risk,
                "cost": movement_cost,
                "goal_progress": {"survival": 1.0 - estimated_risk},
                "context_tags": ["undertale", "battle", mode, "pixel_heuristic"],
            })
        world = {
            "game_id": GAME_ID,
            "world_id": WORLD_ID,
            "goal_priorities": {"survival": 1.0, "avoid_repeated_failure": 0.9, "learn_mechanics": 0.35},
            "needs": {"safety": 0.98, "energy": 0.4, "curiosity": 0.55},
            "mode": "battle",
        }
        decision = self.brain.choose_action(world, brain_candidates)
        chosen = decision.get("chosen_action") if isinstance(decision, dict) else None
        if not isinstance(chosen, dict):
            return "none"
        action = str(chosen.get("action", "none"))
        allowed = {name for name, _, _ in candidates}
        return action if action in allowed else "none"

    def _control_key(self, action: str) -> str:
        controls = self.runtime.game_profile.get("controls", {})
        defaults = {"left": "left", "right": "right", "up": "up", "down": "down",
                    "interact": "z", "confirm": "enter", "cancel": "x", "menu": "c",
                    "jump": "space", "attack": "z", "inventory": "i", "use_item": "i"}
        value = str(controls.get(action, defaults.get(action, action))).strip().lower()
        return value if value in VK else defaults.get(action, action)

    def _action_keys(self, action: str, mode: str) -> set[str]:
        left, right = self._control_key("left"), self._control_key("right")
        up, down = self._control_key("up"), self._control_key("down")
        mapping = {
            "left": {left}, "right": {right}, "up": {up}, "down": {down},
            "up_left": {up, left}, "up_right": {up, right},
            "down_left": {down, left}, "down_right": {down, right},
            "left_jump": {left, up}, "right_jump": {right, up},
            "jump": {up if GAME_ID == "undertale" and mode == "battle" else self._control_key("jump")},
            "interact": {self._control_key("interact")}, "confirm": {self._control_key("confirm")},
            "cancel": {self._control_key("cancel")}, "menu": {self._control_key("menu")},
            "attack": {self._control_key("attack")}, "inventory": {self._control_key("inventory")},
            "use_item": {self._control_key("use_item")},
            "none": set(),
        }
        # On Undertale's blue soul an up input is a jump; generic profiles disable battle detection.
        return {key for key in mapping.get(action, set()) if key in VK}

    def _tap_key(self, screen: WindowsScreen, name: str, hold_seconds: float = 0.055) -> None:
        """Tap a key with guaranteed release, even if the loop is interrupted."""
        try:
            screen.key(name, True)
            time.sleep(hold_seconds)
        finally:
            screen.key(name, False)
            self.held.discard(name)

    def _log(self, observation: Observation | None, action: str, event: str | None = None) -> None:
        now = time.monotonic()
        if now - self._last_log < 0.45 and event is None:
            return
        self._last_log = now
        try:
            self.memory.log_runtime(
                mode=self._last_mode, action=action, event=event,
                observation=observation.to_dict() if observation else None,
                details={"game_id": GAME_ID, "world_id": WORLD_ID,
                         "adapter_version": ADAPTER_VERSION, "armed": self.armed,
                         "training_eligible": False})
        except Exception as exc:
            self.runtime.last_error = f"database log write failed: {type(exc).__name__}"

    OVERWORLD_ACTIONS = ["left", "right", "up", "down", "interact", "cancel", "menu"]

    def _available_overworld_actions(self) -> list[str]:
        actions = list(self.OVERWORLD_ACTIONS)
        profile = self.runtime.game_profile
        if profile.get("generic_mode"):
            actions.extend(("jump", "confirm"))
            known = set(profile.get("configured_controls", [])) | set(profile.get("auto_detected_controls", []))
            controls = profile.get("controls", {})
            for name in ("attack", "inventory", "use_item"):
                if name in known and controls.get(name):
                    actions.append(name)
        return list(dict.fromkeys(actions))

    def _scene(self, frame: Frame, now: float, force: bool = False) -> SceneMatch:
        if force or self._active_scene is None or now >= self._next_scene_refresh:
            self._active_scene = self.memory.identify(frame)
            self._next_scene_refresh = now + 0.18
        return self._active_scene

    def _discard_exploration_step(self) -> None:
        self._release_all()
        self.explore_phase = "idle"
        self.explore_action = None
        self.explore_before_state = None
        self.explore_before_features = None
        self.explore_before_frame = None
        self.explore_before_policy_features = None
        self.explore_before_game_state = None

    def _exploration_tick(self, frame: Frame, screen: WindowsScreen, now: float,
                          obs: Observation | None = None) -> None:
        """Explore non-battle scenes in short, reversible steps and retain outcomes."""
        if self.explore_phase == "holding":
            if now >= self.explore_until:
                self._release_all()
                self.explore_phase = "resolving"
                self.explore_until = now + 0.035
            return
        if self.explore_phase == "resolving":
            self._release_all()
            if now < self.explore_until:
                return
            after = self.memory.identify(frame)
            before = self.explore_before_features or after.features
            coarse_change = visual_change(before, after.features)
            change = frame_change(self.explore_before_frame, frame)
            from_state = self.explore_before_state or after.state_id
            action = self.explore_action or "none"
            blocked_count = 0
            if action in {"left", "right", "up", "down"} and after.state_id == from_state and change < 0.003:
                blocked_count = self.memory.record_blocked_attempt(from_state, "overworld", action)
                self._blocked_action_hint = action
                self._no_progress_streak += 1
            elif after.state_id != from_state or change >= 0.003:
                if action in {"left", "right", "up", "down"} and change >= 0.003:
                    self.memory.resolve_blocked_attempt(from_state, "overworld", action)
                if after.state_id != from_state or action in {"left", "right", "up", "down"}:
                    self._no_progress_streak = 0
                    self._blocked_action_hint = None

            after_game_state = self._poll_external_game_state(time.monotonic(), force=True)
            explicit_outcome = _external_outcome(self.explore_before_game_state, after_game_state)
            assessment = evaluate_transition(
                mode="overworld", action=action, from_state=from_state, to_state=after.state_id,
                visual_delta=change, new_scene=after.is_new,
                repeated_blocked=blocked_count, explicit_outcome=explicit_outcome)
            reward = assessment.reward
            self._last_exploration_reward = reward
            self._last_reward_signal = reward
            self.memory.record("overworld", from_state, action, after.state_id, reward, change,
                               {"is_new_scene": after.is_new, "similarity": after.similarity,
                                "coarse_signature_change": coarse_change,
                                "no_progress_streak": self._no_progress_streak,
                                "blocked_attempt_count": blocked_count,
                                "feedback_category": assessment.category,
                                "feedback_explanation": assessment.explanation,
                                "explicit_game_outcome": explicit_outcome,
                                "feedback_quality": ("fresh_game_state_feed" if explicit_outcome else "visual_proxy_not_ground_truth")},
                               policy_features=self.explore_before_policy_features,
                               learn=assessment.learn)
            if assessment.learn and self.explore_before_policy_features is not None:
                self._queue_policy_training()
            self.last_action = action
            self._log(None, action, f"exploration_feedback reward={reward:.3f} category={assessment.category} change={change:.3f} to={after.state_id}")
            self.explore_phase = "idle"
            self.explore_action = None
            self.explore_before_state = None
            self.explore_before_features = None
            self.explore_before_frame = None
            self.explore_before_policy_features = None
            self._active_scene = after
            self._next_scene_refresh = now + 0.18

        if self.explore_phase != "idle":
            return
        scene = self.memory.identify(frame)
        self._active_scene = scene
        self._next_scene_refresh = now + 0.18
        current_obs = obs if obs is not None else analyze_profiled_frame(frame)
        policy_features = self._policy_features(frame, "overworld", current_obs, scene)
        self._last_policy_features = policy_features
        neural_scores = self.policy_network.predict(policy_features)
        allowed_actions = self._available_overworld_actions()
        external_state = self._poll_external_game_state(now)
        declared = external_state.get("allowed_actions") if isinstance(external_state, dict) and external_state.get("available") else None
        if isinstance(declared, list):
            filtered = [str(value).strip().lower() for value in declared
                        if str(value).strip().lower() in allowed_actions]
            if filtered:
                allowed_actions = list(dict.fromkeys(filtered))
            elif not declared:
                self._release_all()
                self.last_action = "none"
                self._log(current_obs, "none", "state_feed_allowed_actions_empty")
                return
            else:
                self.runtime.last_error = "State feed supplied allowed_actions but none match the agent action vocabulary"
        # Keep all actions available, but softly disfavor recent wall hits and repeated
        # no-op buttons. Hard-filtering a direction forever is wrong because the player
        # may have moved to another position in the same visually similar room.
        action = self.memory.choose_action(scene.state_id, "overworld", allowed_actions,
                                           neural_scores=neural_scores)
        self._reflect("overworld", current_obs, scene, action, now,
                      rationale=("Avoiding a previously blocked direction" if self._blocked_action_hint else
                                 "Choose an untried route/action from scene, memory and human demonstrations"))
        self.explore_before_state = scene.state_id
        self.explore_before_features = scene.features
        self.explore_before_frame = frame
        self.explore_before_policy_features = policy_features
        self.explore_before_new = scene.is_new
        self.explore_before_game_state = self._poll_external_game_state(now, force=True)
        self.explore_action = action
        self.autonomous_decisions += 1
        self.last_action_unix = time.time()
        if action in {"left", "right", "up", "down"}:
            self.loop_stage = "send_overworld_direction"
            self._set_keys(self._action_keys(action, "overworld"))
            self.last_successful_action_unix = time.time()
            self.explore_phase = "holding"
            self.explore_until = now + 0.075
        elif action in {"interact", "confirm", "jump", "attack", "inventory", "use_item"}:
            self.loop_stage = "send_overworld_button"
            self._tap_key(screen, self._control_key(action), 0.040)
            self.last_successful_action_unix = time.time()
            self.explore_phase = "resolving"
            self.explore_until = time.monotonic() + 0.035
        elif action == "menu":
            self.loop_stage = "send_overworld_menu"
            self._tap_key(screen, self._control_key("menu"), 0.040)
            self.last_successful_action_unix = time.time()
            self.explore_phase = "resolving"
            self.explore_until = time.monotonic() + 0.035
        else:
            self.loop_stage = "send_overworld_fallback"
            self._tap_key(screen, self._control_key("cancel"), 0.040)
            self.last_successful_action_unix = time.time()
            self.explore_phase = "resolving"
            self.explore_until = time.monotonic() + 0.06
        self.last_action = action
        self._log(None, action, f"exploration_action scene={scene.state_id} new={scene.is_new}")

    def _human_keys(self) -> tuple[str, ...]:
        configured = set(str(value).lower() for value in self.runtime.game_profile.get("controls", {}).values())
        # Probe common keyboard keys while F7 is active so custom profiles can learn an alternative layout.
        common = set(VK) - {"f7", "f8"}
        return tuple(sorted((configured | common) - {"f7", "f8"}))

    def _human_action_names(self, keys: set[str], mode: str, soul_mode: str) -> list[str]:
        actions: list[str] = []
        controls = self.runtime.game_profile.get("controls", {})
        physical = {str(controls.get(action, action)).lower(): action for action in ("left", "right", "up", "down")}
        directions = [physical[key] for key in keys if key in physical]
        if mode == "overworld":
            actions.extend(directions)
            if str(controls.get("interact", "z")).lower() in keys or (GAME_ID == "undertale" and "z" in keys):
                actions.append("interact")
            if str(controls.get("confirm", "enter")).lower() in keys:
                actions.append("interact" if GAME_ID == "undertale" else "confirm")
            if str(controls.get("cancel", "x")).lower() in keys or (GAME_ID == "undertale" and keys.intersection({"x", "shift", "escape"})):
                actions.append("cancel")
            if str(controls.get("menu", "c")).lower() in keys or (GAME_ID == "undertale" and "ctrl" in keys):
                actions.append("menu")
            known = set(self.runtime.game_profile.get("configured_controls", [])) | set(self.runtime.game_profile.get("auto_detected_controls", []))
            for extra in ("jump", "attack", "inventory", "use_item"):
                if extra in known and str(controls.get(extra, "")).lower() in keys:
                    actions.append(extra)
        else:
            if soul_mode == "blue":
                if "up" in directions:
                    if "left" in directions:
                        actions.append("left_jump")
                    elif "right" in directions:
                        actions.append("right_jump")
                    else:
                        actions.append("jump")
                else:
                    actions.extend(key for key in directions if key in {"left", "right"})
            else:
                diagonal_map = {
                    frozenset({"up", "left"}): "up_left",
                    frozenset({"up", "right"}): "up_right",
                    frozenset({"down", "left"}): "down_left",
                    frozenset({"down", "right"}): "down_right",
                }
                direction_set = frozenset(directions)
                if direction_set in diagonal_map:
                    actions.append(diagonal_map[direction_set])
                else:
                    actions.extend(directions)
            if (str(controls.get("interact", "z")).lower() in keys or
                    str(controls.get("confirm", "enter")).lower() in keys or "z" in keys or "enter" in keys):
                actions.append("confirm")
            if str(controls.get("cancel", "x")).lower() in keys or (GAME_ID == "undertale" and keys.intersection({"x", "shift", "escape"})):
                actions.append("cancel")
            if str(controls.get("menu", "c")).lower() in keys or (GAME_ID == "undertale" and "ctrl" in keys):
                actions.append("menu")
        return list(dict.fromkeys(actions))

    def _discard_human_demo(self) -> None:
        self._human_active_keys.clear()
        self._human_before_frame = None
        self._human_before_scene = None
        self._human_before_policy_features = None
        self._human_started_at = 0.0

    def _record_human_input(self, screen: WindowsScreen, hwnd: int, now: float) -> None:
        """Record player key timing, scene context, key combinations, and imitation examples."""
        current = {name for name in self._human_keys() if screen.key_down(name)}
        previous = set(self._human_active_keys)
        if current == previous:
            return

        after_frame: Frame | None = None
        after_obs: Observation | None = None
        after_scene: SceneMatch | None = None
        if previous and self._human_before_frame and self._human_before_scene:
            try:
                after_frame = screen.capture(hwnd)
                after_obs = analyze_profiled_frame(after_frame)
                after_scene = self.memory.identify(after_frame)
                change = frame_change(self._human_before_frame, after_frame)
                duration = max(0.0, now - self._human_started_at)
                actions = self._human_action_names(previous, self._human_mode, self._human_soul_mode)
                for action in actions:
                    self.memory.record_demonstration(
                        self._human_mode, self._human_before_scene.state_id, action,
                        after_scene.state_id, change, duration,
                        {"keys": sorted(previous),
                         "scene_changed": after_scene.state_id != self._human_before_scene.state_id,
                         "elapsed_since_agent_start_s": round(time.time() - self._human_session_started, 4),
                         "feedback": "human_preference_not_verified_success"},
                        policy_features=self._human_before_policy_features)
                # Persist individual key-up edges with the resulting screen context.
                for key in sorted(previous - current):
                    self.memory.record_human_key_event(
                        self._human_mode, after_scene.state_id, key, "up", current,
                        after_scene.features,
                        {"duration_s": round(duration, 4), "elapsed_since_agent_start_s": round(time.time() - self._human_session_started, 4)})
                if actions:
                    # Keep the temporal policy context aligned with the human's most
                    # recent chosen action for the next demonstrated state.
                    self.last_action = actions[-1]
                    self._last_policy_features = self._human_before_policy_features
                    self._last_mode = self._human_mode
                    self._log(None, actions[0], "human_demonstration actions=" + ",".join(actions) +
                              f" duration={duration:.3f} change={change:.3f}")
                    self._queue_policy_training()
                self._active_scene = after_scene
                self._next_scene_refresh = now + 0.18
            except Exception as exc:
                self.runtime.last_error = f"human demo capture failed: {type(exc).__name__}: {exc}"

        # End the previous chord cleanly, then start a fresh timed chord for newly-held keys.
        self._human_active_keys.clear()
        self._human_before_frame = None
        self._human_before_scene = None
        self._human_before_policy_features = None
        self._human_started_at = 0.0
        if not current:
            return
        try:
            before_frame = after_frame if after_frame is not None and current - previous else screen.capture(hwnd)
            before_obs = after_obs if after_obs is not None and current - previous else analyze_profiled_frame(before_frame)
            before_scene = after_scene if after_scene is not None and current - previous else self.memory.identify(before_frame)
            mode = "battle" if before_obs.battle_visible else "overworld"
            soul_mode = str((before_obs.soul or {}).get("mode", "red"))
            policy_features = self._policy_features(before_frame, mode, before_obs, before_scene)
            for key in sorted(current - previous):
                self.memory.record_human_key_event(
                    mode, before_scene.state_id, key, "down", current, before_scene.features,
                    {"elapsed_since_agent_start_s": round(time.time() - self._human_session_started, 4)})
            self._human_active_keys = set(current)
            self._human_before_frame = before_frame
            self._human_before_scene = before_scene
            self._human_before_policy_features = policy_features
            self._human_mode = mode
            self._human_soul_mode = soul_mode
            self._human_started_at = now
        except Exception as exc:
            self.runtime.last_error = f"human demo start failed: {type(exc).__name__}: {exc}"
            self._discard_human_demo()

    def _battle_danger(self, frame: Frame, obs: Observation) -> float:
        if not obs.soul:
            return 1.0
        return self._danger(frame, int(obs.soul["x"]), int(obs.soul["y"]), max(5, int(min(frame.width, frame.height) * 0.04)))

    def _record_battle_feedback(self, frame: Frame, obs: Observation, now: float) -> None:
        pending = self.battle_pending
        if not pending or now < pending["deadline"]:
            return
        scene = self.memory.identify(frame)
        current_danger = self._battle_danger(frame, obs)
        prior_danger = float(pending["danger"])
        delta = prior_danger - current_danger
        change = visual_change(pending["features"], scene.features)
        after_game_state = self._poll_external_game_state(now, force=True)
        explicit_outcome = _external_outcome(pending.get("game_state"), after_game_state)
        assessment = evaluate_transition(
            mode="battle", action=str(pending["action"]), from_state=str(pending["state"]),
            to_state=scene.state_id, visual_delta=change, new_scene=scene.is_new,
            danger_before=prior_danger, danger_after=current_danger,
            hazards_before=int(pending["hazards"]), hazards_after=int(obs.hazards),
            explicit_outcome=explicit_outcome)
        self._last_reward_signal = assessment.reward
        self._last_danger_delta = delta
        self.memory.record("battle", str(pending["state"]), str(pending["action"]), scene.state_id,
                           assessment.reward, change,
                           {"feedback_category": assessment.category,
                            "feedback_explanation": assessment.explanation,
                            "before_local_danger": prior_danger, "after_local_danger": current_danger,
                            "danger_delta": delta, "before_hazards": int(pending["hazards"]),
                            "after_hazards": int(obs.hazards), "explicit_game_outcome": explicit_outcome,
                            "feedback_quality": ("fresh_game_state_feed" if explicit_outcome else "visual_risk_proxy_not_hp_or_death")},
                           policy_features=pending.get("policy_features"), learn=assessment.learn)
        if assessment.learn and pending.get("policy_features") is not None:
            self._queue_policy_training()
        self._active_scene = scene
        self._next_scene_refresh = now + 0.08
        self._reflect("battle", obs, scene, str(pending["action"]), now,
                      rationale=assessment.explanation)
        self.battle_pending = None

    def _apply_hotkey(self, command: str) -> None:
        """Apply an explicit mode command: F7 pauses, F8 enables autonomous control."""
        if command not in {"f7", "f8"}:
            return
        target_armed = command == "f8"
        self.last_hotkey = command
        self.runtime.write_diagnostic("hotkey_command_applied", key=command, armed=target_armed,
                                      hotkeys_registered=sorted(self.hotkey_registered_names))
        if target_armed != self.armed:
            self.armed = target_armed
            self._release_all()
            if target_armed:
                self._discard_human_demo()
            state_text = "AUTONOMOUS" if target_armed else "PAUSED / LEARNING FROM PLAYER"
            print(f"[GTC Undertale] {command.upper()} received -> {state_text}", flush=True)
            self._log(None, "none", "autonomy_enabled_by_f8" if target_armed else "manual_learning_enabled_by_f7")
        else:
            self._log(None, "none", "f8_autonomy_already_enabled" if target_armed else "f7_manual_learning_already_enabled")

    def _run(self) -> None:
        try:
            self.loop_stage = "initialize_windows_api"
            screen = self.runtime._windows()
            self.loop_stage = "loop_started"
            self.runtime.write_diagnostic("agent_loop_started", windows_api="initialized")
            while not self.stop_event.is_set():
                loop_started = time.perf_counter()
                self.loop_iterations += 1
                self.last_loop_unix = time.time()
                try:
                    # F7 means manual control + demonstration recording; F8 means autonomous GTC.
                    # RegisterHotKey is preferred; key-state polling is only a fallback.
                    for hotkey in ("f7", "f8"):
                        if hotkey not in self.hotkey_registered_names:
                            down = screen.key_down(hotkey)
                            if down and not self._hotkey_was_down[hotkey]:
                                self.hotkey_events_received += 1
                                self.runtime.write_diagnostic("hotkey_received", key=hotkey, source="GetAsyncKeyState")
                                self.hotkey_commands.put(hotkey)
                            self._hotkey_was_down[hotkey] = down
                    while not self.hotkey_commands.empty():
                        try:
                            command = self.hotkey_commands.get_nowait()
                        except queue.Empty:
                            break
                        self._apply_hotkey(command)
                    self.loop_stage = "find_game_window"
                    hwnd = screen.find_window()
                    if not hwnd:
                        self._discard_exploration_step()
                        self._discard_human_demo()
                        self.battle_pending = None
                        self.runtime.window = None
                        time.sleep(0.25)
                        continue
                    self.runtime.window = hwnd
                    self.loop_stage = "check_foreground_window"
                    if not screen.is_foreground(hwnd):
                        self.foreground_pause_count += 1
                        self._discard_exploration_step()
                        self._discard_human_demo()
                        self.battle_pending = None
                        time.sleep(0.10)
                        continue
                    if not self.armed:
                        self._discard_exploration_step()
                        self.battle_pending = None
                        now = time.monotonic()
                        if now - self._last_observer_sample_at >= PASSIVE_OBSERVATION_INTERVAL:
                            self.loop_stage = "passive_capture_frame"
                            frame = screen.capture(hwnd)
                            self.last_frame_unix = time.time()
                            self.loop_stage = "passive_analyze_frame"
                            obs = analyze_profiled_frame(frame)
                            self.last_successful_frame_unix = time.time()
                            self.consecutive_loop_errors = 0
                            self.frames_seen += 1
                            self._permanent_observe(frame, obs, now, source="manual_passive_observation")
                        self._record_human_input(screen, hwnd, now)
                        time.sleep(HUMAN_INPUT_SAMPLE_INTERVAL)
                        continue
                    # Do not label the autonomous controller's injected keys as demos.
                    self._discard_human_demo()
                    self.loop_stage = "capture_frame"
                    frame = screen.capture(hwnd)
                    self.last_frame_unix = time.time()
                    self.loop_stage = "analyze_frame"
                    obs = analyze_profiled_frame(frame)
                    self.last_successful_frame_unix = time.time()
                    self.consecutive_loop_errors = 0
                    now = time.monotonic()
                    if now - self._last_observer_sample_at >= PASSIVE_OBSERVATION_INTERVAL:
                        self._permanent_observe(frame, obs, now, source="autonomous_observation")
                    if obs.battle_visible:
                        self._last_battle_visible_at = now
                    # Briefly latch a recognized battle across flickering/missing soul
                    # detections. After the latch expires, return to normal exploration;
                    # do not get permanently stuck in a one-boss "post battle" mode.
                    battle_active = obs.battle_visible or (
                        self.seen_soul_once and now - self._last_battle_visible_at <= 0.20
                    )
                    current_mode = "battle" if battle_active else "overworld"
                    if current_mode != self._last_mode:
                        # Release only on an actual state-machine transition. An
                        # unconditional release every overworld frame cancels the
                        # 75 ms directional pulse before the game can process it.
                        self._release_all()
                        self._active_scene = None
                        self._next_scene_refresh = 0.0
                        self.battle_pending = None
                        self._blocked_action_hint = None
                        self._no_progress_streak = 0
                        self._last_mode = current_mode
                    self.last_observation = obs.to_dict()
                    self.frames_seen += 1
                    if obs.battle_visible:
                        if self.explore_phase != "idle":
                            self._discard_exploration_step()
                        self.battle_frames += 1
                        self.seen_soul_once = True

                    if not battle_active:
                        self.loop_stage = "choose_overworld_action"
                        # Whole-game behaviour: explore in any non-battle scene, including
                        # rooms after an encounter. _exploration_tick owns key-hold timing;
                        # do not cancel its movement pulse at the start of every frame.
                        self._exploration_tick(frame, screen, now, obs)
                        if self.explore_phase == "idle":
                            self._reflect("overworld", obs, self._active_scene, self.last_action, now,
                                          rationale="Inspect current scene and select the next exploration objective")
                            self._log(obs, "none")
                    else:
                        self.loop_stage = "choose_battle_action"
                        if not obs.battle_visible:
                            # On one missing frame, release keys to avoid holding a stale move.
                            self._release_all()
                            time.sleep(AGENT_LOOP_SLEEP)
                            continue
                        scene = self._scene(frame, now, force=(self._active_scene is None))
                        policy_features = self._policy_features(frame, "battle", obs, scene)
                        # Resolve feedback for the previous move before creating the next one.
                        self._record_battle_feedback(frame, obs, now)
                        if self.battle_pending and now < self.battle_pending["deadline"]:
                            action = str(self.battle_pending["action"])
                        else:
                            scene = self._scene(frame, now, force=(self._active_scene is None))
                            policy_features = self._policy_features(frame, "battle", obs, scene)
                            self._last_policy_features = policy_features
                            action = self.choose_action(frame, obs, policy_features=policy_features)
                            self.autonomous_decisions += 1
                            self.last_action_unix = time.time()
                            local_danger = self._battle_danger(frame, obs)
                            self.battle_pending = {
                                "state": scene.state_id, "action": action,
                                "features": scene.features, "policy_features": policy_features,
                                "danger": local_danger, "hazards": obs.hazards,
                                "deadline": now + BATTLE_DECISION_INTERVAL,
                                "game_state": self._poll_external_game_state(now, force=True),
                            }
                            self._reflect("battle", obs, scene, action, now,
                                          rationale="Choose the lowest-risk short movement using visible hazards, history and policy scores")
                        self.loop_stage = "send_battle_input"
                        self._set_keys(self._action_keys(action, obs.soul.get("mode", "red") if obs.soul else "red"))
                        self.last_successful_action_unix = time.time()
                        self.last_action = action
                        self._log(obs, action)
                    # Keep rolling timing diagnostics for real hardware; this makes it clear
                    # whether screen analysis, not the configured interval, is the bottleneck.
                    self._loop_time_samples.append((time.perf_counter() - loop_started) * 1000.0)
                    self.loop_stage = "waiting_next_loop"
                    time.sleep(AGENT_LOOP_SLEEP)
                except Exception as exc:
                    self.loop_errors += 1
                    self.consecutive_loop_errors += 1
                    self.last_error_stage = self.loop_stage
                    self.last_exception_type = type(exc).__name__
                    self.last_exception_unix = time.time()
                    self.last_exception_traceback = traceback.format_exc()[-12000:]
                    self.runtime.last_error = f"{type(exc).__name__} at {self.loop_stage}: {exc}"
                    signature = f"{self.loop_stage}|{type(exc).__name__}|{exc}"
                    if signature != self._last_diagnostic_signature or time.monotonic() - self._last_diagnostic_log_at >= 5.0:
                        self.runtime.write_diagnostic("agent_loop_exception", stage=self.loop_stage,
                                                      error_type=type(exc).__name__, error=str(exc)[:1000],
                                                      traceback=self.last_exception_traceback,
                                                      consecutive_errors=self.consecutive_loop_errors)
                        self._last_diagnostic_signature = signature
                        self._last_diagnostic_log_at = time.monotonic()
                    self.loop_stage = "recover_after_exception"
                    self._release_all()
                    self._log(None, "none", "error")
                    time.sleep(0.25)
        except Exception as exc:
            # A failure while constructing the Windows API wrapper used to terminate
            # this daemon thread before the inner loop's exception handler existed.
            self.loop_errors += 1
            self.consecutive_loop_errors += 1
            self.last_error_stage = self.loop_stage
            self.last_exception_type = type(exc).__name__
            self.last_exception_unix = time.time()
            self.last_exception_traceback = traceback.format_exc()[-12000:]
            self.runtime.last_error = f"{type(exc).__name__} at {self.loop_stage}: {exc}"
            self.runtime.write_diagnostic("agent_fatal_startup_exception", stage=self.loop_stage,
                                          error_type=type(exc).__name__, error=str(exc)[:1000],
                                          traceback=self.last_exception_traceback)
            print(f"[GTC Undertale] Agent stopped during {self.loop_stage}: {type(exc).__name__}: {exc}", flush=True)
        finally:
            self.loop_stage = "stopping"
            self._release_all()


RUNTIME = UndertaleRuntime()
