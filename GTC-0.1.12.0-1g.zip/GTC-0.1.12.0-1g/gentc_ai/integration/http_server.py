"""Local bridge for the merged GenTC AI core and whole-game Undertale adapter.

This is a development-only loopback service. It does not load an LLM and never
executes arbitrary code. Godot remains responsible for validating and executing
commands returned by the decision engine.
"""
from __future__ import annotations

import json
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
import traceback

from gentc_ai.version import VERSION, BUILD_ID
from gentc_ai.core.decision_engine import DecisionEngine
from gentc_ai.core.intent_parser import IntentParser
from gentc_ai.core.world_state import WorldStateAnalyzer
from gentc_ai.integration.undertale_agent import RUNTIME as UNDERTALE_RUNTIME, ADAPTER_VERSION

PROJECT_ROOT = Path(__file__).resolve().parents[2]
PROFILE_PATH = PROJECT_ROOT / "data" / "characters" / "anna.json"
HOST = "127.0.0.1"
PORT = 8765
MAX_BODY_BYTES = 1_000_000


def load_profile() -> dict[str, Any]:
    profile = json.loads(PROFILE_PATH.read_text(encoding="utf-8"))
    if not isinstance(profile, dict) or not profile.get("character_id"):
        raise RuntimeError("Некорректный профиль персонажа.")
    return profile


def process_decision(payload: dict[str, Any]) -> dict[str, Any]:
    """Pure request handler shared by the HTTP endpoint and tests."""
    if not isinstance(payload, dict):
        raise ValueError("Тело запроса должно быть JSON-объектом.")
    text = payload.get("text")
    world = payload.get("world")
    if not isinstance(text, str) or not text.strip():
        raise ValueError("Поле 'text' должно содержать непустую строку.")
    if len(text) > 2000:
        raise ValueError("Слишком длинное сообщение (максимум 2000 символов).")
    if not isinstance(world, dict):
        raise ValueError("Поле 'world' должно содержать снимок состояния игры.")

    game_id = str(payload.get("game_id") or world.get("game_id") or "gtc_playground")
    if game_id != "gtc_playground":
        raise ValueError("Этот демонстрационный сервер принимает только game_id='gtc_playground'.")

    # The tiny playground submits the legacy demo-shaped snapshot. The analyzer
    # checks only whether its key world fields are structurally sound.
    world_report = WorldStateAnalyzer().analyze(world)
    if not world_report.get("valid"):
        return {
            "ok": False,
            "error": "invalid_world_snapshot",
            "world_analysis": world_report,
        }

    profile = load_profile()
    intent = IntentParser().parse(text)
    decision = DecisionEngine().decide(intent, world, profile)

    # This prototype intentionally does not call a real LLM. It returns a
    # grounded speech hint for the future LLM adapter and a declarative plan.
    reply_hint = decision.get("speech_brief", "Решение подготовлено.")
    if intent.get("intent") == "general_dialogue":
        reply_hint = (
            "Текст получен. Свободная генерация ответа LLM пока не подключена; "
            "GTC не должен придумывать факты об игровом мире."
        )
    if intent.get("intent") == "give_item":
        reply_hint = "Команда передачи получена. Демонстрационный проект может добавить топор в инвентарь Анны."

    return {
        "ok": True,
        "protocol_version": "0.1",
        "game_id": game_id,
        "character_id": profile["character_id"],
        "intent": intent,
        "decision": decision,
        "world_analysis": world_report,
        "reply_hint": reply_hint,
        "llm_connected": False,
        "execution_note": "План ещё не выполнен. Его проверяет и исполняет Godot Playground.",
    }


class GTCRequestHandler(BaseHTTPRequestHandler):
    server_version = f"GenTC-AI-Multi-Bridge/{BUILD_ID}"

    def _write_json(self, status: int, body: dict[str, Any]) -> None:
        raw = json.dumps(body, ensure_ascii=False, allow_nan=False, default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def _read_payload(self) -> dict[str, Any]:
        try:
            content_length = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise ValueError("invalid_content_length") from exc
        if content_length <= 0 or content_length > MAX_BODY_BYTES:
            raise OverflowError("body_size_out_of_range")
        try:
            payload = json.loads(self.rfile.read(content_length).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise LookupError("invalid_json") from exc
        if not isinstance(payload, dict):
            raise ValueError("payload_must_be_object")
        return payload

    def do_GET(self) -> None:  # noqa: N802 - BaseHTTPRequestHandler API
        if self.path == "/health":
            self._write_json(200, {
                "ok": True,
                "name": "GenTC AI",
                "version": VERSION,
                "build_id": BUILD_ID,
                "service": "gtc_multi_adapter_bridge",
                "llm_connected": False,
                "undertale_adapter_version": ADAPTER_VERSION,
                "bind": HOST,
            })
            return
        if self.path in {"/undertale/health", "/undertale/status", "/game/status", "/game/health"}:
            self._write_json(200, UNDERTALE_RUNTIME.status())
            return
        if self.path in {"/undertale/observe", "/game/observe"}:
            try:
                self._write_json(200, UNDERTALE_RUNTIME.observe())
            except Exception as exc:
                self._write_json(400, {"ok": False, "error": f"{type(exc).__name__}: {str(exc)[:180]}"})
            return
        if self.path in {"/undertale/learning", "/game/learning"}:
            self._write_json(200, UNDERTALE_RUNTIME.learning_report())
            return
        if self.path in {"/undertale/introspection", "/game/introspection"}:
            self._write_json(200, UNDERTALE_RUNTIME.introspection_report())
            return
        self._write_json(404, {"ok": False, "error": "not_found"})

    def do_POST(self) -> None:  # noqa: N802 - BaseHTTPRequestHandler API
        allowed = {"/decide", "/undertale/launch", "/undertale/agent/start",
                   "/undertale/agent/stop", "/undertale/agent/control", "/undertale/feedback",
                   "/game/launch", "/game/agent/start", "/game/agent/stop", "/game/agent/control", "/game/feedback"}
        if self.path not in allowed:
            self._write_json(404, {"ok": False, "error": "not_found"})
            return
        try:
            payload = self._read_payload()
        except OverflowError:
            self._write_json(413, {"ok": False, "error": "body_size_out_of_range"})
            return
        except LookupError:
            self._write_json(400, {"ok": False, "error": "invalid_json"})
            return
        except ValueError as exc:
            self._write_json(400, {"ok": False, "error": str(exc)})
            return
        try:
            if self.path == "/decide":
                result = process_decision(payload)
            elif self.path in {"/undertale/launch", "/game/launch"}:
                result = UNDERTALE_RUNTIME.launch(payload.get("exe_path"))
            elif self.path in {"/undertale/agent/start", "/game/agent/start"}:
                result = UNDERTALE_RUNTIME.start_agent(bool(payload.get("armed", False)))
            elif self.path in {"/undertale/agent/stop", "/game/agent/stop"}:
                result = UNDERTALE_RUNTIME.stop_agent()
            elif self.path in {"/undertale/agent/control", "/game/agent/control"}:
                result = UNDERTALE_RUNTIME.set_agent_armed(payload.get("armed"))
            else:
                result = UNDERTALE_RUNTIME.record_feedback(payload)
        except ValueError as exc:
            self._write_json(400, {"ok": False, "error": str(exc)[:200]})
            return
        except Exception as exc:
            print(f"[GTC HTTP] Internal error on {self.path}: {type(exc).__name__}", file=sys.stderr)
            traceback.print_exc(file=sys.stderr)
            self._write_json(500, {"ok": False, "error": "internal_error"})
            return
        self._write_json(200 if result.get("ok") else 422, result)

    def log_message(self, fmt: str, *args: object) -> None:
        print(f"[GTC HTTP] {self.address_string()} - {fmt % args}")

def main() -> int:
    try:
        server = ThreadingHTTPServer((HOST, PORT), GTCRequestHandler)
    except OSError as exc:
        print(f"Не удалось открыть {HOST}:{PORT}: {exc}", file=sys.stderr)
        print("Проверьте, не занят ли порт 8765 другим приложением.", file=sys.stderr)
        return 2
    print("=" * 60)
    print(f"GenTC AI {VERSION} ({BUILD_ID}) — permanent game analysis bridge")
    print(f"Адрес: http://{HOST}:{PORT}")
    print("GET /health | POST /decide | Game pilot: /undertale/status, /undertale/observe, /undertale/learning, /undertale/feedback")
    print("Core bridge remains available; Game pilot continuously observes visible frames; static file hints are scanned asynchronously; no process memory or save files are read.")
    print("Сервис слушает только localhost, не доступен из локальной сети.")
    print("Pilot is profile-driven for ordinary movement/interaction, with Undertale-specific battle perception only for the Undertale profile. Static scans never modify game files. Stop with Ctrl+C.")
    print("=" * 60)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nGTC HTTP-мост остановлен.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
