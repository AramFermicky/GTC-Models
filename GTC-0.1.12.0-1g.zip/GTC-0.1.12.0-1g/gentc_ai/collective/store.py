"""SQLite outbox for an explicitly opted-in future sync; never performs network I/O."""
from __future__ import annotations
import json, sqlite3, threading, time
from pathlib import Path
from .messages import CollectiveExperience
from .validator import validate_collective_example

class LocalKnowledgeOutbox:
    def __init__(self, path: str | Path, *, consent: bool = False) -> None:
        self.path = Path(path).expanduser(); self.path.parent.mkdir(parents=True, exist_ok=True)
        self.consent = bool(consent); self._lock = threading.RLock()
        self.db = sqlite3.connect(self.path, check_same_thread=False)
        self.db.execute("CREATE TABLE IF NOT EXISTS outbox (fingerprint TEXT PRIMARY KEY, payload TEXT NOT NULL, created_at REAL NOT NULL, sent INTEGER NOT NULL DEFAULT 0)")
        self.db.commit()
    def enqueue(self, item: CollectiveExperience) -> bool:
        valid, reason = validate_collective_example(item)
        if not valid: raise ValueError(reason)
        if not self.consent: raise PermissionError("collective sharing is disabled until explicit consent is enabled")
        with self._lock:
            cur = self.db.execute("INSERT OR IGNORE INTO outbox(fingerprint,payload,created_at,sent) VALUES(?,?,?,0)",
                                  (item.fingerprint, json.dumps(item.to_dict(), sort_keys=True), time.time()))
            self.db.commit(); return cur.rowcount == 1
    def pending(self, limit: int = 100) -> list[dict[str, object]]:
        if limit < 1 or limit > 1000: raise ValueError("limit must be in [1,1000]")
        with self._lock:
            rows = self.db.execute("SELECT fingerprint,payload,created_at FROM outbox WHERE sent=0 ORDER BY created_at LIMIT ?", (limit,)).fetchall()
        return [{"fingerprint": row[0], "payload": json.loads(row[1]), "created_at": row[2]} for row in rows]
    def close(self) -> None:
        with self._lock: self.db.close()
