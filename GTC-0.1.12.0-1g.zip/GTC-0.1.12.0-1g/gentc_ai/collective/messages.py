"""Shareable experience summaries deliberately exclude screenshots and save data."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any
import hashlib, json

@dataclass(frozen=True)
class CollectiveExperience:
    game_family: str
    state_signature: str
    action: str
    outcome: str
    reward: float
    confidence: float
    schema_version: int = 1
    @property
    def fingerprint(self) -> str:
        raw = json.dumps(asdict(self), sort_keys=True, ensure_ascii=True, allow_nan=False)
        return hashlib.sha256(raw.encode("ascii")).hexdigest()
    def to_dict(self) -> dict[str, Any]:
        return {**asdict(self), "fingerprint": self.fingerprint}
