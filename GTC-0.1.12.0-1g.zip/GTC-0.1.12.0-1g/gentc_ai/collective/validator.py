"""Strict allowlist validator for compact knowledge-sharing examples."""
from __future__ import annotations
import math
from .messages import CollectiveExperience

_ALLOWED_OUTCOMES = {"neutral", "progress", "dodge", "blocked", "missed_attack", "damage", "item_misuse", "death", "goal_completed"}

def validate_collective_example(item: CollectiveExperience) -> tuple[bool, str]:
    if not isinstance(item, CollectiveExperience): return False, "wrong_type"
    if item.schema_version != 1: return False, "unsupported_schema_version"
    if not item.game_family or len(item.game_family) > 80: return False, "invalid_game_family"
    if not item.state_signature or len(item.state_signature) > 128: return False, "invalid_state_signature"
    if not item.action or len(item.action) > 80: return False, "invalid_action"
    if item.outcome not in _ALLOWED_OUTCOMES: return False, "invalid_outcome"
    if not math.isfinite(item.reward) or not -1 <= item.reward <= 1: return False, "reward_out_of_range"
    if not math.isfinite(item.confidence) or not 0 <= item.confidence <= 1: return False, "confidence_out_of_range"
    if item.outcome == "neutral" and item.reward != 0: return False, "neutral_outcome_must_be_unrewarded"
    # The schema itself contains no arbitrary details field, personal data, file path, or image payload.
    return True, "valid"
