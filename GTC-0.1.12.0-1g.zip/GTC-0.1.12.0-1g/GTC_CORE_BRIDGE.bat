@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not defined GTC_MODEL_ROOT set "GTC_MODEL_ROOT=%~dp0"
call :find_python
if errorlevel 1 (
  echo [GTC] Python 3.11 or newer was not found.
  pause
  exit /b 2
)
echo [GTC] Core bridge using %PY_EXE%
"%PY_EXE%" -u -m gentc_ai.integration.girl_server
echo [GTC] Core bridge stopped.
pause
exit /b 0

:find_python
set "PY_EXE="
if defined GTC_PYTHON_EXE if exist "%GTC_PYTHON_EXE%" set "PY_EXE=%GTC_PYTHON_EXE%"
if not defined PY_EXE if exist "%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe" set "PY_EXE=%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe"
if not defined PY_EXE if exist "%LOCALAPPDATA%\Python\bin\python.exe" set "PY_EXE=%LOCALAPPDATA%\Python\bin\python.exe"
if not defined PY_EXE for /f "delims=" %%P in ('py -V:3.14 -c "import sys;print(sys.executable)" 2^>nul') do if not defined PY_EXE set "PY_EXE=%%P"
if not defined PY_EXE for /f "delims=" %%P in ('py -3.14 -c "import sys;print(sys.executable)" 2^>nul') do if not defined PY_EXE set "PY_EXE=%%P"
if not defined PY_EXE for /f "delims=" %%P in ('py -3 -c "import sys;print(sys.executable)" 2^>nul') do if not defined PY_EXE set "PY_EXE=%%P"
if not defined PY_EXE for /f "delims=" %%P in ('where python 2^>nul') do if not defined PY_EXE set "PY_EXE=%%P"
if not defined PY_EXE exit /b 1
"%PY_EXE%" -c "import sys;raise SystemExit(0 if sys.version_info >= (3,11) else 1)" >nul 2>&1
if errorlevel 1 (
  set "PY_EXE="
  exit /b 1
)
exit /b 0
