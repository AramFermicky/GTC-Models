GTC 0.1.9.3 / LOGS

GTC_START_BRIDGE.bat запускает мост и пишет в gtc_runtime.log / events.jsonl: старты, выбор действий, подтверждённые результаты, награды, Q-update и обучение сети. GTC_LOG.bat показывает gtc_runtime.log в реальном времени. GTC_TEST.bat сохраняет вывод проверки в test_latest.log.
