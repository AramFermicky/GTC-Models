Журнал gtc_diagnostics.jsonl будет создан после первого запуска START_GTC.bat.
