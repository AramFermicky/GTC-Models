@echo off
setlocal EnableExtensions
cd /d "%~dp0"
chcp 65001 >nul
echo ========================================================
echo GenTC AI - Deep Diagnostics
echo ========================================================
echo.
call :find_python
if errorlevel 1 (
  echo [GTC] Python 3.11 or newer was not found.
  echo Set GTC_PYTHON_EXE to your Python executable and retry.
  pause
  exit /b 2
)
echo [GTC] Python: %PY_EXE%
echo [GTC] This test reads local status and logs. It does not copy game saves or screenshots.
echo [GTC] A LEFT-arrow input test is optional and requires typing TEST explicitly.
echo.
"%PY_EXE%" -u "%~dp0scripts\gtc_diagnostics.py"
set "RESULT=%ERRORLEVEL%"
echo.
if not "%RESULT%"=="0" echo [GTC] Diagnostic tool exited with code %RESULT%.
echo Send the generated ERRORS_LOG_TESTING_REPORT_*.zip file in ChatGPT.
pause
exit /b %RESULT%

:find_python
set "PY_EXE="
if defined GTC_PYTHON_EXE if exist "%GTC_PYTHON_EXE%" set "PY_EXE=%GTC_PYTHON_EXE%"
if not defined PY_EXE if exist "%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe" set "PY_EXE=%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe"
if not defined PY_EXE if exist "%LOCALAPPDATA%\Python\bin\python.exe" set "PY_EXE=%LOCALAPPDATA%\Python\bin\python.exe"
if not defined PY_EXE for /f "delims=" %%P in ('py -V:3.14 -c "import sys;print(sys.executable)" 2^>nul') do if not defined PY_EXE set "PY_EXE=%%P"
if not defined PY_EXE for /f "delims=" %%P in ('py -3.14 -c "import sys;print(sys.executable)" 2^>nul') do if not defined PY_EXE set "PY_EXE=%%P"
if not defined PY_EXE for /f "delims=" %%P in ('py -3 -c "import sys;print(sys.executable)" 2^>nul') do if not defined PY_EXE set "PY_EXE=%%P"
if not defined PY_EXE for /f "delims=" %%P in ('where python 2^>nul') do if not defined PY_EXE set "PY_EXE=%%P"
if not defined PY_EXE exit /b 1
"%PY_EXE%" -c "import sys;raise SystemExit(0 if sys.version_info >= (3,11) else 1)" >nul 2>&1
if errorlevel 1 (
  set "PY_EXE="
  exit /b 1
)
exit /b 0
